//
//  PNGstream.java
//  planetGenesis
//
//  Created by David Burnett on Fri Jan 24 2003.
//  Copyright (c) 2003 Vargolsoft. All rights reserved.
//

package Utilities;
import java.io.*;
import java.util.zip.*;


public class PNGstream extends ByteArrayOutputStream {

    public PNGstream(int bufferSize) {
        super(bufferSize);
    }
    
    
    public void writeByteArrayToDataStream(DataOutputStream out) {

        try {
            out.write(buf, 0, size());
        } catch (IOException e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
        }

    }

    public void updateCRC32ForByteArray(CRC32 crc) {

        crc.update(buf,0 , size());
    }

}
