/*
 Copyright (c) 2002, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
		  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
		  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

package Utilities;

/*
 * Grid.java
 *
 * Created on 05 March 2002, 22:34
 */


import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Locale;

import GUI.HashBasedPanel;
import GUI.Progress;

/**
*
 * @author  David
 */
public class Torus extends Landscape {
	
	double noiseRadius, scale, xMeshScale, zMeshScale, r, R;

	public Torus() {
		String[] titles = {"Torus Radius", "Tube Radius", "Mesh Width", "Mesh Height", "Scale"};
		String[] defaults = {"1.0", "0.1", "640", "480", "0.02"};
		String[] keys = {"R", "r","torus", "tube", "scale"};
		String[] tooltips = {"Torus Radius", "Tube Radius",
				             "Planet Circumference in Vertices.", 
				             "Tube Circumference in Vertices.",
				             "Scale"};
		
		panel = new HashBasedPanel(keys, titles, defaults, tooltips);		
	}

	public void setNoiseSpace(NoiseEngine engine) {
		noiseEngine = engine;
		Vertex size = engine.getNoiseSize();
		Vertex offset =  engine.getNoiseOffset();
		xNoise = size.getX();
		yNoise = size.getY();
		zNoise = size.getZ();

		xNoiseOffset = offset.getX();
		yNoiseOffset = offset.getY();
		zNoiseOffset = offset.getZ();
		
		noiseRadius = size.getX();
	}

	public void setWorldSpace(double x, double y, double z) {
		xMesh = (int)x;
		scale = y;
		yMesh = (int)z;
		zMesh = (int)(z);
		
		R = 1.0 / (2.0 * Math.PI);
		r = 0.2 / (2.0 * Math.PI);
	
		xMeshScale = 1.0 / xMesh;
		zMeshScale = 1.0 / zMesh;
		
	}	

	public void setWorldSpace() {
		xMesh = panel.getInt("torus");
		scale = panel.getDouble("scale");
		zMesh = panel.getInt("tube");
	
//		R = 1.0 / (2.0 * Math.PI);
//		r = 0.2 / (2.0 * Math.PI);;
		
		R = panel.getDouble("R");
		r = panel.getDouble("r");
		
		xMeshScale = 1.0 / xMesh;
		zMeshScale = 1.0 / zMesh;
	
	}	
	
	public void setProjection(int projection) {
		worldProjection = projection;

	}

	public Vertex getNoiseVertex(int index) {
		
		return noiseVertex(index);
		
	}
		
	public Vertex getWorldVertex(int index) {

		return vertex(index);
	}
	
	
	private Vertex vertex(int index) {
		
		/* map U,V to 0..2*M_PI
		 * freed into parameter equation for a torus
		 */

		double xPixel = index % xMesh;
		double zPixel = index * xMeshScale;	

		double u = (xPixel * xMeshScale) * 2.0 * Math.PI;
		double v = (zPixel * zMeshScale) * 2.0 * Math.PI;

//		if(xPixel == 0.0) {
//			System.err.println(""+ zPixel + "," + (R + (r * Math.cos(v))) + "," + Math.cos(v));
//		}
		
		double x = (R + (r * Math.cos(v))) * Math.cos(u);
		double y = (R + (r * Math.cos(v))) * Math.sin(u);
		double z = r * Math.sin(v);

		return new Vertex(x,
						  y,	
						  z);
	}
	
	public Vertex noiseVertex(int index) {
		Vertex tmp = vertex(index);
		tmp.multiply(xNoise * 0.5, yNoise * 0.5, zNoise * 0.5);
		tmp.add(xNoiseOffset, yNoiseOffset, zNoiseOffset);
		return tmp;
	}

	
	public Vertex displacedVertex(int index, double noise) {
		double xPixel = index % xMesh;
		double zPixel = index * xMeshScale;	

		double u = (xPixel * xMeshScale) * 2.0 * Math.PI;
		double v = (zPixel * zMeshScale) * 2.0 * Math.PI;
	
		noise += r;
		
		double x = (R + (noise * Math.cos(v))) * Math.cos(u);
		double y = (R + (noise * Math.cos(v))) * Math.sin(u);
		double z = noise * Math.sin(v);

		return new Vertex(x,
						  y,	
						  z);	}
	public Landscape getNewLandscape() {
		Torus newPlanet = new Torus();
		newPlanet.setWorldSpace(xMesh,scale,zMesh);
		return newPlanet;
	} 	
	
	public String getType() {
		return "Planet";
	}

	public int getVertexCount() {
		return 2 + ((xMesh - 2) * zMesh);
	}

	public void getTerrainAsPov(FileWriter out, Progress progress){

		int vertexCount = xMesh  * zMesh;
		double minNoise = Double.POSITIVE_INFINITY;
		double maxNoise = Double.NEGATIVE_INFINITY;
		double noise, factor;
		        
//		scale = 0.02;  // get this from the front end eventually.        
		try {
			DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(Locale.ENGLISH);
			df.setMaximumFractionDigits(5);
			df.setDecimalSeparatorAlwaysShown(false);


			out.write("#declare terrain = mesh2{\nvertex_vectors{" );
			out.write(vertexCount+",\n");

			Vertex point;

			// we have to scale the point to get reasonable results,
			// after all the noise could be 0.0001 or 10,000
			
			progress.setProgressText("Scaling noise.");
			progress.setMaxValue(vertexCount-1);
			int delta = vertexCount / 100;

			for(int i=0; i < vertexCount; i++) {
				noise = noiseEngine.getNoiseForVertex(getNoiseVertex(i));
				if(noise > maxNoise) {
					maxNoise = noise;
				}
				if(noise < minNoise) {
					minNoise = noise;
				}
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}
			
			if(maxNoise == minNoise) {
				factor = 1;
			} else {
				factor = (1/(maxNoise - minNoise)) * scale;
			}
			
			progress.setProgressText("Writing vertices.");
			progress.setProgressValue(0);
 
			
			Vertex vector;
 			for(int i=0; i < vertexCount; i++) {

 				vector = displacedVertex(i, ((noiseEngine.getNoiseForVertex(getNoiseVertex(i)) - minNoise) * factor));
				out.write("<"+df.format(vector.getX())+","+df.format(vector.getY())+","+df.format(vector.getZ()) + ">\n");
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}

			progress.setProgressText("Writing faces.");
			progress.setProgressValue(0);

			out.write("}\nface_indices{" );
			
			int quadsPerCircle = xMesh;
			int faces = 2 * quadsPerCircle * zMesh;
			out.write(faces+",\n");

			int index = 0;

			if(zMesh > 2) {
				for(int i = 1; i < zMesh ; i++) {
					for(int j = 1; j < quadsPerCircle; j++) {
						out.write("<"+index + ","+ (index + quadsPerCircle + 1)+","+(index  + 1) + ">");
						out.write("<"+index+","+(index + quadsPerCircle)+","+ (index + quadsPerCircle + 1) + ">\n");
						index++;
					}
					index++;
					out.write("<"+(index  - 1)+","+index+"," + (index - quadsPerCircle) + ">");
					out.write("<"+(index  - 1)+","+(index - 1 + quadsPerCircle)+","+index + ">\n");					
					progress.setProgressValue(index);
				}				
			}

//			index -= quadsPerCircle;
			int firstIndex = 0;
			// south pole
			for(int i = 1; i < quadsPerCircle; i++) {
				out.write("<"+index+","+(firstIndex  + 1)+","+ firstIndex + ">");
				out.write("<"+index+","+(index + 1)+","+ (firstIndex  + 1) + ">\n");
				index++;
				firstIndex++;
			}
			out.write("<"+index+ "," + (quadsPerCircle - 1) + ",0>");
			out.write("<"+index+",0,"+(index - quadsPerCircle + 1)+">\n");					

			progress.setProgressValue(index);

			out.write("}\n}\n" );
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	
	
	public void getTerrainAsWavefront(FileWriter out, GUI.Progress progress){		
		int vertexCount = xMesh * zMesh;
		double minNoise = Double.POSITIVE_INFINITY;
		double maxNoise = Double.NEGATIVE_INFINITY;
		double noise, factor;
		        
		try {
			DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(Locale.ENGLISH);
			df.setMaximumFractionDigits(5);
			df.setDecimalSeparatorAlwaysShown(false);


			out.write("o terrain\n" );

			Vertex point;

			// we have to scale the point to get reasonable results,
			// after all the noise could be 0.0001 or 10,000
			int delta = vertexCount / 100;
			progress.setProgressText("Scaling noise.");
			progress.setMaxValue(vertexCount-1);
			
			for(int i=0; i < vertexCount; i++) {
				noise = noiseEngine.getNoiseForVertex(getNoiseVertex(i));
				if(noise > maxNoise) {
					maxNoise = noise;
				}
				if(noise < minNoise) {
					minNoise = noise;
				}
			
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}
			
			if(maxNoise == minNoise) {
				factor = 1;
			} else {
				factor = (1/(maxNoise - minNoise)) * scale;
			}
			
			progress.setProgressText("Writing vertices.");
			progress.setProgressValue(0);
			 
			Vertex vector;
			for(int i=0; i < vertexCount; i++) {
 				vector = displacedVertex(i, ((noiseEngine.getNoiseForVertex(getNoiseVertex(i)) - minNoise) * factor));
				out.write("v "+df.format(vector.getX())+" "+df.format(vector.getY())+" "+df.format(vector.getZ()) + "\n");
			}


			progress.setProgressText("Writing faces.");
			progress.setProgressValue(0);

			int quadsPerCircle = xMesh;
			int faces = 2 * quadsPerCircle * zMesh;
			out.write(faces+",\n");

			int index = 1;

			if(zMesh > 2) {
				for(int i = 1; i < zMesh ; i++) {
					for(int j = 1; j < quadsPerCircle; j++) {
//						out.write("f "+index + " "+ (index + quadsPerCircle + 1)+" "+(index  + 1) + "\n");
//						out.write("f "+index+" "+(index + quadsPerCircle)+" "+ (index + quadsPerCircle + 1) + "\n");
						out.write("f "+index+" "+(index  + 1) + " "+ (index + quadsPerCircle + 1) + "\n");
						out.write("f "+index+" "+ (index + quadsPerCircle + 1)+" "+(index + quadsPerCircle) + "\n");
						index++;
					}
					index++;
					out.write("f "+(index  - 1)+" " + (index - quadsPerCircle)+" "+index + "\n");
					out.write("f "+(index  - 1)+" "+index+" "+(index - 1 + quadsPerCircle) + "\n");					
					progress.setProgressValue(index);
				}				
			}

			int firstIndex = 1;

			for(int i = 1; i < quadsPerCircle; i++) {
				out.write("f "+index+" "+ firstIndex+" "+(firstIndex  + 1) + "\n");
				out.write("f "+index+" "+ (firstIndex  + 1) + " "+(index + 1)+"\n");
				index++;
				firstIndex++;
			}
			out.write("f "+index+ " 1 " + quadsPerCircle + "\n");
			out.write("f "+index+" "+(index - quadsPerCircle + 1)+" 1\n");					
			
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	public void getTerrainAsYafray(FileWriter out, GUI.Progress progress){		
		int vertexCount = xMesh * zMesh;
		double minNoise = Double.POSITIVE_INFINITY;
		double maxNoise = Double.NEGATIVE_INFINITY;
		double noise, factor;
		        
		try {
			DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(Locale.ENGLISH);
			df.setMaximumFractionDigits(5);
			df.setDecimalSeparatorAlwaysShown(false);

			startYafRayScene(out);

			out.write("<points>\n" );

			Vertex point;

			// we have to scale the point to get reasonable results,
			// after all the noise could be 0.0001 or 10,000
			int delta = vertexCount / 100;
			progress.setProgressText("Scaling noise.");
			progress.setMaxValue(vertexCount-1);
			
			for(int i=0; i < vertexCount; i++) {
				noise = noiseEngine.getNoiseForVertex(getNoiseVertex(i));
				if(noise > maxNoise) {
					maxNoise = noise;
				}
				if(noise < minNoise) {
					minNoise = noise;
				}
			
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}
			
			if(maxNoise == minNoise) {
				factor = 1;
			} else {
				factor = (1/(maxNoise - minNoise)) * scale;
			}
			
			progress.setProgressText("Writing vertices.");
			progress.setProgressValue(0);
			 
			Vertex vector;
			for(int i=0; i < vertexCount; i++) {
 				vector = displacedVertex(i, ((noiseEngine.getNoiseForVertex(getNoiseVertex(i)) - minNoise) * factor));
//				out.write("v "+df.format(vector.getX())+" "+df.format(vector.getY())+" "+df.format(vector.getZ()) + "\n");
				out.write("<p " +
						  "x=\"" + df.format(vector.getX()) + "\" " +
						  "y=\"" + df.format(vector.getY()) + "\" " +
						  "z=\"" + df.format(vector.getZ()) + "\"/>");
			}

			out.write("\n</points>");
			out.write("\n<faces>\n");

			progress.setProgressText("Writing faces.");
			progress.setProgressValue(0);

			int quadsPerCircle = xMesh;

			int index = 0;

			if(zMesh > 2) {
				for(int i = 1; i < zMesh ; i++) {
					for(int j = 1; j < quadsPerCircle; j++) {
//						out.write("f "+index+" "+(index  + 1) + " "+ (index + quadsPerCircle + 1) + "\n");
//						out.write("f "+index+" "+ (index + quadsPerCircle + 1)+" "+(index + quadsPerCircle) + "\n");

						out.write("<f "+
						          "a=\"" + index +"\" "+
						          "b=\"" + (index + quadsPerCircle + 1) + "\" "+						
								  "c=\"" + (index + 1) + "\"/>");						

						out.write("<f "+
						          "a=\"" + index +"\" "+
						          "b=\"" + (index + quadsPerCircle + 1) + "\" "+						
								  "c=\"" + (index + quadsPerCircle) + "\"/>");						

						index++;
					}
					index++;
					
//					out.write("f "+(index - 1)+" " + (index - quadsPerCircle)+" "+index + "\n");
//					out.write("f "+(index - 1)+" "+index+" "+(index - 1 + quadsPerCircle) + "\n");					

					out.write("<f "+
					          "a=\"" + (index  - 1) +"\" "+
					          "b=\"" + (index - quadsPerCircle) + "\" "+						
							  "c=\"" + index + "\"/>");						

					out.write("<f "+
					          "a=\"" + (index  - 1) +"\" "+
					          "b=\"" + index + 	"\" "+					
							  "c=\"" + (index - 1 + quadsPerCircle) + "\"/>");						
					
					progress.setProgressValue(index);
				}				
			}

			int firstIndex = 0;

			for(int i = 1; i < quadsPerCircle; i++) {
//				out.write("f "+index+" "+ firstIndex+" "+(firstIndex  + 1) + "\n");
//				out.write("f "+index+" "+ (firstIndex  + 1) + " "+(index + 1)+"\n");
			
				out.write("<f "+
				          "a=\"" + index +"\" "+
				          "b=\"" + firstIndex +"\" "+ 						
						  "c=\"" + (firstIndex + 1) + "\"/>");						

				out.write("<f "+
				          "a=\"" + index +"\" "+
				          "b=\"" + (firstIndex + 1)  + "\" "+					
						  "c=\"" + (index + 1 ) + "\"/>");						

				
				index++;
				firstIndex++;
			}
//			out.write("f "+index+ " 1 " + quadsPerCircle + "\n");
//			out.write("f "+index+" "+(index - quadsPerCircle + 1)+" 1\n");					

			out.write("<f "+
			          "a=\"" + index +"\" "+
			          "b=\"0\" "+						
					  "c=\"" + quadsPerCircle + "\"/>");						

			out.write("<f "+
			          "a=\"" + index +"\" "+
			          "b=\"" + (index - quadsPerCircle + 1)  + 	"\" "+					
					  "c=\"0\"/>");						

			out.write("\n</faces>");

			endYafRayScene(out);

			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}		