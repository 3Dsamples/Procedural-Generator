/*
 * Created on Mar 29, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package Utilities;

import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.Enumeration;

import javax.media.j3d.Appearance;
import javax.media.j3d.Background;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.IndexedQuadArray;
import javax.media.j3d.Node;
import javax.media.j3d.PolygonAttributes;
import javax.media.j3d.QuadArray;
import javax.media.j3d.RenderingError;
import javax.media.j3d.RenderingErrorListener;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.vecmath.Point3d;

import GUI.HighResolutionComputer;

import com.sun.j3d.utils.behaviors.mouse.MouseRotate;
import com.sun.j3d.utils.behaviors.mouse.MouseTranslate;
import com.sun.j3d.utils.behaviors.mouse.MouseZoom;
import com.sun.j3d.utils.universe.SimpleUniverse;

/**
 * @author vargol
 *
 */
public class Preview3d {
	
	final private float[] vertices = new float[64*64*12];
	final private float[] greyArray = new float[64*64*12];
	final QuadArray previewObject = new QuadArray(63*63*4, QuadArray.COORDINATES|QuadArray.COLOR_3|QuadArray.BY_REFERENCE);
	final Shape3D shape;
	JFrame pG = new JFrame();
	JLabel status=new JLabel("Status:");
	
	public static final int HR_SIDE1=128;
	IndexedQuadArray hrObject1=new IndexedQuadArray(HR_SIDE1*HR_SIDE1, 
			QuadArray.COORDINATES|QuadArray.COLOR_3|QuadArray.BY_REFERENCE|QuadArray.BY_REFERENCE_INDICES|QuadArray.USE_COORD_INDEX_ONLY
			, (HR_SIDE1-1)*(HR_SIDE1-1)*4);
	double[] hrVertices1=new double[HR_SIDE1*HR_SIDE1*3];
	float[] hrGrey1=new float[HR_SIDE1*HR_SIDE1*3];
	Shape3D hrShape1;
	Shape3D waterShape;
	
	BranchGroup shapeG=new BranchGroup(), hrG1=new BranchGroup();
	BranchGroup[] allG=new BranchGroup[]{shapeG, hrG1};
	BranchGroup waterG = new BranchGroup();// so that water can be hidden
	Canvas3D canvas;
	SimpleUniverse simpleU ;
	
	double[] lastNoise;
	float waterLevel=-.3F;
	float vertScaling=.2f;
	private Transform3D scaleTr;
	double[] scaleMat={1, 0, 0, 0,
					   0, vertScaling, 0, 0,
					   0, 0, 1, 0,
					   0, 0, 0, 1,  };
	double[] waterTransMat={
			   1, 0, 0, 0,
			   0, 1, 0, waterLevel,
			   0, 0, 1, 0,
			   0, 0, 0, 1
	};
	TransformGroup scaleTG;
	QuadArray waterObject=new QuadArray(64*64*4, QuadArray.COORDINATES|QuadArray.COLOR_3|QuadArray.BY_REFERENCE);
	float[] waterVerts=new float[64*64*12];
	float[] waterColors=new float[64*64*12];
	
	TransformGroup waterTransG;
	Transform3D waterTrans;
	TransformGroup vpTrans;
	
	HighResolutionComputer highResC;
	
	public Preview3d() {
//		System.out.println(System.getProperty("j3d.rend"));
//		System.setProperty("j3d.rend", "d3d");
//		System.out.println(System.getProperty("j3d.rend"));

		float xPoint, zPoint = -0.5f;
		final float gap = 1.0f/63.0f;
		int vertexIndex = 0;

		for(int z = 0; z < 63; z++) {
			xPoint = -0.5f;
			for(int x = 0; x < 63; x++) {
			
				vertices[vertexIndex+0] = xPoint+gap;
				vertices[vertexIndex+1] = 0.0f;
				vertices[vertexIndex+2] =  zPoint;
				
				vertices[vertexIndex+3] = xPoint+gap;
				vertices[vertexIndex+4] = 0.0f;
				vertices[vertexIndex+5] =  zPoint+gap;
				
				vertices[vertexIndex+6] = xPoint;
				vertices[vertexIndex+7] = 0.0f;
				vertices[vertexIndex+8] =  zPoint+gap;
				
				vertices[vertexIndex+9] = xPoint;
				vertices[vertexIndex+10] = 0.0f;
				vertices[vertexIndex+11] =  zPoint;
			
				vertexIndex+=12;		
				xPoint += gap;
			}
			zPoint += gap;
		}
		System.arraycopy(vertices, 0, waterVerts, 0, vertices.length);
		Arrays.fill(waterColors, 0.0f);
		waterObject.setCoordRefFloat(waterVerts);
		waterObject.setColorRefFloat(waterColors);
		
		previewObject.setCoordRefFloat(vertices);
		previewObject.setColorRefFloat(greyArray);

		waterObject.setCapability(QuadArray.ALLOW_REF_DATA_WRITE);
		
		shape = new Shape3D(previewObject);
		Appearance app = new Appearance();
		PolygonAttributes poly =  new PolygonAttributes();
		
		poly.setCullFace(PolygonAttributes.CULL_NONE);
		app.setPolygonAttributes(poly);
		shape.setAppearance(app);
		shapeG.addChild(shape);
		
		waterShape=new Shape3D(waterObject);
		waterShape.setAppearance(app);

		shapeG.setCapability(BranchGroup.ALLOW_DETACH);
		hrG1.setCapability(BranchGroup.ALLOW_DETACH);
		shapeG.setName("Preview Noise");
		hrG1.setName("High Res Noise");
		
		waterG.setCapability(BranchGroup.ALLOW_DETACH);
		waterG.setName("Water");
		
		hrShape1=initIndexedQuad(hrObject1, hrVertices1, hrGrey1, HR_SIDE1, app);
		hrG1.addChild(hrShape1);
		hrG1.compile();
		
		pG.setTitle("planetGenesis Preview");
		
		Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		screenSize.width *= 0.6;
		screenSize.height *= 0.6;
		
		pG.setBounds((int)(screenSize.width * 0.3), (int)(screenSize.height *  0.3), screenSize.width, screenSize.height);

		vpTrans = null;
		BoundingSphere mouseBounds = null;
		BranchGroup objRoot = new BranchGroup();
		GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
		
		canvas = new Canvas3D(config);
		
		simpleU = new SimpleUniverse(canvas);
		
		vpTrans = new TransformGroup();
		vpTrans.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		vpTrans.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);

		objRoot.addChild(vpTrans);
//		vpTrans.addChild(shape);

		scaleTr = new Transform3D(scaleMat);
//		scaleTr.setScale(new Vector3d(new double[]{1, vertScaling, 1}));
		scaleTG = new TransformGroup(scaleTr);
		scaleTG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		scaleTG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		scaleTG.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
		scaleTG.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
//		scaleTG.addChild(shapeG);
		
		vpTrans.addChild(scaleTG);
		
		waterTrans=new Transform3D(waterTransMat);
		waterTransG=new TransformGroup(waterTrans);
		waterTransG.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		waterTransG.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		waterTransG.addChild(waterShape);
		waterG.addChild(waterTransG);
		scaleTG.addChild(waterG);
		
		// Set the background color and its application bounds
		BoundingSphere worldBounds = new BoundingSphere(new Point3d(), 1000.0);                      

        Background background = new Background( );
        background.setColor( 0.0f, 0.0f, 0.3f );
        background.setCapability( Background.ALLOW_COLOR_WRITE );
        background.setApplicationBounds( worldBounds );
        objRoot.addChild( background );		
		
		mouseBounds = new BoundingSphere(new Point3d(), 1000.0);

		MouseRotate myMouseRotate = new MouseRotate(/*MouseBehavior.INVERT_INPUT*/);
		myMouseRotate.setTransformGroup(vpTrans);
		myMouseRotate.setSchedulingBounds(mouseBounds);
		myMouseRotate.setFactor(0.01);

		objRoot.addChild(myMouseRotate);

		MouseTranslate myMouseTranslate = new MouseTranslate(/*MouseBehavior.INVERT_INPUT*/);
		myMouseTranslate.setTransformGroup(vpTrans);
		myMouseTranslate.setSchedulingBounds(mouseBounds);
		myMouseTranslate.setFactor(0.01);
		
		objRoot.addChild(myMouseTranslate);

		MouseZoom myMouseZoom = new MouseZoom(/*MouseBehavior.INVERT_INPUT*/);
		myMouseZoom.setTransformGroup(vpTrans);
		myMouseZoom.setSchedulingBounds(mouseBounds);
		myMouseZoom.setFactor(0.01);
		
		objRoot.addChild(myMouseZoom);

		pG.getContentPane().setLayout(new BoxLayout(pG.getContentPane(), BoxLayout.Y_AXIS));
		pG.getContentPane().add(canvas);
		pG.getContentPane().add(status);
		
		objRoot.compile();
		simpleU.getViewingPlatform().setNominalViewingTransform();
		simpleU.addBranchGraph(objRoot);

		canvas.addKeyListener(new KeyAdapter(){

			@Override
			public void keyTyped(KeyEvent e)
			{
				char k=e.getKeyChar();
//				System.out.println("in preview Typed "+k);
				/*
				 * Hides preview window on escape
				 */
				if(k==KeyEvent.VK_ESCAPE)
				{
					hidePreview();
				}
				else if(k=='[')
				{
					decreaseWaterLevel();
				}
				else if(k==']')
				{
					increaseWaterlevel();
				}
				else if(k=='=' || k=='+')
				{
					increaseMeshHeight();
				}
				else if(k=='-')
				{
					decreaseMeshHeight();
				}
				else if(k=='`')
				{
					toggleMesh();
					
				}
				else if(k=='\\')
				{
					toggleWater();
				}
				super.keyTyped(e);
			}
			
		});
		
		SimpleUniverse.addRenderingErrorListener(new RenderingErrorListener(){

			public void errorOccurred(RenderingError arg0)
			{
				JOptionPane.showMessageDialog(pG, arg0.getDetailMessage(), "Rendering Error : "+arg0.getErrorMessage(), JOptionPane.ERROR_MESSAGE);
			}
			
		});
		highResC = new HighResolutionComputer(this);
		highResC.start();
		
		pG.setMenuBar(new Preview3DMenu(this));
		
	}
	
	public void ShowGeometry(Shape3D object) {
		
		
//		pG.getContentPane().add(canvas);

		pG.setVisible(true);	
				

	}

	public void ShowGeometry(Shape3D object, boolean dummy) {//currently never called
		
		JFrame pG = new JFrame();
		Canvas3D canvas;
		
		pG.setTitle("planetGenesis");
		
		Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		screenSize.width *= 0.6;
		screenSize.height *= 0.6;
		
		pG.setBounds((int)(screenSize.width * 0.3), (int)(screenSize.height *  0.3), screenSize.width, screenSize.height);

		TransformGroup vpTrans = null;
		BoundingSphere mouseBounds = null;
		BranchGroup objRoot = new BranchGroup();
		GraphicsConfiguration config = SimpleUniverse.getPreferredConfiguration();
		canvas = new Canvas3D(config);
		
		SimpleUniverse simpleU = new SimpleUniverse(canvas);
		
		vpTrans = new TransformGroup();
		vpTrans.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		vpTrans.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);

		objRoot.addChild(vpTrans);
		vpTrans.addChild(object);	

        // Set the background color and its application bounds
		BoundingSphere worldBounds = new BoundingSphere(new Point3d(), 1000.0);                      

        Background background = new Background( );
        background.setColor( 0.0f, 0.0f, 0.3f );
        background.setCapability( Background.ALLOW_COLOR_WRITE );
        background.setApplicationBounds( worldBounds );
        objRoot.addChild( background );		
		
		mouseBounds = new BoundingSphere(new Point3d(), 1000.0);

		MouseRotate myMouseRotate = new MouseRotate(/*MouseBehavior.INVERT_INPUT*/);
		myMouseRotate.setTransformGroup(vpTrans);
		myMouseRotate.setSchedulingBounds(mouseBounds);
		myMouseRotate.setFactor(0.01);

		objRoot.addChild(myMouseRotate);

		MouseTranslate myMouseTranslate = new MouseTranslate(/*MouseBehavior.INVERT_INPUT*/);
		myMouseTranslate.setTransformGroup(vpTrans);
		myMouseTranslate.setSchedulingBounds(mouseBounds);
		myMouseTranslate.setFactor(0.01);
		
		objRoot.addChild(myMouseTranslate);

		MouseZoom myMouseZoom = new MouseZoom(/*MouseBehavior.INVERT_INPUT*/);
		myMouseZoom.setTransformGroup(vpTrans);
		myMouseZoom.setSchedulingBounds(mouseBounds);
		myMouseZoom.setFactor(0.01);
		
		objRoot.addChild(myMouseZoom);


		pG.getContentPane().add(canvas);
	
		objRoot.compile();
		simpleU.getViewingPlatform().setNominalViewingTransform();
		simpleU.addBranchGraph(objRoot);

		pG.setVisible(true);	
				

	}
	
	
	public Shape3D makePreview(NoiseEngine ne) {
		double[] noise=ne.getPreviewNoise();
		
		if(noise!=lastNoise)//new noise
		{
			waterLevel=-.3F;
			vertScaling=.2f;
			
			waterTransMat[7]=waterLevel;
			waterTrans.set(waterTransMat);
			waterTransG.setTransform(waterTrans);
			
			scaleMat[5]=vertScaling;
			scaleTr.set(scaleMat);
			scaleTG.setTransform(scaleTr);
			
			vpTrans.setTransform(new Transform3D());
			
			lastNoise=noise;
		}

		float zPoint, xPoint;
		float gap = 1.0f/63.0f;
		float grey;
		int index = 0;
		double min, max, scale;
		
		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;
		

		for(int j = 0; j < noise.length; j++){
			if(Double.isNaN(noise[j])) {
				noise[j] = 0;
			}
			if(noise[j] > max) {
				max = noise[j];
			}
			if(noise[j] < min) {
				min = noise[j];
			}
		}

		double greyScale; 
		double yShift;
		
		if(max != min) {
			scale = 1.0/(max - min);
			greyScale = 1.0/(max - min);
			yShift = scale * (-min - ((max - min) * 0.5));
		} else {
			scale = 0;
			greyScale = 0.5;
			yShift = -0.3;
		}

		grey = 1.0f;
		
		zPoint = -0.5f;
		
//		float scaledWaterLevel=(float) (scale*waterLevel+yShift);
//		yShift-=scaledWaterLevel; //waterlevel=0
//		scaledWaterLevel=0;
		
		int noiseIndex = 0;
		for(int z = 0; z < 63; z++) {
			xPoint = -0.5f;
			for(int x = 0; x < 63; x++) {
			
				grey = (float)((noise[noiseIndex+1] - min) * greyScale);
					greyArray[index * 3] = grey;
					greyArray[(index * 3) + 1] = grey;
					greyArray[(index * 3) + 2] = grey;
					waterColors[(index * 3) + 2] = grey;
					
					vertices[(index * 3) + 1] = (float)(scale * (noise[noiseIndex+1]) + yShift);
				index++;
		
			
				grey = (float)((noise[noiseIndex+65] - min) * greyScale);	
					greyArray[index * 3] = grey;
					greyArray[(index * 3) + 1] = grey;
					greyArray[(index * 3) + 2] = grey;
					waterColors[(index * 3) + 2] = grey;
					
					vertices[(index * 3) + 1] = (float)(scale * (noise[noiseIndex+65]) + yShift);
				index++;
				
				
				grey = (float)((noise[noiseIndex+64] - min) * greyScale);
					greyArray[index * 3] = grey;
					greyArray[(index * 3) + 1] = grey;
					greyArray[(index * 3) + 2] = grey;
					waterColors[(index * 3) + 2] = grey;
					
					vertices[(index * 3) + 1] = (float)(scale * (noise[noiseIndex+64]) + yShift);

				index++;

				grey = (float)((noise[noiseIndex] - min) * greyScale);
					greyArray[index * 3] = grey;
					greyArray[(index * 3) + 1] = grey;
					greyArray[(index * 3) + 2] = grey;
					waterColors[(index * 3) + 2] = grey;
					
					vertices[(index * 3) + 1] = (float)(scale * (noise[noiseIndex]) + yShift);
				index++;			
				
			
				xPoint += gap;
				noiseIndex++;
			}
			zPoint += gap;
			noiseIndex++;			
		}
//	   	scaleTG.removeChild(hrG1);
//	   	scaleTG.removeChild(hrG2);
		removeMeshBranches(scaleTG);
	   	scaleTG.addChild(shapeG);
	   	
		highResC.runForNoiseEngine(ne);
		
		return shape;
	}
	Shape3D initIndexedQuad(IndexedQuadArray hrObject, double[] hrVertices, float[] hrGrey, int sidelen, Appearance app)
	{
		int[] idx=new int[(sidelen-1)*(sidelen-1)*4];
		int idxidx=0;
		for(int i=0; i<sidelen-1; i++)
		{
			for(int j=0; j<sidelen-1; j++)
			{
				idx[idxidx]=j*sidelen+i;
				idx[idxidx+1]=(j+1)*sidelen+i;
				idx[idxidx+2]=(j+1)*sidelen+i+1;
				idx[idxidx+3]=j*sidelen+i+1;
				idxidx+=4;
			}
		}
		System.out.println(idxidx+ " indices");
		hrObject.setCoordIndicesRef(idx);
		
		double xPoint=-0.5, zPoint=-0.5, gap = 1.0/(sidelen-1);
		int vertexIndex=0;
		for(int z = 0; z < sidelen; z++) {
			xPoint = -0.5;
			for(int x = 0; x < sidelen; x++) {
			
				hrVertices[vertexIndex+0] = zPoint;
				hrVertices[vertexIndex+1] = 0.0;
				hrVertices[vertexIndex+2] = xPoint;
			
				vertexIndex+=3;		
				xPoint += gap;
			}
			zPoint += gap;
		}
		System.out.println(idxidx+ " verts");
		Arrays.fill(hrGrey, 0.0f);
		
		hrObject.setCoordRefDouble(hrVertices);
		hrObject.setColorRefFloat(hrGrey);
		hrObject.setCapability(QuadArray.ALLOW_REF_DATA_WRITE);
		
		Shape3D hrShape = new Shape3D(hrObject);
		hrShape.setAppearance(app);
		return hrShape;
	}


	private void removeMeshBranches(TransformGroup tg)
	{
		Enumeration<Node> e=tg.getAllChildren();
		while(e.hasMoreElements())
		{
			Node n=e.nextElement();
			if(n instanceof BranchGroup && n!=waterG)
				tg.removeChild(n);
		}
		
	}

	public void setStatus(String string)
	{
		status.setText(string);
		status.repaint();
	}

	public void setHRNoise(int i, double[] hrNoise)
	{
		if(i==1)
		{
			double max=Double.NEGATIVE_INFINITY, min=Double.POSITIVE_INFINITY;
			for(int k=0; k<hrNoise.length; k++)
			{
				if(hrNoise[k]>max) max=hrNoise[k];
				if(hrNoise[k]<min) min=hrNoise[k];
			}
			double range=max-min;
			System.out.println("min max range "+min+" "+max+" "+range);
			for(int k=0; k<hrVertices1.length/3/*hrNoise.length*/; k++)
			{
				hrVertices1[k*3+1]=(hrNoise[k]-min)/range-.5;//range -.5 to +.5
//				hrVertices1[k*3+1]=Math.random();
				hrGrey1[k*3]=hrGrey1[k*3+1]=hrGrey1[k*3+2]=(float) ((hrNoise[k]-min)/range);
			}
			removeMeshBranches(scaleTG);
			scaleTG.addChild(hrG1);
		}
		
	}

	public void hidePreview()
	{
		pG.setVisible(false);
	}

	public void decreaseWaterLevel()
	{
		waterLevel-=.1;
		waterTransMat[7]=waterLevel;
		waterTrans.set(waterTransMat);
		waterTransG.setTransform(waterTrans);
		canvas.repaint();
	}

	public void increaseWaterlevel()
	{
		waterLevel+=.1;
		waterTransMat[7]=waterLevel;
		waterTrans.set(waterTransMat);
		waterTransG.setTransform(waterTrans);
		canvas.repaint();
	}

	public void toggleWater()
	{
		int idx = scaleTG.indexOfChild(waterG);
		if(idx==-1)
			scaleTG.addChild(waterG);
		else
			scaleTG.removeChild(idx);
		
		canvas.repaint();
	}
	
	public void increaseMeshHeight()
	{
		vertScaling+=.1;
		scaleMat[5]=vertScaling;
		scaleTr.set(scaleMat);
		scaleTG.setTransform(scaleTr);
		canvas.repaint();
	}

	public void decreaseMeshHeight()
	{
		vertScaling-=.1;
		scaleMat[5]=vertScaling;
		scaleTr.set(scaleMat);
		scaleTG.setTransform(scaleTr);
		canvas.repaint();
	}

	public void toggleMesh()
	{
		BranchGroup curG=null;
		int idx=0;
		//find first (and only) non water mesh
		for(int i=0; i<scaleTG.numChildren(); i++)
		{
			 Node bg = scaleTG.getChild(i);
			if(bg!=waterG){
				curG=(BranchGroup) bg;
				idx=i;
			}
				
		}
		
		if(curG==null)
		{
			scaleTG.addChild(allG[0]);
			System.err.println("-> "+allG[0].getName());
			return;
		}
		
		int i=0;
		for(; i<allG.length; i++)
		{
			if(allG[i]==curG)
				break;
		}
		i++; if(i>=allG.length) i=0;
		scaleTG.removeChild(idx);
		scaleTG.addChild(allG[i]);
		System.err.println(curG.getName()+"->"+allG[i].getName());
	}
	
	
}
