package Utilities;

/**
 * This class provides a set of utility methods to simplify development of PostProcess nodes.
 * @author su_liam
 *
 */
public abstract class PostProcessHelper extends PostProcess
{
	private boolean scroll = false;
	
	/**
	 * Kind of a bonehead method here. It allows inheriting classes to control whether effects scroll across the maps
	 * in a manner appropriate to the terrain shape chosen. The default is false, so, by default effects are clamped 
	 * to the edge of the screen.
	 * Depending on the node-programmers choice, scrolling can be set by the user, set by the node, or hardwired. Oh, sweet freedom...
	 * @param scroll
	 */
	protected void setScroll(boolean scroll)
	{
		this.scroll = scroll;
	}
	
	/**
	 * This method returns the index into the storage array of a point (x,y).
	 * @param x the x-coordinate of the desired point
	 * @param y the y-coordinate of the desired point
	 * @return the index to the storage array corresponding to the point (x,y)
	 */
	public int getIndex(double x, double y)
	{
		double width = getTerrain().xMesh;
		double height = getTerrain().yMesh;
		int index = (int)(x + y*width);
		
		return index;
	}
	
	/**
	 * This method returns the index representing a point, (x+deltaX,y+deltaY), in other words, the point deltaX to the right of the original point and deltaY
	 * above the original point. Values of x and y outside of the screen space are dealt with appropriately.
	 * @param x the x-coordinate of the original point
	 * @param y the y_coordinate of the original point
	 * @param deltaX the distance moved to the right
	 * @param deltaY the distance moved down
	 * @return the storage array index corresponding to the new point
	 */
	public int move(double x, double y, double deltaX, double deltaY)
	{
		if(!scroll)
			return moveClamped(x, y, deltaX, deltaY);
		if(getTerrain() instanceof Planet)
			return movePlanet(x, y, deltaX, deltaY);
		return moveScroll(x, y, deltaX, deltaY);//scrolling movement
	}
	
	
	//I may change the "move" methods to private, depending on input from others in the project.
	/**
	 * This method returns the index representing a point, (x+deltaX,y+deltaY), in other words, the point deltaX to the right of the original point and deltaY
	 * above the original point. Values of x and y outside of the screen space are scrolled over.
	 * @param x the x-coordinate of the original point
	 * @param y the y_coordinate of the original point
	 * @param deltaX the distance moved to the right
	 * @param deltaY the distance moved down
	 * @return the storage array index corresponding to the new point
	 */
	protected int moveScroll(double x, double y, double deltaX, double deltaY)
	{
		double width = getTerrain().xMesh;
		double height = getTerrain().yMesh;
		double newX = (x + deltaX) % width;
		double newY = (y + deltaY) % height;
		
		return getIndex(newX, newY);
	}
	
	/**
	 * This method returns the index representing a point, (x+deltaX,y+deltaY), in other words, the point deltaX to the right of the original point and deltaY
	 * above the original point. Values of x and y outside of the screen space are scrolled over in a manner appropriate to a sphere.
	 * @param x the x-coordinate of the original point
	 * @param y the y_coordinate of the original point
	 * @param deltaX the distance moved to the right
	 * @param deltaY the distance moved down
	 * @return the storage array index corresponding to the new point
	 */
	protected int movePlanet(double x, double y, double deltaX, double deltaY)
	{
		double width = getTerrain().xMesh;
		double height = getTerrain().yMesh;
		double newX = x + deltaX;
		double newY = y + deltaY;
		newX += 0.5 * width * ((int)newY / height);
		newY %= height;
		return getIndex(newX, newY);
	}
	
	/**
	 * This method returns the index representing a point, (x+deltaX,y+deltaY), in other words, the point deltaX to the right of the original point and deltaY
	 * above the original point. Values of x and y outside of the screen space are clamped to the edge of the screen space.
	 * @param x the x-coordinate of the original point
	 * @param y the y_coordinate of the original point
	 * @param deltaX the distance moved to the right
	 * @param deltaY the distance moved down
	 * @return the storage array index corresponding to the new point
	 */
	protected int moveClamped(double x, double y, double deltaX, double deltaY)
	{
		double width = getTerrain().xMesh;
		double height = getTerrain().yMesh;
		double newX = x + deltaX;
		double newY = y + deltaY;
		if(newX < 0)
			newX = 0;
		if(newY < 0)
			newY =0;
		if(newX > width - 1)
			newX = width - 1;
		if(newY > height - 1)
			newY = height - 1;
		
		return getIndex(newX, newY);
	}
	
	public Vertex getVertex(int index)
	{
		double x = (int)(index) % (int)(getTerrain().xMesh);
		double y = (int)index / (int)(getTerrain().yMesh);
		
		return new Vertex(x, y, 0.0);
	}
}