/*
 * Created on Sep 6, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package Utilities;

/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Spline {

	double[] knots;
	Vertex[] points;
	int order;

	public void initSpline(Vertex[] points, int order) {

		this.points = points;
		this.order = order;
		 
		knots = makeKnots(order + 1, points.length - 1);
	}

	public void initSpline(double[] points, int order) {

		this.order = order;
		 
		knots = makeKnots(order + 1, points.length - 1, points);
	}	
	
	public double spline(double inputValue) {
		double splineValue = 0;
		double blendValue;
		for(int i = 0; i<points.length; i++) {
			blendValue = (points[i].getY() * blend(i, order+1, inputValue));
			splineValue += blendValue; 
		}
		return splineValue;
	}

	public double spline(double inputValue, double[] points) {
		double splineValue = 0;
		double blendValue;
		for(int i = 0; i<points.length; i++) {
			blendValue = (points[i] * blend(i, order+1, inputValue));
			splineValue += blendValue; 
		}
		return splineValue;
	}
	
	private double blend(final int index, final int order, final double inputValue) {
	
		
		if(order == 1) {
			if(knots[index] <= inputValue && inputValue < knots[index+1]) {
				return 1;
			}
			
			return 0;
			 
		}
		
		/* avoid divide by zero errors by checking
		 * the two demoninators for the equation
		 */
		 
		double rht, lht;
		

		if(knots[index+order-1] == knots[index]) {
			lht = 0.0;
		} else {
			lht = (inputValue - knots[index]) / (knots[index+order-1] - knots[index]) * blend(index, order-1, inputValue);
		}

		if(knots[index+order]== knots[index+1]) {
			rht = 0.0;
		} else {
			rht = (knots[index+order] - inputValue) / (knots[index+order] - knots[index+1]) * blend(index+1, order-1, inputValue);
		}

		return lht + rht;

	}

	private double[] makeKnots(int orderPlusOne, int pointsMinusOne) {
		double[] tmp = new double[orderPlusOne + pointsMinusOne + 1];
		for(int i = 0; i <= orderPlusOne + pointsMinusOne; i++ ) {
			if(i < orderPlusOne) {
				tmp[i] = points[0].getX(); 
			} else if ((i > pointsMinusOne)) {
				tmp[i] = points[pointsMinusOne].getX();
			} else {
				tmp[i] = points[i-orderPlusOne].getX() + ((points[i-orderPlusOne+1].getX() - points[i-orderPlusOne].getX()) / 2);
			}
		}
		return tmp;
	}

	private double[] makeKnots(int orderPlusOne, int pointsMinusOne, double[] points) {
		double[] tmp = new double[orderPlusOne + pointsMinusOne + 1];
		for(int i = 0; i <= orderPlusOne + pointsMinusOne; i++ ) {
			if(i < orderPlusOne) {
				tmp[i] = points[0]; 
			} else if ((i > pointsMinusOne)) {
				tmp[i] = points[pointsMinusOne];
			} else {
				tmp[i] = points[i-orderPlusOne] + ((points[i-orderPlusOne+1] - points[i-orderPlusOne]) / 2);
			}
		}
		return tmp;
	}
}
