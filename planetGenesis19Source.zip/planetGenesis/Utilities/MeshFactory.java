/*
 * MeshFactory.java
 *
 * Created on 29 March 2003, 3.00pm
 */


/*
 Copyright (c) 2003, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

package Utilities;
import java.io.*;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import GUI.Progress;
/**
*
 * @author  David
 */
public class MeshFactory implements Factory {

    // header
    int meshWidth;
    int meshHeight;
    int meshType;
    double landScale;
	String outFileName;
	String outType;

	private Landscape land; 
	private NoiseEngine engine;
	
	Progress progress;


    /** Creates a new instance of meshfactory */
    public MeshFactory() {
	//	String[] titles = {"Width", "Depth", "Height"};
    //	frame = new SizeFrame(titles);
    }


    public long make (Progress progress, boolean dummyParameter) {



        	long timeForRun = System.currentTimeMillis();
       
        	try {
        		land.setWorldSpace();
 			land.setNoiseSpace(engine);
			land.setProjection(Landscape.Projection3D);
			engine.initNoise();
			
			engine.setProjection(Landscape.Projection3D);

		
			if(outType.compareTo("POV") == 0) {			
				land.getTerrainAsPov(new FileWriter(outFileName), progress);
			} else if( outType.compareTo("YAFRAY") == 0) {
				land.getTerrainAsYafray(new FileWriter(outFileName), progress); 
			} else {
				land.getTerrainAsWavefront(new FileWriter(outFileName), progress);			
			}
			
			progress.dispose();
        } catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
			progress.dispose();
			JOptionPane pane = new JOptionPane("Could not open a file called '" + outFileName + "'!" , JOptionPane.ERROR_MESSAGE);
			JDialog dialog = pane.createDialog(null, "Warning");
			dialog.setModal(false);
			dialog.setVisible(true);
        }  catch (Exception e) {
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
        
	    timeForRun = System.currentTimeMillis() - timeForRun;
        return timeForRun;
        
    }

	public void setFile(String fileName) {
		outFileName = fileName; 
	}

	public void setFile(String fileName, String type) {
		outFileName = fileName; 
		outType = type; 
	}
	

	public JDialog getDialog(JFrame owner) {
		JDialog frame = new JDialog(owner, "Mesh ("+ land.getType() + ")");
		frame.getContentPane().add(land.getPanel());
		return frame; 
	}
	
	public String getName() {
		return "Mesh (<i>"+ land.getType() + "</i>)";
	}

	public void setLandscape(Landscape newLandscape) {
		land = newLandscape;
	}
	
	public void setEngine(NoiseEngine newEngine) {
		engine = newEngine;
	}
	
	public int getDimensions() {
		return(3);
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		// TODO Auto-generated method stub
		land.getPanel().save(file);
		
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		land.getPanel().load(file);
		
	}
	



}

