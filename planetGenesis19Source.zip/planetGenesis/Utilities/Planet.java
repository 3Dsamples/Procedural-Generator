/*
 Copyright (c) 2002, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
		  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
		  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

package Utilities;

/*
 * Grid.java
 *
 * Created on 05 March 2002, 22:34
 */
import java.io.*;
import java.text.DecimalFormat;
import java.util.Locale;

import GUI.HashBasedPanel;
import GUI.Progress;
/**
*
 * @author  David
 */
public class Planet extends Landscape {
	
	VertexAlgorithm algorithm;
	double noiseRadius, scale;

	public Planet() {
		String[] titles = {"Circumference", "Scale"};
		String[] defaults = {"640", "0.02"};
		String[] keys = {"Circumference", "Scale"};
		String[] tooltips = {"Circumference in Vertices.", "Scale in renderer space units."};
		
		panel = new HashBasedPanel(keys, titles, defaults, tooltips);		
	}

	public void setNoiseSpace(NoiseEngine engine) {
		noiseEngine = engine;
		Vertex size = engine.getNoiseSize();
		Vertex offset =  engine.getNoiseOffset();
		xNoise = size.getX();
		yNoise = size.getY();
		zNoise = size.getZ();

		xNoiseOffset = offset.getX();
		yNoiseOffset = offset.getY();
		zNoiseOffset = offset.getZ();
		
		noiseRadius = size.getX();
	}

	public void setWorldSpace(double x, double y, double z) {
		xMesh = (int)x;
		scale = y;
		yMesh = (int)z;
		zMesh = (int)(x/2);
	}	

	public void setWorldSpace() {
		xMesh = panel.getInt("Circumference");
		scale = panel.getDouble("Scale");
		zMesh = (xMesh/2);
	}	
	
	public void setProjection(int projection) {
		worldProjection = projection;
		if(projection == Landscape.Projection2D) {
			algorithm = new Vertex3dProjection();
		} else {
			algorithm = new Vertex3dProjection();
		}
	}

	public Vertex getNoiseVertex(int index) {
		
		return algorithm.noiseVertex(index);
		
	}
		
	public Vertex getWorldVertex(int index) {

		return algorithm.vertex(index);
	}
	
	public void getTerrainAsPov(FileWriter out, Progress progress){

		int vertexCount = 2 + ((xMesh - 2) * zMesh);
		double minNoise = Double.POSITIVE_INFINITY;
		double maxNoise = Double.NEGATIVE_INFINITY;
		double noise, factor;
		        
//		scale = 0.02;  // get this from the front end eventually.        
		try {
			DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(Locale.ENGLISH);
			df.setMaximumFractionDigits(5);
			df.setDecimalSeparatorAlwaysShown(false);


			out.write("#declare terrain = mesh2{\nvertex_vectors{" );
			out.write(vertexCount+",\n");

			Vertex point;

			// we have to scale the point to get reasonable results,
			// after all the noise could be 0.0001 or 10,000
			
			progress.setProgressText("Scaling noise.");
			progress.setMaxValue(vertexCount-1);
			int delta = vertexCount / 100;

			for(int i=0; i < vertexCount; i++) {
				noise = noiseEngine.getNoiseForVertex(getNoiseVertex(i));
				if(noise > maxNoise) {
					maxNoise = noise;
				}
				if(noise < minNoise) {
					minNoise = noise;
				}
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}

			if(minNoise == maxNoise) {
				factor = 1.0;	
			} else {
				factor = (1/(maxNoise - minNoise)) * scale;				
			}
						
			progress.setProgressText("Writing vertices.");
			progress.setProgressValue(0);
 
 			for(int i=0; i < vertexCount; i++) {
				point = getWorldVertex(i);
				point.scalePoint(1 + ((noiseEngine.getNoiseForVertex(getNoiseVertex(i)) - minNoise) * factor));
				out.write("<"+df.format(point.getX())+","+df.format(point.getY())+","+df.format(point.getZ()) + ">\n");
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}

			progress.setProgressText("Writing faces.");
			progress.setProgressValue(0);

			out.write("}\nface_indices{" );
			
			int quadsPerCircle = xMesh;
			int faces = 2 * quadsPerCircle * (zMesh - 2);
			out.write(faces+",\n");

			int index = 1;
			int firstIndex;

			// north pole
			for(int i = 1; i < quadsPerCircle; i++) {
				out.write("<0,"+ index + ","+ (index + 1) + ">\n");
				index++;
			}
			out.write("<0,"+ index + ",1>\n");
			index++;
			progress.setProgressValue(index);

			if(zMesh > 2) {
				for(int i = 2; i < zMesh - 1 ; i++) {
					firstIndex = index;
					for(int j = 1; j < quadsPerCircle; j++) {
						out.write("<"+(index - quadsPerCircle+1)+","+(index - quadsPerCircle)+","+ index + ">");
						out.write("<"+(index + 1)+","+(index - quadsPerCircle + 1)+","+ index + ">\n");
						index++;
					}
					out.write("<"+(firstIndex - quadsPerCircle)+"," + (index - quadsPerCircle)+","+index + ">");
					out.write("<"+firstIndex+","+(firstIndex - quadsPerCircle)+","+index + ">\n");					
					index++;
					progress.setProgressValue(index);
				}				
			}

			index -= quadsPerCircle;
			firstIndex = index;
			int lastIndex = vertexCount - 1;
			
			// south pole
			for(int i = 1; i < quadsPerCircle; i++) {
				out.write("<"+ (index + 1) + ","+ index + "," + lastIndex + ">\n");
				index++;
			}
			out.write("<"+ firstIndex + ","+ index + "," + lastIndex + ">\n");
			progress.setProgressValue(index);

			out.write("}\n}\n" );
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public void getTerrainAsWavefront(FileWriter out, GUI.Progress progress){		
		int vertexCount = 2 + ((xMesh - 2) * zMesh);
		double minNoise = Double.POSITIVE_INFINITY;
		double maxNoise = Double.NEGATIVE_INFINITY;
		double noise, factor;
		        
		try {
			DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(Locale.ENGLISH);
			df.setMaximumFractionDigits(5);
			df.setDecimalSeparatorAlwaysShown(false);


			out.write("o terrain\n" );

			Vertex point;

			// we have to scale the point to get reasonable results,
			// after all the noise could be 0.0001 or 10,000
			int delta = vertexCount / 100;
			progress.setProgressText("Scaling noise.");
			progress.setMaxValue(vertexCount-1);
			
			for(int i=0; i < vertexCount; i++) {
				noise = noiseEngine.getNoiseForVertex(getNoiseVertex(i));
				if(noise > maxNoise) {
					maxNoise = noise;
				}
				if(noise < minNoise) {
					minNoise = noise;
				}
			
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}
			
			if(minNoise == maxNoise) {
				factor = 1.0;	
			} else {
				factor = (1/(maxNoise - minNoise)) * scale;				
			}

			progress.setProgressText("Writing vertices.");
			progress.setProgressValue(0);
			 
			for(int i=0; i < vertexCount; i++) {
				point = getWorldVertex(i);
				point.scalePoint(1 + ((noiseEngine.getNoiseForVertex(getNoiseVertex(i)) - minNoise) * factor));
				out.write("v "+df.format(point.getX())+" "+df.format(point.getY())+" "+df.format(point.getZ()) + "\n");
			}


			int quadsPerCircle = xMesh;

			int index = 2;
			int firstIndex;
			progress.setProgressText("Writing faces.");
			progress.setProgressValue(0);

			// north pole
			for(int i = 1; i < quadsPerCircle; i++) {
				out.write("f 1 "+ (index + 1) + " "+ index + "\n");
				index++;
			}
			out.write("f 1 2 "+ index+"\n");
			index++;
			progress.setProgressValue(index);

			if(zMesh > 2) {
				for(int i = 2; i < zMesh - 1 ; i++) {
					firstIndex = index;
					for(int j = 1; j < quadsPerCircle; j++) {
						out.write("f "+(index - quadsPerCircle)+" "+(index - quadsPerCircle + 1)+" "+ " "+(index + 1)+" "+ index + "\n");
			//			out.write("f "+(index - quadsPerCircle + 1)+" "+(index + 1)+" "+ index + "\n");
						index++;
					}
					out.write("f "+(index - quadsPerCircle)+" "+(firstIndex - quadsPerCircle)+" "+firstIndex+" "+ index + "\n");
			//		out.write("f "+(firstIndex - quadsPerCircle + 1)+" "+firstIndex+" "+ index + "\n");					
					index++;
				}				
				progress.setProgressValue(index);
			}

			index -= quadsPerCircle;
			firstIndex = index;
			int lastIndex = vertexCount;
			
			// south pole
			for(int i = 1; i < quadsPerCircle; i++) {
				out.write("f "+ index + " "+ (index + 1) + " " + lastIndex + "\n");
				index++;
			}
			out.write("f "+ index + " "+ firstIndex + " " + lastIndex + "\n");
			progress.setProgressValue(index);

			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void getTerrainAsYafray(FileWriter out, Progress progress){

		int vertexCount = 2 + ((xMesh - 2) * zMesh);
		double minNoise = Double.POSITIVE_INFINITY;
		double maxNoise = Double.NEGATIVE_INFINITY;
		double noise, factor;
		        
//		scale = 0.02;  // get this from the front end eventually.        
		try {
			DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(Locale.ENGLISH);
			df.setMaximumFractionDigits(5);
			df.setDecimalSeparatorAlwaysShown(false);

			startYafRayScene(out);

			Vertex point;

			// we have to scale the point to get reasonable results,
			// after all the noise could be 0.0001 or 10,000
			
			progress.setProgressText("Scaling noise.");
			progress.setMaxValue(vertexCount-1);
			int delta = vertexCount / 100;

			for(int i=0; i < vertexCount; i++) {
				noise = noiseEngine.getNoiseForVertex(getNoiseVertex(i));
				if(noise > maxNoise) {
					maxNoise = noise;
				}
				if(noise < minNoise) {
					minNoise = noise;
				}
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}
			
			if(minNoise == maxNoise) {
				factor = 1.0;	
			} else {
				factor = (1/(maxNoise - minNoise)) * scale;				
			}
						
			progress.setProgressText("Writing vertices.");
			progress.setProgressValue(0);
 
			out.write("<points>");

 			for(int i=0; i < vertexCount; i++) {
				point = getWorldVertex(i);
				point.scalePoint(1 + ((noiseEngine.getNoiseForVertex(getNoiseVertex(i)) - minNoise) * factor));
				out.write("<p " +
						  "x=\"" + df.format(point.getX()) + "\" " +
						  "y=\"" + df.format(point.getY()) + "\" " +
						  "z=\"" + df.format(point.getZ()) + "\"/>");
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}

			out.write("\n</points>");

			progress.setProgressText("Writing faces.");
			progress.setProgressValue(0);


			out.write("\n<faces>\n");

			int quadsPerCircle = xMesh;

			int index = 1;
			int firstIndex;

			// north pole
			for(int i = 1; i < quadsPerCircle; i++) {
				out.write("<f "+
				          "a=\"0\" "+
				          "b=\"" + index +"\" "+
				          "c=\"" + (index + 1) + "\"/>");
				index++;
			}
			out.write("<f "+
			          "a=\"0\" "+
			          "b=\"" + index +"\" "+
			          "c=\"1\"/>");
			index++;
			progress.setProgressValue(index);

			if(zMesh > 2) {
				for(int i = 2; i < zMesh - 1 ; i++) {
					firstIndex = index;
					for(int j = 1; j < quadsPerCircle; j++) {
						out.write("<f "+
						          "a=\"" + (index - quadsPerCircle+1)+"\" "+
						          "b=\"" + (index - quadsPerCircle)+"\" "+
						          "c=\"" + index + "\"/>");
						out.write("<f "+
						          "a=\"" + (index + 1)+"\" "+
						          "b=\"" + (index - quadsPerCircle + 1)+"\" "+
						          "c=\"" + index + "\"/>");
						index++;
					}
					out.write("<f "+
					          "a=\"" + (firstIndex - quadsPerCircle)+"\" "+
					          "b=\"" + (index - quadsPerCircle)+"\" "+
					          "c=\"" + index + "\"/>");
					out.write("<f "+
					          "a=\"" + firstIndex +"\" "+
					          "b=\"" + (firstIndex - quadsPerCircle)+"\" "+
					          "c=\"" + index + "\"/>");
					index++;
					progress.setProgressValue(index);
				}				
			}

			index -= quadsPerCircle;
			firstIndex = index;
			int lastIndex = vertexCount - 1;
			
			// south pole
			for(int i = 1; i < quadsPerCircle; i++) {
				out.write("<f "+
				          "a=\"" + (index + 1) +"\" "+
				          "b=\"" + index+"\" "+
				          "c=\"" + lastIndex + "\"/>");
				index++;
			}
			out.write("<f "+
			          "a=\"" + firstIndex +"\" "+
			          "b=\"" + index+"\" "+
			          "c=\"" + lastIndex + "\"/>");
			progress.setProgressValue(index);

			out.write("\n</faces>");

			endYafRayScene(out);

			
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}	

	
	
	private interface VertexAlgorithm {
		public Vertex vertex(int index);
		public Vertex noiseVertex(int index);
	} 
	
	private class Vertex2dProjection implements VertexAlgorithm {

		double phiDelta;
		double phi;
		double theta;
		double thetaDelta;    			
		double noiseRadius;

		public Vertex2dProjection() {
			// uv mapping;
			theta = 1;
			thetaDelta = 2 / (double)(zMesh-1);					
		}

		public Vertex vertex(int index) {
			int xPixel = index % xMesh;
			int zPixel = index / xMesh;	
		
			double circleHeight = theta - (thetaDelta * zPixel);
			double phi = -1 * Math.sqrt(1 - (circleHeight * circleHeight));
			double phiDelta =  -(2 * phi) / xMesh;    			
			
			return new Vertex(phi + (xPixel * phiDelta),
							  0,	
							  circleHeight
			);
		}
		public Vertex noiseVertex(int index) {
			Vertex tmp = vertex(index);
			tmp.multiply(xNoise * 0.5, 0, zNoise * 0.5);
			tmp.add(xNoiseOffset, yNoiseOffset, zNoiseOffset);
			return tmp;
		}
	}

	private class Vertex3dProjection implements VertexAlgorithm {
		double phiDelta;
		double thetaDelta;
		double theta;
		double phi;
		int maxIndex;

		public Vertex3dProjection() {
			// uv mapping;
			phiDelta = (2.0 * Math.PI) / xMesh;
			thetaDelta = Math.PI / zMesh;
			theta = Math.PI/2.0;
			phi = 0.0;
			
			maxIndex = 1 + ((xMesh - 2) * xMesh);
			System.err.println("xMesh " + xMesh);
			System.err.println("maxIndex " + maxIndex);
			System.err.println("phiDelta " + phiDelta);
			System.err.println("thetaDelta " + thetaDelta);
			
		}
		public Vertex vertex(int index)  {
			
			if(index == 0) {
				return new Vertex(0,1,0);
			}
			if(index == maxIndex){
				return new Vertex(0,-1,0);
			}
			
			int xVertex = (index - 1) % xMesh;
			int yVertex = ((index - 1) / xMesh) + 1;	

			double circleHeight = Math.sin (theta + (yVertex * thetaDelta));
			double circleRadius = Math.cos (theta + (yVertex * thetaDelta));			
			
			return new Vertex(circleRadius * Math.cos(phi + (xVertex* phiDelta)),
							  circleHeight,
							  circleRadius * Math.sin(phi + (xVertex* phiDelta))
			);
		}
		
		public Vertex noiseVertex(int index) {
			Vertex tmp = vertex(index);
			tmp.multiply(xNoise * 0.5, yNoise * 0.5, zNoise * 0.5);
			tmp.add(xNoiseOffset, yNoiseOffset, zNoiseOffset);
			return tmp;
		}

	}

	public Landscape getNewLandscape() {
		Planet newPlanet = new Planet();
		newPlanet.setWorldSpace(xMesh,scale,yMesh);
		return newPlanet;
	} 	
	
	public String getType() {
		return "Planet";
	}

	public int getVertexCount() {
		return 2 + ((xMesh - 2) * zMesh);
	}
}		