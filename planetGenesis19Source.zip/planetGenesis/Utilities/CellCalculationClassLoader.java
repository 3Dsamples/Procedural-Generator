package Utilities;

/* Custom class loader, loads class fom the current directory */
import java.io.File;
import java.io.FileInputStream;

import GUI.TerrainComponent;


public class CellCalculationClassLoader extends ClassLoader {

    CellCalculationClassLoader() {
        super();
    }

    protected Class findClass(String name) throws ClassNotFoundException {
        FileInputStream classStream;

        try {
            System.out.println("Finding " + name);
            File classFile = new File(name + ".class");
			File tmp = new File(name);

            classStream = new FileInputStream(classFile);
            byte[] classBytes = new byte[classStream.available()];
			classStream.read(classBytes);
			classStream.close();
            classFile.delete();
            return defineClass(tmp.getName(), classBytes, 0, classBytes.length);
        }
        catch (Exception e) {
            // We could not find the class, so indicate the problem with an exception
            throw new ClassNotFoundException(name);
        }
    }
    
   	
    
}

