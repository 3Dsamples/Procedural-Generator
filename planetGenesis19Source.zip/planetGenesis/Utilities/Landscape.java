/*
Copyright (c) 2002, David Burnett
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products
derived from this software without specific prior
written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
		  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
		  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

package Utilities;

/*
* Grid.java
*
* Created on 05 March 2002, 22:34
*/
import java.io.*;
import java.text.DecimalFormat;
import java.util.Locale;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import GUI.HashBasedPanel;

/**
*
* @author  David
*/
public class Landscape {

	public final static int Projection2D  = 0;
	public final static int Projection3D  = 1;

	protected double xNoiseOffset;
	protected double yNoiseOffset;
	protected double zNoiseOffset;

	protected double xNoise;
	protected double yNoise;
	protected double zNoise;

	protected int xMesh;
	protected double yMesh;
	protected int zMesh;
	
	protected double scale;

	protected int worldProjection;

	protected NoiseEngine noiseEngine;
	protected HashBasedPanel panel;

	protected int tile;

	protected final Vertex noiseVertex = new Vertex(0,0,0);
	protected final Vertex worldVertex = new Vertex(0,0,0);

	public Landscape () {
		String[] titles = {"Width (vertices)", "Depth (vertices)", "Scale (render units)"};
		String[] defaults = {"640.0", "640.0", "0.25"};
		String[] keys = {"Width", "Depth", "Height"};
		String[] tooltips = {"Mesh Width in Vertices.", "Mesh Depth in Vertices.", "Mesh Height in Vertices."};

		panel = new HashBasedPanel(keys, titles, defaults, tooltips);
	}

	public void setWorldSpace(double x, double y, double z) {
		xMesh = (int)x;
		yMesh = z;
		zMesh = (int)y;

	}

	public void setWorldSpace() {
		xMesh = panel.getInt("Width");
		yMesh = panel.getDouble("Height");
		zMesh = panel.getInt("Depth");
		
	}

	public void setNoiseSpace(NoiseEngine engine) {
		noiseEngine = engine;
		Vertex size = engine.getNoiseSize();
		Vertex offset =  engine.getNoiseOffset();
		xNoise = size.getX();
		yNoise = size.getY();
		zNoise = size.getZ();

		xNoiseOffset = offset.getX();
		yNoiseOffset = offset.getY();
		zNoiseOffset = offset.getZ();
	}

	public void setProjection(int projection) {
		worldProjection = projection;
	}

	public Vertex getNoiseVertex(int index) {
		noiseVertex.setPoint(
//		return new Vertex(
			(index % xMesh) * (xNoise / (xMesh - tile)) + xNoiseOffset,
			yNoiseOffset,
			(index / xMesh) * (zNoise / (zMesh - tile)) + zNoiseOffset
		);
		return noiseVertex;
	}

	public Vertex getWorldVertex(int index) {

		worldVertex.setPoint(
	//	return new Vertex(
			(index % (double)xMesh) / (xMesh - 1),
			0,
			(double)(index / xMesh) / (zMesh - 1)
		);
		return worldVertex;
	}

	public void getTerrainAsPov(FileWriter out, GUI.Progress progress){


		int vertexCount = Math.round(xMesh*zMesh);
//		Vector3D[] vertexNormal = new Vector3D[vertexCount];
//		Vertex[] vertex = new Vertex[vertexCount];
//		byte[] vertexUseTotal = new byte[vertexCount];

		try {
			DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(Locale.ENGLISH);
			df.setMaximumFractionDigits(5);
			df.setDecimalSeparatorAlwaysShown(false);

			progress.setProgressText("Writing vertices.");
			progress.setMaxValue(vertexCount);
			int delta = vertexCount / 100;
			out.write("#declare terrain = mesh2{\nvertex_vectors{" );
			out.write(vertexCount+",\n");

			Vertex point, noisePoint;

			for(int i=0; i < vertexCount; i++) {
				point = getWorldVertex(i);
//				vertexNormal[i] = new Vector3D(0,0,0);
//				vertex[i] = point;
//				vertexUseTotal[i] = 0;
				noisePoint = getNoiseVertex(i);
				point.setY(noiseEngine.getNoiseForVertex(noisePoint) * yMesh );
				out.write("<"+df.format(point.getX())+","+df.format(point.getY())+","+df.format(point.getZ()) + ">\n");
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}

			int index = 0;


			progress.setMaxValue(xMesh);
			progress.setProgressText("Writing faces.");
			progress.setProgressValue(0);
			out.write("}\nface_indices{" );
			out.write(2*(xMesh-1)*(zMesh-1)+",\n");

			index = 0;
			for(int i = 0; i < zMesh - 1 ; i++) {
				for(int j = 0; j < xMesh - 1 ; j++) {

					out.write("<"+(index + xMesh)+","+(index + 1)+","+ index + ">\n");
					out.write("<"+(index + xMesh)+","+(index + xMesh + 1)+","+(index + 1) + ">\n");
					index++;

				}
				index++;
				progress.setProgressValue(xMesh);
			}
			out.write("}\n}\n" );
			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (OutOfMemoryError e) {
			JOptionPane pane = new JOptionPane("Out of Memory.\nThe mesh was to big to smooth.\n Increase the java or try again withiut smoothing.", JOptionPane.INFORMATION_MESSAGE);
			JDialog dialog = pane.createDialog(null, "Warning");
			dialog.setModal(false);
			dialog.setVisible(true);
			System.gc();

		}

	}

	public void getTerrainAsWavefront(FileWriter out, GUI.Progress progress){
		int vertexCount = Math.round(xMesh*zMesh);

		try {
			DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(Locale.ENGLISH);
			df.setMaximumFractionDigits(5);
			df.setDecimalSeparatorAlwaysShown(false);

			progress.setProgressText("Writing vertices.");
			progress.setMaxValue(vertexCount);
			int delta = vertexCount / 100;

			Vertex point, noisePoint;

			for(int i=0; i < vertexCount; i++) {
				point = getWorldVertex(i);
				noisePoint = getNoiseVertex(i);
				point.setY(noiseEngine.getNoiseForVertex(noisePoint) * yMesh);
			out.write("v "+df.format(point.getX())+" "+df.format(point.getY())+" "+df.format(point.getZ()) + "\n");
				if(i % delta == 0) {
					progress.setProgressValue(i);
				}
			}

			progress.setMaxValue(xMesh);
			progress.setProgressText("Writing faces.");
			progress.setProgressValue(0);

			int index = 1;
			for(int i = 0; i < zMesh - 1 ; i++) {
				for(int j = 0; j < xMesh - 1 ; j++) {
					out.write("f "+(index + xMesh)+" "+(index + xMesh+ 1)+" "+(index + 1)+" "+ index + "\n");
					index++;
				}
				index++;
				progress.setProgressValue(xMesh);
			}

			out.flush();
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void getTerrainAsYafray(FileWriter out, GUI.Progress progress){


			int vertexCount = Math.round(xMesh*zMesh);
//			Vector3D[] vertexNormal = new Vector3D[vertexCount];
//			Vertex[] vertex = new Vertex[vertexCount];
//			byte[] vertexUseTotal = new byte[vertexCount];

			try {
				DecimalFormat df = (DecimalFormat)DecimalFormat.getInstance(Locale.ENGLISH);
				df.setMaximumFractionDigits(5);
				df.setDecimalSeparatorAlwaysShown(false);

				scale = yMesh;

				
				progress.setProgressText("Writing vertices.");
				progress.setMaxValue(vertexCount);
				int delta = vertexCount / 100;

				startYafRayScene(out);

				Vertex point, noisePoint;

				out.write("\n<points>\n");

				for(int i=0; i < vertexCount; i++) {
					point = getWorldVertex(i);
					noisePoint = getNoiseVertex(i);
//					point.setY();
					out.write("<p " +
							  "x=\"" + df.format(point.getX()) + "\" " +
							  "y=\"" + df.format(scale * noiseEngine.getNoiseForVertex(noisePoint)) + "\" " +
							  "z=\"" + df.format(point.getZ()) + "\"/>");
					if(i % delta == 0) {
						progress.setProgressValue(i);
					}
				}
				out.write("\n</points>\n");

				int index = 0;


				progress.setMaxValue(xMesh);
				progress.setProgressText("Writing faces.");
				progress.setProgressValue(0);
				out.write("<faces>\n");

				index = 0;
				for(int i = 0; i < zMesh - 1 ; i++) {
					for(int j = 0; j < xMesh - 1 ; j++) {
						out.write("<f "+
						          "a=\"" + (index + xMesh)+"\" "+
						          "b=\"" + (index + 1)+"\" "+
						          "c=\"" + index + "\"/>");
						out.write("<f "+
						          "a=\"" + (index + xMesh)+"\" "+
						          "b=\"" + (index + xMesh + 1)+"\" "+
						          "c=\"" + (index + 1) + "\"/>");
						index++;

					}
					index++;
					progress.setProgressValue(xMesh);
				}

				out.write("\n</faces>");

				endYafRayScene(out);


				out.flush();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (OutOfMemoryError e) {
				JOptionPane pane = new JOptionPane("Out of Memory.\nThe mesh was to big to smooth.\n Increase the java or try again withiut smoothing.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "Warning");
				dialog.setModal(false);
				dialog.setVisible(true);
				System.gc();

			}

		}

	public HashBasedPanel getPanel() {
		return panel;
	}

	public String getType() {
		return "Landscape";
   }

	public Landscape getNewLandscape() {
		Landscape newLandscape = new Landscape();
		newLandscape.setWorldSpace(xMesh, zMesh, yMesh);
		return newLandscape;
	}


	public void setTile(boolean setTile) {
		if(setTile) {
			tile = 0;
		} else {
			tile = 1;
		}

	}


	/**
	 * @return
	 */
	public int getXMesh() {
		return xMesh;
	}

	/**
	 * @return
	 */
	public int getZMesh() {
		return zMesh;
	}

	protected void startYafRayScene(FileWriter out) throws IOException {

	    out.write("<scene>");
	    out.write("<shader type= \"generic\" name=\"Default\">");
        out.write("<attributes>");
        out.write("<color r=\"0.750000\" g=\"0.750000\" b=\"0.800000\" />");
        out.write("<specular r=\"0.000000\" g=\"0.000000\" b=\"0.000000\" />");
        out.write("<reflected r=\"0.000000\" g=\"0.000000\" b=\"0.000000\" />");
        out.write("<transmitted r=\"0.000000\" g=\"0.000000\" b=\"0.000000\" />");
        out.write("</attributes>");
        out.write("</shader>\n");

        out.write("<object name=\"planetGenesis\" shader_name=\"Default\" caus_IOR=\"1.0\" recv_rad=\"on\" emit_rad=\"on\" shadow=\"on\">");
		out.write("<attributes>");
		out.write("<caus_tcolor r=\"1.000000\" g=\"1.000000\" b=\"1.000000\"/>");
		out.write("<caus_rcolor r=\"1.000000\" g=\"1.000000\" b=\"1.000000\"/>");
		out.write("</attributes>\n");
		out.write("<mesh autosmooth=\"70.0\">");

	}

	protected void endYafRayScene(FileWriter out) throws IOException {

		out.write("\n</mesh>");
		out.write("\n</object>");
		
		out.write("<light type=\"pathlight\" name=\"path\" power= \"0.5000000\" depth=\"2\" samples = \"16\" use_QMC = \"on\" cache=\"on\"  cache_size=\"0.008000\"");  out.write("angle_threshold=\"0.200000\"  shadow_threshold=\"0.200000\" >");
		out.write("</light>\n");

		out.write("<background type=\"sunsky\" name=\"Sun1\" turbidity=\"4.000000\" add_sun=\"on\" sun_power=\"1.000000\"");
		out.write(" a_var=\"1.000000\" b_var=\"1.000000\" c_var=\"1.000000\" d_var=\"1.000000\" e_var=\"1.000000\" >");
		out.write("<from x=\"-0.007401\" y=\"8.589217\" z=\"3.737965\"/>");
		out.write("</background>\n");

		out.write("<camera name=\"Camera\" resx=\"1024\" resy=\"576\" focal=\"1.015937\" >");
		out.write("<from x=\"0.5\" y=\"0.75\" z=\"-2.5\" />");
		out.write("<to x=\"0.5\" y=\"0.0\" z=\"0.5\" />");
		out.write("<up x=\"0.5\" y=\"1.0\" z=\"0.0\" />");
		out.write("</camera>\n");

		out.write("<render camera_name=\"Camera\" AA_passes=\"2\" AA_minsamples=\"2\" AA_pixelwidth=\"1.500000\" AA_threshold=\"0.040000\"");
		out.write(" raydepth=\"5\" bias=\"0.300000\" indirect_samples=\"1\" gamma=\"1.000000\" exposure=\"0.000000\" background_name=\"Sun1\">");
		out.write("<outfile value=\"genesis.tga\"/>");
		out.write("<save_alpha value=\"on\"/>");
		out.write("</render>");		
		
	    out.write("\n</scene>\n");
	}

	public int getVertexCount() {
		return Math.round(xMesh*zMesh);
	}
}