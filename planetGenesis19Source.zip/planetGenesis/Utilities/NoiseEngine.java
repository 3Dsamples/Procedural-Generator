/*
 * NoiseEngine.java
 *
 * Created on 07 March 2002, 21:57
 */


/*
Copyright (c) 2002, David Burnett
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the following disclaimer 
in the documentation and/or other materials provided with the 
distribution. 
Neither the name of the copyright holder nor the names of its 
contributors may be used to endorse or promote products 
derived from this software without specific prior 
written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT 
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

package Utilities;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JPanel;

/**
 *
 * @author  David
 */
public abstract class NoiseEngine {
   
	final protected BufferedImage preview = new BufferedImage(64, 64, BufferedImage.TYPE_BYTE_GRAY);
	final protected double[] previewNoise = new double[64*64];

	protected JPanel panel;
	protected Landscape terrain;
	protected double max, min, xGap;
	protected int gridProjection, scanlineSize;
	protected double[] noiseArray;


	/**
	 * @param scanlineSize The scanlineSize to set.
	 */
    abstract public NoiseEngine copy();
    abstract public String description();
    abstract public String getDetails();
    abstract public double getNoiseForVertex(Vertex vertex);
    /**
     * Range 0 to 1 spans the width of the preview window.
     * @param vertex
     * @return
     */
    abstract public double getScaledMovedNoiseForVertex(double x, double y, double z);
    abstract public double getNoiseForVertex(int vertex);
    abstract public JPanel getPanel();
    abstract public void initNoise(); 
    abstract public void load(ObjectInputStream file)  throws ClassNotFoundException,IOException;	
    abstract public void makePreview() ;
    abstract public String name();  
    abstract public void restoreSettings();
    abstract public void save(ObjectOutputStream file) throws IOException;
    abstract public void storeSettings();

	void setScanlineSize(int scanlineSize) {
		noiseArray = new double[scanlineSize];
		this.scanlineSize = scanlineSize;
		xGap = 1.0/(double)(scanlineSize - 1);
		
	}

    public void setTerrain(Landscape terrain) {
		this.terrain = terrain;
		terrain.setNoiseSpace(this);
		terrain.setProjection(gridProjection);
		terrain.setTile(false);
		scanlineSize = terrain.getXMesh();
		return;
	} 

    public Landscape getTerrain() {
    	return terrain;
	}     
    
	public Vertex getNoiseSize() {
		return new Vertex(1.0, 1.0, 1.0);
	}

	public Vertex getNoiseOffset() {
		return new Vertex(0.0, 0.0, 0.0);
	}
	
	public void paintIcon(Graphics2D g2, java.awt.image.ImageObserver noiseComponent) {
		g2.drawImage(preview,0,0,noiseComponent);
	}

	public double[] getPreviewNoise() {
		return previewNoise;
	}
    public Vertex[] getPreviewVertices() {

		Vertex[]  vertices = new Vertex[64*64];
		int index;
		
		index = 0;	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				vertices[index] = new Vertex(i /  63.0, 
											0, 
											j / 63.0); 	
				index++;
			}
		}
		
		return vertices;
	}	
    
	public void setProjection(int projection) {
		gridProjection = projection;
	}

	public Vertex getVertex(int index) {
		return terrain.getNoiseVertex(index);
	}

	/**
	 * @return Returns the max.
	 */
	public double getMax() {
		return max;
	}
	/**
	 * @return Returns the min.
	 */
	public double getMin() {
		return min;
	}
}
