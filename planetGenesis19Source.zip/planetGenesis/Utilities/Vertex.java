
/*
Copyright (c) 2002, David Burnett
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the following disclaimer 
in the documentation and/or other materials provided with the 
distribution. 
Neither the name of the copyright holder nor the names of its 
contributors may be used to endorse or promote products 
derived from this software without specific prior 
written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT 
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

package Utilities;

/*
 * Vertex.java
 *
 * Created on 05 March 2002, 20:43
 */

/**
 *
 * @author  David
 */
public class Vertex {
    
	//made public for faster access, since getters and setters need to extra magic
	//by datta_sid
    public double x;
    
    public double y;
    
    public double z;
    
    /** Creates a new instance of Vertex */
    public Vertex(double newX, double newY, double newZ) {
        x = newX;
        y = newY;
        z = newZ;
    }
    
    public Vertex(Vector3D v)
	{
    	x=v.x;
    	x=v.x;
    	x=v.x;
	}

	public double getX() {
        return x;
    } 

    public double getY() {
        return y;
    } 
    
    public double getZ() {
        return z;
    } 

 	public void setX(double newX) {
	    x = newX;
	}  

    public void setY(double newY) {
        y = newY;
    } 
    
    public void setZ(double newZ) {
        z = newZ;
    } 

    public void setPoint(double newX, double newY, double newZ) {
        x = newX;
        y = newY;
        z = newZ;
    }

    public void Normalise() {
 
        double length;
        length = Math.sqrt(x * x + y * y + z * z);
        if (length != 0) { 
                x /= length;
                y /= length; 
                z /= length;
                
        } else {
                 x = 0; y = 0; z = 0; 
        }    
        return;
    }
    
    public void scalePoint(double scale) {
        double length;
       
        length = Math.sqrt(x * x + y * y + z * z);
        if (length != 0) { 
        //      fprintf(stderr, "before %f %f %f ", p->x,p->y,p->z);
                x /= length;
                y /= length; 
                z /= length;
        //      fprintf(stderr, "height %f", p->height);
                x *= scale;
                y *= scale; 
                z *= scale;
        //      fprintf(stderr, "after %f %f %f\n ", p->x,p->y,p->z);
        } else {
        //      fprintf(stderr, "scaling to zero\n");
                 x = 0;
                 y = 0;
                 z = 0; 
        }
    }
    
    public double euclideanDistance(Vertex point2) {
        return Math.sqrt(Math.pow(x - point2.getX(), 2) + 
                         Math.pow(y - point2.getY(), 2) +
                         Math.pow(z - point2.getZ(), 2));
                         
    }

    public double manhattanDistance(Vertex point2) {
        return Math.abs(x - point2.getX()) + 
               Math.abs(y - point2.getY()) +
               Math.abs(z - point2.getZ());
                         
    }

    public double chessboardDistance(Vertex point2) {
        return Math.max(Math.max(Math.abs(x - point2.getX()),
                                 Math.abs(y - point2.getY())),
                        Math.abs(z - point2.getZ()));
                         
    }
    
 
	public double euclideanDistanceSquared(Vertex point2) {
		return (Math.pow(x - point2.getX(), 2) + 
						 Math.pow(y - point2.getY(), 2) +
						 Math.pow(z - point2.getZ(), 2));
                         
	}


    public void add(Vertex vertex) {
    	x += vertex.getX();
    	y += vertex.getY();
    	z += vertex.getZ();
    }

	public Vector3D sub(Vector3D vector) {
		return (new Vector3D(x - vector.x, y - vector.y, z - vector.z));
	}

	public Vertex sub(Vertex vertex) {
		return (new Vertex(x - vertex.x, y - vertex.y, z - vertex.z));
	}

	public void add(double newX, double newY, double newZ) {
		x += newX;
		y += newY;
		z += newZ;
	}
	
	public void multiply(double newX, double newY, double newZ) {
		x *= newX;
		y *= newY;
		z *= newZ;
	}
	
	public void displacePoint(double scale) {
		double length;
		double tmpX, tmpY, tmpZ;

		length = Math.sqrt(x * x + y * y + z * z);
		scale *= length;
		
		if (length != 0) { 

			tmpX = x / length;
			tmpY = y / length; 
			tmpZ =  z / length;

			tmpX *= scale;
			tmpY *= scale; 
			tmpZ *= scale;

			this.add(tmpX, tmpY, tmpZ);
		} 
	}	
	   
	public void debug() {
		System.err.println("vertex " + x + " " + y + " " + z);
	}

}
