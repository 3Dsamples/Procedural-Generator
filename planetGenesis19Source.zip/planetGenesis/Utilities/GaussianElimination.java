package Utilities;

import java.util.Arrays;

public class GaussianElimination
{

	
	/**
	 * Solves Ax=b
	 * Results will be in b
	 * A[i][j] = j-th coefficient of i-th equation
	 * @param A
	 * @param b
	 */
	public static void solve(double[][] A, double[] b)
	{
		int n = A.length;
		assert(A[0].length == n);
		assert(b.length == n);
		
		for(int i=0; i<n; i++)
		{
			//find row with max value in col i
			int mr = findRowBelowWithMaxInCol(A, i);
			//swap with it
			swapRows(A, b, i, mr);
			
			if(A[i][i]==0) //no solution possible, or better method needed
			{
				makeZero(b);
				return;
			}
			// for all rest of the equations
			for(int j=i+1; j<n; j++)
			{
				double num = A[i][i];
				double denom = A[j][i];
				
				//for all coefficients, (<j should be 0 already )
				for(int k=i; k<n; k++)
				{
//					System.out.println("k = "+k+" A[j][k] = "+A[j][k]);
					A[j][k] -= (A[i][k]*denom/num);
//					System.out.println("k = "+k+" A[j][k] = "+A[j][k]);
				}
				
				b[j] -= (b[i]*denom/num);
			}
		}
		
//		for(int i=0; i<n; i++)
//			System.out.println(Arrays.toString(A[i]));
//		System.out.println("b "+Arrays.toString(b));
		
		//back calc
		for(int i=n-1; i>=0; i--)
		{
			double sum = 0;
			for(int j=i+1; j<n; j++)
			{
				sum += A[i][j] * b[j];
			}
			
			b[i] -= sum;
			b[i] /= A[i][i];
		}
		
//		System.out.println("result "+Arrays.toString(b));
		return;
	}
	
	private static void makeZero(double[] b)
	{
		Arrays.fill(b, 0);
	}

	public static void main(String[] args)
	{
		double[] b = new double[]{6., 10., 23.};
		solve(new double[][]{
				{1., 1., 1.},
				{3., 2., 1.},
				{5., 6., 2.}
		}, b);
		System.out.println(Arrays.toString(b));
		//result 1 2 3
	}
	
	static int findRowBelowWithMaxInCol(double[][] A, int i)
	{
		double max=Double.NEGATIVE_INFINITY;
		int maxRow = -1;
		for(int k=i; k<A.length; k++)
		{
			if(A[k][i]>max)
			{
				max = A[k][i];
				maxRow = k;
			}
		}
		return maxRow;
	}
	
	static void swapRows(double[][] A, double[] b, int i, int j)
	{
		double[] t1 = A[i]; A[i] = A[j]; A[j] = t1;
		double t2 = b[i]; b[i] = b[j]; b[j] = t2;
	}
}
