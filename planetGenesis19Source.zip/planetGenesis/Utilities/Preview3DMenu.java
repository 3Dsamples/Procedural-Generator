package Utilities;

import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.MenuShortcut;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;

/**
 * Heavyweight menu required to show on the top of opengl.
 * @author sidatta
 *
 */
public class Preview3DMenu extends MenuBar implements ActionListener
{

	//TODO: Improve display of shortcut keys, hopefully without using accelarators
	
	private static final String TOGGLE_HIGH_RES_PREVIEW_MESH = "`          Toggle High-Rez/Preview Mesh";
	private static final String DECREASE_HEIGHT              = "-          Decrease Height";
	private static final String INCREATE_HEIGHT              = "+ or =  Increate Height";
	
	private static final String TOGGLE_WATER_LEVEL   = "\\  Toggle WaterLevel";
	private static final String DECREASE_WATER_LEVEL = "[  Decrease WaterLevel";
	private static final String INCREASE_WATER_LEVEL = "]  Increase WaterLevel";
	
	private static final String HIDE = "ESCAPE  Hide";

	Preview3d p3d;
	
	public Preview3DMenu(Preview3d p3d)
	{
		super();
		
		this.p3d = p3d;
		
		Menu view = new Menu("View");
		attach(view, HIDE, this, KeyEvent.VK_ESCAPE);
		add(view);
		
		Menu water = new Menu("Water Level");
		attach(water, INCREASE_WATER_LEVEL, this, KeyEvent.VK_OPEN_BRACKET);
		attach(water, DECREASE_WATER_LEVEL, this, KeyEvent.VK_CLOSE_BRACKET);
		attach(water, TOGGLE_WATER_LEVEL, this, KeyEvent.VK_BACK_SLASH);
		add(water);
		
		Menu mesh = new Menu("Mesh");
		attach(mesh, INCREATE_HEIGHT, this, 0);
		attach(mesh, DECREASE_HEIGHT, this, 0);
		attach(mesh, TOGGLE_HIGH_RES_PREVIEW_MESH, this, 0);
		add(mesh);
		
		
	}
	
	void attach(Menu m, String miName, ActionListener al, int ke) {
		MenuItem mi = new MenuItem(miName/*, new MenuShortcut(ke)*/);
		// Menu shortcuts have a compulsory Ctrl+, whcih I dont like.
		// Keyboard shortcuts are implemented in the keylistener in Preview3d
		// -sdatta
		m.add(mi);
		mi.addActionListener(al);
	}

	public void actionPerformed(ActionEvent e)
	{
		String cmd = e.getActionCommand();
//		System.out.println(cmd);
		if(cmd==HIDE)
			p3d.hidePreview();
		else if(cmd==INCREASE_WATER_LEVEL)
			p3d.increaseWaterlevel();
		else if(cmd==DECREASE_WATER_LEVEL)
			p3d.decreaseWaterLevel();
		else if(cmd==INCREATE_HEIGHT)
			p3d.increaseMeshHeight();
		else if(cmd==DECREASE_HEIGHT)
			p3d.decreaseMeshHeight();
		else if(cmd==TOGGLE_HIGH_RES_PREVIEW_MESH)
			p3d.toggleMesh();
		else if(cmd==TOGGLE_WATER_LEVEL)
			p3d.toggleWater();
		else
			System.err.println("Not implemented menu function "+cmd);
		
	}
}
