/*
 * PNGfactory.java
 *
 * Created on 09 March 2002, 15:53
 */

/*
Copyright (c) 2002, David Burnett
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the following disclaimer 
in the documentation and/or other materials provided with the 
distribution. 
Neither the name of the copyright holder nor the names of its 
contributors may be used to endorse or promote products 
derived from this software without specific prior 
written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT 
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

package Utilities;

import java.io.*;
import java.nio.DoubleBuffer;
import java.nio.channels.FileChannel;
import java.util.zip.*;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author  David
 */
public class PNGFactory implements Factory {

	// header
	int pngWidth;
	int pngHeight;
	byte pngBpp;
	byte pngColourType;
	byte pngCompression;
	byte pngFilter;
	byte pngInterlace;
	byte pngFilterType;
	String pngFileName;

	DataOutputStream pngFile;
	PNGstream buffer;
	
	private Landscape land; 
	private NoiseEngine engine;
	
	FilterMethod filterMethod;
	byte[] byteScanline;

	Deflater zlib;
	Compressor stream;

	CRC32 crc;


	/** Creates a new instance of PNGfactory */
	public PNGFactory(Landscape land) {

		//        if (bpp == 8) {
		pngBpp = 16;
		pngColourType = 0;
		//       } else {
		//           pngColourType = 6;
		//       }
		pngCompression = 0;
		pngFilter = 0;
		pngInterlace = 0;
		pngFilterType = 1;
		crc = new CRC32();
		switch(pngFilterType) {
			case 0: 
				filterMethod = new Method0();
				break;			
			case 1: 
				filterMethod = new Method1();
				break;			
			default: 
				filterMethod = new Method0();
				break;			
		}
		
	}

	private void start() throws IOException {

		pngFile.write(createSignature());
		writeHeader(pngFile);
		int bufferSize = 8388608 ;  /* 8MB */

		buffer = new PNGstream(bufferSize);
		zlib = new Deflater(Deflater.BEST_COMPRESSION);
		stream = new Compressor(buffer, zlib, bufferSize);
		byteScanline = new byte[(pngWidth * 2) + 1];
	};

	private void end() throws IOException {
		writeEnd(pngFile);
	};

	private void writeHeader(DataOutputStream out) throws IOException {
		byte[] header = createHeader();
		out.writeInt((header.length - 4));
		out.write(header);
		crc.reset();
		crc.update(header);
		out.writeInt((int) crc.getValue());

	}

	private byte[] int2ByteArray(int oldint) {
		byte[] convert = new byte[4];
		convert[0] = (byte) ((oldint >> 24) & 0xFF);
		convert[1] = (byte) ((oldint >> 16) & 0xFF);
		convert[2] = (byte) ((oldint >> 8) & 0xFF);
		convert[3] = (byte) (oldint & 0xFF);

		return convert;
	}

	private short[] int2ShortArray(int oldint) {
		short[] convert = new short[4];
		convert[1] = (byte) ((oldint >> 8) & 0xFFFF);
		convert[2] = (byte) ((oldint >> 0) & 0xFFFF);

		return convert;
	}

	private byte[] createHeader() {
		byte[] header = new byte[17];
		byte[] convert;

		header[0] = 'I';
		header[1] = 'H';
		header[2] = 'D';
		header[3] = 'R';
		convert = int2ByteArray(pngWidth);
		header[4] = convert[0];
		header[5] = convert[1];
		header[6] = convert[2];
		header[7] = convert[3];
		convert = int2ByteArray(pngHeight);
		header[8] = convert[0];
		header[9] = convert[1];
		header[10] = convert[2];
		header[11] = convert[3];

		header[12] = pngBpp;
		header[13] = pngColourType;
		header[14] = pngCompression;
		header[15] = pngFilter;
		header[16] = pngInterlace;

		return header;
	};
	private byte[] createSignature() {
		byte[] signature = {(byte) 137, 80, 78, 71, 13, 10, 26, 10 };
		return signature;
	};

	private void writeEnd(DataOutputStream out) throws IOException {

		stream.finish();
		if(buffer.size()> 0) {
			byte[] dataArray = new byte[4];
			dataArray[0] = 'I';
			dataArray[1] = 'D';
			dataArray[2] = 'A';
			dataArray[3] = 'T';
			out.writeInt(buffer.size());
			out.write(dataArray);
			buffer.writeByteArrayToDataStream(out);
			crc.reset();
			crc.update(dataArray);
			buffer.updateCRC32ForByteArray(crc);
			out.writeInt((int) crc.getValue());
		}

		byte[] end = createEnd();
		out.writeInt(end.length - 4);
		out.write(end);
		crc.reset();
		crc.update(end);
		out.writeInt((int) crc.getValue());
		return;
	}

	private byte[] createEnd() {

		byte[] end = new byte[4];
		end[0] = 'I';
		end[1] = 'E';
		end[2] = 'N';
		end[3] = 'D';

		return end;
	};

	private void createData(byte[] scanLine) {

		byte[] typeArray = { pngFilterType };

		try {
			stream.write(typeArray);
			stream.write(scanLine);
		} catch (IOException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}

	private void createData(short[] scanline) {

		//        System.err.println("starting createData");
		//        System.err.println("scanline.length " + scanline.length);
		//        byteScanline = new byte[(scanline.length * 2) + 1];
		byteScanline[0] = pngFilterType;
		for (int i = 0; i < scanline.length; i++) {
			byteScanline[(i * 2) + 1] = (byte) ((scanline[i] >> 8) & 0xFF);
			byteScanline[(i * 2) + 2] = (byte) (scanline[i] & 0xFF);
		}

		//        System.err.println("writing scanline");
		//        System.err.println("byteScanline "  + byteScanline.length);
		;
		try {
			stream.write(filterMethod.filter(byteScanline));
		} catch (IOException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}


	public static void main(String[] args) {


		byte[] dataArray = new byte[4];
		dataArray[0] = 'I';
		dataArray[1] = 'D';
		dataArray[2] = 'A';
		dataArray[3] = 'T';

		CRC32 crc = new CRC32();
		crc.reset();
		crc.update(dataArray);

		System.err.println("CRC " + crc.getValue());

		crc.reset();
		crc.update(dataArray[0]);
		crc.update(dataArray[1]);
		crc.update(dataArray[2]);
		crc.update(dataArray[3]);

		System.err.println("CRC " + crc.getValue());
		

		return;
	}

	public long make(GUI.Progress progress, boolean dummyParameter) {

		int value, i, j, vertexCount;
		double high = Double.NEGATIVE_INFINITY;
		double low = Double.POSITIVE_INFINITY;

		double noise;
		double factor  = 1.0;
		short[] pngData; 
		
		long timeForRun = System.currentTimeMillis();
 
	
		try {
			pngFile =  new DataOutputStream(new FileOutputStream(pngFileName));
		} catch (FileNotFoundException e) {

			e.printStackTrace();
			progress.dispose();
			JOptionPane pane = new JOptionPane("Could not open a file called '" + pngFileName + "'!" , JOptionPane.ERROR_MESSAGE);
			JDialog dialog = pane.createDialog(null, "Warning");
			dialog.setModal(false);
			dialog.setVisible(true);
			return -1;
		} 
		
			
		try {

 			land.setWorldSpace();
			land.setProjection(Landscape.Projection2D);
			engine.setProjection(Landscape.Projection2D);
			engine.setTerrain(land.getNewLandscape());
			//land.setNoiseSpace(engine);
			engine.initNoise();
			System.err.println("Factory using " + engine.name());

			pngWidth = land.xMesh;
			pngHeight = land.zMesh;
			pngData = new short[pngWidth];
			filterMethod.init();
			
			vertexCount = pngHeight * pngWidth;
			double delta = vertexCount / 100;
			progress.setMaxValue(vertexCount);
			progress.setProgressText("Scaling Noise");

			
			File tmpdoubleFile = File.createTempFile("tmpDouble", null);

			FileChannel rwCh =
                new RandomAccessFile(
              		  tmpdoubleFile,"rw").
                        getChannel();			

		    long fileSize = vertexCount * 8;
		    DoubleBuffer noiseMap = rwCh.map(
		        FileChannel.MapMode.READ_WRITE,
		                          0, fileSize).asDoubleBuffer();
			
			if (engine instanceof PostProcess) {
				PostProcess tmpEngine = (PostProcess) engine;
				tmpEngine.processNoiseMap(noiseMap, progress);
				
				high = 1.0;
				low = 0.0;

				
			} else {
						
				high = Double.NEGATIVE_INFINITY;
				low = Double.POSITIVE_INFINITY;
		
				noise = engine.getNoiseForVertex(0);
				low = noise;
				high = noise;
				noiseMap.put(noise);
				
				
				for (i = 1; i < vertexCount; i++) {
	
					noise = engine.getNoiseForVertex(i);
					if (noise < low) {
						low = noise;
					} else if (noise > high) {
						high = noise;
					}
					
					if(i % delta == 0) {
						progress.setProgressValue(i);
					}
					noiseMap.put(noise);
	
				}

				factor = high - low;

				if(high == Double.POSITIVE_INFINITY || low == Double.NEGATIVE_INFINITY) {

					JOptionPane pane = new JOptionPane("The Function graph produces infinity for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
					JDialog dialog = pane.createDialog(null, "Warning");
					dialog.setModal(false);
					dialog.setVisible(true);
				}

				
			}			
		    
			delta = pngHeight / 100;
			progress.setMaxValue(pngHeight);
			progress.setProgressValue(0);
			progress.setProgressText("Creating PNG file");
		
			System.err.println("high = " + high);		
			System.err.println("low = " + low);		
			System.err.println("factor = " + factor);
			System.err.println("65535.0 / factor = " + 65535.0 /factor);
			factor = 65535.0 / factor;
			vertexCount = 0;

			start();

			noiseMap.position(0);
			
			for (i = 0; i < pngHeight; i++) {
				for (j = 0; j < pngWidth; j++) {
					value =
						(int) ((noiseMap.get() - low)* factor);
					//	System.err.println(tmpDouble + " " + value);
					//                    System.err.println(value);
					pngData[j] = (short) (value & 0xFFFF);
					vertexCount++;
				}
				//					  System.err.println("pngData  " + pngData.length);
				createData(pngData);
				writeChunk(pngFile);
				if(i%delta == 0) {
					progress.setProgressValue(i);
				}
			}
			end();

			progress.dispose();
			rwCh.close();
			noiseMap = null;
			tmpdoubleFile.delete();
			pngFile.flush();
			pngFile.close();
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		
	    timeForRun = System.currentTimeMillis() - timeForRun;
	    return timeForRun;
	  		
	}


	private interface FilterMethod {
		public void init();
		public byte[] filter(byte[] scanlineToFilter);
	}
	
	private class Method0 implements FilterMethod{
		public void init() {};
		public byte[] filter(byte[] scanlineToFilter) {
			return scanlineToFilter;
		}
	}
	
	private class Method1 implements FilterMethod{
		
		byte[] returnArray;
		public void init() {
			returnArray = new byte[1 + (pngWidth * 2)];
		};

		public byte[] filter(byte[] scanlineToFilter) {
			
			int bytesPerPixel = pngBpp / 8;
			returnArray[0] = scanlineToFilter[0];
			returnArray[1] = scanlineToFilter[1];
			returnArray[2] = scanlineToFilter[2];
			for(int i=3; i<scanlineToFilter.length; i++) {
				returnArray[i] = (byte)((scanlineToFilter[i] - scanlineToFilter[i-bytesPerPixel]));
			}
			return returnArray;
		}
	}

	private void writeChunk(DataOutputStream out) throws IOException {
		
		/* write a check every 4MB */
		if(buffer.size() > 4194304 ) {
			byte[] dataArray = new byte[4];
			dataArray[0] = 'I';
			dataArray[1] = 'D';
			dataArray[2] = 'A';
			dataArray[3] = 'T';
			out.writeInt(buffer.size());
			out.write(dataArray);
			buffer.writeByteArrayToDataStream(out);
			crc.reset();
			crc.update(dataArray);
			buffer.updateCRC32ForByteArray(crc);
			out.writeInt((int) crc.getValue());
			buffer.reset();
		}
	}
	
	private class Compressor extends DeflaterOutputStream {
		
		Compressor (OutputStream out, Deflater def, int size) {
			super(out, def, size);
		}
		public void deflateStream() throws IOException{
			deflate();
		}
	}

	public JDialog getDialog(JFrame owner) {
		JDialog frame = new JDialog(owner, "PNG ("+ land.getType() + ")");
		frame.getContentPane().add(land.getPanel());
		return frame; 
	}
	
	public String getName() {
		return "PNG (<i>"+ land.getType() + "</i>)";
	}
	public void setLandscape(Landscape newLandscape) {
		land = newLandscape;	
	}
	
	public void setEngine(NoiseEngine newEngine) {
		engine = newEngine;
	}
	
	public void setFile(String fileName) {		
		pngFileName = fileName;
	}

	public void setFile(String fileName, String type) {
		pngFileName = fileName;
	}
	
	public int getDimensions() {
		return(2);
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		// TODO Auto-generated method stub
		land.getPanel().save(file);
		
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		land.getPanel().load(file);
		
	}

	
}

