//
//  CellCalculation.java
//  planetGenesis
//
//  Created by David Burnett on Tue Jan 28 2003.
//  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
//
package Utilities;


public class CellCalculation {

    public double calc(double[] neighbour) {

        return neighbour[1];     
    }
    

}
