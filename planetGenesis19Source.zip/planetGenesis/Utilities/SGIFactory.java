package Utilities;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.nio.DoubleBuffer;
import java.nio.channels.FileChannel;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import GUI.Progress;



public class SGIFactory implements Factory {


	private Landscape land; 
	private NoiseEngine engine;
	private String fileName;

	byte[] byteScanline;
	
	public SGIFactory() {
				
	}
	
	public JDialog getDialog(JFrame owner) {

		JDialog frame = new JDialog(owner, "SGI ("+ land.getType() + ")");
		frame.getContentPane().add(land.getPanel());
		return frame; 

	}

	public int getDimensions() {
		return 2;
	}

	public String getName() {
		return "SGI (<i>"+ land.getType() + "</i>)";
	}

	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		land.getPanel().load(file);
		
	}

	public long make(Progress progress, boolean dummyParameter) {

		DataOutputStream sgiFile;

		
		long timeForRun = System.currentTimeMillis();
		
		int value, i, j, vertexCount;
		double high = Double.NEGATIVE_INFINITY;
		double low = Double.POSITIVE_INFINITY;

		double noise;
		double factor  = 1.0;
		
		try {
			sgiFile =  new DataOutputStream(new FileOutputStream(fileName));
		} catch (FileNotFoundException e) {

			e.printStackTrace();
			progress.dispose();
			JOptionPane pane = new JOptionPane("Could not open a file called '" + fileName + "'!" , JOptionPane.ERROR_MESSAGE);
			JDialog dialog = pane.createDialog(null, "Warning");
			dialog.setModal(false);
			dialog.setVisible(true);
			return -1;
		} 

		try {

 			land.setWorldSpace();
			land.setProjection(Landscape.Projection2D);
			engine.setProjection(Landscape.Projection2D);
			engine.setTerrain(land.getNewLandscape());
			//land.setNoiseSpace(engine);
			engine.initNoise();
			System.err.println("Factory using " + engine.name());

			int width = land.xMesh;
			int height = land.zMesh;
			short[] sgiData = new short[width];
			byteScanline = new byte[width * 2];

			
			vertexCount = height * width;
			double delta = vertexCount / 100;

			progress.setMaxValue(vertexCount);
			progress.setProgressText("Scaling Noise");

			
			File tmpdoubleFile = File.createTempFile("tmpDouble", null);

			FileChannel rwCh =
                new RandomAccessFile(
              		  tmpdoubleFile,"rw").
                        getChannel();			

		    long fileSize = vertexCount * 8;
		    DoubleBuffer noiseMap = rwCh.map(
		        FileChannel.MapMode.READ_WRITE,
		                          0, fileSize).asDoubleBuffer();
			
			if (engine instanceof PostProcess) {
				PostProcess tmpEngine = (PostProcess) engine;
				tmpEngine.processNoiseMap(noiseMap, progress);
				
				high = 1.0;
				low = 0.0;

				
			} else {
						
				high = Double.NEGATIVE_INFINITY;
				low = Double.POSITIVE_INFINITY;
		
				noise = engine.getNoiseForVertex(0);
				low = noise;
				high = noise;
				noiseMap.put(noise);
				
				
				for (i = 1; i < vertexCount; i++) {
	
					noise = engine.getNoiseForVertex(i);
					if (noise < low) {
						low = noise;
					} else if (noise > high) {
						high = noise;
					}
					
					if(i % delta == 0) {
						progress.setProgressValue(i);
					}
					noiseMap.put(noise);
	
				}

				factor = high - low;

				if(high == Double.POSITIVE_INFINITY || low == Double.NEGATIVE_INFINITY) {

					JOptionPane pane = new JOptionPane("The Function graph produces infinity for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
					JDialog dialog = pane.createDialog(null, "Warning");
					dialog.setModal(false);
					dialog.setVisible(true);
				}

				
			}			
		    
			delta = height / 100;
			progress.setMaxValue(height);
			progress.setProgressValue(0);
			progress.setProgressText("Creating SGI file");
		
			System.err.println("high = " + high);		
			System.err.println("low = " + low);		
			System.err.println("factor = " + factor);
			System.err.println("65535.0 / factor = " + 65535.0 /factor);
			factor = 65535.0 / factor;
			vertexCount = 0;

			
			writeHeader(sgiFile, width, height);

			noiseMap.position(0);
			
			for (i = 0; i < height; i++) {
				for (j = 0; j < width; j++) {
					value =
						(int) ((noiseMap.get() - low)* factor);
					//	System.err.println(tmpDouble + " " + value);
					//                    System.err.println(value);
					sgiData[j] = (short) (value & 0xFFFF);
					vertexCount++;
				}
				//					  System.err.println("pngData  " + pngData.length);

				writeData(sgiData, sgiFile);
				
				if(i%delta == 0) {
					progress.setProgressValue(i);
				}
			}

			progress.dispose();
			rwCh.close();
			noiseMap = null;
			tmpdoubleFile.delete();
			sgiFile.flush();
			sgiFile.close();
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		
	    timeForRun = System.currentTimeMillis() - timeForRun;
	    return timeForRun;
		
		
	}

	public void save(ObjectOutputStream file) throws IOException {

		land.getPanel().save(file);
		
	}

	public void setEngine(NoiseEngine newNoise) {

		engine = newNoise;
		
	}

	public void setFile(String fileName) {		
		this.fileName = fileName;
	}

	public void setFile(String fileName, String type) {
		this.fileName = fileName;
	}
	

	public void setLandscape(Landscape newLandscape) {

		land = newLandscape;	
		
	}
	
	private void writeHeader(DataOutputStream sgiFile, int width, int height) {
	
		/*
	      2 bytes | short  | MAGIC     | IRIS image file magic number
	      1 byte  | char   | STORAGE   | Storage format
	      1 byte  | char   | BPC       | Number of bytes per pixel channel 
	      2 bytes | ushort | DIMENSION | Number of dimensions
	      2 bytes | ushort | XSIZE     | X size in pixels 
	      2 bytes | ushort | YSIZE     | Y size in pixels 
	      2 bytes | ushort | ZSIZE     | Number of channels
	      4 bytes | long   | PIXMIN    | Minimum pixel value
	      4 bytes | long   | PIXMAX    | Maximum pixel value
	      4 bytes | char   | DUMMY     | Ignored
	     80 bytes | char   | IMAGENAME | Image name
	      4 bytes | long   | COLORMAP  | Colormap ID
	    404 bytes | char   | DUMMY     | Ignored
		*/
		
		try {
			sgiFile.write(short2ByteArray((short)474));
			sgiFile.write((byte)0);
			sgiFile.write((byte)2);
			sgiFile.write(short2ByteArray((short)2));
			sgiFile.write(short2ByteArray((short)width));
			sgiFile.write(short2ByteArray((short)height));
			sgiFile.write(short2ByteArray((short)1));
			sgiFile.write(int2ByteArray(0));
			sgiFile.write(int2ByteArray(0xFFFF));
			byte[] buffer = new byte[4];
			sgiFile.write(buffer);
			String nameString = "planetGenesis";
			sgiFile.write(nameString.getBytes());
			buffer = new byte[67];
			sgiFile.write(buffer);
			sgiFile.write(int2ByteArray(0));
			buffer = new byte[404];
			sgiFile.write(buffer);
			
		} catch (IOException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}			
				

	
	private void writeData(short[] scanline, DataOutputStream sgiFile) {

		//        byteScanline = new byte[(scanline.length * 2) + 1];
		for (int i = 0; i < scanline.length; i++) {
			byteScanline[(i * 2) ] = (byte) ((scanline[i] >> 8) & 0xFF);
			byteScanline[(i * 2) + 1] = (byte) (scanline[i] & 0xFF);
		}

		try {
			sgiFile.write(byteScanline);
		} catch (IOException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}	
	
	private byte[] int2ByteArray(int oldint) {
		byte[] convert = new byte[4];
		convert[0] = (byte) ((oldint >> 24) & 0xFF);
		convert[1] = (byte) ((oldint >> 16) & 0xFF);
		convert[2] = (byte) ((oldint >> 8) & 0xFF);
		convert[3] = (byte) (oldint & 0xFF);

		return convert;
	}

	private byte[] short2ByteArray(short oldShort) {
		byte[] convert = new byte[2];
		convert[0] = (byte) ((oldShort >> 8) & 0xFF);
		convert[1] = (byte) (oldShort & 0xFF);

		return convert;
	}
	
	private short[] int2ShortArray(int oldint) {
		short[] convert = new short[4];
		convert[1] = (byte) ((oldint >> 8) & 0xFFFF);
		convert[2] = (byte) ((oldint >> 0) & 0xFFFF);

		return convert;
	}	

}
