/*
 * Created on Sep 6, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package Utilities;

/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class SplinePatch {

	double[] knots;
	double[] points;
	int order;

	public void initSpline(double[] points, int order) {

		this.points = points;
		this.order = order;
		 
		knots = makeKnots(order, points.length);
	}
	
	public double spline(double u, double v, double[][] controlPoints ) {
		
		double tmp = 0,  topHalf = 0, bottomHalf = 0;
		u *= (points.length - 1);
		v *= (points.length - 1);
		
		
		for(int i = 0; i<controlPoints.length; i++) {
			for(int j = 0; j<controlPoints.length; j++) {
				tmp = blend(i, order, u) * blend(j, order, v);
				topHalf += (controlPoints[i][j] * tmp);
				bottomHalf += tmp;
			}
		}
		
		return bottomHalf != 0 ? topHalf / bottomHalf : topHalf ;
	}

	private double blend(int index, int order, double inputValue) {
	
		
		if(order == 0) {
			if(knots[index] <= inputValue && inputValue < knots[index+1] && knots[index] < knots[index+1]) {
				return 1;
			} 
				
			return 0;
			 
		}
		
		/* avoid divide by zero errors by checking
		 * the two demoninators for the equation
		 */
		 
		double rht, lht;
		

		if(knots[index+order] == knots[index]) {
			lht = 0.0;
		} else {
			lht = (inputValue - knots[index]) / (knots[index+order] - knots[index]) * blend(index, order-1, inputValue);
		}

		if(knots[index+order+1] == knots[index+1]) {
			rht = 0.0;
		} else {
			rht = (knots[index+order+1] - inputValue) / (knots[index+order+1] - knots[index+1]) * blend(index+1, order-1, inputValue);
		}

		return lht + rht;

	}

	private double[] makeKnots(int order, int numberOfPoints) {
		double[] tmp = new double[order + numberOfPoints + 1];
		for(int i = 0; i <= order + numberOfPoints; i++ ) {
			if(i < order) {
				tmp[i] = 0; 
			} else if (i > order + numberOfPoints - 2) {
				tmp[i] = numberOfPoints - 1;
			} else {
				tmp[i] = tmp[i-1] + 1;
			}
		}
		return tmp;
	}

}
