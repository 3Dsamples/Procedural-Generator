package Utilities;

import java.nio.DoubleBuffer;

import GUI.Progress;

public abstract class PostProcess extends NoiseEngine {

	protected NoiseEngine noise;

	protected void populateNoiseMap(DoubleBuffer noiseMap, Progress progress) {

		noise.initNoise();
		int vertexCount = noise.getTerrain().getVertexCount();		
		double delta = vertexCount / 100;
		
		
		progress.setMaxValue(vertexCount);
		progress.setProgressText("Calculating Noise");
		progress.setProgressValue(0);
		noiseMap.position(0);
		
		Vertex noisePoint;
		
		for(int i=0; i < vertexCount; i++) {
			noisePoint = noise.getTerrain().getNoiseVertex(i);
			noiseMap.put(noise.getNoiseForVertex(noisePoint));
			if(i % delta == 0) {
				progress.setProgressValue(i);
			}
		}
		
		return;

	}

	protected void processNoiseMap(DoubleBuffer noiseMap, Progress progress) {
		
		if ( noise instanceof PostProcess) {
			PostProcess temp = (PostProcess)noise;
			temp.processNoiseMap(noiseMap, progress);
		} else {
			populateNoiseMap(noiseMap, progress);
		}
		
		process(noiseMap, progress);

	}
	
	abstract protected void process(DoubleBuffer noiseMap, Progress progress);
	
	
	
	public void setNoiseEngine(NoiseEngine noise) {
		this.noise = noise;
	}	

	public void initNoise() {		
		noise.initNoise();
		return;
	}

	public void setTerrain(Landscape terrain) {
		this.terrain = terrain.getNewLandscape();
		noise.setTerrain(terrain);
		return;
	}	

}
