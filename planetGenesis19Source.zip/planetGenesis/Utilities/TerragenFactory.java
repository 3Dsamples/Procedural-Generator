/*
 * Created on Apr 15, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package Utilities;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import GUI.ExtendedHashBasedPanel;
import GUI.Progress;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class TerragenFactory implements Factory {

	private Landscape land;
	private NoiseEngine engine;

	private int xPoints, yPoints, radius, height, base;
	private float scale;
	private String terragenFileName;
	private ExtendedHashBasedPanel panel;

	public TerragenFactory() {

		xPoints = 257;
		yPoints = 257;
		scale = 30;
		radius = 6370;
		height = 30;
		base = 0;
		
		
		String[] defaults = new String[5];
//		defaults[0] = "129 x 129";
		defaults[0] = "257 x 257";
		defaults[1] = "513 x 513";
		defaults[2] = "1025 x 1025";
		defaults[3] = "2049 x 2049";
		defaults[4] = "4097 x 4097";

		panel = new ExtendedHashBasedPanel();
		
		panel.addDropDown("size", "Size", defaults, "Terragen Terrain size");
		panel.addTextBox("min", "Minimum Height (m)",  "" + 0, "Scale of the Terragen terrain file in metres per point");		
		panel.addTextBox("max", "Maximum Height (m)",  "" + 1000, "Scale of the Terragen terrain file in metres per point");
//		panel.addTextBox("HSCALE", "Elevation",  "" + height, "Scale of the Terragen terrain file in metres per point");		
//		panel.addTextBox("BASEHEIGHT", "BaseHeight",  "" + base, "Scale of the Terragen terrain file in metres per point");		
		panel.addTextBox("SCAL", "Scale (m/point)",  "" + scale, "Scale of the Terragen terrain file in metres per point");		
		panel.addCheckBox("CRVM", "Curved Planet", false, "Determines if the terrain allows for planetary curvature");
		panel.addTextBox("CRAD", "Radius (km)",  "" + radius, "<html><Radius of the Terragen planet.<br>Set to Zero for a flat planet</html>");
		
		panel.addOkayApplyRestorePanel();		
		
		panel.setValue("size", "257 x 257");
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#make(GUI.Progress)
	 */
	public long make(Progress progress, boolean dummyParameter) {

		DataOutputStream terragenFile;
	    long  timeForRun = System.currentTimeMillis();
	  
		try {
			terragenFile =
					new DataOutputStream(
						new FileOutputStream(terragenFileName));

		} catch(FileNotFoundException e) {
			e.printStackTrace();
			progress.dispose();
			JOptionPane pane = new JOptionPane("Could not open a file called '" + terragenFileName + "'!" , JOptionPane.ERROR_MESSAGE);
			JDialog dialog = pane.createDialog(null, "Warning");
			dialog.setModal(false);
			dialog.setVisible(true);
			return -1;
		}
		
		double noise, factor;
		double high = Double.NEGATIVE_INFINITY;
		double low = Double.POSITIVE_INFINITY;

		String size = panel.getText("size");
		
		if(size.compareTo("257 x 257") == 0) {
			xPoints = yPoints = 257;
		} else if(size.compareTo("129 x 129") == 0) {
			xPoints = yPoints = 129;
		} else if(size.compareTo("513 x 513") == 0) {
			xPoints = yPoints = 513;
		} else if(size.compareTo("1025 x 1025") == 0) {
			xPoints = yPoints = 1025;
		} else if(size.compareTo("2049 x 2049") == 0) {
			xPoints = yPoints = 2049;
		} else if(size.compareTo("4097 x 4097") == 0) {
			xPoints = yPoints = 4097;
		}   
		
		
		land.setWorldSpace(xPoints, yPoints, 0.0);
		land.setProjection(Landscape.Projection2D);
		engine.setProjection(Landscape.Projection2D);
		engine.setTerrain(land.getNewLandscape());
		//land.setNoiseSpace(engine);
		engine.initNoise();
		System.err.println("Factory using " + engine.name());

		int points = xPoints * yPoints;
		progress.setMaxValue(yPoints);
		noise = 0;
		progress.setProgressText("Scaling Noise");

		try {
			File tmpdoubleFile = File.createTempFile("tmpDouble", null);
			DataOutputStream tmp =
				new DataOutputStream(
					new BufferedOutputStream(
						new FileOutputStream(tmpdoubleFile),
						xPoints * 8));
			for (int y = yPoints-1; y >= 0 ; y--) {
				for (int x = 0; x < xPoints; x++) {
					noise = engine.getNoiseForVertex(x + (y * xPoints));
					if (noise < low) {
						low = noise;
					}
					if (noise > high) {
						high = noise;
					}
					tmp.writeDouble(noise);
				}
				progress.setProgressValue(yPoints - y);
			}

			tmp.close();

			DataInputStream inTmp =
				new DataInputStream(
					new BufferedInputStream(
						new FileInputStream(tmpdoubleFile),
						xPoints * 8));

			
			writeHeaders(terragenFile);
		
			double terragenRange = 1.0/height;
			int min = panel.getInt("min");
			int max = panel.getInt("max");
			
			// factor converts value between high and low to a value between min and max 
			factor = (max - min) / (high - low);
			
			progress.setMaxValue(points);
			progress.setProgressValue(0);
			progress.setProgressText("Writing Terragen File");

			double value;
			double delta = points/100; 
			for (int i = 0; i < points; i++) {
			
				value = inTmp.readDouble();
				
				if(value == low) {
					System.err.println("");
				}
				value -= low;
				value *= factor;
				value += min;
				
				
				value -= base;
				
				value *= terragenRange;
				
				
				value *= 65535.0;
				
						
				terragenFile.write(shortToIntelBytes((short) Math.floor(value )));
				if (i % delta == 0) {
					progress.setProgressValue(i);
				}
			}

			if(points % 2 > 0) {
				terragenFile.writeShort(0);
			}
			writeEnd(terragenFile);
			terragenFile.flush();
			terragenFile.close();
			inTmp.close();
			
			tmpdoubleFile.delete();

		} catch (Exception e) {
			e.printStackTrace();

		}

		progress.dispose();
	    timeForRun = System.currentTimeMillis() - timeForRun;
        return timeForRun;
	  
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#setLandscape(Utilities.Landscape)
	 */
	public void setLandscape(Landscape newLandscape) {
		land = newLandscape;
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#setEngine(Utilities.NoiseEngine)
	 */
	public void setEngine(NoiseEngine newNoise) {
		engine = newNoise;
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#setFile(java.lang.String)
	 */
	public void setFile(String fileName) {
		terragenFileName = fileName;

	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#setFile(java.lang.String, java.lang.String)
	 */
	public void setFile(String fileName, String type) {
		terragenFileName = fileName;
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#getFrame()
	 */
	public JDialog getDialog(JFrame owner) {
		JDialog frame = new JDialog(owner, getName());
		frame.getContentPane().add(panel);
		return frame; 
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#getName()
	 */
	public String getName() {
		return "Terragen";
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#getDimensions()
	 */
	public int getDimensions() {
		return 2;
	}
	
	public void writeHeaders(DataOutputStream out) throws IOException {
		// TODO Auto-generated method stub
		short size;
		float tmpFloat;
		out.writeBytes("TERRAGENTERRAIN SIZE");
		
		size = (short)(xPoints < yPoints ? xPoints : yPoints);
		size--;
		out.write(shortToIntelBytes(size));
		out.writeBytes("\0\0XPTS");
		out.write(shortToIntelBytes((short)xPoints));
		out.writeBytes("\0\0YPTS");
		out.write(shortToIntelBytes((short)yPoints));
		out.writeBytes("\0\0SCAL");
		float scale = (float)panel.getDouble("SCAL");
		out.write(floatToIntelBytes(scale));
		out.write(floatToIntelBytes(scale));
		out.write(floatToIntelBytes(scale));
		out.writeBytes("CRAD");
		tmpFloat = (float)panel.getDouble("CRAD");
		out.write(floatToIntelBytes(tmpFloat));
		out.writeBytes("CRVM");
		if(panel.getCheckBoxState("CRVM")) {
			out.write(intToIntelBytes(1));					
		} else {
			out.writeInt(0);					
		}	
		out.writeBytes("ALTW");
		
		int min = panel.getInt("min");
	    int max = panel.getInt("max");
	    int hScale1, hScale2;

	    	base = max - min;
	    	base = (int)((base / 2.0) + 0.5);
	    	base += min;
	    base = (int)((base / scale));
	    base *= scale;
	    
	    
	    hScale1 = ( (int)(Math.ceil(max))-base ) ;
	    hScale2 = (  base - (int)(Math.floor(min)) );
	    
	    if (hScale1 > hScale2) {
	    		height = hScale1;
	    } 	else {
	     	height = hScale2;
	    }   		
		
	    height = (int)(Math.ceil(height / scale));
	    height *= scale;
	    height *= 2;
	    
	    tmpFloat = height / scale;
		out.write(shortToIntelBytes((short)(tmpFloat + 0.5f)));					

		tmpFloat = base / scale;
		out.write(shortToIntelBytes((short)(tmpFloat + 0.5f)));					
		
	}

	public void writeEnd(DataOutputStream out)  throws IOException {
		out.writeBytes("EOF ");
	}
	
	private byte[] shortToIntelBytes(short oldint) {
		byte[] convert = new byte[2];
		convert[1] = (byte) ((oldint >> 8) & 0xFFFF);
		convert[0] = (byte) ((oldint >> 0) & 0xFFFF);

		return convert;
	}

	private byte[] intToIntelBytes(int oldint) {
		byte[] convert = new byte[4];
		convert[3] = (byte) (oldint >> 24);
		convert[2] = (byte) (oldint >> 16);
		convert[1] = (byte) (oldint >> 8);
		convert[0] = (byte) (oldint >> 0);

		return convert;
	}

	public static byte[] floatToIntelBytes(float value){
	   int i = Float.floatToIntBits(value);
	   byte[] result = new byte[4];
	   result[3] = (byte)(i>>24);
	   result[2] = (byte)(i>>16);
	   result[1] = (byte)(i>>8);
	   result[0] = (byte)i;
	   
	   return result;
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		// TODO Auto-generated method stub
		panel.save(file);
	}

	/* (non-Javadoc)
	 * @see Utilities.Factory#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		panel.load(file);

	}


	
	
}
