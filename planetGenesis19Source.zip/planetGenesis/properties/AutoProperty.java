package properties;

import java.awt.Component;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.JSpinner.NumberEditor;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;
import javax.swing.text.NumberFormatter;

import GUI.EasyGBC;


public class AutoProperty
{

	/**
	 * Owner of the properties
	 */
	Object owner;
	Class ownerClass;
	public enum DisplayType { TEXT, COMBOBOX, RADIO, RANDOMSEED};
	
	Map<String, PropertyBundle> props=new HashMap<String, PropertyBundle>();
	Vector<String> orderedProps=new Vector<String>();
	
//	Vector<String> groupNames=new Vector<String>();
//	Vector<String[]> groups=new Vector<String[]>();
	Map<String, Group> groups = new HashMap<String, Group>();
	
	
	/*
	 * TODO : improve display of property panel with gridbag
	 */
	Vector<String> displayOrder=new Vector<String>();
	
	public AutoProperty(Object owner)
	{
		super();
		this.owner = owner;
		this.ownerClass=owner.getClass();
	}
	
	public void registerProperty(String name) throws AutoPropertyException
	{
		registerProperty(name, name, name, null, DisplayType.TEXT);
	}
	
	public void registerProperty(String name, String label, String toolTip) throws AutoPropertyException
	{
		registerProperty(name, label, toolTip, null, DisplayType.TEXT);
	}
	
	public void registerRandomSeed(String name) throws AutoPropertyException
	{
		registerProperty(name, name, "Random Seed", null, DisplayType.RANDOMSEED);
	}
	
	public void registerComboProperty(String name, String label, String toolTip, String[] allowedValues) throws AutoPropertyException
	{
		if(allowedValues==null)
			throw new AutoPropertyException("ComboBox property needs an array of allowed values");
		registerProperty(name, label, toolTip, allowedValues, DisplayType.COMBOBOX);
	}

	public void registerRadioProperty(String name, String label, String toolTip, String[] allowedValues) throws AutoPropertyException
	{
		if(allowedValues==null)
			throw new AutoPropertyException("RadioButton property needs an array of allowed values");
		registerProperty(name, label, toolTip, allowedValues, DisplayType.RADIO);
	}
	
	public void registerProperty(String name, String label, String toolTip, 
			String[] allowedvalues, DisplayType displayType) throws AutoPropertyException
	{
		PropertyBundle bundle=new PropertyBundle();
		
		//try to access the property
		try
		{
			String getName="get"+Character.toUpperCase(name.charAt(0))+name.substring(1);
			String setName="set"+Character.toUpperCase(name.charAt(0))+name.substring(1);
			
			Method getM=null, setM=null;
			Method[] allM=ownerClass.getMethods();
			for(Method m:allM)
			{
				if(m.getName().equals(getName) && m.getParameterTypes().length==0)
				{
					getM=m;
				}
				if(m.getName().equals(setName) && m.getParameterTypes().length==1)
				{
					setM=m;
				}
				if(getM!=null && setM!=null)
					break;
			}
			
//			try
//			{
//				getM=ownerClass.getMethod(getName, null);
//			} catch (NoSuchMethodException e){/*e.printStackTrace();*/}
//			try
//			{
//				setM=ownerClass.getMethod(setName, new Class[]{int.class});
//			} catch (NoSuchMethodException e){e.printStackTrace();}
			
			Field f=null;
			try {
				f=ownerClass.getField(name);
			}catch(NoSuchFieldException e){/*e.printStackTrace();*/}
			if(f==null && getM==null)
				throw new AutoPropertyException("No way to get property "+name+", maybe field/getter not public ?");
			if(f==null && setM==null)
				throw new AutoPropertyException("No way to set property "+name+", maybe field/getter not public ?");
			
			bundle.field=f;
			bundle.getM=getM;
			bundle.setM=setM;
			bundle.displayType=displayType;
			
			props.put(name, bundle);
			Object defaultValue=getValue(name);
			Class type=defaultValue.getClass();
			bundle.type=type;
			bundle.defaultValue=defaultValue;
			
		} catch (Exception e)
		{
			props.put(name, null);
			throw new AutoPropertyException(e);
		}
		
		
		createView(bundle, bundle.type, name, label, toolTip, allowedvalues, displayType);
		
		
		orderedProps.add(name);
		displayOrder.add(name);
	}
	
	void createView(PropertyBundle bundle, Class propertyClazz, String name, String label, String toolTip, 
			String[] allowedValues, DisplayType displayType) throws AutoPropertyException
	{
//		System.out.println("creating view for "+name);
		bundle.label=label;
		bundle.toolTip=toolTip;
		bundle.values=allowedValues;
		
		String defaultValue=bundle.defaultValue.toString();
		
		if(displayType==DisplayType.TEXT)
		{
			JSpinner s=null;
			if(propertyClazz==Double.class)
			{
				s=new JSpinner(new SpinnerNumberModel(
						((Double)bundle.defaultValue).doubleValue(), Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, 1.0));
				((NumberFormatter)((NumberEditor)s.getEditor()).getTextField().getFormatter()).setFormat(new DecimalFormat("0.0#############"));
				
			}
			else if(propertyClazz==Float.class)
			{
				s=new JSpinner(new SpinnerNumberModel(
						((Float)bundle.defaultValue).floatValue(), Float.NEGATIVE_INFINITY, Float.POSITIVE_INFINITY, 1.0f));
				((NumberFormatter)((NumberEditor)s.getEditor()).getTextField().getFormatter()).setFormat(new DecimalFormat("0.0#############"));
			}
			else if(propertyClazz==Integer.class)
			{
				s=new JSpinner(new SpinnerNumberModel(
						((Integer)bundle.defaultValue).intValue(), Integer.MIN_VALUE, Integer.MAX_VALUE, 1));
			}
			if(s!=null)
			{
				s.setToolTipText(toolTip);
				bundle.view=s;
			}
			else
			{
				JTextField f=new JTextField(bundle.defaultValue.toString());;
				f.setToolTipText(toolTip);
				f.setText(defaultValue);
				bundle.view=f;
			}
			
		}
		else if(displayType==DisplayType.RANDOMSEED)
		{
			JTextField f=new JTextField(bundle.defaultValue.toString());;
			f.setToolTipText(toolTip);
			f.setText(defaultValue);
			bundle.view=f;
		}
		else if(displayType==DisplayType.RADIO)
		{
			if(allowedValues==null)
			{
				throw new AutoPropertyException("Must give multiple choices for Radio display type");
			}
			JPanel p=new JPanel();
			p.setBorder(BorderFactory.createTitledBorder(label));
			p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
			ButtonGroup bg=new ButtonGroup();
			for(int i=0; i<allowedValues.length; i++)
			{
				JRadioButton b=new JRadioButton(allowedValues[i]);
				p.add(b);
				bg.add(b);
				if(allowedValues[i].equals(defaultValue))
				{
					bg.setSelected(b.getModel(), true);
				}
			}
			bundle.view=p;
			bundle.buttonGroup=bg;
		}
		else
		{
			JComboBox cb=new JComboBox(allowedValues);
			cb.setToolTipText(toolTip);
			cb.setEditable(false);
			bundle.view=cb;
			int selectedIndex=0;
			for(int i=0; i<allowedValues.length; i++)
			{
				if(allowedValues[i].equals(defaultValue))
				{
					selectedIndex=i;
					break;
				}
			}
			cb.setSelectedIndex(selectedIndex);
		}
	}

	public JPanel createPanel()
	{
		JPanel panel=new JPanel();
//		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setLayout(new GridBagLayout());
		EasyGBC gbc_l=new EasyGBC().center().xy(1, 1).weight(.1).insets(2, 2, 2, 2),
				gbc_r=gbc_l.clone().nextCol().weight(.1, 1).fillH(),
				gbc_p=gbc_l.clone(),
				gbc_pr=gbc_r.clone();
		
//		Set<String> done=new HashSet<String>();
		
		for(String name: displayOrder)
		{
//			int i=groupNames.indexOf(name);
			Group g = groups.get(name);
			if(g != null)
			{
				//handle group
				LockingListener ll = new LockingListener(g.items);
				gbc_p.xy(1, 1); gbc_pr.xy(2, 1);
				JPanel p=new JPanel();
				p.setLayout(new GridBagLayout());
				
				p.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder()
						, g.name));
				
				
				for(String item:g.items)
				{
					System.out.println("Adding "+item+" in "+g.name);
					
					PropertyBundle bundle=props.get(item);
					if(bundle.view instanceof JTextField || bundle.view instanceof JSpinner)
					{
						JLabel l=new JLabel(bundle.label);
						l.setHorizontalAlignment(SwingConstants.RIGHT);
						l.setToolTipText(bundle.toolTip);
						p.add(l, gbc_p.nextRow());
						p.add(bundle.view, gbc_pr.xy(2, gbc_p.gridy));
						
						if(g.lockable) {
							if (bundle.view instanceof JTextField)
							{
								JTextField vv = (JTextField) bundle.view;
								vv.getDocument().addDocumentListener(ll);
							} else if (bundle.view instanceof JSpinner)
							{
								JSpinner vv = (JSpinner) bundle.view;
								vv.addChangeListener(ll);
							}
						}
					}
					else
					{
						p.add(bundle.view, gbc_pr.xy(2, gbc_p.gridy));
					}
				}
				
				if(g.lockable)
				{
					JCheckBox lockCheckBox = new JCheckBox("Lock fields");
					p.add(lockCheckBox, gbc_pr.xy(2, gbc_p.gridy+1));
					lockCheckBox.addActionListener(ll);
				}
				
				panel.add(p, gbc_l.nextRow().clone().wh(2, 1).fillH());
			}
			else
			{
				System.out.println("Adding "+name);
				PropertyBundle bundle=props.get(name);
				
				if(bundle.displayType!=DisplayType.RADIO && bundle.displayType!=DisplayType.RANDOMSEED)
				{
					JLabel l=new JLabel(bundle.label);
					l.setHorizontalAlignment(SwingConstants.RIGHT);
					panel.add(l, gbc_l.nextRow());
					l.setToolTipText(bundle.toolTip);
					panel.add(bundle.view, gbc_r.xy(2, gbc_l.gridy));
				}
				else
				{
					if(bundle.displayType==DisplayType.RANDOMSEED)
					{
						JPanel p=new JPanel();
						p.setBorder(BorderFactory.createTitledBorder("Random Seed"));
						p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
						((JTextField)bundle.view).setHorizontalAlignment(SwingConstants.RIGHT);
						p.add(bundle.view);
						JButton b=new JButton("Randomize");
						b.addActionListener(new RandomizeActionListener((JTextComponent) bundle.view));
						p.add(b);
						panel.add(p, gbc_l.nextRow().clone().wh(2, 1).fillH());
					}
					else
						panel.add(bundle.view, gbc_l.nextRow().clone().wh(2, 1).fillH());
				}
			}
		}
		return panel;
	}
	protected static class RandomizeActionListener implements ActionListener
	{
		JTextComponent c;
		public RandomizeActionListener(JTextComponent c)
		{
			this.c=c;
		}
		public void actionPerformed(ActionEvent e)
		{
			c.setText(Long.toString(System.currentTimeMillis()));
		}
	}
	public Object getValue(String name) throws AutoPropertyException
	{
		PropertyBundle bundle=props.get(name);
		if(bundle==null)
			throw new AutoPropertyException("Property "+name+" is not registered");
		
		if(bundle.getM!=null)
		{
			try
			{
				return bundle.getM.invoke(owner, (Object[])null);
			} catch (Exception e)
			{
				throw new AutoPropertyException("Couldnt invoke getter "+bundle.getM
						+": "+e.getMessage(), e);
			}
		}
		else
		{
			try
			{
				return bundle.field.get(owner);
			} catch (Exception e)
			{
				throw new AutoPropertyException("Couldnt get field "+bundle.field
						+": "+e.getMessage(), e);
			}
		}
	}
	
	public void setValue(String name, Object value) throws AutoPropertyException
	{
//		System.out.println("Setting "+name+" to "+value);
		PropertyBundle bundle=props.get(name);
		if(bundle==null)
			throw new AutoPropertyException("Property "+name+" is not registered");
		
		if(bundle.setM!=null)
		{
			try
			{
				bundle.setM.invoke(owner, new Object[]{value});
			} catch (Exception e)
			{
				throw new AutoPropertyException("Couldnt invoke setter "+bundle.setM
						+": "+e.getMessage(), e);
			}
		}
		else
		{
			try
			{
				bundle.field.set(owner, value);
			} catch (Exception e)
			{
				throw new AutoPropertyException("Couldnt set field "+bundle.field
						+": "+e.getMessage(), e);
			}
		}
	}

	/**
	 * Can only create groups of texts
	 * @param name
	 * @param lockable Can the fields be locked to have the same value ?
	 * @param items
	 * @throws AutoPropertyException 
	 */
	public void createGroup(String name, boolean lockable, String...items) throws AutoPropertyException
	{
		if(props.containsKey(name))
			throw new AutoPropertyException("Group name "+name+" coincides with a property name. Please try a different name. Try different case or appending or prepending spaces if you really must have this group name");
		for(String item:items)
		{
			if(!props.containsKey(item))
				throw new AutoPropertyException("Property "+item+" was not found while creating group "+name);
		}
//		groupNames.add(name);
//		groups.add(items);
		groups.put(name, new Group(name, items, lockable));
		
		displayOrder.removeAll(Arrays.asList(items));
		displayOrder.add(name);
	}
	
	/**
	 * Copy values from from object to UI
	 *
	 */
	public void restoreSettimgs()
	{
//		System.out.println("Restoresettings callednumprops "+orderedProps.size()+" "+props.size());
		for(String name:orderedProps)
		{
			try
			{
				Object val=getValue(name);
//				System.out.println("got "+name+" as "+val);
				PropertyBundle bundle=props.get(name);
				JComponent view=bundle.view;
				DisplayType disp=bundle.displayType;
				
				if(disp==DisplayType.TEXT || disp==DisplayType.RANDOMSEED)
				{
//					System.out.println("Setting text to "+val);
//					System.out.println(view);
					if(view instanceof JSpinner)
						((JSpinner)view).setValue(val);
					else
						((JTextComponent)view).setText(val.toString());
				}
				else if(disp==DisplayType.COMBOBOX)
				{
					int sel=0;
					JComboBox jb=(JComboBox) view;

					for(int i=0; i<jb.getItemCount(); i++)
					{
						Object item=jb.getItemAt(i);
						if(val.equals(item))
						{
							sel=i;
							break;
						}
					}
					
					jb.setSelectedIndex(sel);
				}
				else if(disp==DisplayType.RADIO)
				{
					int sel=0;
					
					for(int i=0; i<view.getComponentCount(); i++)
					{
						String item=((JRadioButton)view.getComponent(i)).getText();
						if(val.equals(item))
						{
							sel=i;
							break;
						}
					}
					
					bundle.buttonGroup.setSelected(((JRadioButton)view.getComponent(sel)).getModel(), true);
				}
				view.repaint();
			} catch (AutoPropertyException e)
			{
				System.err.println("Could not restore "+name);
				e.printStackTrace();
			}
				
		}
	}

	/**
	 * Copy properties from UI to objects
	 * @throws AutoPropertyException 
	 *
	 */
	public void storeSettings() throws AutoPropertyException
	{
//		System.out.println("Storesettings called numprops "+orderedProps.size()+" "+props.size());
		String err="";
		for(String name:orderedProps)
		{
				
			PropertyBundle bundle=props.get(name);
			JComponent view=bundle.view;
//			System.out.println("for "+name+" got "+bundle.hashCode()+" and "+bundle.view.hashCode());
			DisplayType dispType=bundle.displayType;
			
			Object val=null;
			if(dispType==DisplayType.TEXT || dispType==DisplayType.RANDOMSEED)
			{
				if(view instanceof JSpinner)
					val=((JSpinner)view).getValue();
				else
					val=((JTextField)view).getText();
//				System.out.println("Got val "+val+" from "+view.hashCode());
			}
			else if(dispType==DisplayType.COMBOBOX)
			{
				val=((JComboBox)view).getSelectedItem();
			}
			else if(dispType==DisplayType.RADIO)
			{
				for(Component c:view.getComponents())
				{
					if(((JRadioButton)c).isSelected())
					{
						val=((JRadioButton)c).getText();
						break;
					}
				}
			}
			
			Class type=bundle.type;
			if(val instanceof String)
			{
				if(type==Double.class || type==Float.class)
				{
					try{
						Double d=Double.parseDouble((String) val);
						if(type==Float.class)
							setValue(name, new Float(d));
						else
							setValue(name, d);
					}catch(NumberFormatException e)
					{
							//report
						throw new AutoPropertyException("Property "+bundle.label+" (or "+name
								+") could not be set, value "+val+" is not a number(double)");
					}
				}else if(type==Integer.class||type==Long.class)
				{
					try{
						long i=Long.parseLong((String) val);
						if(type==Integer.class)
							setValue(name, new Integer((int)i));//some bug here maybe
						else
						{
//							System.out.println("Setting "+name+" to "+val);
							setValue(name, i);
						}
					}catch(NumberFormatException e)
					{
							//report
						throw new AutoPropertyException("Property "+bundle.label+" (or "+name
								+") could not be set, value "+val+" is not an integer");
					}
				}
				else
				{
					//hope this works, implement a setX(String) method
					//to take care of coercion urself
					setValue(name, val);
				}
			}
			else
			{
				//hope this works, implement a setX(String) method
				//to take care of coercion urself
				if(val instanceof Double && type==Float.class)
					setValue(name, new Float((Double)val));
				else
					setValue(name, val);
			}
			
				
		}
	}

	public String[] getPropertyNames()
	{
		return orderedProps.toArray(new String[0]);
	}
	

	public void setPropertyStepSize(String name, Number d) throws AutoPropertyException
	{
		PropertyBundle b=props.get(name);
		if(b==null)
			throw new AutoPropertyException("No such property registered : "+name);
		if(b.view instanceof JSpinner)
		{
			SpinnerModel js=((JSpinner)b.view).getModel();
			if(js instanceof SpinnerNumberModel)
				((SpinnerNumberModel)js).setStepSize(d);
			
		}
	}

	class LockingListener implements DocumentListener, ChangeListener, ActionListener
	{
		private boolean locked = false;
		PropertyBundle[] properties;
		
		public LockingListener(String... items)
		{
			properties = new PropertyBundle[items.length];
			for(int i=0; i<items.length; i++)
			{
				String item = items[i];
				PropertyBundle pb = props.get(item);
				assert(pb!=null);
				properties[i] = pb;
			}
		}

		private void changeTo(Object value)
		{
			if(locked) 
			{
//				System.out.println("Should change to "+value);
//				System.out.println("Properties to change "+properties.length);
				for(PropertyBundle pb:properties)
				{
					if (pb.view instanceof JTextField)
					{
						JTextField vv = (JTextField) pb.view;
						vv.setText(value.toString());
						vv.repaint();
					} else if (pb.view instanceof JSpinner)
					{
						JSpinner vv = (JSpinner) pb.view;
						vv.setValue(value);
						vv.repaint();
					}
				}
			}
		}
		
		public void handleDocument(DocumentEvent e)
		{
			try
			{
				changeTo(e.getDocument().getText(0, e.getDocument().getLength()));
			} catch (BadLocationException e1)
			{
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		public void changedUpdate(DocumentEvent e)
		{
			handleDocument(e);
		}

		public void insertUpdate(DocumentEvent e)
		{
			handleDocument(e);			
		}

		public void removeUpdate(DocumentEvent e)
		{
			handleDocument(e);			
		}

		public void stateChanged(ChangeEvent e)
		{
			JSpinner js = (JSpinner) e.getSource();
			changeTo(js.getValue());
		}

		public void actionPerformed(ActionEvent e)
		{
			locked = ((JCheckBox)e.getSource()).isSelected();
//			System.out.println("Lock state "+locked);
		}

	}
	
	class Group
	{
		public String name;
		public String[] items;
		public boolean lockable;
		
		public Group(String name, String[] items, boolean lockable)
		{
			super();
			this.name = name;
			this.items = items;
			this.lockable = lockable;
		}
	}
	
	
	
	class PropertyBundle
	{
		public String toolTip;
		public Object defaultValue;
		Method setM;
		Method getM;
		Field field;
		Class type;
		
		JComponent view;// GUI for the property
		String label;

		String[] values;
		
		DisplayType displayType;
		ButtonGroup buttonGroup;//for RADIO option
	}
	
	public static void main(String[] args)
	{
		class c
		{
			public int i;
			public int j;
			public int getI()
			{
				System.out.println("geti called");
				return 3;
			}
			public void setI(int i)
			{
				System.out.println("seti called");
//				this.i=i;
			}
		}
		c c1=new c();
		AutoProperty p=new AutoProperty(c1);
		try
		{
			c1.i=100;
			c1.j=2;
			
			p.registerProperty("i", "i", "i");
			p.registerRadioProperty("j", "j", "j", new String[]{"1", "2", "3"});
//			System.out.println(c1.i);
			p.setValue("i", 1);
//			System.out.println(c1.i);
//			c1.i=2;
			System.out.println(p.getValue("i"));
			
			JFrame jf=new JFrame();
			jf.getContentPane().add(p.createPanel());
			jf.pack();
			jf.setVisible(true);
			jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		} catch (AutoPropertyException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
