package properties;

public class AutoPropertyException extends Exception
{

	public AutoPropertyException(String msg)
	{
		super(msg);
	}
	public AutoPropertyException(Throwable e)
	{
		super(e);
	}
	public AutoPropertyException(String msg, Throwable e)
	{
		super(msg, e);
	}
}
