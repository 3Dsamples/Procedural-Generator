package plugins.functions;

import properties.AutoPropertyException;

public class AddScaleFunction extends ManagedFunctionEngine
{
    
    
    public double offset=0.0, scale=1.0;
    
    public AddScaleFunction()
    {
        super();
        try
        {
            properties.registerProperty("offset", "Offset Value by", "Offset Value by");
            properties.setPropertyStepSize("offset", .1);
            properties.registerProperty("scale", "Scale Value by", "ScaleValue by");
            properties.setPropertyStepSize("scale", .1);
        } catch (AutoPropertyException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        noiseName="Offset Scale";
        noiseDescription="Offset and Scale the noise value";
    }
    

    @Override
    public double getNoiseForVertex(double x, double y, double z)
    {
        if(noiseEngine==null)
            return 0;
        
        return noiseEngine.getScaledMovedNoiseForVertex(x, y, z) * scale + offset;
    }

    public void setFunction(String name)
    {
        //IGNORE
    }

    
}
