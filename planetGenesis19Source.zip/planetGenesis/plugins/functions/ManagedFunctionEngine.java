package plugins.functions;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.ImageObserver;

import plugins.noiseGen.ManagedNoiseEngine;
import Utilities.NoiseEngine;
import Utilities.Vertex;

public abstract class ManagedFunctionEngine extends ManagedNoiseEngine implements
		FunctionEngine
{
	public NoiseEngine noiseEngine;
	
	public ManagedFunctionEngine()
    {
	    super();
	    noiseName="Managed AutoProperty Function";
	    noiseDescription="Abstract class for function whose " +
	                "store, restore, save load are taken care of automatically";
    }
	
	@Override
	public NoiseEngine copy()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDetails()
	{
		return "<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" +
		"<table>" + "<tr><td><b><u>Details</u></b></td></tr>" +
		"<tr><td><b>Function:</b> </td><td align=right>"+ noiseName + "</td></tr></table>";
	}

//	public void setFunction(String name)
//	{
//		
//	}

	
	public void setNoiseEngine(NoiseEngine noiseEngine)
	{
		this.noiseEngine=noiseEngine;
	}
	
	public NoiseEngine getNoiseEngine()
	{
		return noiseEngine;
	}

	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		return getNoiseForVertex(x, y, z);//Ignore scale and offset
	}
	
	@Override
	public Vertex[] getPreviewVertices() {

		Vertex[]  vertices = new Vertex[64*64];
		int index;
		
		index = 0;	
		initNoise();	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				vertices[index] = new Vertex((i / 63.0),
											 0,
											 (j / 63.0)); 	
				index++;
			}
		}
		
		return vertices;
	}	
	
	@Override
	public void makePreview() {
		int index = 0;
		double scale, x, y, z;

		initNoise();	
		
		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;
		Vertex v=new Vertex(0., 0., 0.);
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				v.x = (i / 63.0);
				v.y = yOffset;
				v.z = (j / 63.0);
				previewNoise[index] = getNoiseForVertex(v);
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				index++;
			}
		}
		
		scale = 255 / (max - min); 
		for(int i = 0; i < 64*64; i++) {
			preview.getRaster().getDataBuffer().setElem(i, (int)((previewNoise[i]  - min) * scale));			
		}
	
	}

	@Override
	public void paintIcon(Graphics2D g2, ImageObserver noiseComponent)
	{
	    if(noiseEngine!=null)
	        super.paintIcon(g2, noiseComponent);
	    else
	    {
	        Color c=g2.getColor();
	        g2.setColor(Color.white);
	        g2.fillRect(0, 0, (int)width, (int)height);
	        g2.setColor(c);
	    }
	    g2.setFont(new Font(null, Font.ITALIC, 16));
	    g2.drawString(noiseName, 6, 38);
	}
}
