package plugins.functions;

public class MusgraveRidgedFractallize extends MusgraveHybridFractallize
{
    public MusgraveRidgedFractallize()
    {
        super();
        noiseName="MusRidge";
        noiseDescription="Musgrave Ridged Fractallize";
    }
    
	@Override
	public double getNoiseForVertex(double x, double y, double z)
	{
		if(noiseEngine==null)
			return 0;
		
		double ret=1, pow=1;
		double signal = offset - Math.abs(noiseEngine.getScaledMovedNoiseForVertex(x, y, z));
		signal *= signal;
		ret = signal;
		double weight = 1.0;

		for(int i=1; i<(int)octaves; i++ ) {
		x *= lacunarity;
		y *= lacunarity;
		z *= lacunarity;
		weight = signal * gain;
		if (weight>1.0) weight=1.0; else if (weight<0.0) weight=0.0;
		signal = offset - Math.abs(noiseEngine.getScaledMovedNoiseForVertex(x, y, z));
		signal *= signal;
		signal *= weight;
		ret += signal * pow;
		pow *= powHL;
		} 
		
		return ret;
	}
}
