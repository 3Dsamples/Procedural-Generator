package plugins.functions;

public class MusgraveMultiFractallize extends MultiFractallizeFunction
{
    
    public MusgraveMultiFractallize()
    {
        super();
        noiseName="MusMulti";
        noiseDescription="Musgrave MultiFractalize";
    }
    
	@Override
	public double getNoiseForVertex(double x, double y, double z)
	{
		if(noiseEngine==null)
			return 0;
		
		double ret=1, pow=1;
		
		for(int i=0; i<octaves; i++)
		{
			ret*=(noiseEngine.getScaledMovedNoiseForVertex(x, y, z)*pow+1.0);
			x*=lacunarity; y*=lacunarity; z*=lacunarity;
			pow*=powHL;
		}
		return ret;
	}
	
	
}
