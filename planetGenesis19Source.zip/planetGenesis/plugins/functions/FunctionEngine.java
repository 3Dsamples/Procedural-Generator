package plugins.functions;

import java.awt.Graphics2D;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JPanel;

import Utilities.NoiseEngine;

public interface FunctionEngine
{

	void setNoiseEngine(NoiseEngine noiseEngine);
	NoiseEngine getNoiseEngine();
	
	void paintIcon(Graphics2D g2, ImageObserver component);

	void setFunction(String name);

	JPanel getPanel();

	void save(ObjectOutputStream file)  throws IOException;

	void load(ObjectInputStream file) throws ClassNotFoundException, IOException;

	String name();

	void storeSettings();

	void restoreSettings();

	void makePreview();

	String description();

	String getDetails();

}
