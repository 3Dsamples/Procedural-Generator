package plugins.functions;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

import Utilities.NoiseEngine;

public class FunctionFunction extends ManagedFunctionEngine
{

	FunctionDesignPanel displayFDPanel;
	FunctionDesignPanel usedFDPanel;

	public FunctionFunction()
	{
		super();
		
		noiseName="f(x)";
	    noiseDescription="An arbitrary function over values";
	    
	    createPanel();
	}
	
	public JPanel createPanel()
	{
		panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		displayFDPanel = new FunctionDesignPanel();
		panel.add(displayFDPanel);
		panel.add(properties.createPanel());
		
		usedFDPanel = new FunctionDesignPanel();
		
		return panel;
	}
	
	@Override
	public NoiseEngine copy()
	{
		return null;
	}

//	@Override
//	public String getDetails()
//	{
//		return "Applies an arbitrary function on the value/height";
//	}

	public void setFunction(String name)
	{
		//ignore
	}
	

	@Override
	public double getNoiseForVertex(double x, double y, double z)
	{
		if(noiseEngine!=null)
			return 1 - usedFDPanel.function(noiseEngine.getScaledMovedNoiseForVertex(x, y, z));
		else
			return 0;
	}
	
	@Override
	public void storeSettings()
	{
		super.storeSettings();
		
		displayFDPanel.copyValuesTo(usedFDPanel);

	}
	
	@Override
	public void restoreSettings()
	{
		super.restoreSettings();
		
		usedFDPanel.copyValuesTo(displayFDPanel);
		displayFDPanel.setProperCheckButtonStates();
		
		displayFDPanel.repaint();
	}

	@Override
	public void save(ObjectOutputStream file) throws IOException
	{
		super.save(file);
		
		usedFDPanel.save(file);
	}
	
	@Override
	public void load(ObjectInputStream file) throws ClassNotFoundException,
			IOException
	{
		super.load(file);
		
		usedFDPanel.load(file);
		usedFDPanel.copyValuesTo(displayFDPanel);
		
		displayFDPanel.setProperCheckButtonStates();

		displayFDPanel.repaint();
	}
}
