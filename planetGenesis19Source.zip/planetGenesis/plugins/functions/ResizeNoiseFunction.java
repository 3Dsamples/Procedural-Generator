package plugins.functions;

import properties.AutoPropertyException;

public class ResizeNoiseFunction extends ManagedFunctionEngine
{
    
    
    public double xSize=1.0, ySize=1.0, zSize=1.0;
    
    public ResizeNoiseFunction()
    {
        super();
        try
        {
            properties.registerProperty("xSize", "X Noise Size", "X Noise Size");
            properties.setPropertyStepSize("xSize", .5);
            properties.registerProperty("ySize", "Y Noise Size", "Y Noise Size");
            properties.setPropertyStepSize("ySize", .5);
            properties.registerProperty("zSize", "Z Noise Size", "Z Noise Size");
            properties.setPropertyStepSize("zSize", .5);
        } catch (AutoPropertyException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        noiseName="Resize";
        noiseDescription="Resize the noise";
    }
    
//    public void setH(double H)
//    {
//        this.H=H;
//        powHL=Math.pow(lacunarity, -H);
//        System.out.println("PowHL "+powHL);
//    }
    

    @Override
    public double getNoiseForVertex(double x, double y, double z)
    {
//      System.out.println("powHL "+powHL);
        if(noiseEngine==null)
            return 0;
        
        return noiseEngine.getScaledMovedNoiseForVertex(x*xSize, y*ySize, z*zSize);
    }

    public void setFunction(String name)
    {
        //IGNORE
    }

    
}
