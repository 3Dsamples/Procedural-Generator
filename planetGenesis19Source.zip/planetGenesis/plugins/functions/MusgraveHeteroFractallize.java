package plugins.functions;

import properties.AutoPropertyException;

public class MusgraveHeteroFractallize extends MultiFractallizeFunction
{
    
	public double offset=1;
	public MusgraveHeteroFractallize()
	{
		super();
		try
		{
			properties.registerProperty("offset");
		} catch (AutoPropertyException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		noiseName="MusHetero";
	    noiseDescription="Musgrave Hetero Fractallize";

	}
	
	@Override
	public double getNoiseForVertex(double x, double y, double z)
	{
		if(noiseEngine==null)
			return 0;
		
		double ret=1, pow=1;
		
		for(int i=0; i<octaves; i++)
		{
			ret*=((noiseEngine.getScaledMovedNoiseForVertex(x, y, z)+offset)*pow+1.0);
			x*=lacunarity; y*=lacunarity; z*=lacunarity;
			pow*=powHL;
		}
		return ret;
	}
}
