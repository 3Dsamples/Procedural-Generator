package plugins.functions;

import properties.AutoPropertyException;

public class MultiFractallizeFunction extends ManagedFunctionEngine
{
    public int octaves=2;
	public double lacunarity=2.0;
	public double H=1;
	
	double powHL=0.5;
	
	public MultiFractallizeFunction()
	{
	    super();
	    
		try
		{
			properties.registerProperty("octaves");
			properties.registerProperty("lacunarity");
			properties.setPropertyStepSize("lacunarity", .5);
			properties.registerProperty("H", "Fractal Dimension", "Fractal Dimension");
			properties.setPropertyStepSize("H", .5);
		} catch (AutoPropertyException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		noiseName="MultiFractallize";
	    noiseDescription=noiseName;
	}
	
	public void setH(double H)
	{
		this.H=H;
		powHL=Math.pow(lacunarity, -H);
		System.out.println("PowHL "+powHL);
	}
	
	public void setLacunarity(double lacunarity)
	{
		this.lacunarity=lacunarity;
		powHL=Math.pow(lacunarity, -H);
	}
	
	public void setFunction(String name)
	{
		//IGNORE, only 1 function
	}

	@Override
	public double getNoiseForVertex(double x, double y, double z)
	{
//		System.out.println("powHL "+powHL);
		if(noiseEngine==null)
			return 0;
		
		double ret=0, pow=1;
		
		for(int i=0; i<octaves; i++)
		{
			ret+=noiseEngine.getScaledMovedNoiseForVertex(x, y, z)*pow;
			x*=lacunarity; y*=lacunarity; z*=lacunarity;
			pow*=powHL;
		}
		return ret;
	}

	
}
