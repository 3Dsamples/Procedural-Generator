package plugins.functions;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.vecmath.Point2i;

import Utilities.GaussianElimination;

public class FunctionDesignPanel extends JPanel implements MouseListener, 
				MouseMotionListener, Cloneable
{

	public static final int HANDLE_SIZE = 5;
	public static final int RESTRICT_WIDTH = 400;
	public static final int RESTRICT_HEIGHT = 200;
	
	short shape = SMOOTH_INTERPOLATE;
	public static final short LINEAR = 0;
    public static final short SMOOTH_INTERPOLATE = 1;
	
	Vector<Point2i> handles = new Vector<Point2i>();
	Point2i selected;
	int selectedi = -1;
	double[] a0, a1, a2, a3, x, y;
	
	boolean repeat = false;
	double maxx;
	double minx;
	private JCheckBox cb;
	private JCheckBox lin;
	
	public FunctionDesignPanel()
	{
		super();
		
		setLayout(null);
		
		JButton b =new JButton("Delete");
		b.setSize(b.getPreferredSize());
//		b.setSize(80, 40);
		b.setLocation(10, RESTRICT_HEIGHT + 30);
		add(b);
		
		cb = new JCheckBox("Repeat");
		cb.setSize(cb.getPreferredSize());
		cb.setLocation(10 + RESTRICT_WIDTH/3, RESTRICT_HEIGHT + 30);
		add(cb);
		
		lin = new JCheckBox("Linear");
		lin.setSize(lin.getPreferredSize());
		lin.setLocation(10 + 2*RESTRICT_WIDTH/3, RESTRICT_HEIGHT + 30);
		add(lin);
		
		b.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e)
			{
				if(selected!=null)
				{
					handles.remove(selected);
    				selected = null;
    				sortHandles();
    				calculateCoefficients();
    				repaint();
				}
			}
			
		});
		
		cb.addChangeListener(new ChangeListener(){

			public void stateChanged(ChangeEvent e)
			{
				repeat = cb.isSelected();
				calculateCoefficients();
				repaint();
			}
			
		});
		
		lin.addChangeListener(new ChangeListener(){

			public void stateChanged(ChangeEvent e)
			{
				if(lin.isSelected())
					shape = LINEAR;
				else
					shape = SMOOTH_INTERPOLATE;
				
				calculateCoefficients();
				repaint();
			}
			
		});
		
		Dimension sz = new Dimension(RESTRICT_WIDTH + 20, RESTRICT_HEIGHT + 30 + cb.getHeight() + 10);
		setSize(sz);
		setPreferredSize(sz);
		setMinimumSize(sz);
		
		Point2i first = new Point2i(10, RESTRICT_HEIGHT+10);
		handles.add(first);
		handles.add(new Point2i(RESTRICT_WIDTH+10, 10));
		selected = first;
		selectedi=0;
		sortHandles();
		calculateCoefficients();

		addMouseListener(this);
		addMouseMotionListener(this);
	}		
	
	public void copyValuesTo(FunctionDesignPanel other)
	{
		other.handles.clear();
		for(Point2i p:this.handles)
		{
			other.handles.add(new Point2i(p.x, p.y));
		}
		
		other.a0 = this.a0;
		other.a1 = this.a1;
		other.a2 = this.a2;
		other.a3 = this.a3;
		other.x = this.x;
		other.y = this.y;
		other.maxx = this.maxx;
		other.minx = this.minx;
		other.repeat = this.repeat;
		other.shape = this.shape;
	}
	
	public void setProperCheckButtonStates()
	{
		lin.setSelected(shape == LINEAR);
		cb.setSelected(repeat);
	}
	
	public static void main(String[] args)
	{
		JFrame jf = new JFrame();
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		FunctionDesignPanel ft = new FunctionDesignPanel();
		ft.addMouseListener(ft);
		ft.addMouseMotionListener(ft);
		ft.setLayout(null);
//		ft.setLayout(new BoxLayout(ft, BoxLayout.Y_AXIS));
		
		
		
		jf.getContentPane().add(ft);
		
		jf.setSize(900, 300);
		jf.setVisible(true);
	}
	
	@Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		g.setColor(Color.black);
//		g.fillRect(0, 0, getWidth(), getHeight());
		g.fillRect(0, 0, getWidth(), RESTRICT_HEIGHT+20);
		g.setColor(Color.blue.darker());
		g.drawRect(10, 10, RESTRICT_WIDTH, RESTRICT_HEIGHT);
		
		g.setColor(Color.white);
		
		int i=0;
		for(Point2i p:handles)
		{
			if(p==selected)
				g.setColor(Color.red);
			else
				g.setColor(Color.white);
			
			g.drawRect(p.x-HANDLE_SIZE, p.y-HANDLE_SIZE, 2*HANDLE_SIZE+1, 2*HANDLE_SIZE+1);
			g.drawRect(p.x, p.y, 0, 0);
//			g.drawString(""+i, p.x, p.y);
			i++;
		}
		
		g.setColor(new Color(0x66a8ff));
		double lastX = 10, lastY = function(0) * RESTRICT_HEIGHT + 10;
		for(double k=0.; k<=1.; k+=.01)
		{
			double v = function(k) * RESTRICT_HEIGHT+ 10;
			double x = k*RESTRICT_WIDTH + 10;
			
//			g.setColor(new Color((int) (Math.random()*(1<<24))));
			g.drawLine((int)lastX, (int)lastY, (int)x, (int)v);
			
//			System.out.println("Drawing "+x+" "+v+" "+function(k));
			
			lastX = x;
			lastY = v;
		}
//		System.out.println("Done drawing");
		
		
	}

	public void mouseClicked(MouseEvent e)
	{
		
	}

	public void mouseEntered(MouseEvent e)
	{}

	public void mouseExited(MouseEvent e)
	{}

	public void mousePressed(MouseEvent e)
	{
		int x=e.getX(), y=e.getY();
		if(x<5 || y<5 || x>RESTRICT_WIDTH+15 || y>RESTRICT_HEIGHT+15)
			return;
		
		boolean found = false;
		for(Point2i p:handles)
		{
			if(x >= p.x-HANDLE_SIZE && x <= p.x+HANDLE_SIZE 
					&& y >= p.y-HANDLE_SIZE && y <= p.y+HANDLE_SIZE)
			{
				selected = p;
				selectedi = handles.indexOf(selected);
				found = true;
				break;
			}
		}
//		System.out.println("found "+found);
		if(!found)
		{
			if(x<10 || y<10 || x>RESTRICT_WIDTH+10 || y>RESTRICT_HEIGHT+10)
				return;
			
			Point2i p1 = new Point2i(x, y);
			handles.add(p1);
			selected = p1;
		}
		
		sortHandles();
		calculateCoefficients();
		repaint();
	}

	public void mouseReleased(MouseEvent e)
	{}

	public void mouseDragged(MouseEvent e)
	{
		int x=e.getX(), y=e.getY();
		if(x<10 || y<10 || x>RESTRICT_WIDTH+10 || y>RESTRICT_HEIGHT+10)
			return;
		
		selected.x = x; selected.y = y;
		sortHandles();
		calculateCoefficients();
		repaint();
	}

	public void mouseMoved(MouseEvent e)
	{}
	
	public void sortHandles()
	{
		Collections.sort(handles, new Comparator<Point2i>(){

			public int compare(Point2i o1, Point2i o2)
			{
				return o1.x - o2.x;
			}
			
		});
	}
	
	public double function(double value)
	{
//		System.out.println("Value "+value);
		int size = handles.size();
		if(size == 0)
			return 0;
		else if(size == 1)
			return (y[0]);
		
		if (value <= 0.0 || value >= 1.0)
		{
//			System.out.println("Value "+value+" outside limits");
			if (repeat)
				value -= Math.floor(value);
			else if (value <= 0.0)
				return y[0];
			else
				return y[size -1];
		}
		
		if(value <= minx)
			return y[0];
		
		if(value >= maxx)
			return y[y.length - 1];
		
//		System.out.println("val "+value+" maxx "+maxx+" minx "+minx);
		
		int i;
		for (i = 1; i < size && value > x[i]; i++)
			;
		i--;
//		System.out.println("i "+i);
		if (shape == SMOOTH_INTERPOLATE)
			return a0[i] + value * (2.0 * a1[i] + value * (3.0 * a2[i] + value * 4.0 * a3[i]));
		else
			return a0[i] + value * 2.0 * a1[i];
	}
	  
	public void calculateCoefficients() {
		//TODO: need a SVD solving package... start using Jama ?
		int size = handles.size();
		x = new double[size]; y = new double[size];
		maxx = Double.NEGATIVE_INFINITY; minx = Double.POSITIVE_INFINITY;
		for(int i=0; i<size; i++)
		{
			x[i] = (handles.get(i).x-10.0)/RESTRICT_WIDTH;
			y[i] = (handles.get(i).y-10.0)/RESTRICT_HEIGHT;
			
			if(x[i] < minx)
				minx = x[i];
			if(x[i] > maxx)
				maxx = x[i];
		}
//		System.out.println("x "+Arrays.toString(x));
//		System.out.println("y "+Arrays.toString(y));
		if(size == 0 || size == 1)
			return;
		
		a0 = new double [size-1];
	    a1 = new double [size-1];
	    a2 = new double [size-1];
	    a3 = new double [size-1];
		double m[][] = new double [4][4], a[] = new double [4], 
			   deriv[] = new double [size];
		
		if (shape == LINEAR)
		{
			for (int i = 0; i < a0.length; i++)
			{
				double dx = x[i + 1] - x[i];
				if (dx == 0.0)
					continue;
				a1[i] = (y[i + 1] - y[i]) / dx;
				a0[i] = y[i] - a1[i] * x[i];
				a1[i] *= 0.5;
			}
			return;
		}
		
		for (int i = 1; i < size-1; i++)
		{
			if (x[i-1] != x[i+1])
		        deriv[i] = (y[i+1]-y[i-1])/(x[i+1]-x[i]);
//			else
//				deriv[i] = 0;
		}
		if (repeat)
			deriv[0] = deriv[x.length-1] = (y[1]-y[y.length-2])/(1.0+x[1]-x[x.length-2]);
//			deriv[0] = deriv[x.length-1] = (y[0]-y[y.length-1])/(1.0+x[0]-x[x.length-1]);
//		System.out.println("deriv "+Arrays.toString(deriv));
		for (int i = 0; i < a0.length; i++)
	      {
			m[0][0] = 0.0;
	        m[0][1] = 1.0;
	        m[0][2] = 2.0*x[i];
	        m[0][3] = 3.0*x[i]*x[i];
	        a[0] = deriv[i];
	        m[1][0] = 1.0;
	        m[1][1] = x[i];
	        m[1][2] = x[i]*x[i];
	        m[1][3] = x[i]*x[i]*x[i];
	        a[1] = y[i];
	        m[2][0] = 1.0;
	        m[2][1] = x[i+1];
	        m[2][2] = x[i+1]*x[i+1];
	        m[2][3] = x[i+1]*x[i+1]*x[i+1];
	        a[2] = y[i+1];
	        m[3][0] = 0.0;
	        m[3][1] = 1.0;
	        m[3][2] = 2.0*x[i+1];
	        m[3][3] = 3.0*x[i+1]*x[i+1];
	        a[3] = deriv[i+1];
//	        SVD.solve(m, a);
	        GaussianElimination.solve(m, a);
//	        System.out.println("solution "+Arrays.toString(a));
	        a0[i] = a[0];
	        a1[i] = 0.5*a[1];
	        a2[i] = a[2]/3.0;
	        a3[i] = 0.25*a[3];
//	        b[i+1] = b[i] + x[i+1]*(a0[i]+x[i+1]*(a1[i]+x[i+1]*(a2[i]+x[i+1]*a3[i]))) - x[i]*(a0[i]+x[i]*(a1[i]+x[i]*(a2[i]+x[i]*a3[i])));
	      }
//	    for (int i = 1; i < b.length-1; i++)
//	      b[i] -= x[i]*(a0[i]+x[i]*(a1[i]+x[i]*(a2[i]+x[i]*a3[i])));
//		System.out.println("a0 "+Arrays.toString(a0));
//		System.out.println("a1 "+Arrays.toString(a1));
//		System.out.println("a2 "+Arrays.toString(a2));
//		System.out.println("a3 "+Arrays.toString(a3));
	}
	
	public void save(ObjectOutputStream file) throws IOException
	{
		file.writeObject(this.handles);
		file.writeObject(this.a0);
		file.writeObject(this.a1);
		file.writeObject(this.a2);
		file.writeObject(this.a3);
		file.writeObject(this.x);
		file.writeObject(this.y);
		file.writeDouble(this.maxx);
		file.writeDouble(this.minx);
		file.writeBoolean(this.repeat);
		file.writeShort(this.shape);
	}
	
	public void load(ObjectInputStream file) throws 
			ClassNotFoundException,IOException
	{
		this.handles = (Vector<Point2i>) file.readObject();
		this.a0 = (double[]) file.readObject();
		this.a1 = (double[]) file.readObject();
		this.a2 = (double[]) file.readObject();
		this.a3 = (double[]) file.readObject();
		this.x = (double[]) file.readObject();
		this.y = (double[]) file.readObject();
		this.maxx = file.readDouble();
		this.minx = file.readDouble();
		this.repeat = file.readBoolean();
		this.shape = file.readShort();
	}
}
