package plugins.functions;

import properties.AutoPropertyException;

public class MusgraveHybridFractallize extends MusgraveHeteroFractallize
{
    
	public double gain=1.0;
	public MusgraveHybridFractallize()
	{
	    super();
	    
		try
		{
			properties.registerProperty("gain");
		} catch (AutoPropertyException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		noiseName="MusHybrid";
	    noiseDescription="Musgrave Hybrid Fractallize";
	    
	}
	
	@Override
	public double getNoiseForVertex(double x, double y, double z)
	{
//		System.out.println(offset);
		if (noiseEngine == null)
			return 0;

		double result = 1, pow = 1;

		result = noiseEngine.getScaledMovedNoiseForVertex(x, y, z) + offset;
		double weight = gain * result, signal;
		x *= lacunarity;
		y *= lacunarity;
		z *= lacunarity;

		for (int i = 1; (weight > 0.001) && (i < (int) octaves); i++)
		{
			if (weight > 1.0)
				weight = 1.0;
			signal = (noiseEngine.getScaledMovedNoiseForVertex(x, y, z) + offset)
					* pow;
			pow *= powHL;
			result += weight * signal;
			weight *= gain * signal;
			x *= lacunarity;
			y *= lacunarity;
			z *= lacunarity;
		}
		return result;
	}
}
