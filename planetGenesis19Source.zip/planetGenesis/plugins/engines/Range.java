/*
 * Created on Jul 5, 2007
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import java.awt.Graphics2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JPanel;

import GUI.ExtendedHashBasedPanel;
import Utilities.Vertex;


/**
 * @author su_liam
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Range extends ApplyFunction
{
	private class RangeFunction extends Function
	{
		private double rangeLow=0.0;
		private double rangeHigh=1.0;
		private double belowRange=0.0;
		private double inRange=1.0;
		private double aboveRange=0.0;
		private double ramp = 0.0;
		
		
		
		final private ExtendedHashBasedPanel rangePanel = new ExtendedHashBasedPanel();
		
		private final String[] rangeKey = {"rangeLow", "rangeHigh", "ramp"};
		private final String[] rangeLabel = {"Lower End", "Upper End", "Ramp     "};
		private final String[] rangeValue = {"" + rangeLow, "" + rangeHigh, "" + ramp};
		private final String[] rangeTooltip = {"Lower end of range", "Upper end of range", "The width of the soft-selected area"};
	
		private final String[] valueKey = {"belowRange", "inRange", "aboveRange"};
		private final String[] valueLabel = {"Value below range", "Value within range", "Value above range"};
		private final String[] valueValue = {"" + belowRange, "" + inRange, "" + aboveRange};
		private final String[] valueTooltip = {"Value returned when input below range", 
								 "Value returned when input is within range", 
								 "Value returned when input is above range"};
	
			
		
		RangeFunction() {
			
			rangePanel.addTextBoxGroup("Input Range", "Input values describing the selection range",
					rangeKey, rangeLabel, rangeValue, rangeTooltip);

			rangePanel.addTextBoxGroup("Output Values", "Output values based on the input range",
					valueKey, valueLabel, valueValue, valueValue);

					
		}
		
		public JPanel getPanel(){return rangePanel;}
		
		public double function(Vertex vertex)
		{
			return function(noise.getNoiseForVertex(vertex));
		}
		
		public double function (double value)
		{
			if(value < rangeLow - 0.5*ramp)
				return belowRange;
			if(value > rangeHigh + 0.5*ramp)
				return aboveRange;
			if(between(value, rangeLow + 0.5*ramp, rangeHigh - 0.5*ramp))
				return inRange;
			if(between(value, rangeLow - 0.5*ramp, rangeLow + 0.5*ramp))
				return ramp(value, rangeLow - 0.5*ramp, rangeLow + 0.5*ramp, belowRange, inRange);
			return ramp(value, rangeHigh - 0.5*ramp, rangeHigh + 0.5*ramp, inRange, aboveRange);
			
		}
		
		protected boolean between(double val, double low, double high)
		{
			if(val < low || val > high)
				return false;
			return true;
		}
		
		protected double ramp(double val, double low, double high, double lowVal, double highVal)
		{
			//func.ramp(x, 0, 10, 5, 30)
			double slope = (highVal - lowVal) / (high - low);
			double intercept = lowVal - slope*low;
			return slope*val + intercept;
		}
		
		public void storeSettings() {
			
			rangeLow = rangePanel.getDouble("rangeLow");
			rangeHigh = rangePanel.getDouble("rangeHigh");
			belowRange = rangePanel.getDouble("belowRange");
			inRange = rangePanel.getDouble("inRange");
			aboveRange = rangePanel.getDouble("aboveRange");
			ramp = rangePanel.getDouble("ramp");

			
		}

		public void restoreSettings() {	
			
			rangePanel.setValue("rangeLow", ""+rangeLow);
			rangePanel.setValue("rangeHigh", ""+rangeHigh);
			rangePanel.setValue("belowRange", ""+belowRange);
			rangePanel.setValue("inRange", ""+inRange);
			rangePanel.setValue("aboveRange", ""+aboveRange);
			rangePanel.setValue("ramp", ""+ramp);
		
			
		}

		public void save(ObjectOutputStream file) throws IOException
		 {
		
			file.writeObject(this.getClass().getName());
			rangePanel.save(file);


		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

			String functionType = (String)file.readObject(); 

			rangePanel.load(file);
			storeSettings();
		
		}
		
		public void	drawIcon (Graphics2D g2)
		{
			g2.drawString("Range", 6, 38);
		}
		
		void setup(double floor, double ceiling, double under, double in, double over, double ramp)
		{
			this.rangeLow = floor;
			this.rangeHigh = ceiling;
			this.belowRange = under;
			this.inRange = in;
			this.aboveRange = over;
			this.ramp = ramp;
			restoreSettings();
		}
	}
	
	public void setFunction(String functionName)
	{
		System.err.println("Function Name set to" + functionName);
		this.functionName = functionName;
		if(functionName.compareTo("Range") == 0)
		{  
			math = new RangeFunction();
		}

		return;
	}
	
	RangeFunction getMath()
	{
		return (RangeFunction)math;
	}
	
	public static void main(String[] args)
	{
		Range range = new Range();
		range.setFunction("Range");
		RangeFunction func = range.getMath();
		func.setup(-12, 12, 0, 30, 35, 3);
		System.out.println("floor = -12");
		System.out.println("ceiling = 12");
		System.out.println("under = 0");
		System.out.println("in = 30");
		System.out.println("over = 35");
		System.out.println("ramp = 3");
		for(double x = -20; x < 21; x++)
		{
			System.out.println("" + x + " : " + func.function(x));
		}
	}
}
