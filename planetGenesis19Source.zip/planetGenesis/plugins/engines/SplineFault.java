/*
 * Created on Jul 13, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import java.util.Random;
import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import GUI.ExtendedHashBasedPanel;
import Utilities.NoiseEngine;
import Utilities.NoiseType;
import Utilities.SplinePatch;
import Utilities.Vector3D;
import Utilities.Vertex;

/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class SplineFault extends NoiseEngine {
	
	protected double[] scanDoubles;
	protected NoiseType noiseType;

	private ExtendedHashBasedPanel panel;
	private double scale;// yNoise, zNoise;
	private int iterations, resolution;
	private long seed;
	
	private Vector3D[] offsets;
	private int[] directions;

	private double[] samplePoints;
	private double[][] controlPoints;
	private final SplinePatch spline = new SplinePatch();

	/** Creates a new instance of perlin */
	public SplineFault() {
		panel = new ExtendedHashBasedPanel();
		resolution = 10;
		panel.addTextBox("res", "Resolution", ""+resolution, "Defines how sharp the texture is.");
		panel.addTextBox("iterations", "Interations", "1000", "Defines the complexity of the texture is.");
		panel.addRandomSeed("seed", "Random Seed", System.currentTimeMillis());
		storeSettings();
		makePreview();
	}







	public String name() {
		return "Spline Fault Noise";
	}

	public String description() {
		return "Simple plate techtonics simulation.\n" + 
				"Works best with meshes.";
	}

	public javax.swing.JPanel getPanel() {
		return panel;
	}

	public void initNoise() {
		samplePoints = new double[resolution];
		controlPoints = new double[resolution][resolution];
		/* samplePoints is only used to create knots */
		for(int i=0; i<resolution; i++) {
			samplePoints[i] = (double)i/(resolution-1);
		}
		spline.initSpline(samplePoints, 3);
		
		for(int x=0; x<resolution; x++) {
			for(int y=0; y<resolution; y++) {
					
				controlPoints[x][y] = faultPoint((double)x/(resolution-1), 0.0, (double)y/(resolution-1));
					
			}
		}
	}

	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)	{
		return  spline.spline(x, z, controlPoints);
	}

	public double getNoiseForVertex(Vertex vertex) {
		double x = vertex.getX(); 
		double z = vertex.getZ();
		
		return  spline.spline(x, z, controlPoints);
	
	}

	public double faultPoint(double x, double y, double z) {
		
		double dotValue;
		double height = 0;


		for(int i= 0; i < iterations; i++ ) {
			
			dotValue = offsets[i].DotProduct(x+offsets[i].x, 0, z+offsets[i].z);
			
			if(dotValue > 0) {
					height+=directions[i];
			} else {
					height-=directions[i];
			}
		}
		
		return height * scale;
	}


	public double getNoiseForVertex(int vertex) {
		return getNoiseForVertex(terrain.getNoiseVertex(vertex));
	}
	

    public Vertex[] getPreviewVertices() {

		Vertex[]  vertices = new Vertex[64*64];
		int index;
		
		index = 0;	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				vertices[index] = new Vertex(i * (1.0 / 63.0), 
											0.0, 
											j * (1.0 / 63.0)); 	
				index++;
			}
		}
		
		return vertices;
	}	
	
	public void makePreview() {
		int index = 0;	
		double previewScale;
		double x, y, z;
		final DataBuffer data = preview.getRaster().getDataBuffer();

		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;


		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				
					x = i;
					x *= (1.0 / 64.0);
					y = 0.0;
					z = j;  
					z *=  (1.0 / 64.0);
					previewNoise[index] = getNoiseForVertex(new Vertex(x,y,z));
					if(previewNoise[index] > max) {
						max = previewNoise[index];
					}
					if(previewNoise[index] < min) {
						min = previewNoise[index];
					}
					index++;			}
		}	
		
		previewScale = 255 / (max - min); 

		for(int i = 0; i < 64*64; i++) {
			data.setElem(i, (int)((previewNoise[i]  - min) * previewScale));			
		}

	}
	
	public void storeSettings() {
		seed = Long.parseLong(panel.getText("seed"));
		resolution = Integer.parseInt(panel.getText("res"));
		Random rand = new Random(seed);
		iterations = panel.getInt("iterations"); 
		scale = 1.0/iterations;
		offsets = new Vector3D[iterations];
		directions = new int[iterations];
		for(int i= 0; i < iterations; i++ ) {
			offsets[i] = new Vector3D((rand.nextDouble()-0.5) ,0 , (rand.nextDouble()-0.5));
			directions[i] = rand.nextDouble() > 0.5 ? 1: -1;
		}
		initNoise();
	}
	
	public void restoreSettings() {
	
		panel.setValue("res", ""+resolution);
		panel.setValue("seed", ""+seed);
		panel.setValue("iterations", ""+iterations);	
	}
	

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);
	
	}
	
	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}

	   /* (non-Javadoc)
     * @see Utilities.NoiseEngine#copy()
     */
    public NoiseEngine copy() {
        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            ((ExtendedHashBasedPanel)copy.getPanel()).setValuesUsingHash(panel.getHash());
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
           e.printStackTrace();
        }	
        return null;
    }

	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Resolution:</b> </td><td align=right>"+ resolution + "</td></tr>" +
			"<tr><td><b>Iterations:</b> </td><td align=right>"+ iterations + "</td></tr>" +
			"<tr><td><b>Seed:</b> </td><td align=right>" + seed + "</td></tr></table>";
			
	}
	
	public Vertex getNoiseSize() {
		return new Vertex(1, 1, 1);
	}

}
