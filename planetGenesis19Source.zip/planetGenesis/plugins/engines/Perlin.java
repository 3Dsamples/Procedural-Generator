
/*
 * perlin.java
 *
 * Created on 05 March 2002, 19:08
 */

/*
 Copyright (c) 2002, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

package plugins.engines;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;



import GUI.ExtendedHashBasedPanel;
import Utilities.*;
/**
*
 * @author  David
 */
public class Perlin extends NoiseEngine {

	protected ExtendedHashBasedPanel panel;
	protected NoiseType noiseType;

	private Class noiseClass;
	private	String noiseName="plugins.noise.Perlin3D";

	protected int gridProjection;
	
	protected int octaves=6;

	protected double persistence=2.;
	protected double frequency=2.;

	private double height=10.;
	private double width=10.;
	private double depth=10.;

	private double xOffset=1.1;
	private double yOffset=1.2;
	private double zOffset=1.3;

	private long seed=System.currentTimeMillis();
	//Colin 12-12-07: made powerArray protected
	protected double[] powerArray;
	
	

	public static void main(String[] args) {
		try {
			Class noiseClass = Class.forName("plugins.engines.Perlin"); 
			Utilities.NoiseEngine noise =
				(Utilities.NoiseEngine) noiseClass.newInstance();
			//            plugins.engines.Perlin noise = new plugins.engines.Perlin();
			noise.initNoise();
			//            octaves = panel.getOctaves();
			//            terrain = noise.CreateTerrain(50, 50, 0.5);
			//            noise.CreatePlanetPNG(1024, 1024, "D:\\test3Java.png" );
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(99);
		}
	}

	/** Creates a new instance of perlin */
	public Perlin() {
		panel = new ExtendedHashBasedPanel();
		
		panel.addDropDown("noiseName", "Noise Type", 
				new String[] {"plugins.noise.Perlin3D", "plugins.noise.RidgedPerlin3D", "plugins.noise.BillowyPerlin3D", "plugins.noise.Perlin2D",
				"plugins.noise.SimplexNoise3D", "plugins.noise.RidgedSimplex3D", "plugins.noise.BillowySimplex3D", "plugins.noise.SineWave"}, 
				"The type of noise.");
		panel.addTextBox("octaves", "Octaves", ""+octaves, "The number of turbulence octaves");
		panel.addTextBox("frequency", "Frequency", ""+frequency, "The turbulence frequency");
		panel.addTextBox("persistence", "Persistence", ""+persistence, "The turbulence persistence s");
		panel.addRandomSeed("seed", "Seed", System.currentTimeMillis() % Integer.MAX_VALUE);
		
		panel.addTextBoxGroup("Offset", "The co-ordinates of the offset point in Noise Space.", 
				new String[] {"xOffset", "yOffset", "zOffset"},
				new String[] {"x", "y", "z"},
				new String[] { ""+(xOffset),  ""+(yOffset),  ""+(zOffset)},
				new String[] {"Offset Point x co-ordinate", "Offset Point y co-ordinate", "Offset Point z co-ordinate"}); 

		panel.addTextBoxGroup("Noise Size", "The size of Noise Space.", 
				new String[] {"width", "depth", "height"},
				new String[] {"Width", "Depth", "Height"},
				new String[] { ""+(width),  ""+(depth),  ""+(height)},
				new String[] {"Noise Width", "Noise Depth", "Noise Height"}); 


		storeSettings();
	//	icon = java.awt.Toolkit.getDefaultToolkit().getImage(getClass().getResource("/plugins/engines/images/genesis.png"));
	}

	public String name() {
		return "Perlin Noise 2";
	}

	public String description() {
		return "Classic Perlin Noise with Turbulence.";
	}

	public javax.swing.JPanel getPanel() {
		return panel;
	}

	public void initNoise() {

//		storeSettings();

		try {
			noiseClass = Class.forName(noiseName);
			noiseType = (NoiseType) noiseClass.newInstance();
			noiseType.InitNoise(seed);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		
		powerArray = new double[octaves];
		
		for (int i = 0; i < octaves; i++) {
			powerArray[i] = (1 / Math.pow(persistence, i)); 
		}
	}

	protected double Turbulence(Vertex vert, long octaves) {

		double tmpX, tmpY, tmpZ;
		int i;
		double result;

		tmpX = vert.getX();
		tmpY = vert.getY();
		tmpZ = vert.getZ();

		result = (powerArray[0] * (noiseType.Noise(tmpX, tmpY, tmpZ)));
		
		for (i = 1; i < octaves; i++) {

			tmpX *= frequency;
			tmpY *= frequency;
			tmpZ *= frequency;
			
			result
			+= (powerArray[i]
				* (noiseType.Noise(tmpX, tmpY, tmpZ)));

 		}

		return result;

	}

	public double getNoiseForVertex(Vertex vertex) {
		return Turbulence(vertex, octaves);
	}

	public double getScaledMovedNoiseForVertex(double x, double y, double z) {
		// Using vertex.add and multiply cretes 2 objects , we dont need that
		return Turbulence(x*width+xOffset, y*height+yOffset, z*depth+zOffset, octaves);
	}
	
	public Vertex getNoiseSize() {
		return new Vertex(width, height, depth);
	}

	public Vertex getNoiseOffset() {
		return new Vertex(xOffset, yOffset, zOffset);
	}
	
	public void setProjection(int projection) {
		gridProjection = projection;
	}

	public double getNoiseForVertex(int vertex) {
		return Turbulence(terrain.getNoiseVertex(vertex), octaves);
	}
	
	public void setTerrain(Landscape terrain) {
		this.terrain = terrain;
		terrain.setNoiseSpace(this);
		terrain.setProjection(gridProjection);
		terrain.setTile(false);
		return;
	}
	

	public void makePreview() {
		int index = 0;
		double scale, x, y, z;

		initNoise();	
		
		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;

		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				x = (i * (width / 63.0)) + xOffset;
				y = yOffset;
				z = (j * (depth / 63.0)) + zOffset;
				previewNoise[index] = Turbulence(x,y,z, octaves);
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				index++;
			}
		}
		
		scale = 255 / (max - min); 
		for(int i = 0; i < 64*64; i++) {
			preview.getRaster().getDataBuffer().setElem(i, (int)((previewNoise[i]  - min) * scale));			
		}
	
	}
	
	public void storeSettings() {
		persistence = panel.getDouble("persistence");
		frequency = panel.getDouble("frequency");

		height = panel.getDouble("height");
		width = panel.getDouble("width");
		depth = panel.getDouble("depth");

		xOffset = panel.getDouble("xOffset");
		yOffset = panel.getDouble("yOffset");
		zOffset = panel.getDouble("zOffset");
		
		seed = (long)panel.getInt("seed");
		octaves = panel.getInt("octaves");
		noiseName = panel.getText("noiseName");
	}
	
	public void restoreSettings() {
	
		panel.setValue("persistence", ""+persistence);
		panel.setValue("frequency", ""+frequency);

		panel.setValue("height", ""+height);
		panel.setValue("width", ""+width);
		panel.setValue("depth", ""+depth);

		panel.setValue("xOffset", ""+xOffset);
		panel.setValue("yOffset", ""+yOffset);
		panel.setValue("zOffset", ""+zOffset);
		
		panel.setValue("seed", ""+seed);
		panel.setValue("octaves", ""+octaves);
		panel.setValue("noiseName", noiseName);

	}
	
	public Vertex[] getPreviewVertices() {

		Vertex[]  vertices = new Vertex[64*64];
		int index;
		
		index = 0;	
		initNoise();	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				vertices[index] = new Vertex((i * (width / 63.0)) + xOffset,
											 yOffset,
											 (j * (depth / 63.0)) + zOffset); 	
				index++;
			}
		}
		
		return vertices;
	}	

	public long getSeed()
	{
		return seed;
	}

	public void setSeed(long seed)
	{
		this.seed = seed;
	}

	protected double Turbulence(double tmpX, double tmpY,  double tmpZ, long octaves) {

		int i;
		double result;

		result = (powerArray[0] * (noiseType.Noise(tmpX, tmpY, tmpZ)));	
		
		for (i = 1; i < octaves; i++) {

			tmpX *= frequency;
			tmpY *= frequency;
			tmpZ *= frequency;

			result += (powerArray[i] * (noiseType.Noise(tmpX, tmpY, tmpZ)));
				         		
//              fprintf(stderr, "%f\n", result);
		}

		return result;

	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);
	
	}
	
	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}

	   /* (non-Javadoc)
     * @see Utilities.NoiseEngine#copy()
     */
    public NoiseEngine copy() {
        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            ((ExtendedHashBasedPanel)copy.getPanel()).setValuesUsingHash(panel.getHash());
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
           e.printStackTrace();
        }	
        return null;
    }
    
public String getDetails() {
	return 
		"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" + 
		"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
		"<tr><td><b>Noise:</b> </td><td align=right>"+ noiseName + "</td></tr>" + 
		"<tr><td><b>Octaves:</b> </td><td align=right> " + octaves + "</td></tr>" + 
		"<tr><td><b>Frequency:</b> </td><td align=right>" + frequency + "</td></tr>" + 
		"<tr><td><b>Persistence:</b> </td><td align=right>" + persistence + "</td></tr>" + 
		"<tr><td><b>Noise Size:</b> </td><td align=right>" + width + ", " + height + ", " +depth  + "</td></tr>" +
   		"<tr><td><b>Noise Offset:</b> </td><td align=right>" + xOffset + ", " + yOffset + ", " +zOffset  + "</td></tr>" +
		"<tr><td><b>Seed:</b> </td><td align=right>"+seed + "</td></tr></table>";
			
}

public String getNoiseName()
{
	return noiseName;
}

public void setNoiseName(String noiseName)
{
	this.noiseName = noiseName;
}

public int getOctaves()
{
	return octaves;
}

public void setOctaves(int octaves)
{
	this.octaves = octaves;
}

public void setNoiseSize(Vertex size)
{
	width=size.x;
	height=size.y;
	depth=size.z;
}
}
