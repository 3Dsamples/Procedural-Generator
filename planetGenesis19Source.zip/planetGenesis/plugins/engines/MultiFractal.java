/*
 * Created on Apr 12, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import Utilities.Vertex;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class MultiFractal extends Perlin {

	public String name() {
		return "Perlin MultiFractal Noise";
	}

	public String description() {
		return "Hybrid Perlin MultiFractal Noise.";
	}
	protected double Turbulence(Vertex vert, long octaves) {

		double tmpX, tmpY, tmpZ;
		long i;
		double result, value = 0, weight = 1.0;

		tmpX = vert.getX();
		tmpY = vert.getY();
		tmpZ = vert.getZ();

		result = 0;
		for (i = 0; i < octaves; i++) {
			/**
			value
				= (weight * (1 / Math.pow(persistence, i))
					* (noiseType.Noise(tmpX, tmpY, tmpZ)));
			**/
			//Maybe a speed benefit. Seems a shame to waste all that effort initializing the powerArray not to use it, anyway.
			value = weight * powerArray[(int)i] * noiseType.Noise(tmpX, tmpY, tmpZ);
			
			weight = value;
			result += value;		
			//                result += ((pow(1.2, i)) * (perlin_noise_2d(tmpX, tmpY)));
			tmpX *= frequency;
			tmpY *= frequency;
			tmpZ *= frequency;
			//              fprintf(stderr, "%f\n", result);
		}

		return result;

	}

	protected double Turbulence(double tmpX, double tmpY,  double tmpZ, long octaves) {

		long i;
		double result, value = 0, weight = 1.0;

		result = 0;
		for (i = 0; i < octaves; i++) {
			/*
			value
				= (weight * (1 / Math.pow(persistence, i))
					* (noiseType.Noise(tmpX, tmpY, tmpZ)));
			*/
			
			//Maybe a speed benefit. Seems a shame to waste all that effort initializing the powerArray not to use it, anyway.
			value = weight * powerArray[(int)i] * noiseType.Noise(tmpX, tmpY, tmpZ);
			
			weight = value;
			result += value;		
			tmpX *= frequency;
			tmpY *= frequency;
			tmpZ *= frequency;
		}

		return result;

	}
	
}
