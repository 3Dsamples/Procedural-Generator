/*
 * Created on Sep 30, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import java.awt.Graphics2D;
import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



import GUI.ExtendedHashBasedPanel;
import Utilities.Landscape;
import Utilities.SplinePatch;
import Utilities.Vertex;

/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class BasedFunction extends ApplyFunction {

	private final Vertex noiseSizeVertex = new Vertex(1,1,1);
	private final Vertex noiseOffsetVertex = new Vertex(0,0,0);
	
	
	public double getNoiseForVertex(int vertex) {
		return math.function(terrain.getNoiseVertex(vertex));
	}
	
    public Vertex[] getPreviewVertices() {

		Vertex[]  vertices = new Vertex[64*64];
		int index;
		
		index = 0;	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				vertices[index] = new Vertex(i /  63.0, 
											0, 
											j / 63.0); 	
				index++;
			}
		}
		
		return vertices;
	}
	
	public void makePreview() {

		System.err.println(name() + " makePreview");
		boolean nanWarning = false;
 		double  scale;
		DataBuffer previewData = preview.getRaster().getDataBuffer();

		if(noise != null) {		
			max = Double.NEGATIVE_INFINITY;
			min = Double.POSITIVE_INFINITY;
			initNoise();

			int index = 0;
			
			for(double j = 0; j < 64; j++){
				for(double i = 0; i < 64; i++){
					
					previewNoise[index] = math.function(new Vertex(i/63.0,0,j/63.0));
					if(previewNoise[index] > max) {
						max = previewNoise[index];
					}
					if(previewNoise[index] < min) {
						min = previewNoise[index];
					}
					if(Double.isNaN(previewNoise[index])) {
						nanWarning = true;
					}

					index++;
				}
			}	
			
		
			if(max == Double.POSITIVE_INFINITY || min == Double.NEGATIVE_INFINITY) {

				JOptionPane pane = new JOptionPane(name() + " produces infinity for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "Warning");
				dialog.setModal(false);
				dialog.setVisible(true);
			}

			if(nanWarning) {
				JOptionPane pane = new JOptionPane(name() + " results in complex numbers being generated for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "NaN Warning");
				dialog.setModal(false);
				dialog.setVisible(true);				
			}
			
			scale = 255.0 / (max - min); 
			
			for(int i = 0; i < 64*64; i++) {
				previewData.setElem(i, (int)((previewNoise[i]  - min) * scale));			
			}
		}
		return;
	}

	public void setFunction(String functionName) {
		
		System.err.println("Function Name set to" + functionName);
		this.functionName = functionName;
		if(functionName.compareTo("Splinify") == 0) {  
			math = new SplineFunction();
		}
		
		return;
	}	

	public Vertex getNoiseSize() {
		return noiseSizeVertex;
	}

	public Vertex getNoiseOffset() {
		return noiseOffsetVertex;
	}

	public Vertex getVertex(int index) {
		return terrain.getNoiseVertex(index);
	}		
	
    public void setTerrain(Landscape terrain) {
		this.terrain = terrain;
		terrain.setNoiseSpace(this);
		terrain.setProjection(gridProjection);
		terrain.setTile(false);
		scanlineSize = terrain.getXMesh();
		return;
	} 
		
	private class SplineFunction extends Function{

		/*
		 *  The idea is to get the noise size and offset.
		 *  Calculate the centre point of the noise
		 *  Subtract the centre from the point
		 *  rotate the point and add the centre back 
		 * 
		 */
		
		private double[][] controlPoints;
		private final SplinePatch spline = new SplinePatch();

		private int resolution = 10;
		
		final private ExtendedHashBasedPanel scalePanel = new ExtendedHashBasedPanel();
		
		SplineFunction() {
			scalePanel.addTextBox("RES", "Number of Control Points", ""+resolution, "Rotation Value");
		}
		
		public void init() {
			
			double[] samplePoints = new double[resolution];
			controlPoints = new double[resolution][resolution];
			/* samplePoints is only used to create knots */
			for(int i=0; i<resolution; i++) {
				samplePoints[i] = (double)i/(resolution-1);
			}
			spline.initSpline(samplePoints, 3);
			
			Vertex size = noise.getNoiseSize();
			Vertex offset = noise.getNoiseOffset();
			double xScale = size.getX() / (resolution - 1); 
			double zScale = size.getX() / (resolution - 1); 
			double offsetX = offset.getX();
			double offsetY = offset.getY();		
			double offsetZ = offset.getZ();
			
			for(int x=0; x<resolution; x++) {
				for(int y=0; y<resolution; y++) {
						
					controlPoints[x][y] = noise.getNoiseForVertex(new Vertex((xScale * x) + offsetX, offsetY, (zScale * y) + offsetZ));
						
				}
			}		
		}

		
		public JPanel getPanel(){return scalePanel;};	

		public double function(Vertex vertex) {
			
			double x = vertex.getX(); 
			double z = vertex.getZ();
			
			return spline.spline(x, z, controlPoints);
			
		}



		public void	drawIcon (Graphics2D g2){
			g2.drawString("Spline", 7, 38);
		}


		public void save(ObjectOutputStream file) throws IOException
		 {
		
			scalePanel.save(file);
	
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

			scalePanel.load(file);
			storeSettings();
			
		}

		public void storeSettings() {			
			resolution = scalePanel.getInt("RES");
		}
	
		public void restoreSettings() {	
			scalePanel.setValue("RES", ""+resolution);
		}

		/* (non-Javadoc)
		 * @see plugins.engines.ApplyFunction.Function#function(double)
		 */
		public double function(double value) {
			// TODO Auto-generated method stub
			return 0;
		}		
	}		

	public String getDetails() {
		return "<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" +
			"<table>" + "<tr><td><b><u>Details</u></b></td></tr>" +
			"<tr><td><b>Function:</b> </td><td align=right>"+ functionName + "</td></tr></table>";
			
	}	
}
