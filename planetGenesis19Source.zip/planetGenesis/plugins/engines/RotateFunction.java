/*
 * Created on Nov 24, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import GUI.ExtendedHashBasedPanel;
import Utilities.Vertex;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
/*
 *  The idea is to get the noise size and offset.
 *  Calculate the centre point of the noise
 *  Subtract the centre from the point
 *  rotate the point and add the centre back 
 * 
 */


public class RotateFunction extends ApplyFunction {


	private double moveX;
	private double moveZ;
	private double rotate = 90;
	private double rotateCosA;
	private double rotateSinA;
	private double rotateMinusSinA;
	final private ExtendedHashBasedPanel scalePanel = new ExtendedHashBasedPanel();

	
	public RotateFunction() {
		scalePanel.addTextBox("ROTATE", "Degrees Rotation (Clockwise)", ""+90.0, "Rotation Value");
	}	

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#description()
	 */
	public String description() {
		return "Rotates The noise";
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#getDetails()
	 */
	public String getDetails() {
		return "<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" +
		"<table>" + "<tr><td><b><u>Details</u></b></td></tr>" +
		"<tr><td><b>Function:</b> </td><td align=right> Rotate</td></tr>" +
		"<tr><td><b>Angle:</b> </td><td align=right>"+ rotate + "</td></tr>" + 
		"</table>";
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#getNoiseForVertex(Utilities.Vertex)
	 */
	public double getNoiseForVertex(Vertex vertex) {
		return noise.getNoiseForVertex(rotateVertex(vertex.getX(), vertex.getY(), vertex.getZ()));
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#getNoiseForVertex(int)
	 */
	public double getNoiseForVertex(int vertex) {
		Vertex tmp = noise.getVertex(vertex);
		tmp = rotateVertex(tmp.getX(), tmp.getY(), tmp.getZ());			
		return noise.getNoiseForVertex(tmp);
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#getPanel()
	 */
	public JPanel getPanel() {
		return scalePanel;
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#initNoise()
	 */
	public void initNoise() {
			
		if(noise != null) {		
			noise.initNoise();
		}

		Vertex centre, offset;
		
		centre = noise.getNoiseSize();
		centre.multiply(0.5, 0.5, 0.5);
		offset = noise.getNoiseOffset();
		centre.add(offset);
		moveX = centre.getX();
		moveZ = centre.getZ();
		rotateCosA = Math.cos(Math.toRadians(-rotate));
		rotateSinA = Math.sin(Math.toRadians(-rotate));
		rotateMinusSinA = -rotateSinA;
		
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, 	IOException {
		scalePanel.load(file);		
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#makePreview()
	 */
	public void makePreview() {
		System.err.println(name() + " makePreview");
		boolean nanWarning = false;
 		double scale;
 		Vertex tmp;
		DataBuffer previewData = preview.getRaster().getDataBuffer();
		

		if(noise != null) {		
			max = Double.NEGATIVE_INFINITY;
			min = Double.POSITIVE_INFINITY;
			initNoise();
			Vertex[] inputNoise = noise.getPreviewVertices();
			
			for(int index = 0; index < 64 * 64; index++){
				
				tmp = inputNoise[index];
				tmp = rotateVertex(tmp.getX(), tmp.getY(), tmp.getZ());
				previewNoise[index] = noise.getNoiseForVertex(tmp);
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				if(Double.isNaN(previewNoise[index])) {
					nanWarning = true;
				}
			}
		
			if(max == Double.POSITIVE_INFINITY || min == Double.NEGATIVE_INFINITY) {

				JOptionPane pane = new JOptionPane(name() + " produces infinity for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "Warning");
				dialog.setModal(false);
				dialog.setVisible(true);
			}

			if(nanWarning) {
				JOptionPane pane = new JOptionPane(name() + " results in complex numbers being generated for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "NaN Warning");
				dialog.setModal(false);
				dialog.setVisible(true);				
			}
			
			scale = 255 / (max - min); 
			for(int i = 0; i < 64*64; i++) {
				previewData.setElem(i, (int)((previewNoise[i]  - min) * scale));			
			}
		}
		return;
	
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#name()
	 */
	public String name() {
		return "Rotate";
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#restoreSettings()
	 */
	public void restoreSettings() {
		scalePanel.setValue("ROTATE", ""+rotate);
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		file.writeObject(this.getClass().getName());
		scalePanel.save(file);		
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#storeSettings()
	 */
	public void storeSettings() {
		rotate = scalePanel.getDouble("ROTATE");
	}
	
	public void paintIcon(Graphics2D g2, java.awt.image.ImageObserver component) {
		Font old = g2.getFont();
		g2.setFont(new Font(null, Font.ITALIC, 18));
		if(noise != null) {
			g2.drawImage(preview,0,0,component);
		}
		g2.drawString("Rotate", 7, 38);
		g2.setFont(old);
	}
	
	public void setFunction(String functionName) {
	}	

	public Vertex rotateVertex(double x, final double y, double z) {
		
		x -= moveX;
		z -= moveZ;
		
		return new Vertex(
				(x * rotateCosA) + (z * rotateMinusSinA) + moveX ,
				y,
				(x * rotateSinA) + (z * rotateCosA) + moveZ);
		
	}	
}
