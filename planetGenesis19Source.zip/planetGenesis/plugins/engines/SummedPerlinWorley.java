/*
 * Created on May 1, 2004
 *
 */

/*
Copyright (c) 2004, David Burnett
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products
derived from this software without specific prior
written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
         SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
         OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

package plugins.engines;

import plugins.noise.Perlin1D;
import Utilities.Vertex;

/**
 * @author vargol
 *
 */
public class SummedPerlinWorley extends SummedWorley {


	Perlin1D perlin;
	
	public SummedPerlinWorley() {
		super();
		perlin = new Perlin1D();
		perlin.InitNoise(seed);
	}

	public void initNoise() {

		storeSettings();

		if (metric.compareTo("Euclidean") == 0) {
			distanceCalc = new Euclidean();
		} else if (metric.compareTo("Manhattan") == 0) {
			distanceCalc = new Manhattan();
		} else if (metric.compareTo("ChessBoard") == 0) {
			distanceCalc = new ChessBoard();
		}else if (metric.compareTo("SineSquared") == 0) {
			distanceCalc = new SineSquared();
		}else if (metric.compareTo("QuasiEuclidean") == 0) {
			distanceCalc = new QuasiEuclidean();
		}
		
		cells.clear();
		tmp = new double[nth];
		perlin.InitNoise(seed);

	}
	
	
	public double getNoiseForVertex(Vertex vertex) {
		double[] distances = calculateDistanceArray(vertex.getX(), vertex.getY(), vertex.getZ());
		double result = 0;
			
		for(int i=0; i < nth; i++) {
			result += perlin.Noise(5 * distances[i],0,0);// make the 5 a strength parameter ?		
		}
		return result;	
	}

	public String name() {
		return "Summed Perlin Worley";
	}

	public String description() {
		return "Worley Cell based algorithm, sums the distances to nth nearest neighbours. <p>Each output of each is perlin distorted, producing rippling.";
	}
}
