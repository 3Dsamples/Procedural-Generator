package plugins.engines;

import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.nio.DoubleBuffer;
import java.nio.channels.FileChannel;

import javax.swing.JPanel;

import GUI.Progress;
import Utilities.NoiseEngine;
import Utilities.PostProcessHelper;
import Utilities.Vertex;

public class DerivativeX extends PostProcessHelper
{
	private double high = 1.0;
	private double low = 0.0;
	private int terrainWidth;
	private int terrainHeight;
	private int startPos;
	
	@Override
	protected void process(DoubleBuffer noiseMap, Progress progress)
	{
		int vertexCount = terrain.getVertexCount();
		
		double delta = vertexCount / 100;
		
		terrainWidth = terrain.getXMesh() - 1;
		terrainHeight = terrain.getZMesh() - 1;
		
		//TODO set up doublebuffer
		try
		{
			FileChannel rwCh = new RandomAccessFile(File.createTempFile("tmpDouble", null),"rw").getChannel();
			long fileSize = vertexCount * 8;
		    DoubleBuffer derivativeMap = rwCh.map(FileChannel.MapMode.READ_WRITE,0, fileSize).asDoubleBuffer();
			derivativeMap.position(0); 	
			noiseMap.position(0);
			
			progress.setMaxValue(terrainHeight);
			progress.setProgressText("Processing " + name());
			progress.setProgressValue(0);
			
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		
		progress.setMaxValue(vertexCount * 2);
		progress.setProgressText("Processing " + name());
		progress.setProgressValue(0);
		
		noiseMap.position(0);
		for(int i = 0; i < vertexCount; i++)
		{
			Vertex vert = getVertex(i);
			double x = vert.getX();
			double y = vert.getY();
			double value = scanNeighbors(x, y, noiseMap);
		}
		
	}
	
	private double scanNeighbors(double x, double y, DoubleBuffer noiseMap)
	{
		double sum = 0.0;
		int index = 0;
		//Upper left: add value
		index = move(x, y, -1, -1);
		sum += noiseMap.get(index);
		
		//Left: add value
		index = move(x, y, -1, 0);
		sum += noiseMap.get(index);
		
		//Lower left: add value
		index = move(x, y, -1, 1);
		sum += noiseMap.get(index);
		
		//
		//Upper right: sub value
		move(x, y, 1, -1);
		sum -= noiseMap.get(index);
		
		//Right: sub value
		move(x, y, 1, 0);
		sum -= noiseMap.get(index);
		
		//Lower right: sub value
		move(x, y, 1, 1);
		sum -= noiseMap.get(index);
		
		return sum;
	}

	@Override
	public NoiseEngine copy()
	{
		return null;
	}

	@Override
	public String description()
	{
		return "Creates a map of the partial derivative with respect to x of the noise.";
	}

	@Override
	public String getDetails() {
		return "<table ><tr><td><b><u>X Derivative</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" +
		"<table>" + "<tr><td><b><u>Details</u></b></td></tr>" +
		"<tr><td><b>New Low:</b> </td><td align=right>"+ low + "</td></tr>" +
		"<tr><td><b>New High:</b> </td><td align=right>"+ high + "</td></tr>" +
		"</table>";
	}

	@Override
	public double getNoiseForVertex(Vertex vertex)
	{
		return 0.0;
	}

	@Override
	public double getNoiseForVertex(int vertex)
	{
		return 0.0;
	}

	
    @Override
    public double getScaledMovedNoiseForVertex(double x, double y, double z)
    {
        return 0;
    }
    
	@Override
	public JPanel getPanel()
	{
		// TODO Auto-generated method stub
		//I don't know if this needs any settings
		return null;
	}

	@Override
	public void load(ObjectInputStream file) throws ClassNotFoundException,
			IOException
	{
		// TODO Auto-generated method stub
		//What settings?

	}

	@Override
	public void makePreview()
	{
		for(int i = 0; i < previewNoise.length; i++)
		{
			double[] tempNoise = noise.getPreviewNoise();
			previewNoise[i] = tempNoise[i];
			//TODO For the moment, I'll just feedback the input preview
		}
	}

	@Override
	public String name()
	{
		return "XDerivative 0.1";
	}

	@Override
	public void restoreSettings()
	{
		// TODO Auto-generated method stub
		//What settings?
	}

	@Override
	public void save(ObjectOutputStream file) throws IOException
	{
		file.writeObject(this.getClass().getName());
	}

	@Override
	public void storeSettings()
	{
		// TODO Auto-generated method stub
		//What settings?
	}

}
