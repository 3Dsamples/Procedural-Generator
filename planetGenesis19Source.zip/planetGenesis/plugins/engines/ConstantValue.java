
/*
 * ConstantValue.java
 *
 * Created on 21 August 2003
 */

/*
 Copyright (c) 2003, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

package plugins.engines;

import GUI.ExtendedHashBasedPanel;
import Utilities.*;

import java.awt.Font;
import java.awt.Graphics2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
/**
*
 * @author  David
 */
public class ConstantValue extends NoiseEngine {

	private ExtendedHashBasedPanel panel;
	private double constant;
	
	
	public static void main(String[] args) {
		try {
			Class noiseClass = Class.forName("plugins.engines.Fault");
			Utilities.NoiseEngine noise =
				(Utilities.NoiseEngine) noiseClass.newInstance();
			//            plugins.engines.Perlin noise = new plugins.engines.Perlin();
			noise.initNoise();
			//            octaves = panel.getOctaves();
			//            terrain = noise.CreateTerrain(50, 50, 0.5);
			//            noise.CreatePlanetPNG(1024, 1024, "D:\\test3Java.png" );
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(99);
		}
	}

	/** Creates a new instance of perlin */
	public ConstantValue() {
		panel = new ExtendedHashBasedPanel();
		panel.addTextBox("constant", "Constant", "1.0", "A constant value");
		storeSettings();
	}

	public String name() {
		return "Constant";
	}

	public String description() {
		return "Returns a constant value. For use with MultiNoise";
	}

	public javax.swing.JPanel getPanel() {
		return panel;
	}

	public void initNoise() {
		constant = panel.getDouble("constant");		
	}

	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		return constant;
	}
	
	public double getNoiseForVertex(Vertex vertex) {
		
		return constant;
	}

	
	public void setProjection(int projection) {
		gridProjection = projection;
	}

	public double getNoiseForVertex(int vertex) {
		return constant;
	}
	


	public void paintIcon(Graphics2D g2, java.awt.image.ImageObserver noiseComponent) {
		Font old = g2.getFont();
		g2.setFont(new Font(null, Font.ITALIC, 18));
		g2.drawString(""+constant, 27, 38);
		g2.setFont(old);		
	}
	
	public void makePreview() {
		initNoise();	
		for(int i=0; i < 64*64; i++) {
			previewNoise[i] = constant;
		}
	
	}
	
	public void storeSettings() {
		constant = panel.getDouble("constant"); 
	}
	
	public void restoreSettings() {
	
		panel.setValue("constant", ""+constant);
	}
	

	public void save(ObjectOutputStream file) throws IOException
	 {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);	
	
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}

   /* (non-Javadoc)
     * @see Utilities.NoiseEngine#copy()
     */
    public NoiseEngine copy() {
        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            ((ExtendedHashBasedPanel)copy.getPanel()).setValuesUsingHash(panel.getHash());
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
           e.printStackTrace();
        }	
        return null;
    }	
	
	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Value:</b> </td><td align=right>"+ constant + "</td></tr></table>";
			
	}
}
