
/*
 * MultiNoise.java
 *
 * Created on 05 March 2002, 19:08
 */

/*
 Copyright (c) 2002, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

package plugins.engines;

import Utilities.*;

import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JDialog;
import javax.swing.JOptionPane;


/**
*
 * @author  David
 */
public class MultiNoise extends NoiseEngine {

	private NoiseEngine[] noise;
	private Function math;

	private String functionName;

	public static void main(String[] args) {
		try {
			Class noiseClass = Class.forName("plugins.engines.Perlin");
			Utilities.NoiseEngine noise =
				(Utilities.NoiseEngine) noiseClass.newInstance();
			//            plugins.engines.Perlin noise = new plugins.engines.Perlin();
			noise.initNoise();
			//            octaves = panel.getOctaves();
			//            terrain = noise.CreateTerrain(50, 50, 0.5);
			//            noise.CreatePlanetPNG(1024, 1024, "D:\\test3Java.png" );
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(99);
		}
	}

	/** Creates a new instance of perlin */
	public MultiNoise() {
		noise = new NoiseEngine[2];
		math = new AddFunction(); 
		storeSettings();
	}

	public String name() {
		return functionName;
	}

	public String description() {
		return "Combines the results of two noise sources";
	}

	public javax.swing.JPanel getPanel() {
		return panel;
	}

	public void initNoise() {
				
		if(noise[0] != null && noise[1] != null ) {
			noise[0].initNoise();
			noise[1].initNoise();
		}
	}
	
	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		return math.scaledFunction(x, y, z);
	}
	public double getNoiseForVertex(Vertex vertex) {
		return math.function(vertex);
	}

	public Vertex getNoiseSize() {
		return noise[0].getNoiseSize();
	}

	public Vertex getNoiseOffset() {
		return noise[0].getNoiseSize();
	}
	
	public void setProjection(int projection) {
		noise[0].setProjection(projection);
		noise[1].setProjection(projection);
	}
	
	private interface Function {
		public double scaledFunction(double x, double y, double z);
		public double function (Vertex vertex);
		public double function (int vertex);
	//	public void   function (double[] noise1, Vertex[] vertices, double[] returnArray);
		public void   function (double[] returnArray);
		public void drawIcon(Graphics2D g2);
	}
	
	
	private class AddFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final double[] noise2 = noise[1].getPreviewNoise();;
			
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = noise1[i] + noise2[i];
			}
		}
		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = noise1[i] + noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		
		public double function (Vertex vertex) {
			return noise[0].getNoiseForVertex(vertex) +  noise[1].getNoiseForVertex(vertex);
		}

		public double function (int vertex) {
			return noise[0].getNoiseForVertex(vertex) +  noise[1].getNoiseForVertex(vertex);
		}

		public double function (double noise1, double noise2, double x, double y, double z) {
			return noise1 + noise2;
		}

		public void drawIcon(Graphics2D g2) {
			g2.drawString("+", 28, 38);
		}

		public double scaledFunction(double x, double y, double z)
		{
			return noise[0].getScaledMovedNoiseForVertex(x, y, z)+noise[1].getScaledMovedNoiseForVertex(x, y, z);
		}
	}

	private class SubtractFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final double[] noise2 = noise[1].getPreviewNoise();;
			
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = noise1[i] - noise2[i];
			}
		}
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = noise1[i] - noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {
			return noise1 - noise2;
		}

		public double function (Vertex vertex) {
			return noise[0].getNoiseForVertex(vertex) -  noise[1].getNoiseForVertex(vertex);
		}

		public double function (int vertex) {
			return noise[0].getNoiseForVertex(vertex) -  noise[1].getNoiseForVertex(vertex);
		}
		public void drawIcon(Graphics2D g2) {
			g2.drawString("-", 30, 38);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return noise[0].getScaledMovedNoiseForVertex(x, y, z)-noise[1].getScaledMovedNoiseForVertex(x, y, z);
		}
	}

	private class MultiplyFunction implements Function{
	

		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final double[] noise2 = noise[1].getPreviewNoise();;
			
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = noise1[i] * noise2[i];
			}
		}

		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = noise1[i] * noise[1].getNoiseForVertex(vertices[i]);
			}
		}
		public double function (double noise1, double noise2, double x, double y, double z) {
			return noise1 * noise2;
		}

		public double function (Vertex vertex) {
			return noise[0].getNoiseForVertex(vertex) *  noise[1].getNoiseForVertex(vertex);
		}

		public double function (int vertex) {
			return noise[0].getNoiseForVertex(vertex) *  noise[1].getNoiseForVertex(vertex);
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 24));
			g2.drawString("*", 29, 46);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return noise[0].getScaledMovedNoiseForVertex(x, y, z)*noise[1].getScaledMovedNoiseForVertex(x, y, z);
		}
	}

	private class DivideFunction implements Function{
		

		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final double[] noise2 = noise[1].getPreviewNoise();;
			
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = noise1[i] / noise2[i];
			}
		}

		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = noise1[i] / noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {
			return noise1 / noise2;
		}

		public double function (Vertex vertex) {
			return noise[0].getNoiseForVertex(vertex) /  noise[1].getNoiseForVertex(vertex);
		}

		public double function (int vertex) {
			return noise[0].getNoiseForVertex(vertex) /  noise[1].getNoiseForVertex(vertex);
		}

		public void drawIcon(Graphics2D g2) {
			g2.drawString("/", 31, 38);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return noise[0].getScaledMovedNoiseForVertex(x, y, z)/noise[1].getScaledMovedNoiseForVertex(x, y, z);
		}
	}

	private class PowerFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final double[] noise2 = noise[1].getPreviewNoise();;
			
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = Math.pow(noise1[i], noise2[i]);
			}
		}
	
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = Math.pow(noise1[i],noise[1].getNoiseForVertex(vertices[i]));
			}
		}


		public double function (double noise1, double noise2, int vertex) {
			return Math.pow(noise1,noise2);
		}

		public double function (Vertex vertex) {
			return Math.pow(noise[0].getNoiseForVertex(vertex), noise[1].getNoiseForVertex(vertex));
		}

		public double function (int vertex) {
			return Math.pow(noise[0].getNoiseForVertex(vertex), noise[1].getNoiseForVertex(vertex));
		}

		public void drawIcon(Graphics2D g2) {
			g2.drawString("x**y", 18, 38);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return Math.pow(noise[0].getScaledMovedNoiseForVertex(x, y, z), noise[1].getScaledMovedNoiseForVertex(x, y, z));
		}
	}

	private class DisturbFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final Vertex[] vertices = noise[1].getPreviewVertices();
			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].multiply(noise1[i], noise1[i], noise1[i]);
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}
		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].multiply(noise1[i], noise1[i], noise1[i]);
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {
			x *= noise1;
			y *= noise1;
			z *= noise1;
			return noise[1].getNoiseForVertex(new Vertex(x,y,z));    
		}
               
		public double function (Vertex vertex) {
			double noiseValue = noise[0].getNoiseForVertex(vertex); 
			vertex.multiply(noiseValue, noiseValue, noiseValue);
			return noise[1].getNoiseForVertex(vertex);
		}

		public double function (int vertex) {
			Vertex tmp;
			double noiseValue = noise[0].getNoiseForVertex(vertex);
			tmp =  noise[1].getVertex(vertex);
			tmp.multiply(noiseValue, noiseValue, noiseValue);
		//	vertex.multiply(noiseValue, noiseValue, noiseValue);
			return noise[1].getNoiseForVertex(tmp);
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Disturb", 8, 40);
		}
		
		public double scaledFunction(double x, double y, double z)
		{
			double noiseVal=noise[0].getScaledMovedNoiseForVertex(x, y, z);
			return noise[1].getScaledMovedNoiseForVertex(x*noiseVal, y*noiseVal, z*noiseVal);
		}
	}
	
	private class WarpFunction implements Function{
		

		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final Vertex[] vertices = noise[1].getPreviewVertices();
			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].add(noise1[i], noise1[i], noise1[i]);
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].add(noise1[i], noise1[i], noise1[i]);
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {
			x += noise1;
			y += noise1;
			z += noise1;
			return noise[1].getNoiseForVertex(new Vertex(x,y,z));
		}

		public double function (Vertex vertex) {
			double noiseValue = noise[0].getNoiseForVertex(vertex); 
			vertex.add(noiseValue, noiseValue, noiseValue);
			return noise[1].getNoiseForVertex(vertex);
		}

		public double function (int vertex) {
			Vertex tmp;
			double noiseValue = noise[0].getNoiseForVertex(vertex);
			tmp =  noise[1].getVertex(vertex);
			tmp.add(noiseValue, noiseValue, noiseValue);
		//	vertex.multiply(noiseValue, noiseValue, noiseValue);
			return noise[1].getNoiseForVertex(tmp);
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Warp", 15, 40);
		}
		public double scaledFunction(double x, double y, double z)
		{
			double noiseVal=noise[0].getScaledMovedNoiseForVertex(x, y, z);
			return noise[1].getScaledMovedNoiseForVertex(x+noiseVal, y+noiseVal, z+noiseVal);
		}
	}
	
	private class ReplaceYFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final Vertex[] vertices = noise[1].getPreviewVertices();

			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setY(noise1[i]);
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			double j;
			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setY(noise1[i]);
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {

			y = noise1;
			return noise[1].getNoiseForVertex(new Vertex(x,y,z));

		}

		public double function (Vertex vertex) {
		
			double noise0 = noise[0].getNoiseForVertex(vertex);
			vertex.setY(noise0);
			return noise[1].getNoiseForVertex(vertex);

		}

		public double function (int vertex) {
			Vertex tmp;
		
			tmp = noise[1].getVertex(vertex);
			tmp.setY(noise[0].getNoiseForVertex(vertex));
			return noise[1].getNoiseForVertex(tmp);
			
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Set Y", 15, 40);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return noise[1].getScaledMovedNoiseForVertex(x, noise[0].getScaledMovedNoiseForVertex(x, y, z), z);
		}
	}

	private class ReplaceXFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final Vertex[] vertices = noise[1].getPreviewVertices();

			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setX(noise1[i]);
//				vertices[i].debug();
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
			
			return;
		}

		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			double j;
			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setX(noise1[i]);
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {

			x = noise1;
			return noise[1].getNoiseForVertex(new Vertex(x,y,z));

		}

		public double function (Vertex vertex) {
		
			double noise0 = noise[0].getNoiseForVertex(vertex);
			vertex.setX(noise0);
			return noise[1].getNoiseForVertex(vertex);

		}

		public double function (int vertex) {
			Vertex tmp, tmp1;
		
			tmp = noise[1].getVertex(vertex);
			tmp.setX(noise[0].getNoiseForVertex(vertex));
//			tmp.debug();

			return noise[1].getNoiseForVertex(tmp);
			
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Set X", 15, 40);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return noise[1].getScaledMovedNoiseForVertex(noise[0].getScaledMovedNoiseForVertex(x, y, z), y, z);
		}
	}
	
	private class ReplaceZFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final Vertex[] vertices = noise[1].getPreviewVertices();

			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setZ(noise1[i]);
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			double j;
			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setZ(noise1[i]);
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {

			z = noise1;
			return noise[1].getNoiseForVertex(new Vertex(x,y,z));

		}

		public double function (Vertex vertex) {
		
			double noise0 = noise[0].getNoiseForVertex(vertex);
			vertex.setZ(noise0);
			return noise[1].getNoiseForVertex(vertex);

		}

		public double function (int vertex) {
			Vertex tmp;
		
			tmp = noise[1].getVertex(vertex);
			tmp.setZ(noise[0].getNoiseForVertex(vertex));
			return noise[1].getNoiseForVertex(tmp);
			
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Set Z", 15, 40);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return noise[1].getScaledMovedNoiseForVertex(x, y, noise[0].getScaledMovedNoiseForVertex(x, y, z));
		}
	}
	
	private class WarpYFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final Vertex[] vertices = noise[1].getPreviewVertices();

			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setY(noise1[i] + vertices[i].getY());
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			double j;
			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setY(noise1[i] + vertices[i].getY());
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {

			y += noise1;
			return noise[1].getNoiseForVertex(new Vertex(x,y,z));

		}

		public double function (Vertex vertex) {
		
			double noise0 = noise[0].getNoiseForVertex(vertex);
			vertex.setY(noise0 + vertex.getY());
			return noise[1].getNoiseForVertex(vertex);

		}

		public double function (int vertex) {
			Vertex tmp;
		
			tmp = noise[1].getVertex(vertex);
			tmp.setY(tmp.getY()+noise[0].getNoiseForVertex(vertex));
			return noise[1].getNoiseForVertex(tmp);
			
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Warp Y", 7, 40);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return noise[1].getScaledMovedNoiseForVertex(x, y+noise[0].getScaledMovedNoiseForVertex(x, y, z), z);
		}
	}

	private class WarpXFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final Vertex[] vertices = noise[1].getPreviewVertices();

			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setX(noise1[i] + vertices[i].getX());
//				vertices[i].debug();
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
			
			return;
		}

		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			double j;
			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setX(noise1[i] + vertices[i].getX());
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {

			x += noise1;
			return noise[1].getNoiseForVertex(new Vertex(x,y,z));

		}

		public double function (Vertex vertex) {
		
			double noise0 = noise[0].getNoiseForVertex(vertex);
			vertex.setX(vertex.getX() + noise0);
			return noise[1].getNoiseForVertex(vertex);

		}

		public double function (int vertex) {
			Vertex tmp, tmp1;
		
			tmp = noise[1].getVertex(vertex);
			tmp.setX(tmp.getX() + noise[0].getNoiseForVertex(vertex));
//			tmp.debug();

			return noise[1].getNoiseForVertex(tmp);
			
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Warp X", 7, 40);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return noise[1].getScaledMovedNoiseForVertex(x+noise[0].getScaledMovedNoiseForVertex(x, y, z), y, z);
		}
	}
	
	private class WarpZFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final Vertex[] vertices = noise[1].getPreviewVertices();

			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setZ(noise1[i] + vertices[i].getZ());
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			double j;
			
			for(int i = 0; i < noise1.length; i++) {
				vertices[i].setZ(noise1[i] + vertices[i].getZ());
				returnArray[i] = noise[1].getNoiseForVertex(vertices[i]);
			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {

			z += noise1;
			return noise[1].getNoiseForVertex(new Vertex(x,y,z));

		}

		public double function (Vertex vertex) {
		
			double noise0 = noise[0].getNoiseForVertex(vertex);
			vertex.setZ(noise0 + vertex.getZ());
			return noise[1].getNoiseForVertex(vertex);

		}

		public double function (int vertex) {
			Vertex tmp;
		
			tmp = noise[1].getVertex(vertex);
			tmp.setZ(tmp.getZ() + noise[0].getNoiseForVertex(vertex));
			return noise[1].getNoiseForVertex(tmp);
			
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Warp Z", 7, 40);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return noise[1].getScaledMovedNoiseForVertex(x, y, z+noise[0].getScaledMovedNoiseForVertex(x, y, z));
		}
	}
	
	
	private class TurbulenceFunction implements Function{
		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			double j, mult=1;//mult is factor taking care of the fraction part of the octave
			int limit;
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = 0;
				limit=(int) Math.floor(noise1[i]+1);
				for(j=1; j<=limit; j++) {
					if(j==limit)
						mult=noise1[i]-Math.floor(noise1[i]);
					else
						mult=1;
					vertices[i].multiply(noise1[i], noise1[i], noise1[i]);
					returnArray[i] += ((1/(j * j)) * noise[1].getNoiseForVertex(vertices[i]))*mult;
				}
				

			}
		}

		public double function (double noise1, double noise2, double x, double y, double z) {
			double returnValue = 0;
			double j, mult;
			
			double limit=(int) Math.floor(noise1+1);
			for(j=1; j<=limit; j++) {
				if(j==limit)
					mult=noise1-Math.floor(noise1);
				else
					mult=1;
				x *= noise1;
				y *= noise1;
				z *= noise1;
				returnValue += ((1/(j * j)) * noise[1].getNoiseForVertex(new Vertex(x,y,z)))*mult;
			}


			return returnValue;
		}

		public double function (Vertex vertex) {
			
			double returnValue = 0;
			double j, noise0, mult;
			
			noise0 = noise[0].getNoiseForVertex(vertex);
			double limit=(int) Math.floor(noise0+1);
			for(j=1; j<=limit; j++) {
				if(j==limit)
					mult=noise0-Math.floor(noise0);
				else
					mult=1;
				vertex.multiply(noise0, noise0, noise0);
				returnValue += ((1/(j * j)) * noise[1].getNoiseForVertex(vertex))*mult;
			}
				

			return returnValue;
		}

		public double function (int vertex) {
			Vertex tmp;
			double returnValue = 0;
			double j, noise0;
			
			tmp = noise[0].getVertex(vertex);
			noise0 = noise[0].getNoiseForVertex(vertex);
			
			for(j=1; j<=noise0; j++) {
				tmp.multiply(noise0, noise0, noise0);
				returnValue += ((1/(j * j)) * noise[1].getNoiseForVertex(tmp));
			}
				
			j = noise0 - j+1;
			
			if(j > 0) {	
//				tmp.multiply(j, j, j);
				tmp.multiply(noise0, noise0, noise0);
				returnValue += ((1/(j * j)) * noise[1].getNoiseForVertex(tmp));
			}
			return returnValue;
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Turb", 15, 40);
		}
		
		public double scaledFunction(double x, double y, double z)
		{
			double noise0=noise[0].getScaledMovedNoiseForVertex(x, y, z);
//			System.out.println("vert "+x+" "+z+" -> "+noise0);
			double returnValue = 0;
			
			double j;
			for(j=1; j<=noise0+1; j++) {
				x*=noise0; y*=noise0; z*=noise0;
				returnValue += ((1/(j * j)) * noise[1].getScaledMovedNoiseForVertex(x, y, z));
			}
//			System.out.println(returnValue);
			double rmd = noise0 - j+2;
//			System.out.println("Extra j "+rmd);
			if(rmd > 0) {	
				x*=noise0; y*=noise0; z*=noise0;
				returnValue += ((1/(j * j)) * noise[1].getScaledMovedNoiseForVertex(x, y, z))*rmd;
			}
//			System.out.println(returnValue);
			return returnValue;
		}
		
		public void   function (double[] returnArray) {
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final Vertex[] vertices = noise[1].getPreviewVertices();
			double j;
			double noise0;
			for(int i = 0; i < noise1.length; i++) {
//				System.out.println("vert "+vertices[i].x+" "+vertices[i].z+" -> "+noise1[i]);
//				noise0=noise1[i];
				noise0=noise[0].getScaledMovedNoiseForVertex(vertices[i].x, vertices[i].y, vertices[i].z);
				returnArray[i] = 0;
				for(j=1; j<=noise0+1; j++) {
					vertices[i].multiply(noise0, noise0, noise0);
//					returnArray[i] += ((1/(j * j)) * noise[1].getNoiseForVertex(vertices[i]));
					double nn=noise[1].getScaledMovedNoiseForVertex(vertices[i].x, vertices[i].y, vertices[i].z);
					returnArray[i] += ((1/(j * j)) * nn);
//					System.out.println(returnArray[i]+"("+vertices[i].x+" "+vertices[i].z+") -> "+nn);
				}
//				System.out.println(returnArray[i]);
				double rmd = noise0 - j+2;
				if(rmd > 0) {	
					vertices[i].multiply(noise0, noise0, noise0);
//					returnArray[i] += ((1/(j * j)) * noise[1].getNoiseForVertex(vertices[i]))*rmd;
					returnArray[i] += ((1/(j * j)) * noise[1].getScaledMovedNoiseForVertex(vertices[i].x, vertices[i].y, vertices[i].z))*rmd;
				}
//				System.out.println(returnArray[i]);
			}
		}
	}


	private class MaximumFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final double[] noise2 = noise[1].getPreviewNoise();;
			
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = Math.max(noise1[i], noise2[i]);
			}
		}
		
		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = Math.max(noise1[i], noise[1].getNoiseForVertex(vertices[i]));
			}
		}
		
		public double function (Vertex vertex) {
			return Math.max(noise[0].getNoiseForVertex(vertex), noise[1].getNoiseForVertex(vertex));
		}

		public double function (int vertex) {
			return Math.max(noise[0].getNoiseForVertex(vertex), noise[1].getNoiseForVertex(vertex));
		}

		public double function (double noise1, double noise2, double x, double y, double z) {
			return Math.max(noise1, noise2);
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Max", 18, 38);
		}
		public double scaledFunction(double x, double y, double z)
		{
			return Math.max(noise[0].getScaledMovedNoiseForVertex(x, y, z), noise[1].getScaledMovedNoiseForVertex(x, y, z));
		}

	}

	private class MinimumFunction implements Function{
		
		public void   function (double[] returnArray) {
			
			final double[] noise1 = noise[0].getPreviewNoise(); 
			final double[] noise2 = noise[1].getPreviewNoise();;
			
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = Math.min(noise1[i], noise2[i]);
			}
		}

		public void   function (double[] noise1, Vertex[] vertices, double[] returnArray) {
			for(int i = 0; i < noise1.length; i++) {
				returnArray[i] = Math.min(noise1[i], noise[1].getNoiseForVertex(vertices[i]));
			}
		}
		
		public double function (Vertex vertex) {
			return Math.min(noise[0].getNoiseForVertex(vertex), noise[1].getNoiseForVertex(vertex));
		}

		public double function (int vertex) {
			return Math.min(noise[0].getNoiseForVertex(vertex), noise[1].getNoiseForVertex(vertex));
		}

		public double function (double noise1, double noise2, double x, double y, double z) {
			return Math.min(noise1, noise2);
		}

		public void drawIcon(Graphics2D g2) {
			g2.setFont(new Font(null, Font.PLAIN, 16));
			g2.drawString("Min", 18, 38);
		}

		public double scaledFunction(double x, double y, double z)
		{
			return Math.min(noise[0].getScaledMovedNoiseForVertex(x, y, z), noise[1].getScaledMovedNoiseForVertex(x, y, z));
		}
	}
	
	public double getNoiseForVertex(int vertex) {
		return math.function(vertex);
	}
	
	public void setTerrain(Landscape terrain) {
		noise[0].setTerrain(terrain.getNewLandscape());
		noise[1].setTerrain(terrain.getNewLandscape());
		return;
	}

	public Landscape getTerrain() {
		return noise[0].getTerrain();
	}
	
	public Vertex getVertex(int index) {
		return noise[0].getVertex(index);
	}	


	public void paintIcon(Graphics2D g2, java.awt.image.ImageObserver component) {
		Font old = g2.getFont();
		if(noise[0] != null && noise[1] != null) {
			g2.drawImage(preview,0,0,component);
		}
		
		g2.setFont(new Font(null, Font.PLAIN, 18));
		math.drawIcon (g2);
		g2.setFont(old);
	}
	
	public void setNoiseEngine(NoiseEngine noise, int index) {
		this.noise[index] = noise;
	}
	
	public void setFunction(String functionName) {
		if(functionName.compareTo("Add") == 0) {  
			math = new AddFunction(); 
		} else if(functionName.compareTo("Subtract") == 0) {  
			math = new SubtractFunction(); 
		} else if(functionName.compareTo("Multiply") == 0) {  
			math = new MultiplyFunction(); 
		} else if(functionName.compareTo("Divide") == 0) {  
			math = new DivideFunction(); 
		} else  if(functionName.compareTo("Power") == 0) {  
			math = new PowerFunction(); 
		} else  if(functionName.compareTo("Disturb") == 0) {  
			math = new DisturbFunction(); 
		} else  if(functionName.compareTo("Warp") == 0) {  
			math = new WarpFunction(); 
		} else  if(functionName.compareTo("Turbulence") == 0) {  
			math = new TurbulenceFunction(); 
		} else  if(functionName.compareTo("Set X") == 0) {  
			math = new ReplaceXFunction(); 	
		} else  if(functionName.compareTo("Set Y") == 0) {  
			math = new ReplaceYFunction(); 	
		} else  if(functionName.compareTo("Set Z") == 0) {  
			math = new ReplaceZFunction(); 	
		} else  if(functionName.compareTo("Maximum") == 0) {  
			math = new MaximumFunction(); 
		} else  if(functionName.compareTo("Minimum") == 0) {  
			math = new MinimumFunction(); 
		}  else  if(functionName.compareTo("Warp X") == 0) {  
			math = new WarpXFunction(); 	
		} else  if(functionName.compareTo("Warp Y") == 0) {  
			math = new WarpYFunction(); 	
		} else  if(functionName.compareTo("Warp Z") == 0) {  
			math = new WarpZFunction(); 
		}/*else if(functionName.compareTo("Spectral Add") == 0){
		math = new SpectralFunction();
	}*/
 
		this.functionName = functionName;
		return;
	}
	
	public void makePreview() {

		System.err.println(name() + " makePreview");
		double  scale;
		DataBuffer previewData = preview.getRaster().getDataBuffer();
		boolean nanWarning = false;
  
		if(noise[0] != null && noise[1] != null) {		
			max = Double.NEGATIVE_INFINITY;
			min = Double.POSITIVE_INFINITY;
			initNoise();
			
			math.function(previewNoise);
	
			for(int index = 0; index < 64 * 64; index++){				
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				if(Double.isNaN(previewNoise[index])) {
					nanWarning = true;
				}
			}

			if(max == Double.POSITIVE_INFINITY || min == Double.NEGATIVE_INFINITY) {

				JOptionPane pane = new JOptionPane(name() + " produces infinity for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "Warning");
				dialog.setModal(false);
				dialog.setVisible(true);
			}
		
			if(nanWarning) {
				JOptionPane pane = new JOptionPane(name() + " results in complex numbers being generated for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "NaN Warning");
				dialog.setModal(false);
				dialog.setVisible(true);				
			}
			
			scale = 255 / (max - min); 
			for(int i = 0; i < 64*64; i++) {
				previewData.setElem(i, (int)((previewNoise[i]  - min) * scale));			
			}
		}
		return;
	}
	
	public void storeSettings() {
	}
	
	public void restoreSettings() {	
		setFunction(functionName);
	}
	
	public Vertex[] getPreviewVertices() {		
		return noise[0].getPreviewVertices();	
	}
	

	public void save(ObjectOutputStream file) throws IOException
	 {
		
		file.writeObject(this.getClass().getName());
		file.writeObject("functionName");
		file.writeObject(functionName);
		file.writeObject("END");
	
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		String value;
		String type = (String)file.readObject(); 
		type = (String)file.readObject();
		
		while(type.compareTo("END") != 0) {
			value = (String)file.readObject();
			if(type.compareTo("functionName") == 0) {
				functionName = value;
			}
			type = (String)file.readObject();
		}
		restoreSettings();
	}	
	
	
	public String getDetails() {
		return "<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" +
			"<table>" + "<tr><td><b><u>Details</u></b></td></tr>" +
			"<tr><td><b>Function:</b> </td><td align=right>"+ functionName + "</td></tr></table>";
			
	}

	public NoiseEngine copy() {
		// TODO Auto-generated method stub
		return null;
	}	

}
