/*
 * Created on Dec 10, 2007
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import Utilities.Vertex;
/**
 * @author vargol
 * @author su_liam
 *
 * A modification to the original perlin multifractal algorithm
 * in the hopes of increasing detail while retaining the variable
 * change in detail sizes.
 */
public class ModifiedMultiFractal extends Perlin
{
	protected double sensitivity;
	protected Operation operation;
	
	public void storeSettings()
	{
		if(!panel.validKey("sensitivity"))
			panel.addTextBox("sensitivity", "Sensitivity", "" + 1.0, "The sensitivity of multifractal octaves to local variation in weight");
		sensitivity = panel.getDouble("sensitivity");
		if(!panel.validKey("operation"))
			panel.addDropDown("operation", "Operation", new String[]{"add", "subtract", "difference", "multiply", "shiprocks", "sqrt", "atan", "special"},
					"The mode by which each octave is applied to the fractal");
		//if(operation == null)
			operation = Operation.create(panel.getText("operation"));
		super.storeSettings();
	}
	
	public void restoreSettings()
	{
		panel.setValue("sensitivity", ""+sensitivity);
		panel.setValue("operation", ""+operation);
		super.restoreSettings();
	}
	
	public String name()
	{
		return "Modified MultiFractal Noise";
	}

	public String description()
	{
		return "Modified Hybrid Perlin MultiFractal Noise.";
	}
	protected double Turbulence(Vertex vert, long octaves)
	{

		double tmpX, tmpY, tmpZ;
		long i;
		double result, value = 0, weight = 1.0;

		/*
		tmpX = vert.getX();
		tmpY = vert.getY();
		tmpZ = vert.getZ();

		result = 0;
		for (i = 0; i < octaves; i++) {

			value = weight * (noiseType.Noise(tmpX, tmpY, tmpZ));
			weight = value;
			
			result += (1 / Math.pow(persistence, i)) * value;
			//                result += ((pow(1.2, i)) * (perlin_noise_2d(tmpX, tmpY)));
			tmpX *= frequency;
			tmpY *= frequency;
			tmpZ *= frequency;
			//              fprintf(stderr, "%f\n", result);
		}
		*/
		return Turbulence(vert.getX(), vert.getY(), vert.getZ(), octaves);

	}

	protected double Turbulence(double tmpX, double tmpY,  double tmpZ, long octaves)
	{

		long i;
		double result = 0.0, value = 0.0, weight = 1.0;
		double noise = 0.0;

		result = 0;
		for (i = 0; i < octaves; i++) {
			
			value = weight * noiseType.Noise(tmpX, tmpY, tmpZ);
			
			//result += (1 / Math.pow(persistence, i)) * value;
			//result += powerArray[(int)i] * value;//using powerArray to save overhead on Math.pow(). Should help speed.
			result = operation.apply(result, value, powerArray[(int)i]);
			weight = 1 - value;//for a range of 0.0 to 1.0
			weight = 1 - sensitivity*weight;//for controlling the influence of local effects. Higher values of value will create higher weights.
			//1 - s(1 - v) == 1 - s + sv: let s = 1.0: 1 - 1*1 + 1*v == v
			//So at sensitivity 1.0, this hasn't changed the original MMF algo at all.
			tmpX *= frequency;
			tmpY *= frequency;
			tmpZ *= frequency;
		}
		
		return result;

	}
	
}
