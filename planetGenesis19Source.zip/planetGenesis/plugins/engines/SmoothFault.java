/*
 * Created on Jul 13, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import java.util.Hashtable;
import java.util.Random;
import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import GUI.ExtendedHashBasedPanel;
import Utilities.NoiseEngine;
import Utilities.NoiseType;
import Utilities.Vector3D;
import Utilities.Vertex;

/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class SmoothFault extends NoiseEngine {
	
	protected double[] scanDoubles;
	protected NoiseType noiseType;

	private ExtendedHashBasedPanel panel;
	private double scale;// yNoise, zNoise;
	private int iterations, resolution;
	private long seed;
	
	private Vector3D[] offsets;
	private int[] directions;
	protected Hashtable<Double, double[]> cells;
	protected final static double HASH_MOD_VALUE = Math.pow(2,32);

	/** Creates a new instance of perlin */
	public SmoothFault() {
		resolution = 50;
		panel = new ExtendedHashBasedPanel();
		panel.addTextBox("res", "Resolution", ""+resolution, "Defines how sharp the texture is.");
		panel.addTextBox("iterations", "Interations", "1000", "Defines the complexity of the texture is.");
		panel.addRandomSeed("seed", "Random Seed", System.currentTimeMillis());
		cells = new Hashtable<Double, double[]>(100);
		storeSettings();
		makePreview();
	}




	private double[] getNoiseForCorners(double x, double y, double z) {
		
		double xFloor = Math.floor(x);
		double yFloor = Math.floor(y);
		double zFloor = Math.floor(z);


		Double key = new Double(((702395077*xFloor+915488749*yFloor+2120969693*zFloor) % HASH_MOD_VALUE));

		if(cells.containsKey(key)) {
			return (double[])cells.get(key);
		} 
		
		double[] noise = new double[8];
		noise[0] = doFaulting(new Vertex(xFloor, yFloor, zFloor));
		noise[1] = doFaulting(new Vertex(xFloor+1, yFloor, zFloor));
		noise[2] = doFaulting(new Vertex(xFloor, yFloor+1, zFloor));
		noise[3] = doFaulting(new Vertex(xFloor, yFloor, zFloor+1));
		noise[4] = doFaulting(new Vertex(xFloor+1, yFloor+1, zFloor));
		noise[5] = doFaulting(new Vertex(xFloor+1, yFloor, zFloor+1));
		noise[6] = doFaulting(new Vertex(xFloor, yFloor+1, zFloor+1));
		noise[7] = doFaulting(new Vertex(xFloor+1, yFloor+1, zFloor+1));
		if(cells.size() == 100) {
			cells.clear();
		}
		cells.put(key, noise);
		return noise;
		

	}

	private double lerp(double weight, double pointA, double pointB) {
		return pointA + weight * (pointB - pointA);
	}

	private double fade(double pointOffset) {
		return pointOffset;
			/* * pointOffset
			* pointOffset
			* (pointOffset * (pointOffset * 6 - 15) + 10); */
	}
	public String name() {
		return "Smooth Fault Noise";
	}

	public String description() {
		return "Simple plate techtonics simulation.\n" + 
				"Works best with meshes.";
	}

	public javax.swing.JPanel getPanel() {
		return panel;
	}

	public void initNoise() {
		cells.clear();
	}
    // Not thread safe
	private Vertex vTemp=new Vertex(0, 0, 0);
	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		vTemp.x=x; vTemp.y=y; vTemp.z=z;
		return getNoiseForVertex(vTemp);
	}

	public double getNoiseForVertex(Vertex vertex) {
		double x = vertex.getX(); 
		double y = vertex.getY(); 
		double z = vertex.getZ();
		
		double[] cornersNoise = getNoiseForCorners(x, y, z);


		x -= Math.floor(x); // FIND RELATIVE X,Y,Z
		y -= Math.floor(y); // OF POINT IN CUBE.
		z -= Math.floor(z);
		
		double u = fade(x); // COMPUTE FADE CURVES
		double v = fade(y); // FOR EACH OF X,Y,Z.
		double w = fade(z);
		

		return 	lerp(w, 
					lerp(v, 
						lerp(u, 
						    cornersNoise[0], // AND ADD
							cornersNoise[1]), // BLENDED
						lerp(u, 
							cornersNoise[2], // RESULTS
							cornersNoise[4])), // FROM  8
					lerp(v, 
						lerp(u, 
							cornersNoise[3], // CORNERS
							cornersNoise[5]), // OF CUBE
						lerp(u,
							cornersNoise[6],
							cornersNoise[7])));
	}

	public double doFaulting(Vertex vertex) {
		
		double dotValue;
		double height = 0;
		Vertex tmp;

		for(int i= 0; i < iterations; i++ ) {
			
			tmp = new Vertex(vertex.sub(offsets[i]));
			dotValue = offsets[i].DotProduct(tmp);
			
			if(dotValue > 0) {
					height+=directions[i];
			} else {
					height-=directions[i];
			}
		}
		
		return height * scale;
	}


	public double getNoiseForVertex(int vertex) {
		return getNoiseForVertex(terrain.getNoiseVertex(vertex));
	}
	

    public Vertex[] getPreviewVertices() {

		Vertex[]  vertices = new Vertex[64*64];
		int index;
		
		index = 0;	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				vertices[index] = new Vertex(i * (resolution / 63.0), 
											0.0, 
											j * (resolution / 63.0)); 	
				index++;
			}
		}
		
		return vertices;
	}	
	
	public void makePreview() {
		int index = 0;	
		double previewScale;
		double x, y, z;
		final DataBuffer data = preview.getRaster().getDataBuffer();

		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;


		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				
					x = (i * (resolution / 64.0));
					y = 0.0;
					z = (j * (resolution / 64.0));
					previewNoise[index] = getNoiseForVertex(new Vertex(x,y,z));
					if(previewNoise[index] > max) {
						max = previewNoise[index];
					}
					if(previewNoise[index] < min) {
						min = previewNoise[index];
					}
					index++;			}
		}	
		
		previewScale = 255 / (max - min); 

		for(int i = 0; i < 64*64; i++) {
			data.setElem(i, (int)((previewNoise[i]  - min) * previewScale));			
		}

	}
	
	public void storeSettings() {
		seed = Long.parseLong(panel.getText("seed"));
		resolution = Integer.parseInt(panel.getText("res"));
		Random rand = new Random(seed);
		iterations = panel.getInt("iterations"); 
		scale = 1.0/iterations;
		offsets = new Vector3D[iterations];
		directions = new int[iterations];
		for(int i= 0; i < iterations; i++ ) {
			offsets[i] = new Vector3D((rand.nextDouble()-0.5)*resolution ,(rand.nextDouble()-0.5)*resolution, (rand.nextDouble()-0.5)*resolution);
			directions[i] = rand.nextDouble() > 0.5 ? 1: -1;
		}
	}
	
	public void restoreSettings() {
	
		panel.setValue("res", ""+resolution);
		panel.setValue("seed", ""+seed);
		panel.setValue("iterations", ""+iterations);	
	}
	

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);
	
	}
	
	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}

	   /* (non-Javadoc)
     * @see Utilities.NoiseEngine#copy()
     */
    public NoiseEngine copy() {
        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            ((ExtendedHashBasedPanel)copy.getPanel()).setValuesUsingHash(panel.getHash());
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
           e.printStackTrace();
        }	
        return null;
    }


	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Resolution:</b> </td><td align=right>"+ resolution + "</td></tr>" +
			"<tr><td><b>Iterations:</b> </td><td align=right>"+ iterations + "</td></tr>" +
			"<tr><td><b>Seed:</b> </td><td align=right>" + seed + "</td></tr></table>";
			
	}
	
	public Vertex getNoiseSize() {
		return new Vertex(resolution, resolution, resolution);
	}

}
