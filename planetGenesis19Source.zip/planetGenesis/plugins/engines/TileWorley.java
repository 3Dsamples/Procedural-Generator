package plugins.engines;

import Utilities.Landscape;

/*
 * TileWorley.java
 *
 * Created on 20 July 2003
 */

/*
 Copyright (c) 2003, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

/**
*
 * @author  David
 */
public final class TileWorley extends CacheWorley {


	private double maxX;
	private double maxY;
	private double maxZ;



	public static void main(String[] args) {
		try {
			Class noiseClass = Class.forName("plugins.engines.Fault");
			Utilities.NoiseEngine noise =
				(Utilities.NoiseEngine) noiseClass.newInstance();
			//            plugins.engines.Perlin noise = new plugins.engines.Perlin();
			noise.initNoise();
			//            octaves = panel.getOctaves();
			//            terrain = noise.CreateTerrain(50, 50, 0.5);
			//            noise.CreatePlanetPNG(1024, 1024, "D:\\test3Java.png" );
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(99);
		}
	}

	public String name() {
		return "Tiling Worley";
	}

	public String description() {
		return "Worley Cell based algorithm, distance to nth nearest neighbour<br>Scales and Tiles";
	}


	public void initNoise() {

		super.initNoise();
		
		maxX = panel.getDouble("xNoise");
		maxY = panel.getDouble("yNoise");
		maxZ = panel.getDouble("zNoise");
		storeSettings();
		cells.clear();


	}

	public void setTerrain(Landscape terrain) {
		this.terrain = terrain;
		terrain.setNoiseSpace(this);
		terrain.setProjection(gridProjection);
		terrain.setTile(true);
		return;
	}
	
	protected double FindNeighbours(double x1, final double y1, final double z1, final double xFloor, final double yFloor, final double zFloor, final double[] distances, int index) {
		double distance, temp;
		double seed; 
		Double key;
		double[][] cellCache;
		
		index--;
			
		// genereate random seed
		seed = ((702395077*(xFloor % maxX)+915488749*(yFloor % maxY)+2120969693*(zFloor % maxZ)) % HASH_MOD_VALUE);
		key = new Double(seed);

		if(cells.containsKey(key)) {
			cellCache = (double[][])cells.get(key);
		} else {
			rand.setSeed((long)seed);		
			cellCache= new double[cellCount][3];
			for (int i = 0; i < cellCount; i++) {
				cellCache[i][0] = rand.nextDouble();
				cellCache[i][1] = rand.nextDouble();
				cellCache[i][2] = rand.nextDouble();
			}
			if(cells.size() == 100) {
				cells.clear();
			}
			cells.put(key, cellCache);
		}
		
		for (int i = 0; i < cellCount; i++) {
			distance =
				distanceCalc.compare(
					x1,
					y1,
					z1,
					cellCache[i][0] + xFloor,
					cellCache[i][1] + yFloor,
					cellCache[i][2] + zFloor);
			if (distance < distances[index]) {
				distances[index] = distance;
				int j = index;
				while (j > 0 && distances[j] < distances[j - 1]) {
					temp = distances[j - 1];
					distances[j - 1] = distances[j];
					distances[j] = temp;
					j--;
				}
			}
		}
	//	System.err.println( seed  + "==>" + distances[0] + " in cell " + xFloor + "," +  yFloor + "," +  zFloor);
		return distances[index];
	}

}
