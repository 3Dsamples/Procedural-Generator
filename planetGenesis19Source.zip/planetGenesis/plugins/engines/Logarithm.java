/**
 * 
 */
package plugins.engines;

import java.awt.Graphics2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JPanel;

import Utilities.Vertex;

import GUI.ExtendedHashBasedPanel;

/**
 * @author lindapaddock
 *
 */
public class Logarithm extends ApplyFunction
{
	private class LogarithmFunction extends Function
	{
		private double lnBase;
		
		private final ExtendedHashBasedPanel logPanel = new ExtendedHashBasedPanel();
		private final String[] baseKey = {"base"};
		private final String[] baseLabel = {"Base"};
		private final String[] baseValue = {"" + Math.pow(Math.E, lnBase)};
		private final String[] baseTooltip = {"The base of the logarithm"};
		
		LogarithmFunction()
		{
			logPanel.addTextBoxGroup("Input base", "Input the value of the base", baseKey, baseLabel, baseValue, baseTooltip);
		}
		
		public JPanel getPanel(){return logPanel;}
		
		public double function(Vertex vertex)
		{
			return function(noise.getNoiseForVertex(vertex));
		}
		
		public double function (double value)
		{
			return Math.log(value)/lnBase;
		}
		
		public void storeSettings()
		{
			lnBase = Math.log(logPanel.getDouble("base"));
		}
		
		public void restoreSettings()
		{
			logPanel.setValue("base", ""+Math.pow(Math.E, lnBase));
		}
		
		public void save(ObjectOutputStream file) throws IOException
		 {
			file.writeObject(this.getClass().getName());
			logPanel.save(file);
		}
		
		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException
		{
			String functionType = (String)file.readObject(); 
			
			logPanel.load(file);
			storeSettings();
		}
		
		public void	drawIcon (Graphics2D g2)
		{
			g2.drawString("Logarithm", 6, 38);
		}
	}
	
	public void setFunction(String functionName)
	{
		System.err.println("Function Name set to" + functionName);
		this.functionName = functionName;
		if(functionName.compareTo("Logarithm") == 0)
		{  
			math = new LogarithmFunction();
		}

		return;
	}
	
	LogarithmFunction getMath()
	{
		return (LogarithmFunction)math;
	}
}
