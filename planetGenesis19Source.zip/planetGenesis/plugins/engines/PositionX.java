package plugins.engines;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JPanel;

import Utilities.NoiseEngine;
import Utilities.Vertex;

/*
 * I intend to leave some todos in until I'm sure this thing works properly
 */
public class PositionX extends NoiseEngine
{
	@Override
	/* (non-Javadoc)
     * @see Utilities.NoiseEngine#copy()
     */
    public NoiseEngine copy() {
        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            //No controls, so no panel
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
           e.printStackTrace();
        }	
        return null;
    }	

	@Override
	public String description()
	{
		return "Returns the x-coordinate of the current position. Useful in making textures that vary according to position.";
	}

	@Override
	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Value:</b> </td><td align=right> x-coordinates </td></tr></table>";
			
	}

	@Override
	public double getNoiseForVertex(Vertex vertex)
	{
		return vertex.getX();
	}

	@Override
	public double getNoiseForVertex(int vertex)
	{
		return terrain.getNoiseVertex(vertex).getX();
	}

    @Override
    public double getScaledMovedNoiseForVertex(double x, double y, double z)
    {
        return x;
    }
    
	@Override
	public JPanel getPanel()
	{
		// No controls, so no panel.
		return null;
	}

	@Override
	public void initNoise()
	{
		// TODO Again, no controls, so no initialization. I think...
	}

	@Override
	public void load(ObjectInputStream file) throws ClassNotFoundException,
			IOException
	{
		// TODO No controls, so nothing to load.
	}

	@Override
	public void makePreview()
	{
			int index = 0;
			
			max = Double.NEGATIVE_INFINITY;
			min = Double.POSITIVE_INFINITY;

			for(int j = 0; j < 64; j++){
				for(int i = 0; i < 64; i++){
					previewNoise[index] = i/63.0;
					if(previewNoise[index] > max) {
						max = previewNoise[index];
					}
					if(previewNoise[index] < min) {
						min = previewNoise[index];
					}
					index++;
				}
			}
	}

	@Override
	public String name()
	{
		return "Position in x-coordinate";
	}

	@Override
	public void restoreSettings()
	{
		// TODO Nothing to restore
	}

	@Override
	public void save(ObjectOutputStream file) throws IOException
	{
		file.writeObject(this.getClass().getName());
	}

	@Override
	public void storeSettings()
	{
		// TODO What's to store?
	}

}
