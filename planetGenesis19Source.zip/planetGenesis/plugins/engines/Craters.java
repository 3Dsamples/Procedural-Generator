/*
 * Created on Jun 3, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import Utilities.Spline;
import Utilities.Vertex;

/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class Craters extends CellBasis {

	//double[] knots;
	//Vertex[] points;
	int order = 3;
	double interval = 0.125;
	int nth = 4;
	static private Spline splineEngine = new Spline();

	public Craters() {
		panel.addTextBox("FLOOR", "Crater Floor Height",  "" + 0.0, "Noise value on the crater floor.");
		panel.addTextBox("RIM", "Crater Rim Height",  "" + 1.0, "Noise value on the crater rim.");
	}

	// Thread unsafe
	private Vertex vTemp=new Vertex(0, 0, 0);
	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		vTemp.x=x*xNoise+xOffset;vTemp.y=y*yNoise+yOffset;vTemp.z=z*zNoise+zOffset;
		return getNoiseForVertex(vTemp);
	}

	public double getNoiseForVertex(Vertex vertex) {
		double value = 0, highestSoFar = Double.NEGATIVE_INFINITY;
		double[] distances = calculateDistanceArray(vertex);
		for(int i = 0; i < distances.length; i++) {
			value = splineEngine.spline(distances[i]*3);
			if(value > highestSoFar) {
				highestSoFar = value;
			}
		}
		return highestSoFar;

	}



	public String name() {
		return "Crater Noise";
	}

	public void initNoise(){
		super.initNoise();
		
		double floor = panel.getDouble("FLOOR");
		double rim = panel.getDouble("RIM");
        double ground = 0.0;

		Vertex[] points;
		points = new Vertex[8];
		points[0] = new Vertex(0,floor,0);
		points[1] = new Vertex(0.32,floor,0);
		points[2] = new Vertex(0.35,floor,0);
		points[3] = new Vertex(0.39,rim,0);
		points[4] = new Vertex(0.4,rim,0);
		points[5] = new Vertex(0.46,ground,0);
		points[6] = new Vertex(0.7,ground,0);
		points[7] = new Vertex(1.0,ground,0);

		splineEngine.initSpline(points, order);
		
		xOffset = 0.0;
		
	}
	public double[] calculateDistanceArray(Vertex vertex) {
	
		final double xFloorAddOne;
		final double xFloorSubOne;
		final double yFloorAddOne;
		final double zFloorAddOne;
		final double yFloorSubOne;
		final double zFloorSubOne;

		double[] tmp = new double[nth];
		for(int i = 0; i < nth; i++) {
			tmp[i] = Double.MAX_VALUE;
		}
	
		double nthNearestSoFar = Double.MAX_VALUE;
		final double x = vertex.getX();
		final double y = vertex.getY();
		final double z = vertex.getZ();
		//find point in unit cube
		final double xFloor = Math.floor(x);
		final double yFloor = Math.floor(y);
		final double zFloor = Math.floor(z);

		xFloorAddOne = xFloor+1.0;
		xFloorSubOne = xFloor-1.0;

		yFloorAddOne = yFloor+1.0;
		yFloorSubOne = yFloor-1.0;

		zFloorAddOne = zFloor+1.0;
		zFloorSubOne = zFloor-1.0;
	

		try {

			nthNearestSoFar = FindNeighbours(x, y, z, xFloor, yFloor, zFloor, tmp, nth);

			// find neighbours on the z plane, if the
			// nearest point on the toher cube is farther away
			// than the current nth neigbour then don't bother
			if (distanceCalc.compare(x, y, z, xFloorAddOne, y, z) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, y, z) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, y, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloor, yFloor, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, y, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloor, yFloor, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloorAddOne, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloor, z) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloor, tmp, nth);
			}
			//      now for the z plane corners
			if (distanceCalc.compare(x, y, z, xFloorAddOne, y, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, y, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, y, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, y, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloorSubOne, tmp, nth);
			}
		
			//		adjacent points for the top and bottom
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloorAddOne, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloorAddOne, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloor, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloor, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloorAddOne, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloorAddOne, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloor, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloor, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloorAddOne, tmp, nth);
			}
			//		finally the corner cubes
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloorAddOne, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloorAddOne, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloorAddOne, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloorAddOne, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloor, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloor, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloor, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloor, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloorSubOne, tmp, nth);
			}

			return tmp;

		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
			return null;
		}
	}

	protected double FindNeighbours(double x1, final double y1, final double z1, final double xFloor, final double yFloor, final double zFloor, final double[] distances, int index) {
		double distance, temp;
		double seed; 
		Double key;
		double[][] cellCache;
		
		index--;
			
		// genereate random seed
		seed = ((702395077*xFloor+915488749*yFloor+2120969693*zFloor) % HASH_MOD_VALUE);
		key = new Double(seed);

		if(cells.containsKey(key)) {
			cellCache = (double[][])cells.get(key);
		} else {
			rand.setSeed((long)seed);		
			cellCache= new double[cellCount][3];
			for (int i = 0; i < cellCount; i++) {
				cellCache[i][0] = rand.nextDouble() + xFloor;
				cellCache[i][1] = rand.nextDouble() + yFloor;
				cellCache[i][2] = rand.nextDouble() + zFloor;
			}
			if(cells.size() == 100) {
				cells.clear();
			}
			cells.put(key, cellCache);
		}
		
		for (int i = 0; i < cellCount; i++) {
			distance =
				distanceCalc.compare(
					x1,
					y1,
					z1,
					cellCache[i][0],
					cellCache[i][1],
					cellCache[i][2]);
			if (distance < distances[index]) {
				distances[index] = distance;
				int j = index;
				while (j > 0 && distances[j] < distances[j - 1]) {
					temp = distances[j - 1];
					distances[j - 1] = distances[j];
					distances[j] = temp;
					j--;
				}
			}
		}
	//	System.err.println( seed  + "==>" + distances[0] + " in cell " + xFloor + "," +  yFloor + "," +  zFloor);
		return distances[index];
	}

	public void save(ObjectOutputStream file) throws IOException {
			
		file.writeObject(this.getClass().getName());
		file.writeObject("seed");
		file.writeObject(""+seed);
		file.writeObject("cellCount");
		file.writeObject(""+cellCount);
		file.writeObject("metric");
		file.writeObject(""+metric);

		file.writeObject("xNoise");
		file.writeObject(""+xNoise);
		file.writeObject("yNoise");
		file.writeObject(""+yNoise);
		file.writeObject("zNoise");
		file.writeObject(""+zNoise);

		file.writeObject("FLOOR");
		file.writeObject(""+panel.getDouble("FLOOR"));
		file.writeObject("RIM");
		file.writeObject(""+panel.getDouble("RIM"));
		file.writeObject("END");
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		String value;
		String type = (String)file.readObject(); 
		
		while(type.compareTo("END") != 0) {
			value = (String)file.readObject();
			if(type.compareTo("seed") == 0) {
				seed = Long.parseLong(value);
			} else if(type.compareTo("cellCount") == 0) {
				cellCount = Integer.parseInt(value);
			} else if(type.compareTo("metric") == 0) {
				metric = value;
			} else if(type.compareTo("xNoise") == 0) {
				xNoise = Double.parseDouble(value);
			} else if(type.compareTo("yNoise") == 0) {
				yNoise = Double.parseDouble(value);
			} else if(type.compareTo("zNoise") == 0) {
				zNoise = Double.parseDouble(value);
			}  else if(type.compareTo("FLOOR") == 0) {
				panel.setValue("FLOOR", value);
			} else if(type.compareTo("RIM") == 0) {
				panel.setValue("RIM", value);
			}
			type = (String)file.readObject();
		}
		restoreSettings();
	}


	
	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Points per Cell:</b> </td><td align=right> " + cellCount + "</td></tr>" + 
			"<tr><td><b>Distance Metric:</b> </td><td align=right>" + metric + "</td></tr>" + 
			"<tr><td><b>Noise Size:</b> </td><td align=right>" + xNoise + ", " + yNoise + ", " +zNoise  + "</td></tr>" +
			"<tr><td><b>Seed:</b> </td><td align=right>"+seed + "</td></tr></table>";
			
	}		
	
}
