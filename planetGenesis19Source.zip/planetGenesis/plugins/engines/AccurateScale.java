package plugins.engines;

import java.awt.Graphics2D;
import java.awt.image.DataBuffer;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.DoubleBuffer;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import GUI.ExtendedHashBasedPanel;
import GUI.Progress;
import Utilities.NoiseEngine;
import Utilities.PostProcess;
import Utilities.Vertex;

public class AccurateScale extends PostProcess {

	private double high = 1.0;
	private double low = 0.0;
	
	private double fromScale = 0.0;
	private double toScale = 0.0;
	
	ExtendedHashBasedPanel panel;
	
	public AccurateScale() {
		
		panel = new ExtendedHashBasedPanel();
		panel.addTextBox("low", "Low Value", "0.0", "Scales lowest output value");
		panel.addTextBox("high", "High Value", "1.0", "Scales highest output value");
		storeSettings();

	}
	
	public void initNoise() {
	
		storeSettings();		
		
	}
	
	
	protected void process(DoubleBuffer noiseMap, Progress progress) {

		double fromLow, fromHigh, noiseValue;
		
		
		int vertexCount = terrain.getVertexCount();
		double delta = vertexCount / 100;

		progress.setMaxValue(vertexCount * 2);
		progress.setProgressText("Processing " + name());
		progress.setProgressValue(0);
		
		noiseMap.position(0);
		noiseValue = noiseMap.get();
		fromLow = noiseValue;
		fromHigh = noiseValue;
		
		for (int i = 1; i < vertexCount; i++) {

			noiseValue = noiseMap.get();
			if (noiseValue < fromLow) {
				fromLow = noiseValue;
			} else if (noiseValue > fromHigh) {
				fromHigh = noiseValue;
			}
			
			if(i % delta == 0) {
				progress.setProgressValue(i);
			}

		}

		int endpoint = vertexCount * 2;
		double toScale = this.high - this.low;	
		double fromScale = 1 / (fromHigh - fromLow);
				
		for (int i = 0; i < vertexCount; i++) {

			noiseValue = noiseMap.get(i);
			noiseValue -= fromLow;
			noiseValue *= fromScale;
			noiseValue *= toScale;
			noiseValue += low;
			
			noiseMap.put(i, noiseValue);
			
			
			if(i % delta == 0) {
				progress.setProgressValue(vertexCount + i);
			}

		}

		
	}


	public String description() {
		return "Scales the noise to between the supplied values";
	}
	
	public String getDetails() {
		return "<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" +
		"<table>" + "<tr><td><b><u>Details</u></b></td></tr>" +
		"<tr><td><b>New Low:</b> </td><td align=right>"+ low + "</td></tr>" +
		"<tr><td><b>New High:</b> </td><td align=right>"+ high + "</td></tr>" +
		"</table>";
	}

	public double getNoiseForVertex(Vertex vertex) {
		return 0;
	}

	public double getScaledMovedNoiseForVertex(double x, double y, double z) {
		return 0;
	}
	
	public double getNoiseForVertex(int vertex) {
		return 0;
	}

	public JPanel getPanel() {
		return panel;
	}



	public void makePreview() {

		boolean nanWarning = false;
 		double scale;
		DataBuffer previewData = preview.getRaster().getDataBuffer();

		
		
		if(noise != null) {		
			double toScale = this.high - this.low;	
			
			double fromScale = (noise.getMax() - noise.getMin());
			if( fromScale > 0 )  {
				fromScale = 1.0 / (noise.getMax() - noise.getMin());
			}
			double fromLow = noise.getMin(); 

			double noiseValue;

			max = Double.NEGATIVE_INFINITY;
			min = Double.POSITIVE_INFINITY;
			
			initNoise();
			
			double[] inputNoise = noise.getPreviewNoise();	

			for(int index = 0; index < 64 * 64; index++){
				
				noiseValue = inputNoise[index] ;
				noiseValue -= fromLow;
				noiseValue *= fromScale;
				noiseValue *= toScale;
				noiseValue += low;
					
				previewNoise[index] = noiseValue;
				
				if(noiseValue > max) {
					max = noiseValue;
				}
				if(noiseValue < min) {
					min = noiseValue;
				}
				if(Double.isNaN(previewNoise[index])) {
					nanWarning = true;
				}
			}
			
			
			if(max == Double.POSITIVE_INFINITY || min == Double.NEGATIVE_INFINITY) {

				JOptionPane pane = new JOptionPane(name() + " produces infinity for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "Warning");
				dialog.setModal(false);
				dialog.setVisible(true);
			}

			if(nanWarning) {
				JOptionPane pane = new JOptionPane(name() + " results in complex numbers being generated for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "NaN Warning");
				dialog.setModal(false);
				dialog.setVisible(true);				
			}
			
			scale = 255 / (max - min); 
			for(int i = 0; i < 64*64; i++) {
				previewData.setElem(i, (int)((previewNoise[i]  - min) * scale));			
			}
		}
		return;
	}

	public String name() {
		return "Accurate Scale";
	}

	public NoiseEngine copy() {
		return null;
	}
	
	
	public void storeSettings() {
		low = panel.getDouble("low");
		high = panel.getDouble("high");
	}

	public void restoreSettings() {	
		panel.setValue("low", ""+low);
		panel.setValue("high", ""+high);
	}
		

	public void save(ObjectOutputStream file) throws IOException {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);
	
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}	
	
	public void paintIcon(Graphics2D g2, ImageObserver component) {
		//final Ellipse2D.Double ellipse = new Ellipse2D.Double(4,4,58,58);
		//g2.draw(ellipse);
		if(noise != null) {
			g2.drawImage(preview,0,0,component);
		}
		g2.drawString("Accurate", 6, 38);
	}
	
	
}
