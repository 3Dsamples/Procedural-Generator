package plugins.engines;

public abstract class Operation
{	
	private static final class AddOperation extends Operation
	{

		@Override
		public double apply(double lhs, double rhs, double rhsScale)
		{
			return lhs + rhs*rhsScale;
		}
	}
	
	private static final class SubtractOperation extends Operation
	{
		@Override
		public double apply(double lhs, double rhs, double rhsScale)
		{
			return lhs - rhs*rhsScale;
		}
	}

	private static final class DifferenceOperation extends Operation
	{
		@Override
		public double apply(double lhs, double rhs, double rhsScale)
		{
			return Math.abs(lhs - rhs*rhsScale);
		}
	}
	
	private static final class MultiplyOperation extends Operation
	{
		@Override
		public double apply(double lhs, double rhs, double rhsScale)
		{
			lhs = rescaleASMS(lhs);
			rhs = rescaleASMS(rhs);
			rhs *= rhsScale;
			rhs = 1 - rhs;
			return rescaleMSAS(lhs * rhs);
		}
	}
	
	private static final class ShiprocksOperation extends Operation
	{
		@Override
		public double apply(double lhs, double rhs, double rhsScale)
		{
			rhs = rescaleASMS(rhs);
			return lhs + rescaleMSAS(Math.pow(rhs, 2.0)*rhsScale);
		}
	}
	
	private static final class ArctanOperation extends Operation
	{
		@Override
		public double apply(double lhs, double rhs, double rhsScale)
		{
			rhs = rescaleASMS(rhs);
			return lhs + rescaleMSAS((1/Math.PI)*Math.atan(rhs)*rhsScale);
		}
	}
	
	private static final class SquareRootOperation extends Operation
	{
		@Override
		public double apply(double lhs, double rhs, double rhsScale)
		{
			rhs = rescaleASMS(rhs);
			return lhs + rescaleMSAS(Math.sqrt(rhs)*rhsScale);
		}
	}
	
	private static final class SpecialOperation extends Operation
	{
		@Override
		public double apply(double lhs, double rhs, double rhsScale)
		{
			rhs = rescaleASMS(rhs);
			return lhs + rescaleMSAS(Math.sqrt(rhs)*rhsScale);
		}
	}
	
	public abstract double apply(double lhs, double rhs, double rhsScale);
	
	protected double rescaleASMS(double value)
	{
		value += 1.0d;
		return value/2.0d;
	}
	
	protected double rescaleMSAS(double value)
	{
		value *= 2.0d;
		value -= 1.0d;
		return value;
	}
	
	public static Operation create(String name)
	{
		Operation op = null;
		if(name.equalsIgnoreCase("add"))
			op = new AddOperation();
		if(name.equalsIgnoreCase("subtract"))
			op = new SubtractOperation();
		if(name.equalsIgnoreCase("difference"))
			op = new DifferenceOperation();
		if(name.equalsIgnoreCase("multiply"))
			op = new MultiplyOperation();
		if(name.equalsIgnoreCase("shiprocks"))
			op = new ShiprocksOperation();
		if(name.equalsIgnoreCase("sqrt"))
			op = new SquareRootOperation();
		if(name.equalsIgnoreCase("atan"))
			op = new ArctanOperation();
		if(name.equalsIgnoreCase("special"))
			op = new SpecialOperation();
		
		return op;
	}
	
	
}
