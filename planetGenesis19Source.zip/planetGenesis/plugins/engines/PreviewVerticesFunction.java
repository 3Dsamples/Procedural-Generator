/*
 * Created on Dec 23, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Utilities.Vertex;


/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class PreviewVerticesFunction extends ApplyFunction {

	private class ErodeFunction extends Function{
		
		private double erosionFactor = 0.2;
		private double erosionRadius = 0.01;
		final private JPanel erosionPanel = new JPanel();
		final private JLabel factorLabel = new JLabel("Erosion Factor");
		final private JLabel radiusLabel = new JLabel("Erosion Radius");
		final private JTextField factorText = new JTextField(""+erosionFactor);
		final private JTextField radiusText = new JTextField(""+erosionRadius);
		
		ErodeFunction() {
			erosionPanel.setBorder(new javax.swing.border.TitledBorder(null, functionName, javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 3, 11), new java.awt.Color(255, 0, 0)));
			erosionPanel.add(factorLabel);
			factorText.setPreferredSize(new Dimension(60, 20));
			erosionPanel.add(factorText);
			
			erosionPanel.add(radiusLabel);
			radiusText.setPreferredSize(new Dimension(60, 20));
			erosionPanel.add(radiusText);
						
		}
		
		public JPanel getPanel(){return erosionPanel;};	
		
		public double function(int vertex) {
			return function(noise.getVertex(vertex)); 	
		}		

		public double function(Vertex vertex) {
			double[] erode = new double[8];
			double x,y,z,erodeTotal;
			Vertex tmpVertex = new Vertex(0,0,0);

			x = vertex.getX();
			y = vertex.getY();
			z = vertex.getZ();

			double vertexValue = noise.getNoiseForVertex(vertex);	
			tmpVertex.setPoint(x+erosionRadius,y,z);
			erode[0] = noise.getNoiseForVertex(tmpVertex);

			tmpVertex.setPoint(x,y,z+erosionRadius);
			erode[1] = noise.getNoiseForVertex(tmpVertex);
			
			tmpVertex.setPoint(x-erosionRadius,y,z);
			erode[2] = noise.getNoiseForVertex(tmpVertex);

			tmpVertex.setPoint(x,y,z-erosionRadius);
			erode[3] = noise.getNoiseForVertex(tmpVertex);

			tmpVertex.setPoint(x+erosionRadius,y,z-erosionRadius);
			erode[4] = noise.getNoiseForVertex(tmpVertex);
			
			tmpVertex.setPoint(x+erosionRadius,y,z+erosionRadius);
			erode[6] = noise.getNoiseForVertex(tmpVertex);

			tmpVertex.setPoint(x-erosionRadius,y,z-erosionRadius);
			erode[7] = noise.getNoiseForVertex(tmpVertex);

			erodeTotal = 0;

			for(int i = 0; i < erode.length; i++) {
				
				erodeTotal += erode[i];
			}
			erodeTotal -= ((erode.length - 1) * vertexValue);
			return vertexValue + (erodeTotal * erosionFactor);
			
		}

		public double function (double value) {
			return value;
		}

		public void	drawIcon (Graphics2D g2){
			g2.drawString("Erode", 6, 38);
		}

		public void storeSettings() {
			erosionFactor = Double.parseDouble(factorText.getText());
			erosionRadius = Double.parseDouble(radiusText.getText());
		}
	
		public void restoreSettings() {	
			factorText.setText(""+erosionFactor);
			radiusText.setText(""+erosionRadius);
		}

		public void save(ObjectOutputStream file) throws IOException
		 {
		
			file.writeObject(this.getClass().getName());
			file.writeObject("rim");
			file.writeObject(""+erosionFactor);
			file.writeObject("floor");
			file.writeObject(""+erosionRadius);
			file.writeObject("END");
	
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

			String tmp = (String)file.readObject(); 
			while(tmp.compareTo("END") != 0) {
				if(tmp.compareTo("rim") == 0) {					
					erosionFactor = Double.parseDouble((String)file.readObject());
				} else if(tmp.compareTo("floor") == 0) {					
					erosionRadius = Double.parseDouble((String)file.readObject());
				}
				tmp = (String)file.readObject();
			}
			
		}

	}

	public void setFunction(String functionName) {
		
		System.err.println("Function Name set to" + functionName);
		this.functionName = functionName;
		if(functionName.compareTo("Erode") == 0) {  
			math = new ErodeFunction();
		}

		return;
	}	

	public void makePreview() {

		System.err.println(name() + " makePreview");
		boolean nanWarning = false;
 		double scale;
		DataBuffer previewData = preview.getRaster().getDataBuffer();

		if(noise != null) {		
			max = Double.NEGATIVE_INFINITY;
			min = Double.POSITIVE_INFINITY;
			initNoise();
			Vertex[] inputNoise = noise.getPreviewVertices();	
			for(int index = 0; index < 64 * 64; index++){
				previewNoise[index] = math.function(inputNoise[index]);
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				if(Double.isNaN(previewNoise[index])) {
					nanWarning = true;
				}
			}
		
			if(max == Double.POSITIVE_INFINITY || min == Double.NEGATIVE_INFINITY) {

				JOptionPane pane = new JOptionPane(name() + " produces infinity for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "Warning");
				dialog.setModal(false);
				dialog.setVisible(true);
			}

			if(nanWarning) {
				JOptionPane pane = new JOptionPane(name() + " results in complex numbers being generated for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "NaN Warning");
				dialog.setModal(false);
				dialog.setVisible(true);				
			}
			
			scale = 255 / (max - min); 
			for(int i = 0; i < 64*64; i++) {
				previewData.setElem(i, (int)((previewNoise[i]  - min) * scale));			
			}
		}
		return;
	}
}
