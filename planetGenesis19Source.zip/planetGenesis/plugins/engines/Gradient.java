
/*
 * Gradient.java
 *
 * Created on 05 March 2002, 19:08
 */

/*
 Copyright (c) 2002, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

package plugins.engines;

import GUI.ExtendedHashBasedPanel;
import Utilities.*;

import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JPanel;

/**
*
 * @author  David
 */
public class Gradient extends NoiseEngine {

	protected ExtendedHashBasedPanel panel;
	
	double x1, x2, y1, y2;
	double gradient, yIntersect;
	//int gridProjection;

	
	public static void main(String[] args) {
		try {
			Class noiseClass = Class.forName("plugins.engines.Perlin");
			Utilities.NoiseEngine noise =
				(Utilities.NoiseEngine) noiseClass.newInstance();
			//            plugins.engines.Perlin noise = new plugins.engines.Perlin();
			noise.initNoise();
			//            octaves = panel.getOctaves();
			//            terrain = noise.CreateTerrain(50, 50, 0.5);
			//            noise.CreatePlanetPNG(1024, 1024, "D:\\test3Java.png" );
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(99);
		}
	}

	/** Creates a new instance of perlin */
	public Gradient() {
		panel = new ExtendedHashBasedPanel();
		panel.addTextBoxGroup("Start Point", "The co-ordinates of the start point.", 
				new String[] {"x1", "y1"},
				new String[] {"x co-ordinate", " y co-ordinate"},
				new String[] { ""+(-1.0),  ""+(-1.0)},
				new String[] {"Start Point x co-ordinate", "Start Point y co-ordinate"}); 

		panel.addTextBoxGroup("End Point", "The co-ordinates of the end point.", 
				new String[] {"x2", "y2"},
				new String[] {"x co-ordinate", "y co-ordinate"},
				new String[] { ""+(+1.0),  ""+(+1.0)},
				new String[] {"End Point x co-ordinate", "End Point y co-ordinate"}); 
		storeSettings();
	}

	public String name() {
		return "Gradient";
	}

	public String description() {
		return "Creates a linear gradient between two points.";
	}



	public void initNoise() {
		// figure out the gradient 
		gradient = (x1 - x2) / (y1 - y2);
		yIntersect = y1 - (gradient * x1);		
				
	}
	
    // Not thread safe
	private Vertex vTemp=new Vertex(0, 0, 0);
	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		vTemp.x=x; vTemp.y=y; vTemp.z=z;//no scaling etc yet for this one
		return getNoiseForVertex(vTemp);
	}

	public double getNoiseForVertex(Vertex vertex) {
		
		// calculate new yIntersect

		if(gradient == 0) {
			return (y1 + (vertex.getZ()/64)) / (y1 - y2); 
		} else if(Double.isInfinite(gradient)){
		// calculate new yIntersect
			return (x1 + (vertex.getX()/64)) / (x1 - x2); 
		} else {
			double yIntersect = vertex.getZ() - (-gradient * vertex.getX());
		
		// Now calculate the x co-ordinate of the insertion
			double xI = (yIntersect - this.yIntersect) / (2 * gradient);
			double yI = (gradient * xI) + yIntersect;
		
			return Math.sqrt( ((xI - x1) * (xI - x1)) + ((yI - y1) * (yI - y1))); 
		}		
	}

	public double getNoiseForVertex(int vertex) {
		return getNoiseForVertex(terrain.getNoiseVertex(vertex));
	}
	
	public void makePreview() {

		final DataBuffer data = preview.getRaster().getDataBuffer();
		double previewScale;
		double yIntersect, xI, yI;
		int index = 0;  

		initNoise();
		
		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;

		for(double j = 0; j < 64; j++){
			for(double i = 0; i < 64; i++){

				if(gradient == 0) {
					previewNoise[index] = (y1 + (j/64)) / (y1 - y2); 
				} else if(Double.isInfinite(gradient)){
				// calculate new yIntersect
					previewNoise[index] = (x1 + (i/64)) / (x1 - x2); 
				} else {
					yIntersect = (j/64) - (-gradient * (i/64));
		
					// Now calculate the x co-ordinate of the intesection
					xI = (yIntersect - this.yIntersect) / (2 * gradient);
					yI = (gradient * xI) + yIntersect;
		
					previewNoise[index] =  Math.sqrt( ((xI - x1) * (xI - x1)) + ((yI - y1) * (yI - y1)));
				} 
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}					
				index++;
			}
		}	
		
		previewScale = 255 / (max - min); 
		System.err.println(min+ ", " + max + ", " + previewScale);

		for(int i = 0; i < 64*64; i++) {
			data.setElem(i, (int)((previewNoise[i]  - min) * previewScale));			
		}
		
		
	}
	
	public void storeSettings() {

		x1 = panel.getDouble("x1");
		y1 = panel.getDouble("y1");
		x2 = panel.getDouble("x2");
		y2 = panel.getDouble("y2");

		
		// figure out the gradient 
		gradient = (x1 - x2) / (y1 - y2);
		yIntersect = y1 - (gradient * x1);		

	}
	
	public void restoreSettings() {
		panel.setValue("x1", ""+x1);
		panel.setValue("y1", ""+y1);
		panel.setValue("x2", ""+x2);
		panel.setValue("y2", ""+y2);
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);
	
	}
	
	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}

	   /* (non-Javadoc)
     * @see Utilities.NoiseEngine#copy()
     */
    public NoiseEngine copy() {
        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            ((ExtendedHashBasedPanel)copy.getPanel()).setValuesUsingHash(panel.getHash());
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
           e.printStackTrace();
        }	
        return null;
    }

	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Start Point:</b> </td><td align=right>" + x1 + ", " + y1 + "</td></tr>" +
			"<tr><td><b>End Point:</b> </td><td align=right>" + + x2 + ", " + y2 + "</td></tr></table>";
			
	}
		
	public JPanel getPanel() {
		return panel;
	} 

}
