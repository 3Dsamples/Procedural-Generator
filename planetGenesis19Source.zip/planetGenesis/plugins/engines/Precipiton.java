package plugins.engines;

import java.awt.Graphics2D;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.nio.DoubleBuffer;
import java.nio.channels.FileChannel;
import java.util.Random;

import javax.swing.JPanel;

import GUI.ExtendedHashBasedPanel;
import GUI.Progress;
import Utilities.NoiseEngine;
import Utilities.Planet;
import Utilities.PostProcessHelper;
import Utilities.Vertex;
/**
 * This thing still can't be expected to work...
 * 
 * @author su_liam
 */

public class Precipiton extends PostProcessHelper
{
	public enum Direction
	{
		N(0, -1),
		NE(1, -1),
		E(1, 0),
		SE(-1, -1),
		S(0, 1),
		SW(-1, 1),
		W(-1, 0),
		NW(-1, -1),
		C(0, 0),
		;
		private int[] coords = new int[2];
		
		private Direction(int deltaX, int deltaY)
		{
			coords[0] = deltaX;
			coords[1] = deltaY;
		}
		
		public int[] move()
		{
			return coords;	
		}
	}

	private int numPrecipitons;//The number of precipitons to be dropped on the landscape
	private long seed;//The seed for the random placement of precipitons
	private double strength;//The strength of the erosion effect
	private double dig;//The amount by which the precipiton lowers the ground over which it passes.
	private int run;//The longest distance which a precipiton will be allowed to run.
	ExtendedHashBasedPanel panel;
	
	//
	private double low = 0.0;
	private double high = 1.0;
	
	private double fromScale = 0.0;
	private double toScale = 0.0;
	
	private int terrainWidth, terrainHeight;
	private int startPos;
	private static final double corner = Math.sqrt(.5);
	private static final double precision = 1e-12;
	//
	
	public Precipiton()
	{
		panel = new ExtendedHashBasedPanel();
		panel.addTextBox("numPrecipitons", "Number of precipitons", "100", "The number of precipitons laid down.");
		//panel.addTextBox("seed", "Random seed", "12345", "The seed to the random number generator laying down precipitons.");
		panel.addRandomSeed("seed", "Seed", System.currentTimeMillis() % Integer.MAX_VALUE);
		panel.addTextBox("strength", "Strength of erosion", "1.0", "The strength factor of the desired erosion.");
		panel.addTextBox("dig", "Channel depth", "0.05", "The depth to which the precipiton digs a channel in the land.");
		panel.addTextBox("run", "Run distance", "1000", "The maximum distance which a precipiton will be allowed to run");
		
		storeSettings();
	}
	
	@Override
	protected void process(DoubleBuffer noiseMap, Progress progress)
	{
		int vertexCount;
		
		if (terrain instanceof Planet) {
			startPos = 1;
			vertexCount = terrain.getVertexCount() - 2;
		} else {
			startPos = 0;
			vertexCount = terrain.getVertexCount();
		}
		
		terrainWidth = terrain.getXMesh() - 1;
		terrainHeight = terrain.getZMesh() - 1;
		
		try
		{
			File tmpDoubleFile = File.createTempFile("tmpPrecipiton", null);
			FileChannel rwCh = new RandomAccessFile(tmpDoubleFile,"rw").getChannel();
			long fileSize = vertexCount * 8;
			DoubleBuffer erosionMap = rwCh.map(FileChannel.MapMode.READ_WRITE, 0, fileSize).asDoubleBuffer();
			
			erosionMap.position(0);
			noiseMap.position(0);
			
			progress.setMaxValue(terrainHeight);
			progress.setProgressText("Initializing erosion map..." + name());
			progress.setProgressValue(0);
			
			//Initialize erosionMap to zeros
			for(int index=0; index < vertexCount; index++)
			{
				erosionMap.put(0);
			}
			
			Random random = new Random(seed);
			int position;
			int positionX, positionY;
			//Main Loop: drop precipitons
			for(int precipiton=0; precipiton < numPrecipitons; precipiton++)
			{
				int progressScale = terrainHeight / numPrecipitons;
				positionX = random.nextInt(terrainWidth);
				positionY = random.nextInt(terrainHeight);
				//Run precipiton down
				boolean cont = true;
				for(int length=0; length < run; length ++)
				{
					//Determine slope at center
					double slope = slope(noiseMap, erosionMap, positionX, positionY);
					//Do diffusion
					//TODO uncomment line below
					cont = diffusion(noiseMap, erosionMap, positionX, positionY, slope);
					//TODO remove following block
					/*{
						int center = move(Direction.C.move(), positionX, positionY);
						noiseMap.put(center, 1);
					}//*/
					if(!cont)break;
					//Move to lowest neighbor
					position = trickleDown(noiseMap, erosionMap, positionX, positionY);
					positionX = position % terrainWidth;
					positionY = position / terrainWidth;
					//Rinse and repeat...
					progress.setProgressValue(precipiton * progressScale);//Hope this works...
				}
				
			}//End Main Loop
			
			/*for (int j = 0; j <=  terrainHeight; j++)
			{
				for (int i = 0; i <= terrainWidth; i++)
				{
					doErosion(noiseMap, erosionMap, i, j, noiseMap.get((j * terrainHeight) + terrainWidth + startPos));
				}	
				progress.setProgressValue(j);
			}*/
			
			
			progress.setProgressText("Storing...");
			progress.setProgressValue(0);
			
			//Before
			for(int i=0; i<10; i++)
			{
				System.err.println("Before: " + i + ", " + noiseMap.get(i));
			}

			for(int i=0; i<10; i++)
			{
				System.err.println("Erosion: " + i + ", " + erosionMap.get(i));
			}			
			
			//Transferring erosionMap contents to the noiseMap
			for (int i = startPos; i < vertexCount; i++)
			{
				//TODO uncomment following line
				noiseMap.put(i, noiseMap.get(i) + erosionMap.get(i));
				//TODO remove following block
				/*{
					noiseMap.put(i, erosionMap.get(i));
				}//*/
				//System.err.println("Precipiton215: Position index = " + i + "\tValue = " + noiseMap.get(i));
				progress.setProgressValue(i);
			}
			
			//After
			for(int i=0; i<10; i++)
			{
				System.err.println("After: " + i + ", " + noiseMap.get(i));
			}
			
			//Necessary ablutions... clean up.
			rwCh.close();
			erosionMap = null;
			tmpDoubleFile.delete();
		}
		catch(Exception ex)
		{
			ex.printStackTrace(System.err);
		}
	}
	
	/**
	 * Really quick and dirty attempt at a slope determination. Simply the greatest altitude change between the
	 * center and its neighbors.
	 * @param noiseMap
	 * @param erosionMap
	 * @param posX the position of the center
	 * @param posY the position of the center
	 * @return
	 */
	private double slope(DoubleBuffer noiseMap, DoubleBuffer erosionMap, int posX, int posY)
	{
		int position;
		double value;
		double finalValue = 0;

		double centerValue;
		
		if(posX == 0 && posY == 0 ) {
			System.err.println("0,0");
		}
		
		position = move(Direction.C.move(), posX, posY);
		System.out.println("center: " + position);
		centerValue = noiseMap.get(position) + erosionMap.get(position);
		
		//Case I: Not left edge, do west
		if(posX > 0)
		{
			position = move(Direction.W.move(), posX, posY);
			System.out.println("scanW: "  + position);
			value = noiseMap.get(position) + erosionMap.get(position);
			value = Math.abs(centerValue - value);
			if(value > finalValue)
				finalValue = value;
		}
		//Case II: Not top edge, do north
		if(posY > 0)
		{
			position = move(Direction.N.move(), posX, posY);
			System.out.println("scanN: "  + position);
			value = noiseMap.get(position) + erosionMap.get(position);
			value = Math.abs(centerValue - value);
			if(value > finalValue)
				finalValue = value;
		}
		//Case III: Not right edge, do east
		if(posX < terrainWidth - 1)
		{
			position = move(Direction.E.move(), posX, posY);
			System.out.println("scanE: "  + position);
			value = noiseMap.get(position) + erosionMap.get(position);
			value = Math.abs(centerValue - value);
			if(value > finalValue)
				finalValue = value;
		}
		//Case IV: Not bottom edge, do south
		if(posY < terrainHeight -1)
		{
			position = move(Direction.S.move(), posX, posY);
			System.out.println("scanS: "  + position);
			value = noiseMap.get(position) + erosionMap.get(position);
			value = Math.abs(centerValue - value);
			if(value > finalValue)
				finalValue = value;
		}
		//Case V: Not upper left corner, do NW
		if(posX > 0 && posY >0)
		{
			position = move(Direction.NW.move(), posX, posY);
			System.out.println("scanNW: "  + position);
			value = noiseMap.get(position) + erosionMap.get(position);
			value = Math.abs(centerValue - value);
			if(value > finalValue)
				finalValue = value;
		}
		//Case VI: Not lower left corner, do SW
		if(posX > 0 && posY < terrainHeight - 1)
		{
			position = move(Direction.SW.move(), posX, posY);
			System.out.println("scanSW: "  + position);
			value = noiseMap.get(position) + erosionMap.get(position);
			value = Math.abs(centerValue - value);
			if(value > finalValue)
				finalValue = value;
		}
		//Case VII: Not upper right corner, NE
		if(posX < terrainWidth - 1 && posY > 0)
		{
			position = move(Direction.NE.move(), posX, posY);
			System.out.println("scanNE: "  + position);
			value = noiseMap.get(position) + erosionMap.get(position);
			value = Math.abs(centerValue - value);
			if(value > finalValue)
				finalValue = value;
		}
		//Case VIII: Not lower right corner, do SE
		if(posX < terrainWidth - 1 && posY < terrainHeight - 1)
		{
			position = move(Direction.SE.move(), posX, posY);
			System.out.println("scanSE: "  + position);
			value = noiseMap.get(position) + erosionMap.get(position);
			value = Math.abs(centerValue - value);
			if(value > finalValue)
				finalValue = value;
		}
		
		if(finalValue  == Double.POSITIVE_INFINITY) {
			System.err.println("POSITIVE_INFINITY");
		}
		return finalValue;
	}
	
	private boolean diffusion(DoubleBuffer noiseMap, DoubleBuffer erosionMap, int xPos, int yPos, double centerSlope)
	{
		int neighbors = 0;
		int center = move(Direction.C.move(), xPos, yPos);
		int position;
		double posValue;
		double delta;
		double totalDelta = 0;
		int[] direction = null;
		double lowestValue = 1e99;//I'm going to assume this is higher than any value likely to be met.
		int moveTo;
		
		double centerValue = noiseMap.get(center) + erosionMap.get(center);
		
		//Case I: if not left edge, get western neighbor
		if(xPos > 0)
		{
			position = move(Direction.W.move(), xPos, yPos);
			posValue = noiseMap.get(position) + erosionMap.get(position);
			delta = centerValue - posValue;//Negative values mean this point is high.
			if(posValue < lowestValue)
			{
				lowestValue = posValue;
			}
			posValue = posValue - delta * centerSlope * strength;
			
			totalDelta += delta;
			erosionMap.put(position, posValue);
			neighbors ++;
		}
		//Case II: if not top edge, get northern neighbor
		if(yPos > 0)
		{
			position = move(Direction.N.move(), xPos, yPos);
			posValue = noiseMap.get(position) + erosionMap.get(position);
			delta = centerValue - posValue;//Negative values mean this point is high.
			if(posValue < lowestValue)
			{
				lowestValue = posValue;
			}
			posValue = posValue - delta * centerSlope * strength;
			
			totalDelta += delta;
			erosionMap.put(position, posValue);
			neighbors ++;
		}
		//Case III: if not right edge, get eastern neighbor
		if(xPos < terrainWidth - 1)
		{
			position = move(Direction.E.move(), xPos, yPos);
			posValue = noiseMap.get(position) + erosionMap.get(position);
			delta = centerValue - posValue;//Negative values mean this point is high.
			if(posValue < lowestValue)
			{
				lowestValue = posValue;
			}
			posValue = posValue - delta * centerSlope * strength;
			
			totalDelta += delta;
			erosionMap.put(position, posValue);
			neighbors ++;
		}
		//Case IV: if not bottom edge, get southern neighbor
		if(yPos < terrainHeight - 1)
		{
			position = move(Direction.S.move(), xPos, yPos);
			posValue = noiseMap.get(position) + erosionMap.get(position);
			delta = centerValue - posValue;//Negative values mean this point is high.
			if(posValue < lowestValue)
			{
				lowestValue = posValue;
			}
			posValue = posValue - delta * centerSlope * strength;
			
			totalDelta += delta;
			erosionMap.put(position, posValue);
			neighbors ++;
		}
		//Case V: if not upper left corner: get NW neighbor
		if(xPos > 0 && yPos > 0)
		{
			position = move(Direction.NW.move(), xPos, yPos);
			posValue = noiseMap.get(position) + erosionMap.get(position);
			delta = centerValue - posValue;//Negative values mean this point is high.
			delta *= corner;
			if(posValue < lowestValue)
			{
				lowestValue = posValue;
			}
			posValue = posValue - delta * centerSlope * strength;
			
			totalDelta += delta;
			erosionMap.put(position, posValue);
			neighbors += corner;
		}
		//Case VI: if not lower left corner: get SW neighbor
		if(xPos > 0 && yPos < terrainHeight - 1)
		{
			position = move(Direction.SW.move(), xPos, yPos);
			posValue = noiseMap.get(position) + erosionMap.get(position);
			delta = centerValue - posValue;//Negative values mean this point is high.
			delta *= corner;
			if(posValue < lowestValue)
			{
				lowestValue = posValue;
			}
			posValue = posValue - delta * centerSlope * strength;
			
			totalDelta += delta;
			erosionMap.put(position, posValue);
			neighbors += corner;
		}
		//Case VII: if not upper right corner, get NE neighbor
		if(xPos < terrainWidth - 1 && yPos > 0)
		{
			position = move(Direction.NE.move(), xPos, yPos);
			posValue = noiseMap.get(position) + erosionMap.get(position);
			delta = centerValue - posValue;//Negative values mean this point is high.
			delta *= corner;
			if(posValue < lowestValue)
			{
				lowestValue = posValue;
			}
			posValue = posValue - delta * centerSlope * strength;
			
			totalDelta += delta;
			erosionMap.put(position, posValue);
			neighbors += corner;
		}
		//Case VIII: if not lower right corner, get SE neighbor
		if(xPos < terrainWidth - 1 && yPos < terrainHeight - 1)
		{
			position = move(Direction.SE.move(), xPos, yPos);
			posValue = noiseMap.get(position) + erosionMap.get(position);
			delta = centerValue - posValue;//Negative values mean this point is high.
			delta *= corner;
			if(posValue < lowestValue)
			{
				lowestValue = posValue;
			}
			posValue = posValue - delta * centerSlope * strength;
			
			totalDelta += delta;
			erosionMap.put(position, posValue);
			neighbors += corner;
		}
		if(neighbors > 0)//safety first
			totalDelta /= (double)neighbors;//Scale delta down
		else
			totalDelta = 0;
		centerValue = centerValue + totalDelta * centerSlope * strength - dig;
		erosionMap.put(center, centerValue);

		if(lowestValue > centerValue)
			return false;
		return true;
	}
	
	/**
	 * Returns the noiseMap/erodsionMap index of the lowest neighboring point
	 * @param noiseMap
	 * @param erodeMap
	 * @param x the x value of the current center point
	 * @param y the y value of the current center point
	 * @return
	 */
	private int trickleDown(DoubleBuffer noiseMap, DoubleBuffer erodeMap, int x, int y)
	{
		int[] dir = new int[2];
		int center = move(Direction.C.move(), x, y);
		double centerValue = noiseMap.get(center) + erodeMap.get(center);
		int position = 0;
		double posValue;
		double low = 1e99;
		
		//Case1: Not left edge, check west
		if(x > 0)
		{
			position = move(Direction.W.move(), x, y);
			posValue = noiseMap.get(position) + erodeMap.get(position);
			low = Math.min(low, posValue);
			if(Math.abs(posValue - low) < precision) dir = Direction.W.move();
		}
		//case2 not top edge check north
		if(y > 0)
		{
			position = move(Direction.N.move(), x, y);
			posValue = noiseMap.get(position) + erodeMap.get(position);
			low = Math.min(low, posValue);
			if(Math.abs(posValue - low) < precision) dir = Direction.W.move();
		}
		//case3 not right edge check east
		if(x < terrainWidth - 1)
		{
			position = move(Direction.E.move(), x, y);
			posValue = noiseMap.get(position) + erodeMap.get(position);
			low = Math.min(low, posValue);
			if(Math.abs(posValue - low) < precision) dir = Direction.W.move();
		}
		//case4 not bottom edge check south
		if(y < terrainHeight - 1)
		{
			position = move(Direction.S.move(), x, y);
			posValue = noiseMap.get(position) + erodeMap.get(position);
			low = Math.min(low, posValue);
			if(Math.abs(posValue - low) < precision) dir = Direction.W.move();
		}
		//case5 not ul corner chk NW
		if(x > 0 && y > 0)
		{
			position = move(Direction.NW.move(), x, y);
			posValue = noiseMap.get(position) + erodeMap.get(position);
			low = Math.min(low, posValue);
			if(Math.abs(posValue - low) < precision) dir = Direction.W.move();
		}
		//case6 not ll corner chk SW
		if(x > 0 && y < terrainHeight - 1)
		{
			position = move(Direction.SW.move(), x, y);
			posValue = noiseMap.get(position) + erodeMap.get(position);
			low = Math.min(low, posValue);
			if(Math.abs(posValue - low) < precision) dir = Direction.W.move();
		}
		//case7 not ur corner chk NE
		if(x < terrainWidth - 1 && y > 0)
		{
			position = move(Direction.NE.move(), x, y);
			posValue = noiseMap.get(position) + erodeMap.get(position);
			low = Math.min(low, posValue);
			if(Math.abs(posValue - low) < precision) dir = Direction.W.move();
		}
		//case8 not lr corner chk SE
		if(x < terrainWidth - 1 && y < terrainHeight - 1)
		{
			position = move(Direction.SE.move(), x, y);
			posValue = noiseMap.get(position) + erodeMap.get(position);
			low = Math.min(low, posValue);
			if(Math.abs(posValue - low) < precision) dir = Direction.W.move();
		}
		
		//System.err.println("Precipiton562: New position -- ( " + dir[0] + " , " + dir[1] + ")");
		//It looks like dir[] never got used...
		return dir[0] + terrainWidth * dir[1];
		//return position;
	}
	
	@Override
	public NoiseEngine copy()
	{
		// TODO Not sure this makes sense.
		return null;
	}

	@Override
	public String description()
	{
		return "Applies a channelizing precipiton algorithm.";
	}

	@Override
	public String getDetails()
	{
		return "<table ><tr><td><b><u>Precipiton Erosion</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" +
		"<table>" + "<tr><td><b><u>Details</u></b></td></tr>" +
		"<tr><td><b>New Low:</b> </td><td align=right>"+ low + "</td></tr>" +
		"<tr><td><b>New High:</b> </td><td align=right>"+ high + "</td></tr>" +
		"</table>";
	}
	
	@Override
	public double getNoiseForVertex(Vertex vertex)
	{
		return 0;
	}

	@Override
	public double getNoiseForVertex(int vertex)
	{
		return 0;
	}

	@Override
	public JPanel getPanel()
	{
		return panel;
	}

	@Override
	public void load(ObjectInputStream file) throws ClassNotFoundException,
			IOException
	{
		panel.load(file);
		storeSettings();
	}

	@Override
	//TODO Replace dummy with someting useful
	public void makePreview()
	{
		return;
	}

	@Override
	public String name()
	{
		return "Precipiton Erosion v.0.1";
	}

	@Override
	public void restoreSettings()
	{
		panel.setValue("numPrecipitons", "" + numPrecipitons);
		panel.setValue("seed", "" + (int)seed);
		panel.setValue("strength", "" + strength);
		panel.setValue("dig", "" + dig);
		panel.setValue("run", "" + run);
	}

	@Override
	public void save(ObjectOutputStream file) throws IOException
	{
		file.writeObject(this.getClass().getName());
		panel.save(file);
	}

	@Override
	public void storeSettings()
	{
		numPrecipitons = panel.getInt("numPrecipitons");
		seed = (long)panel.getInt("seed");
		strength = panel.getDouble("strength");
		dig = panel.getDouble("dig");
		run = panel.getInt("run");
	}

	public void paintIcon(Graphics2D g2, ImageObserver component)
	{
		if(noise != null)
		{
			g2.drawImage(preview,0,0,component);
		}
		g2.drawString("Precipiton", 6, 38);
	}
	
	private int vertexNumber(int xPos, int yPos)
	{
		return terrainWidth * yPos + xPos;
	}
	
	private int move(int[] direction, int x, int y)
	{
		return vertexNumber(x + direction[0], y + direction[1]);
	}

    //@Override
    public double getScaledMovedNoiseForVertex(double x, double y, double z)
    {
        //TODO
        // TODO Auto-generated method stub
        return 0;
    }
}
