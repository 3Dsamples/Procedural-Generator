package plugins.engines;

import java.awt.Graphics2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JPanel;

import Utilities.Vertex;

public class InverseFunctions extends ApplyFunction
{
	public InverseFunctions()
	{
		
	}
	
	public void setFunction(String functionName)
	{
		
		System.err.println("Function Name set to " + functionName+" in "+((Object)this));
		this.functionName = functionName;
		if(functionName.compareTo("Reciprocal") == 0) 
			math = new ReciprocalFunction(); 
		else if(functionName.compareTo("Complement") == 0)
			math = new ComplementFunction();
		return;
	}
	
	private class ReciprocalFunction extends Function
	{
		public JPanel getPanel(){return null;}
		
		public double function (Vertex vertex)
		{
			return 1 / noise.getNoiseForVertex(vertex);
		}
		
		public double function (int vertex)
		{
			return 1 / noise.getNoiseForVertex(vertex);
		}
		
		public double function (double value)
		{
			return 1 / value;
		}
		
		public void	drawIcon (Graphics2D g2)
		{
			g2.drawString("1 / x", 18, 38);
		}
		
		public void storeSettings()
		{
			//do nothing
		}
		
		public void restoreSettings()
		{	
			//do nothing
		}
		
		public void save(ObjectOutputStream file) throws IOException
		{
			file.writeObject(this.getClass().getName());
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException
		{
			String functionType = (String)file.readObject(); 
			storeSettings();
		}
	}
	
	private class ComplementFunction extends Function
	{
		public JPanel getPanel(){return null;}
		
		public double function (Vertex vertex)
		{
			return 1 - noise.getNoiseForVertex(vertex);
		}
		
		public double function (int vertex)
		{
			return 1 - noise.getNoiseForVertex(vertex);
		}
		
		public double function (double value)
		{
			return 1 - value;
		}
		
		public void	drawIcon (Graphics2D g2)
		{
			g2.drawString("1 - x", 18, 38);
		}
		
		public void storeSettings()
		{
			//do nothing
		}
		
		public void restoreSettings()
		{	
			//do nothing
		}
		
		public void save(ObjectOutputStream file) throws IOException
		{
			file.writeObject(this.getClass().getName());
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException
		{
			String functionType = (String)file.readObject(); 
			storeSettings();
		}
	}
}
