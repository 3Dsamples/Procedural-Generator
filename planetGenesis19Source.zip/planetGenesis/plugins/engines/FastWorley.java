package plugins.engines;

/*
 * CacheWorley.java
 *
 * Created on 20 July 2003
 */

/*
 Copyright (c) 2003, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

import GUI.ExtendedHashBasedPanel;
import Utilities.*;

import java.awt.image.DataBuffer;
import java.util.Random;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/*
import plugins.engines.CellBasis.ChessBoard;
import plugins.engines.CellBasis.Euclidean;
import plugins.engines.CellBasis.Manhattan;
*/

/**
*
 * @author  David
 */
public class FastWorley extends NoiseEngine {

	protected ExtendedHashBasedPanel panel;
	protected int nth;
	protected int gridProjection;
	protected int cellCount;
	protected DistanceCalculation distanceCalc;
	protected double [][][] cells;
	
	protected double xNoise;
	protected double yNoise;
	protected double zNoise;
	protected double xOffset;
	protected double yOffset;
	protected double zOffset;
	
	
	protected long seed;
	protected String metric;
	
	protected double[] tmp;


	protected final static double HASH_MOD_VALUE = 128;
	protected final static int HASH_AND_VALUE = 127;

	protected final static java.util.Random rand = new Random();

	/** Creates a new instance of CacheWorley */
	public FastWorley() {

		String[] metricButtons = {"Euclidean", "Manhattan", "ChessBoard", "SineSquared", "QuasiEuclidean"};
	    
		panel = new ExtendedHashBasedPanel();
		panel.addTextBox("nth", "Neighbour", "1", "The distance from a point to the n'th nearest neighbour gives the noise value");
		panel.addTextBox("cellCount", "Points per Cell", "10", "The number of points in a cell, must be greater than the Neighbour value");
		panel.addRandomSeed("seed", "Seed", System.currentTimeMillis());
		panel.addDropDown("metric", "Metric", metricButtons, "The way the distance between points is measured");
		panel.addTextBox("xNoise", "Height", "10", "The number of cells per x coordinate");
		panel.addTextBox("yNoise", "Width", "10", "The number of cells per y coordinate, not relavent for 2D noise");
		panel.addTextBox("zNoise", "Depth", "10", "The number of cells per z coordinate");
		cells = new double[128][10][3];
		storeSettings();//		makePreview();
	}

	public static void main(String[] args) {
		try {
			Class noiseClass = Class.forName("plugins.engines.Fault");
			Utilities.NoiseEngine noise =
				(Utilities.NoiseEngine) noiseClass.newInstance();
			//            plugins.engines.Perlin noise = new plugins.engines.Perlin();
			noise.initNoise();
			//            octaves = panel.getOctaves();
			//            terrain = noise.CreateTerrain(50, 50, 0.5);
			//            noise.CreatePlanetPNG(1024, 1024, "D:\\test3Java.png" );
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(99);
		}
	}

	public String name() {
		return "Fast Worley";
	}

	public String description() {
		return "Worley based algorithm, distance to nth nearest neighbour<br>" +
				"Scaleable version with no tiling, not as random as Cache Worley";
	}

	public void Parameters() {
		
	}

	public void initNoise() {

		storeSettings();
		
		metric = panel.getText("metric");
		 
		if (metric.compareTo("Euclidean") == 0) {
			distanceCalc = new Euclidean();
		} else if (metric.compareTo("Manhattan") == 0) {
			distanceCalc = new Manhattan();
		} else if (metric.compareTo("ChessBoard") == 0) {
			distanceCalc = new ChessBoard();
		} else if (metric.compareTo("SineSquared") == 0) {
			distanceCalc = new SineSquared();
		} else if (metric.compareTo("QuasiEuclidean") == 0) {
			distanceCalc = new QuasiEuclidean();
		}
		
		tmp = new double[nth];
	}

	/** returns JPanel for noise settings */
	public javax.swing.JPanel getPanel() {
		return panel;
	}

		

	public double getNoiseForVertex(Vertex vertex) {
		return distanceCalc.distanceToNth(
				calculateDistanceArray(vertex.getX(), vertex.getY(), vertex.getZ()), nth);
	}


    @Override
    public double getScaledMovedNoiseForVertex(double x, double y, double z)
    {
        return distanceCalc.distanceToNth(
                calculateDistanceArray(x*xNoise+xOffset, y*yNoise+yOffset, z*zNoise+zOffset), nth);
    }
    
	protected double[] calculateDistanceArray(double x, double y, double z) {
		
		final double xFloorAddOne;
		final double xFloorSubOne;
		final double yFloorAddOne;
		final double zFloorAddOne;
		final double yFloorSubOne;
		final double zFloorSubOne;

		for(int i = 0; i < nth; i++) {
			tmp[i] = Double.POSITIVE_INFINITY;
		}
		
		double nthNearestSoFar = Double.POSITIVE_INFINITY;

		//find point in unit cube
		final double xFloor = x > 0 ? (int)x : ((int)x - 1.0);
		final double yFloor = y > 0 ? (int)y : ((int)y - 1.0);
		final double zFloor = z > 0 ? (int)z : ((int)z - 1.0);
		

		xFloorAddOne = xFloor+1.0;
		xFloorSubOne = xFloor-1.0;

		yFloorAddOne = yFloor+1.0;
		yFloorSubOne = yFloor-1.0;
	
		zFloorAddOne = zFloor+1.0;
		zFloorSubOne = zFloor-1.0;
		

		try {

			nthNearestSoFar = FindNeighbours(x, y, z, xFloor, yFloor, zFloor, tmp, nth);

			// find neighbours on the z plane, if the
			// nearest point on the toher cube is farther away
			// than the current nth neigbour then don't bother
			if (distanceCalc.compare(x, y, z, xFloorAddOne, y, z) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, y, z) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, y, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloor, yFloor, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, y, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloor, yFloor, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloorAddOne, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloor, z) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloor, tmp, nth);
			}
			//      now for the z plane corners
			if (distanceCalc.compare(x, y, z, xFloorAddOne, y, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, y, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, y, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, y, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloorSubOne, tmp, nth);
			}
			
			//		adjacent points for the top and bottom
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloorAddOne, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloorAddOne, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloor, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloor, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloor, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloorAddOne, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloorAddOne, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloor, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloor, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloorAddOne, tmp, nth);
			}
			//		finally the corner cubes
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloorAddOne, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloorAddOne, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloorAddOne, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloorAddOne, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloor, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloor, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloorAddOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloor, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloorSubOne, tmp, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloor, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloorSubOne, tmp, nth);
			}

			return tmp;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Vertex getNoiseSize() {
	    return new Vertex(panel.getDouble("xNoise"),
	            		  panel.getDouble("yNoise"),
	            		  panel.getDouble("zNoise"));
	}

	public Vertex getNoiseOffset() {
		rand.setSeed((long)panel.getInt("seed"));
		return new Vertex(rand.nextDouble(), rand.nextDouble(), rand.nextDouble());
	}


	public double getNoiseForVertex(int vertex) {
		return getNoiseForVertex(terrain.getNoiseVertex(vertex));
	}
	
	public void setTerrain(Landscape terrain) {
		this.terrain = terrain;
		terrain.setNoiseSpace(this);
		terrain.setProjection(gridProjection);
		terrain.setTile(false);
		return;
	}


	protected double FindNeighbours(double x1, final double y1, final double z1, final double xFloor, final double yFloor, final double zFloor, final double[] distances, int index) {
		double distance, temp;
		
		index--;
			
		// genereate random seed
    	int cellIndex = (int)Math.abs((702395077*xFloor+915488749*yFloor+2120969693*zFloor)  % HASH_MOD_VALUE);
     	
		for (int i = 0; i < cellCount; i++) {
			distance =
				distanceCalc.compare(
					x1,
					y1,
					z1,
					cells[cellIndex][i][0] + xFloor,
					cells[cellIndex][i][1] + yFloor,
					cells[cellIndex][i][2] + zFloor) ;
			if (distance < distances[index]) {
				distances[index] = distance;
				int j = index;
				while (j > 0 && distances[j] < distances[j - 1]) {
					temp = distances[j - 1];
					distances[j - 1] = distances[j];
					distances[j] = temp;
					j--;
				}
			}
		}
	//	System.err.println( seed  + "==>" + distances[0] + " in cell " + xFloor + "," +  yFloor + "," +  zFloor);
		return distances[index];
	}

	protected interface DistanceCalculation {
		public double compare(
			final double x1,
			final double y1,
			final double z1,
			final double x2,
			final double y2,
			final double z2);
		public double distanceToNth(double[] compareArray, int nth);
	}


	protected class Euclidean implements DistanceCalculation {
		
		Euclidean() {
		}
		
		public double compare(
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
			return ((x1 - x2) * (x1 - x2))
				+ ((y1 - y2) * (y1 - y2))
				+ ((z1 - z2) * (z1 - z2));
		}

		public double distanceToNth(double[] compareArray, int index) {
			return Math.sqrt(compareArray[index-1]);
		}

	}

	protected class ChessBoard implements DistanceCalculation {
		public double compare(
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
			return Math.max(Math.max(Math.abs(x1 - x2), Math.abs(y1 - y2)), Math.abs(z1 - z2));				
		}

		public double distanceToNth(double[] compareArray, int index) {
			return compareArray[index-1];
		}

	}

	protected class Manhattan implements DistanceCalculation {
		

		public double compare(			
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
			return Math.abs(x1 - x2) + Math.abs(y1 - y2) + Math.abs(z1 - z2);				
		}

		public double distanceToNth(double[] compareArray, int index) {
			return compareArray[index-1];
		}

	}
	
	protected class SineSquared implements DistanceCalculation {
	
	
		public double compare(			
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
			return Math.sin((x1 - x2) * (x1 - x2))
							+ ((y1 - y2) * (y1 - y2))
							+ ((z1 - z2) * (z1 - z2));
			
		}

		public double distanceToNth(double[] compareArray, int index) {
			return compareArray[index-1];
		}

	}

	protected class QuasiEuclidean implements DistanceCalculation {
		
		public double compare(
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
				
		double fdx, fdy, fdz;
		double dx, dy, dz, d2;
			
		  dx = x1 - x2;
		  dy = y1 - y2;
		  dz = z1 - z2;
		  	
		  fdx = Math.abs(dx); 
		  fdy = Math.abs(dy); 
		  fdz = Math.abs(dz);
		  
		  if (fdx >= fdy)
			  if (fdx >= fdz)
				d2 = fdx + Math.sqrt(dy * dy + dz * dz);
			  else
				d2 = fdz + Math.sqrt(dx * dx + dy * dy);
		  else if (fdy >= fdz)
			  d2 = fdy + Math.sqrt(dx * dx + dz * dz);
		  else
			  d2 = fdz + Math.sqrt(dx * dx + dy * dy);
			
     		return d2;
		}

		public double distanceToNth(double[] compareArray, int index) {
			return Math.sqrt(compareArray[index-1]);
		}

	}
	
	public void makePreview() {

		double  x, y, z, scale;
		int index;
		final DataBuffer data = preview.getRaster().getDataBuffer();
		
		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;
		
		index = 0;	
		initNoise();	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				x = (i * (xNoise / 63)) + xOffset;
				y = yOffset;
				z = (j * (zNoise / 63)) + zOffset;
				previewNoise[index] = getNoiseForVertex(new Vertex(x,y,z));
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				index++;
			}
		}
			
		scale = 255 / (max - min); 
		for(int i = 0; i < 64*64; i++) {
			data.setElem(i, (int)((previewNoise[i]  - min) * scale));			
		}
		
		return;
	}
	
	public void storeSettings() {
		
		seed = (long)panel.getInt("seed");
		nth = panel.getInt("nth");
		cellCount = panel.getInt("cellCount");
		
		metric = panel.getText("metric"); 
		xNoise = panel.getDouble("xNoise");
		yNoise = panel.getDouble("yNoise");
		zNoise = panel.getDouble("zNoise");
		rand.setSeed(seed);
		xOffset = rand.nextDouble();
		yOffset = rand.nextDouble();
		zOffset = rand.nextDouble();
		
		cells = new double[128][cellCount][3];

		rand.setSeed((long)seed);		
		
		for(int j=0; j< 128; j++) {


			for (int i = 0; i < cellCount; i++) {
				cells[j][i][0] = rand.nextDouble();
				cells[j][i][1] = rand.nextDouble();
				cells[j][i][2] = rand.nextDouble();
			}
		}

	}
	
	public void restoreSettings() {
		
			panel.setValue("seed", ""+seed);	
			panel.setValue("nth", ""+nth);
			panel.setValue("cellCount", ""+cellCount);
			panel.setValue("metric", metric);
			panel.setValue("xNoise", ""+xNoise);
			panel.setValue("yNoise", ""+yNoise);
			panel.setValue("zNoise", ""+zNoise);
		
	}
		
		
	public void save(ObjectOutputStream file) throws IOException {
			
			file.writeObject(this.getClass().getName());
			panel.save(file);
		
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		String value;
		String key = (String)file.readObject(); 

		
		while(key.compareTo("END") != 0) {

			value = (String)file.readObject();

			if(key.compareTo("metric") == 0) {
				if (value.compareTo("0") == 0) {
					metric = "Euclidean";
				} else if (value.compareTo("1") == 0) {
					value = "Manhattan";
				} else if (value.compareTo("2") == 0) {
					value = "ChessBoard";
				} else if (value.compareTo("3") == 0) {
					value = "SineSquared";
				}
			}
			panel.setValue(key, value);
			key = (String)file.readObject();		
		}	
	
		
		storeSettings();
			
		if (metric.compareTo("1") == 0) {
			metric = "Euclidean";
		} else if (metric.compareTo("2") == 0) {
			metric = "Manhattan";
		} else if (metric.compareTo("3") == 0) {
			metric = "ChessBoard";
		} else if (metric.compareTo("4") == 0) {
			metric = "SineSquared";
		}
		
		panel.setValue("metric", metric);
	}
	
		   /* (non-Javadoc)
	     * @see Utilities.NoiseEngine#copy()
	     */
    public NoiseEngine copy() {
        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            ((ExtendedHashBasedPanel)copy.getPanel()).setValuesUsingHash(panel.getHash());
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
           e.printStackTrace();
        }	
	        return null;
	}

	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Neighbour:</b> </td><td align=right>"+ nth + "</td></tr>" + 
			"<tr><td><b>Points per Cell:</b> </td><td align=right> " + cellCount + "</td></tr>" + 
			"<tr><td><b>Distance Metric:</b> </td><td align=right>" + metric + "</td></tr>" + 
			"<tr><td><b>Noise Size:</b> </td><td align=right>" + xNoise + ", " + yNoise + ", " +zNoise  + "</td></tr>" +
			"<tr><td><b>Seed:</b> </td><td align=right>"+seed + "</td></tr></table>";
			
	}	

	public Vertex[] getPreviewVertices() {

		Vertex[]  vertices = new Vertex[64*64];
		int index;
		
		index = 0;	
		initNoise();	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				vertices[index] = new Vertex((i * (xNoise / 63.0)) + xOffset,
											 yOffset,
											 (j * (zNoise / 63.0)) + zOffset); 	
				index++;
			}
		}
		
		return vertices;
	}

 
}
