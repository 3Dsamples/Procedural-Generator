
/*
 * ApplyFunction.java
 *
 * Created on 05 March 2002, 19:08
 */

/*
 Copyright (c) 2002, David Burnett
 
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

package plugins.engines;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import plugins.functions.FunctionEngine;
import GUI.ExtendedHashBasedPanel;
import Utilities.Landscape;
import Utilities.NoiseEngine;
import Utilities.Spline;
import Utilities.Vertex;

//import Utilities.*;
/**
*
 * @author  David
 */
public class ApplyFunction extends NoiseEngine implements FunctionEngine 
{


	protected GUI.NoisePanel panel;

	protected Function math;
	protected NoiseEngine noise;
	protected String functionName;

	public static void main(String[] args) {
		try {
			Class noiseClass = Class.forName("plugins.engines.Perlin");
			Utilities.NoiseEngine noise =
				(Utilities.NoiseEngine) noiseClass.newInstance();
			//            plugins.engines.Perlin noise = new plugins.engines.Perlin();
			noise.initNoise();
			//            octaves = panel.getOctaves();
			//            terrain = noise.CreateTerrain(50, 50, 0.5);
			//            noise.CreatePlanetPNG(1024, 1024, "D:\\test3Java.png" );
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(99);
		}
	}


	/** Creates a new instance of function */
	public ApplyFunction() {

	}

	public String name() {
		return functionName;
	}

	public String description() {
		return "Applies a mathematical function to the input.";
	}

	public javax.swing.JPanel getPanel() {
		if(math.getPanel() != null) {
			return math.getPanel();
		} 
		
		return null;
		
	}

	public void initNoise() {
		
		if(noise != null) {		
			noise.initNoise();
		}
		if(math != null) {
			math.init();
		}
	}
	
	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
	    /*
	     * Does not call math.function(vertex) since math.function calls
	     * noise.getNoiseForVertex for all functions, which does not move scale
	     * properly in many noises.
	     * 
	     * Thankfully there are no Warp-like functions in ApplyNoise
	     */
		return math.function(noise.getScaledMovedNoiseForVertex(x, y, z));
	}
	
	public double getNoiseForVertex(Vertex vertex) {
		return math.function((vertex));
	}

	public Vertex getNoiseSize() {
		return noise.getNoiseSize();
	}

	public Vertex getNoiseOffset() {
		//This seems wrong...
		//return noise.getNoiseSize();
		return noise.getNoiseOffset();
	}
	
	public void setProjection(int projection) {
		noise.setProjection(projection);
	}
	
	protected abstract class Function {
		
		public abstract void	  drawIcon (Graphics2D g2);	
		public abstract JPanel getPanel();	
		public abstract double function (Vertex vertex);
		public abstract double function (double value);		
		
		public double function(int vertex) {
			return function(noise.getNoiseForVertex(vertex));
		}
		
		public void init() {}
		public void storeSettings() {}
		public void restoreSettings() {}
		public void save(ObjectOutputStream file) throws IOException {}
		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {}
	}
	
	private class AbsoluteFunction extends Function{
		
		public JPanel getPanel(){return null;};	

		public double function(Vertex vertex) {
			return function(noise.getNoiseForVertex(vertex));
		}


		public void	drawIcon (Graphics2D g2){
			g2.drawString("abs(x)", 8, 38);
		}

		public double function (double value) {
			return Math.abs(value);
		}

	}

	
	private class InvertFunction extends Function{
		
		public JPanel getPanel(){return null;};	

		public double function (Vertex vertex) {
			return noise.getNoiseForVertex(vertex) * -1;
		}

		public double function (int vertex) {
			return noise.getNoiseForVertex(vertex) * -1;
		}


		public double function (double value) {
			return -value;
		}

		public void	drawIcon (Graphics2D g2){
			g2.drawString("-(x)", 18, 38);
		}

	}

	private class SineFunction extends Function{
		
		public JPanel getPanel(){return null;};	

		public double function (Vertex vertex) {
			return Math.sin(noise.getNoiseForVertex(vertex));
		}

		public double function (int vertex) {
			return Math.sin(noise.getNoiseForVertex(vertex));
		}

		public double function (double value) {
			return Math.sin(value);
		}

		public void	drawIcon (Graphics2D g2){
			g2.drawString("sin(x)", 11, 38);
		}


	}

	private class ClampFunction extends Function{
		
		private double high = 1.0;
		private double low = 0.0;
		final private JPanel clampPanel = new JPanel();
		final private JLabel highLabel = new JLabel("High Value");
		final private JLabel lowLabel = new JLabel("Low Value");
		final private JTextField highText = new JTextField("1.0");
		final private JTextField lowText = new JTextField("0.0");
		
		ClampFunction() {
			clampPanel.setBorder(new javax.swing.border.TitledBorder(null, functionName, javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 3, 11), new java.awt.Color(255, 0, 0)));
			clampPanel.add(highLabel);
			highText.setPreferredSize(new Dimension(60, 20));
			clampPanel.add(highText);
			
			clampPanel.add(lowLabel);
			lowText.setPreferredSize(new Dimension(60, 20));
			clampPanel.add(lowText);
		}
		
		public JPanel getPanel(){return clampPanel;};	

		public double function(Vertex vertex) {
			return function(noise.getNoiseForVertex(vertex));
		}

		public double function (double value) {
			return value < low ? low : value > high ? high : value;
		}

		public void	drawIcon (Graphics2D g2){
			g2.drawString("Clamp", 6, 38);
		}

		public void storeSettings() {
			high = Double.parseDouble(highText.getText());
			low = Double.parseDouble(lowText.getText());
		}
	
		public void restoreSettings() {	
			highText.setText(""+high);
			lowText.setText(""+low);
		}

		public void save(ObjectOutputStream file) throws IOException
		 {
		
			file.writeObject(this.getClass().getName());
			file.writeObject("high");
			file.writeObject(""+high);
			file.writeObject("low");
			file.writeObject(""+low);
			file.writeObject("END");
	
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

			String tmp = (String)file.readObject(); 
			while(tmp.compareTo("END") != 0) {
				if(tmp.compareTo("high") == 0) {					
					high = Double.parseDouble((String)file.readObject());
				} else if(tmp.compareTo("low") == 0) {					
					low = Double.parseDouble((String)file.readObject());
				}
				tmp = (String)file.readObject();
			}
			
		}

	}

	private class MaskFunction extends Function{
		
		private double split = 0.0;
		private double lower = 0.0;
		private double higher = 1.0;
		
		final private JPanel maskPanel = new JPanel();
		final private JLabel highLabel = new JLabel("High Value");
		final private JLabel lowLabel = new JLabel("Low Value");
		final private JLabel splitLabel = new JLabel("Split Value");
		final private JTextField highText = new JTextField("1.0");
		final private JTextField lowText = new JTextField("0.0");
		final private JTextField splitText = new JTextField("0.0");
		
		MaskFunction() {
			maskPanel.setBorder(new javax.swing.border.TitledBorder(null, functionName, javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 3, 11), new java.awt.Color(255, 0, 0)));
			maskPanel.add(splitLabel);
			splitText.setPreferredSize(new Dimension(60, 20));
			maskPanel.add(splitText);

			maskPanel.add(highLabel);
			highText.setPreferredSize(new Dimension(60, 20));
			maskPanel.add(highText);
			
			maskPanel.add(lowLabel);
			lowText.setPreferredSize(new Dimension(60, 20));
			maskPanel.add(lowText);
		}

		public JPanel getPanel(){return maskPanel;};	

		public double function(Vertex vertex) {
			return function(noise.getNoiseForVertex(vertex));
		}

		public double function (double value) {
			return value < split ? lower : higher;
		}

		public void	drawIcon (Graphics2D g2){
			g2.drawString("Mask", 8, 38);
		}

		public void storeSettings() {
			higher = Double.parseDouble(highText.getText());
			lower = Double.parseDouble(lowText.getText());
			split = Double.parseDouble(splitText.getText());
		}
	
		public void restoreSettings() {	
			highText.setText(""+higher);
			lowText.setText(""+lower);
			splitText.setText(""+split);
		}

		public void save(ObjectOutputStream file) throws IOException
		 {
		
			file.writeObject(this.getClass().getName());
			file.writeObject("high");
			file.writeObject(""+higher);
			file.writeObject("low");
			file.writeObject(""+lower);
			file.writeObject("split");
			file.writeObject(""+split);
			file.writeObject("END");
	
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

			String tmp = (String)file.readObject(); 
			while(tmp.compareTo("END") != 0) {
				if(tmp.compareTo("high") == 0) {					
					higher = Double.parseDouble((String)file.readObject());
				} else if(tmp.compareTo("low") == 0) {					
					lower = Double.parseDouble((String)file.readObject());
				} else if(tmp.compareTo("split") == 0) {					
					split = Double.parseDouble((String)file.readObject());
				}
				tmp = (String)file.readObject();
			}
			
		}
	}

	private class NoOperationFunction extends Function{
		
		public JPanel getPanel(){return null;};	

		public double function(Vertex vertex) {
			return noise.getNoiseForVertex(vertex);
		}

		public double function(double noise) {
			return noise;
		}

		public void	drawIcon (Graphics2D g2){
			g2.drawString("NOP", 14, 38);
		}

	}

	private class TerraceFunction extends Function{
		
		private double split = 0.5;
		private double slopeLength = 2.0;
		
		
		final private JPanel terracePanel = new JPanel();
		final private JLabel splitLabel = new JLabel("Percentage of flat land (0.0..100.0)");
		final private JTextField splitText = new JTextField("50.0");

		TerraceFunction() {
			terracePanel.setBorder(new javax.swing.border.TitledBorder(null, functionName, javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 3, 11), new java.awt.Color(255, 0, 0)));
			terracePanel.add(splitLabel);
			splitText.setPreferredSize(new Dimension(60, 20));
			terracePanel.add(splitText);
		}
		
		public JPanel getPanel(){return terracePanel;};	

		public double function(Vertex vertex) {
			return noise.getNoiseForVertex(vertex);
		}
		public double function (double value) {
			double floorValue = Math.floor(value);
			double gap = value - floorValue;
			return gap < split ? floorValue : floorValue + ((gap - split) * slopeLength);		
		}

		public void	drawIcon (Graphics2D g2){
			Font oldFont = g2.getFont();
			Font newFont = new Font(oldFont.getName(), oldFont.getStyle(), oldFont.getSize() - 2);
			g2.setFont(newFont);
			g2.drawString("Terrace", 5, 38);
			g2.setFont(oldFont);
		}
		public void storeSettings() {
			split = Double.parseDouble(splitText.getText());
			split /= 100;
			slopeLength = 1.0 / (1.0-split);
		}
	
		public void restoreSettings() {	
			splitText.setText(""+split);
		}

		public void save(ObjectOutputStream file) throws IOException
		 {
		
			file.writeObject(this.getClass().getName());
			file.writeObject("split");
			file.writeObject(""+split);
			file.writeObject("END");
	
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

			String tmp = (String)file.readObject(); 
			while(tmp.compareTo("END") != 0) {
				if(tmp.compareTo("split") == 0) {					
					split = Double.parseDouble((String)file.readObject());
				}
				tmp = (String)file.readObject();
			}
			
		}
	}

	private class RoughScaleFunction extends Function{
		
		private double high = 1.0;
		private double low = 0.0;

		private double fromLow;
		
		private double fromScale = 0.0;
		private double toScale = 0.0;
		
		final private ExtendedHashBasedPanel scalePanel = new ExtendedHashBasedPanel();
		
		RoughScaleFunction() {
			scalePanel.addTextBox("low", "Low Value", "0.0", "Scales lowest output value");
			scalePanel.addTextBox("high", "High Value", "1.0", "Scales highest output value");
		//	scalePanel.finish();
		}
		
		public void init() {
			toScale = high - low;
			
			fromLow =  noise.getMin();
			fromScale = 1 / (noise.getMax() - fromLow);
			
			
		}

		
		public JPanel getPanel(){return scalePanel;};	

		public double function(Vertex vertex) {
			double tmp;
			double value = noise.getNoiseForVertex(vertex);
			
			tmp = value - fromLow;
			tmp *= fromScale;
			
			tmp *= toScale;
			return tmp + low;	
		}

		public double function(int vertex) {
			double tmp;
			double value = noise.getNoiseForVertex(vertex);
			
			tmp = value - fromLow;
			tmp *= fromScale;
			
			tmp *= toScale;
			return tmp + low;		
		}
		public double function (double value) {
			double tmp;
			
			tmp = value - fromLow;
			tmp *= fromScale;
			
			tmp *= toScale;
			return tmp + low;		
			
		}

		public void	drawIcon (Graphics2D g2){
			g2.drawString("Scale", 9, 38);
		}


		public void save(ObjectOutputStream file) throws IOException
		 {
		
			file.writeObject(this.getClass().getName());
			file.writeObject("high");
			file.writeObject(""+high);
			file.writeObject("low");
			file.writeObject(""+low);
			file.writeObject("END");
	
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

			String tmp = (String)file.readObject(); 
			while(tmp.compareTo("END") != 0) {
				if(tmp.compareTo("high") == 0) {					
					high = Double.parseDouble((String)file.readObject());
				} else if(tmp.compareTo("low") == 0) {					
					low = Double.parseDouble((String)file.readObject());
				}
				tmp = (String)file.readObject();
			}
			
		}

		public void storeSettings() {
			low = scalePanel.getDouble("low");
			high = scalePanel.getDouble("high");
		}
	
		public void restoreSettings() {	
			scalePanel.setValue("low", ""+low);
			scalePanel.setValue("high", ""+high);
		}		
	}
	
	private class CraterFunction extends Function{
		
		private double rim = 1.0;
		private double floor = 0.0;
		final private JPanel craterPanel = new JPanel();
		final private JLabel floorLabel = new JLabel("Crater Floor");
		final private JLabel rimLabel = new JLabel("Rim Height");
		final private JTextField floorText = new JTextField("0.0");
		final private JTextField rimText = new JTextField("1.0");
		final private Spline splineEngine = new Spline();
		
		CraterFunction() {
			craterPanel.setBorder(new javax.swing.border.TitledBorder(null, functionName, javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 3, 11), new java.awt.Color(255, 0, 0)));
			craterPanel.add(floorLabel);
			floorText.setPreferredSize(new Dimension(60, 20));
			craterPanel.add(floorText);
			
			craterPanel.add(rimLabel);
			rimText.setPreferredSize(new Dimension(60, 20));
			craterPanel.add(rimText);
			
			Vertex[] points;
			points = new Vertex[8];
			points[0] = new Vertex(0, floor, 0);
			points[1] = new Vertex(0.32, floor, 0);
			points[2] = new Vertex(0.35, floor, 0);
			points[3] = new Vertex(0.39, rim, 0);
			points[4] = new Vertex(0.4, rim, 0);
			points[5] = new Vertex(0.46, 0, 0);
			points[6] = new Vertex(0.7, 0, 0);
			points[7] = new Vertex(1.0, 0, 0);

			splineEngine.initSpline(points, 3);
			
		}
		
		public JPanel getPanel(){return craterPanel;};	

		public double function(Vertex vertex) {
			return function(noise.getNoiseForVertex(vertex));
		}

		public double function (double value) {
			return splineEngine.spline(value);
		}

		public void	drawIcon (Graphics2D g2){
			g2.drawString("Crater", 6, 38);
		}

		public void storeSettings() {
			rim = Double.parseDouble(floorText.getText());
			floor = Double.parseDouble(rimText.getText());
		}
	
		public void restoreSettings() {	
			floorText.setText(""+rim);
			rimText.setText(""+floor);
		}

		public void save(ObjectOutputStream file) throws IOException
		 {
		
			file.writeObject(this.getClass().getName());
			file.writeObject("rim");
			file.writeObject(""+rim);
			file.writeObject("floor");
			file.writeObject(""+floor);
			file.writeObject("END");
	
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

			String tmp = (String)file.readObject(); 
			while(tmp.compareTo("END") != 0) {
				if(tmp.compareTo("rim") == 0) {					
					rim = Double.parseDouble((String)file.readObject());
				} else if(tmp.compareTo("floor") == 0) {					
					floor = Double.parseDouble((String)file.readObject());
				}
				tmp = (String)file.readObject();
			}
			
		}

	}

	
	public double getNoiseForVertex(int vertex) {
		return math.function(vertex);
	}
	
	public void setTerrain(Landscape terrain) {
		noise.setTerrain(terrain.getNewLandscape());
		this.terrain = noise.getTerrain() ;
		return;
	}

	public Landscape getTerrain() {
		return noise.getTerrain() ;
	}
	
	
	public void setFunction(String functionName) {
		
		System.err.println("Function Name set to " + functionName+" in "+((Object)this));
		this.functionName = functionName;
		if(functionName.compareTo("Invert") == 0) {  
			math = new InvertFunction(); 
		} else if(functionName.compareTo("Clamp") == 0) {  
			math = new ClampFunction(); 
		} else if(functionName.compareTo("Sine") == 0) {  
			math = new SineFunction(); 
		} else if(functionName.compareTo("Absolute") == 0) {  
			math = new AbsoluteFunction(); 
		} else if(functionName.compareTo("Mask") == 0) {  
			math = new MaskFunction(); 
		} else if(functionName.compareTo("No Operation")  == 0) {  
			math = new NoOperationFunction();  
		} else if(functionName.compareTo("Rough Scale")  == 0) {  
			math = new RoughScaleFunction();
		} else if(functionName.compareTo("Craterize") == 0) {  
			math = new CraterFunction();
		} else if(functionName.compareTo("Terrace")  == 0) {  
			math = new TerraceFunction();  
		} 
		return;
	}


	public Vertex getVertex(int index) {
		return noise.getVertex(index);
	}	

	public void paintIcon(Graphics2D g2, java.awt.image.ImageObserver component) {
		Font old = g2.getFont();
		g2.setFont(new Font(null, Font.ITALIC, 18));
		if(noise != null) {
			g2.drawImage(preview,0,0,component);
		}
		math.drawIcon (g2);
		g2.setFont(old);
	}
	
	public void setNoiseEngine(NoiseEngine noise) {
		this.noise = noise;
		if(noise != null) {
			System.err.println("Function Noise set to" + noise.name());
		}
	}
	public NoiseEngine getNoiseEngine() {
		return noise;
	}
	
	public void makePreview() {

		System.err.println(name() + " makePreview");
		boolean nanWarning = false;
 		double scale;
		DataBuffer previewData = preview.getRaster().getDataBuffer();

		if(noise != null) {		
			max = Double.NEGATIVE_INFINITY;
			min = Double.POSITIVE_INFINITY;
			initNoise();
			double[] inputNoise = noise.getPreviewNoise();	
//			Vertex[] inputNoise = noise.getPreviewVertices();	
			for(int index = 0; index < 64 * 64; index++){
				previewNoise[index] = math.function(inputNoise[index]);
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				if(Double.isNaN(previewNoise[index])) {
					nanWarning = true;
				}
			}
		
			if(max == Double.POSITIVE_INFINITY || min == Double.NEGATIVE_INFINITY) {

				JOptionPane pane = new JOptionPane(name() + " produces infinity for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "Warning");
				dialog.setModal(false);
				dialog.setVisible(true);
			}

			if(nanWarning) {
				JOptionPane pane = new JOptionPane(name() + " results in complex numbers being generated for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "NaN Warning");
				dialog.setModal(false);
				dialog.setVisible(true);				
			}
			
			scale = 255 / (max - min); 
			for(int i = 0; i < 64*64; i++) {
				previewData.setElem(i, (int)((previewNoise[i]  - min) * scale));			
			}
		}
		return;
	}
	
	
	public double[] getPreviewNoise() {
		return previewNoise;
	}

	public Vertex[] getPreviewVertices() {
		return noise.getPreviewVertices();
	}
	
	public void storeSettings() {
		math.storeSettings();
		return;
	}
	
	public void restoreSettings() {	
		math.restoreSettings();
		return;
	}

	public void save(ObjectOutputStream file) throws IOException
	 {
		
		file.writeObject(this.getClass().getName());
		file.writeObject("functionName");
		file.writeObject(functionName);
		math.save(file);
		file.writeObject("END");
	
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		String value;
		String type = (String)file.readObject(); 
		
		while(type.compareTo("END") != 0) {
			value = (String)file.readObject();
			if(type.compareTo("functionName") == 0) {
				functionName = value;
				setFunction(functionName);
				math.load(file);
			}
			type = (String)file.readObject();
		}
		math.restoreSettings();
	}	
	
	public String getDetails() {
		return "<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" +
			"<table>" + "<tr><td><b><u>Details</u></b></td></tr>" +
			"<tr><td><b>Function:</b> </td><td align=right>"+ functionName + "</td></tr></table>";
			
	}
	
    /* (non-Javadoc)
     * @see Utilities.NoiseEngine#copy()
     */
    public NoiseEngine copy() {
        return null;
    }
    
}
