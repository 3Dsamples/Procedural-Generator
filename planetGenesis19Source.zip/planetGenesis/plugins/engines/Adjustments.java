/*
 * Created on Jul 22, 2008
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

package plugins.engines;

import java.awt.Graphics2D;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JPanel;

import GUI.ExtendedHashBasedPanel;
import Utilities.Vertex;

/**
 * @author su_liam
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

public class Adjustments extends ApplyFunction
{
	private class AdjustmentFunction extends Function
	{
		private double offset = 0.0;
		private double scale = 1.0;
		private double exponent = 1.0;
		/*
		private double xRotation = 0.0;
		private double yRotation = 0.0;
		private double zRotation = 0.0;
		*/
		
		final private ExtendedHashBasedPanel adjustmentPanel = new ExtendedHashBasedPanel();
		
		private final String[] pointKey = {"offset", "scale", "exponent"};
		private final String[] pointLabel = {"Offset", "Scale", "Exponent"};
		private final String[] pointValue = {"" + offset, "" + scale, "" + exponent};
		private final String[] pointTooltip = {"Value added to each point",
								"Value by which to multiply each point",
								"Power to which each point is raised"};
	
		/*
		private final String[] rotationKey = {"xRotation", "yRotation", "zRotation"};
		private final String[] rotationLabel = {"X Rotation", "Y Rotation", "Z Rotation"};
		private final String[] rotationValue = {"" + xRotation, "" + yRotation, "" + zRotation};
		private final String[] rotationTooltip = {"Rotation about x-axis", 
								 "Rotation about y-axis", 
								 "Rotation about z-axis"};
		*/
			
		AdjustmentFunction() {
			
			adjustmentPanel.addTextBoxGroup("Point Adjustments", "Adjustments to the value of each point",
					pointKey, pointLabel, pointValue, pointTooltip);

			/*
			adjustmentPanel.addTextBoxGroup("unimplemented", "The rotation to be applied to the map",
					rotationKey, rotationLabel, rotationValue, rotationTooltip);
			*/		
		}
		
		public JPanel getPanel(){return adjustmentPanel;}
		
		public double function(Vertex vertex)
		{
			return function(noise.getNoiseForVertex(vertex));
		}
		
		public double function (double value)
		{
			//TODO Implement rotation
			return offset + scale * Math.pow(value, exponent);
		}
		
		
		public void storeSettings()
		{
			
			offset = adjustmentPanel.getDouble("offset");
			scale = adjustmentPanel.getDouble("scale");
			exponent = adjustmentPanel.getDouble("exponent");
			
			/*
			xRotation = adjustmentPanel.getDouble("xRotation");
			yRotation = adjustmentPanel.getDouble("yRot");
			zRotation = adjustmentPanel.getDouble("zRotation");
			*/
		}

		public void restoreSettings()
		{	
			
			adjustmentPanel.setValue("offset", ""+offset);
			adjustmentPanel.setValue("scale", ""+scale);
			adjustmentPanel.setValue("exponent", ""+exponent);
			
			/*
			adjustmentPanel.setValue("xRotation", ""+xRotation);
			adjustmentPanel.setValue("yRotation", ""+yRotation);
			adjustmentPanel.setValue("zRotation", ""+zRotation);
			 */
		}

		public void save(ObjectOutputStream file) throws IOException
		{
			file.writeObject(this.getClass().getName());
			adjustmentPanel.save(file);
		}

		public void load(ObjectInputStream file) throws ClassNotFoundException, IOException
		{
			String functionType = (String)file.readObject(); 

			adjustmentPanel.load(file);
			storeSettings();
		}
		
		public void	drawIcon (Graphics2D g2)
		{
			g2.drawString("Adjustments", 6, 38);
		}
		
		void setup(double offset, double scale, double exponent, double xRot, double yRot, double zRot)
		{
			this.offset = offset;
			this.scale = scale;
			this.exponent = exponent;
			/*
			this.xRotation = xRot;
			this.yRotation = yRot;
			this.zRotation = zRot;
			*/
			restoreSettings();
		}
	}

	public void setFunction(String functionName)
	{
		System.err.println("Function Name set to" + functionName);
		this.functionName = functionName;
		if(functionName.compareTo("Adjustments") == 0)
		{  
			math = new AdjustmentFunction();
		}

		return;
	}
	
	AdjustmentFunction getMath()
	{
		return (AdjustmentFunction) math;
	}
}
