/*
 * Created on Jun 3, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import java.awt.image.BufferedImage;
import java.util.Hashtable;

import GUI.ExtendedHashBasedPanel;
import Utilities.Landscape;
import Utilities.NoiseEngine;
import Utilities.Vertex;
import java.awt.image.DataBuffer;
import java.awt.Graphics2D;

import java.util.Random;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class CellBasis extends NoiseEngine{
	
	protected ExtendedHashBasedPanel panel;
	protected String metric; 

	protected java.util.Random rand;

	protected int gridProjection;
	protected int cellCount;
	protected DistanceCalculation distanceCalc;
	protected Hashtable<Double, double[][]> cells;
//	protected Landscape terrain;
	
	protected double xNoise;
	protected double yNoise;
	protected double zNoise;
	protected double xOffset;
	protected double yOffset;
	protected double zOffset;
	
	protected long seed;

	final protected BufferedImage preview;
	final protected double[] previewNoise = new double[64*64];
	protected final static double HASH_MOD_VALUE = Math.pow(2,32);


	public CellBasis() {

		String[] defaults = {"Euclidean", "Manhattan", "ChessBoard", "SineSquared", "QuasiEuclidean"};
		
		panel = new ExtendedHashBasedPanel();
		rand = new java.util.Random();


		panel.addTextBox("cellCount", "Points Per Cell",  "" + 1, "The number of points per cell");
		panel.addDropDown("metric", "Metric", defaults, "The way the distance between points is measured");
//		panel.addTextBox("SEED", "Seed",  "" + System.currentTimeMillis(), "Scale of the Terragen terrain file in metres per point");		
		panel.addRandomSeed("seed", "Seed",  System.currentTimeMillis());		
		panel.addTextBox("xNoise", "Noise Height",  "" + 1, "The height of the noise in cells");		
		panel.addTextBox("yNoise", "Noise Width",  "" + 1, "The width of the noise in cells");		
		panel.addTextBox("zNoise", "Noise Depth",  "" + 1, "The depth of the noise in cells>");
				
	//	panel.finish();	

		preview = new BufferedImage(64,64, BufferedImage.TYPE_BYTE_GRAY);
		cells = new Hashtable<Double, double[][]>(100);
		storeSettings();
	}

	// Thread unsafe
	private Vertex vTemp=new Vertex(0, 0, 0);
	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		vTemp.x=x*xNoise+xOffset; vTemp.y=y*yNoise+yOffset; vTemp.z=z*zNoise+zOffset;
		return calculateSumDistances(vTemp);
	}
	
	public double getNoiseForVertex(Vertex vertex) {
		return  calculateSumDistances(vertex);
	}

	public double getNoiseForVertex(int vertex) {
		return getNoiseForVertex(terrain.getNoiseVertex(vertex));
	}
	
	protected double calculateSumDistances(Vertex vertex) {
		
		final double xFloorAddOne;
		final double xFloorSubOne;
		final double yFloorAddOne;
		final double zFloorAddOne;
		final double yFloorSubOne;
		final double zFloorSubOne;

	
		double valueSoFar = 0;
		final double x = vertex.getX();
		final double y = vertex.getY();
		final double z = vertex.getZ();
		//find point in unit cube
		final double xFloor = Math.floor(x);
		final double yFloor = Math.floor(y);
		final double zFloor = Math.floor(z);

		xFloorAddOne = xFloor+1.0;
		xFloorSubOne = xFloor-1.0;

		yFloorAddOne = yFloor+1.0;
		yFloorSubOne = yFloor-1.0;
	
		zFloorAddOne = zFloor+1.0;
		zFloorSubOne = zFloor-1.0;
		

		try {

			valueSoFar = FindNeighbours(x, y, z, xFloor, yFloor, zFloor, valueSoFar);

			// find neighbours on the z plane, if the
			// nearest point on the toher cube is farther away
			// than the current nth neigbour then don't bother
				valueSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloor, valueSoFar);
				valueSoFar =
					FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloor, valueSoFar);
				valueSoFar =
					FindNeighbours(x, y, z, xFloor, yFloor, zFloorSubOne, valueSoFar);
				valueSoFar =
					FindNeighbours(x, y, z, xFloor, yFloor, zFloorAddOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloor, valueSoFar);
				valueSoFar =
					FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloor, valueSoFar);
			//      now for the z plane corners
				valueSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloorAddOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloorAddOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloorSubOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloorSubOne, valueSoFar);
			
			//		adjacent points for the top and bottom
				valueSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloor, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloor, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloor, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloor, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloorAddOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloorSubOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloorSubOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloorAddOne, valueSoFar);
			//		finally the corner cubes
				valueSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloorAddOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloorAddOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloorSubOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloorSubOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloorAddOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloorAddOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloorSubOne, valueSoFar);
				valueSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloorSubOne, valueSoFar);

			return valueSoFar;

		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
			return 0;
		}
	}

	protected double FindNeighbours(double x1, final double y1, final double z1, final double xFloor, final double yFloor, final double zFloor, double distanceSoFar) {
		double distance;
		double seed; 
		Double key;
		double[][] cellCache;
			
		// genereate random seed
		seed = ((702395077*xFloor+915488749*yFloor+2120969693*zFloor) % HASH_MOD_VALUE);
		key = new Double(seed);

		if(cells.containsKey(key)) {
			cellCache = (double[][])cells.get(key);
		} else {
			rand.setSeed((long)seed);		
			cellCache= new double[cellCount][3];
			for (int i = 0; i < cellCount; i++) {
				cellCache[i][0] = rand.nextDouble() + xFloor;
				cellCache[i][1] = rand.nextDouble() + yFloor;
				cellCache[i][2] = rand.nextDouble() + zFloor;
			}
			if(cells.size() == 100) {
				cells.clear();
			}
			cells.put(key, cellCache);
		}
		
		for (int i = 0; i < cellCount; i++) {
			distance =
				distanceCalc.compare(
					x1,
					y1,
					z1,
					cellCache[i][0],
					cellCache[i][1],
					cellCache[i][2]);
					if (distance < 1) {
						distanceSoFar += (1 - distance);
					}
			
		}
	//	System.err.println( seed  + "==>" + distances[0] + " in cell " + xFloor + "," +  yFloor + "," +  zFloor);
		return distanceSoFar;
	}

	public void initNoise() {
		storeSettings();
		cells.clear();

	}	


	public void setProjection(int projection) {
		gridProjection = projection;
	}
	
	/** returns JPanel for noise settings */
	public javax.swing.JPanel getPanel() {
		return panel;
	}




	public static void main(String[] args) {
		
	}
	
	public void storeSettings() {
		seed = panel.getInt("seed");

		cellCount = panel.getInt("cellCount");
		
		metric = panel.getText("metric");
		 
		if (metric.compareTo("Euclidean") == 0) {
			distanceCalc = new Euclidean();
		} else if (metric.compareTo("Manhattan") == 0) {
			distanceCalc = new Manhattan();
		} else if (metric.compareTo("ChessBoard") == 0) {
			distanceCalc = new ChessBoard();
		} else if (metric.compareTo("SineSquared") == 0) {
			distanceCalc = new SineSquared();
		} else if (metric.compareTo("QuasiEuclidean") == 0) {
			distanceCalc = new QuasiEuclidean();
		}

		xNoise = panel.getDouble("xNoise");
		yNoise = panel.getDouble("yNoise");
		zNoise = panel.getDouble("zNoise");
		rand.setSeed(panel.getInt("seed"));
		xOffset = rand.nextDouble();
		yOffset = rand.nextDouble();
		zOffset = rand.nextDouble();

	}
	
	public void restoreSettings() {
	
		panel.setValue("seed", ""+seed);	
		panel.setValue("xNoise", ""+xNoise);
		panel.setValue("yNoise",  ""+yNoise);
		panel.setValue("zNoise",  ""+zNoise);
		panel.setValue("cellCount",  ""+cellCount);

		panel.setValue("metric", metric);
	
	}
	
	public Vertex getVertex(int index) {
		return terrain.getNoiseVertex(index);
	}
	
	public void paintIcon(Graphics2D g2, ImageObserver component) {
		//final Ellipse2D.Double ellipse = new Ellipse2D.Double(4,4,58,58);
		//g2.draw(ellipse);
		g2.drawImage(preview,0,0,component);
	}

	public void makePreview() {

		double  x, y, z, scale;
		int index;
		final DataBuffer data = preview.getRaster().getDataBuffer();
		
		max = Double.MIN_VALUE;
		min = Double.MAX_VALUE;
		index = 0;	
		initNoise();	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				x = (i * (xNoise / 63.0)) + xOffset;
				y = yOffset;
				z = (j * (zNoise / 63.0)) + zOffset;
				previewNoise[index] = getNoiseForVertex(new Vertex(x,y,z));
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				index++;
			}
		}
			
		scale = 255 / (max - min); 
		for(int i = 0; i < 64*64; i++) {
			data.setElem(i, (int)((previewNoise[i]  - min) * scale));			
		}
		
		return;
	}
	
	public Vertex getNoiseSize() {
		return new Vertex(xNoise, yNoise, zNoise);
	}

	public Vertex getNoiseOffset() {
		Random rand = new Random(seed);
		return new Vertex(rand.nextDouble(), rand.nextDouble(), rand.nextDouble());
	}
	
	public double[] getPreviewNoise() {
		return previewNoise;
	}

	
	
	public void save(ObjectOutputStream file) throws IOException {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);
	
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}
	
	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Points per Cell:</b> </td><td align=right> " + cellCount + "</td></tr>" + 
			"<tr><td><b>Distance Metric:</b> </td><td align=right>" + metric + "</td></tr>" + 
			"<tr><td><b>Noise Size:</b> </td><td align=right>" + xNoise + ", " + yNoise + ", " +zNoise  + "</td></tr>" +
			"<tr><td><b>Seed:</b> </td><td align=right>"+seed + "</td></tr></table>";
			
	}		
	
	
	
	protected interface DistanceCalculation {
		public double compare(
			final double x1,
			final double y1,
			final double z1,
			final double x2,
			final double y2,
			final double z2);
		public double distanceToNth(double[] compareArray, int nth);
	}


	protected class Euclidean implements DistanceCalculation {
		public double compare(
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
			return ((x1 - x2) * (x1 - x2))
				+ ((y1 - y2) * (y1 - y2))
				+ ((z1 - z2) * (z1 - z2));
		}

		public double distanceToNth(double[] compareArray, int index) {
			return Math.sqrt(compareArray[index-1]);
		}

	}

	protected class ChessBoard implements DistanceCalculation {
		public double compare(
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
			return Math.max(Math.max(Math.abs(x1 - x2), Math.abs(y1 - y2)), Math.abs(z1 - z2));				
		}

		public double distanceToNth(double[] compareArray, int index) {
			return compareArray[index-1];
		}

	}

	protected class Manhattan implements DistanceCalculation {
		public double compare(			
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
			return Math.abs(x1 - x2) + Math.abs(y1 - y2) + Math.abs(z1 - z2);				
		}

		public double distanceToNth(double[] compareArray, int index) {
			return compareArray[index-1];
		}

	}	

	protected class SineSquared implements DistanceCalculation {
		
		
		public double compare(			
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
			return Math.sin((x1 - x2) * (x1 - x2))
							+ ((y1 - y2) * (y1 - y2))
							+ ((z1 - z2) * (z1 - z2));
			
		}

		public double distanceToNth(double[] compareArray, int index) {
			return compareArray[index-1];
		}

	}

	protected class QuasiEuclidean implements DistanceCalculation {
		
		public double compare(
		final double x1,
		final double y1,
		final double z1,
		final double x2,
		final double y2,
		final double z2) {
				
		double fdx, fdy, fdz;
		double dx, dy, dz, d2;
			
		  dx = x1 - x2;
		  dy = y1 - y2;
		  dz = z1 - z2;
		  	
		  fdx = Math.abs(dx); 
		  fdy = Math.abs(dy); 
		  fdz = Math.abs(dz);
		  
		  if (fdx >= fdy)
			  if (fdx >= fdz)
				d2 = fdx + Math.sqrt(dy * dy + dz * dz);
			  else
				d2 = fdz + Math.sqrt(dx * dx + dy * dy);
		  else if (fdy >= fdz)
			  d2 = fdy + Math.sqrt(dx * dx + dz * dz);
		  else
			  d2 = fdz + Math.sqrt(dx * dx + dy * dy);
			
     		return d2;
		}

		public double distanceToNth(double[] compareArray, int index) {
			return Math.sqrt(compareArray[index-1]);
		}

	}	
	
	public String name() {
		return "CellBasis";
	}

	public String description() {
		return "Worley based algorithm";
	}

	public void Parameters() {
		
	}	

	public void setTerrain(Landscape terrain) {
		this.terrain = terrain;
		terrain.setNoiseSpace(this);
		terrain.setProjection(gridProjection);
		terrain.setTile(false);
		return;
	}	
    public NoiseEngine copy() {

        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            ((ExtendedHashBasedPanel)copy.getPanel()).setValuesUsingHash(panel.getHash());
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }	

        return null;

    }	
}
