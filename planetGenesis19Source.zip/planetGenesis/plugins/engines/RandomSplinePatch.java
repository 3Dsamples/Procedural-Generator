/*
 * Created on Sep 14, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package plugins.engines;

import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Random;

import javax.swing.JPanel;

import GUI.ExtendedHashBasedPanel;
import Utilities.NoiseEngine;
import Utilities.SplinePatch;
import Utilities.Vertex;

/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class RandomSplinePatch extends NoiseEngine {

	private double [][] controlPoints;
	private SplinePatch patch;
	private ExtendedHashBasedPanel panel;
	int res;
	long seed; 

	public RandomSplinePatch() {
		
		res = 10;
		seed = System.currentTimeMillis(); 
		panel = new ExtendedHashBasedPanel();
		panel.addTextBox("res", "Resolution", res+"", "Spline Patch Resolution.");
		panel.addRandomSeed("seed", "Random Seed", seed);
		//panel.finish();

		storeSettings();
		
	}
	
	public static void main(String[] args) {
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#description()
	 */
	public String description() {
		// TODO Auto-generated method stub
		return "spatch Test";
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#getDetails()
	 */
	public String getDetails() {
		// TODO Auto-generated method stub
		return 
		"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" + 
		"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
		"<tr><td><b>Resolution:</b> </td><td align=right>"+ res + "</td></tr>" +
		"<tr><td><b>Seed:</b> </td><td align=right>" + seed + "</td></tr></table>";

	}

	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		return patch.spline(x, z, controlPoints);
	}
	
	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#getNoiseForVertex(Utilities.Vertex)
	 */
	public double getNoiseForVertex(Vertex vertex) {
		// TODO Auto-generated method stub
		return patch.spline(vertex.getX(), vertex.getZ(), controlPoints);
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#getNoiseForVertex(int)
	 */
	public double getNoiseForVertex(int vertex) {
		// TODO Auto-generated method stub
		return getNoiseForVertex(terrain.getNoiseVertex(vertex));
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#getPanel()
	 */
	public JPanel getPanel() {
		// TODO Auto-generated method stub
		return panel;
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#initNoise()
	 */
	public void initNoise() {
		
		storeSettings();
		Random rand = new Random(seed);
		controlPoints = new double[res][res];
		double[] points = new double[res];
		
		for(int i = 0; i < res; i++) {
			for(int j = 0; j < res; j++) {
				controlPoints[i][j] = rand.nextDouble();
			}		
			points[i] = (double)i/(res - 1);
		}

		patch = new SplinePatch();
		patch.initSpline(points, 3);
		
	}


	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#makePreview()
	 */
	public void makePreview() {
		int index = 0;	
		double previewScale;
		double x, y, z;
		final DataBuffer data = preview.getRaster().getDataBuffer();

		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;

		initNoise();

		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				
					x = (i * (1.0 / 63.0));
					y = 0;
					z = (j * (1.0 / 63.0));
					previewNoise[index] = getNoiseForVertex(new Vertex(x,y,z));
					if(previewNoise[index] > max) {
						max = previewNoise[index];
					}
					if(previewNoise[index] < min) {
						min = previewNoise[index];
					}
					index++;			}
		}	
		
		previewScale = 255 / (max - min); 

		for(int i = 0; i < 64*64; i++) {
			data.setElem(i, (int)((previewNoise[i]  - min) * previewScale));			
		}

	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#name()
	 */
	public String name() {
		// TODO Auto-generated method stub
		return "Spline Patch";
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#restoreSettings()
	 */
	public void restoreSettings() {
		// TODO Auto-generated method stub
		panel.setValue("seed", ""+seed);
		panel.setValue("res", ""+res);
	}

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);
	
	}
	
	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}

	   /* (non-Javadoc)
     * @see Utilities.NoiseEngine#copy()
     */
    public NoiseEngine copy() {
        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            ((ExtendedHashBasedPanel)copy.getPanel()).setValuesUsingHash(panel.getHash());
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
           e.printStackTrace();
        }	
        return null;
    }

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#storeSettings()
	 */
	public void storeSettings() {
		seed = panel.getInt("seed");
		res = panel.getInt("res");
	}
}
