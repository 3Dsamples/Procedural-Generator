
/*
 * Fault.java
 *
 * Created on 21 August 2003
 */

/*
 Copyright (c) 2003, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

package plugins.engines;

import java.util.Random;
import java.awt.image.DataBuffer;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import GUI.ExtendedHashBasedPanel;
import Utilities.*;
/**
*
 * @author  David
 */
public class Fault extends NoiseEngine {

	protected double[] scanDoubles;
	protected NoiseType noiseType;

	private double scale;
	private int iterations;
	private long seed;
	
	private Vector3D[] offsets;
	private int[] directions;
	
	ExtendedHashBasedPanel panel;

	
	public static void main(String[] args) {
		try {
			Class noiseClass = Class.forName("plugins.engines.Fault");
			Utilities.NoiseEngine noise =
				(Utilities.NoiseEngine) noiseClass.newInstance();
			//            plugins.engines.Perlin noise = new plugins.engines.Perlin();
			noise.initNoise();
			//            octaves = panel.getOctaves();
			//            terrain = noise.CreateTerrain(50, 50, 0.5);
			//            noise.CreatePlanetPNG(1024, 1024, "D:\\test3Java.png" );
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(99);
		}
	}

	/** Creates a new instance of perlin */
	public Fault() {
		panel = new ExtendedHashBasedPanel();
		panel.addTextBox("iterations", "Iterations", ""+1000, "Number of Iterations.");
		panel.addRandomSeed("seed", "Seed", System.currentTimeMillis());
		storeSettings();
		//		makePreview();
	}

	public String name() {
		return "Fault Noise";
	}

	public String description() {
		return "Simple plate techtonics simulation.\n" + 
				"Works best with meshes.";
	}

	public javax.swing.JPanel getPanel() {
		return panel;
	}

	public void initNoise() {
		storeSettings();		
	}

    // Not thread safe
	private Vertex vTemp=new Vertex(0, 0, 0);
	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		vTemp.x=x-.5; vTemp.y=y-.5; vTemp.z=z-.5;//no scaling etc yet for this one
		return getNoiseForVertex(vTemp);
	}
	
	public double getNoiseForVertex(Vertex vertex) {
		
		double dotValue;
		double height = 0;
//		Vertex tmp;

		for(int i= 0; i < iterations; i++ ) {
			
			dotValue = offsets[i].DotProduct(vertex.x - offsets[i].x, vertex.y-offsets[i].y, vertex.z - offsets[i].z);
			
//			tmp = new Vertex(vertex.sub(offsets[i]));
//			dotValue = offsets[i].DotProduct(tmp);
			
			if(dotValue > 0) {
					height+=directions[i];
			} else {
					height-=directions[i];
			}
		}
		
		return height * scale;
	}


	public double getNoiseForVertex(int vertex) {
		return getNoiseForVertex(terrain.getNoiseVertex(vertex));
	}
	

	public void makePreview() {
		double dotValue;
		double height = 0;
		int index = 0;	
		double previewScale;

		
		final DataBuffer data = preview.getRaster().getDataBuffer();

		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;

		initNoise();	

		
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){

				for(int k= 0; k < iterations; k++ ) {
				
					dotValue = offsets[k].DotProduct((i / 63.0) -.5 - offsets[k].x, -offsets[k].y-.5, (j / 63.0) - offsets[k].z-.5);
				
					if(dotValue > 0) {
							height+=directions[k];
					} else {
							height-=directions[k];
					}
				}
				previewNoise[index] = height * scale;		
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				index++;
				height = 0;
			}
		}	
		
		previewScale = 255 / (max - min); 

		for(int i = 0; i < 64*64; i++) {
			data.setElem(i, (int)((previewNoise[i]  - min) * previewScale));			
		}

	}
	
	public void storeSettings() {
		seed = (long)panel.getInt("seed");
		Random rand = new Random(seed);
		iterations = panel.getInt("iterations"); 
		scale = 1.0/iterations;
		offsets = new Vector3D[iterations];
		directions = new int[iterations];
		for(int i= 0; i < iterations; i++ ) {
			offsets[i] = new Vector3D((rand.nextDouble()-0.5) ,(rand.nextDouble()-0.5), (rand.nextDouble()-0.5));
			directions[i] = rand.nextDouble() > 0.5 ? 1: -1;
		}
	}
	
	public void restoreSettings() {
	
		panel.setValue("seed",""+seed);
		panel.setValue("iterations",""+iterations);	
	}
	

	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#save(java.io.ObjectOutputStream)
	 */
	public void save(ObjectOutputStream file) throws IOException {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);
	
	}
	
	/* (non-Javadoc)
	 * @see Utilities.NoiseEngine#load(java.io.ObjectInputStream)
	 */
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}

	   /* (non-Javadoc)
     * @see Utilities.NoiseEngine#copy()
     */
    public NoiseEngine copy() {
        try {
            NoiseEngine copy = (NoiseEngine)getClass().newInstance();
            ((ExtendedHashBasedPanel)copy.getPanel()).setValuesUsingHash(panel.getHash());
            return copy;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
           e.printStackTrace();
        }	
        return null;
    }

	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Iterations:</b> </td><td align=right>"+ iterations + "</td></tr>" +
			"<tr><td><b>Seed:</b> </td><td align=right>" + seed + "</td></tr></table>";
			
	}
	
}
