package plugins.engines;

import Utilities.Vertex;

public class PositionY extends PositionX
{
	@Override
	public String description()
	{
		return "Returns the y-coordinate of the current position. Useful in making textures that vary according to position.";
	}
	
	@Override
	public String name()
	{
		return "Position in y-coordinate";
	}
	

    @Override
    public double getScaledMovedNoiseForVertex(double x, double y, double z)
    {
        return y;
    }
    
	@Override
	public double getNoiseForVertex(Vertex vertex)
	{
		return vertex.getY();
	}

	@Override
	public double getNoiseForVertex(int vertex)
	{
		return terrain.getNoiseVertex(vertex).getY();
	}
	
	@Override
	public void makePreview()
	{
			int index = 0;
			
			max = Double.NEGATIVE_INFINITY;
			min = Double.POSITIVE_INFINITY;

			for(int j = 0; j < 64; j++){
				for(int i = 0; i < 64; i++){
					previewNoise[index] = 0;
					if(previewNoise[index] > max) {
						max = previewNoise[index];
					}
					if(previewNoise[index] < min) {
						min = previewNoise[index];
					}
					index++;
				}
			}
	}
	
	@Override
	public String getDetails() {
		return 
			"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
			"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
			"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
			"<br>" + 
			"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
			"<tr><td><b>Value:</b> </td><td align=right> y-coordinates </td></tr></table>";
			
	}
}