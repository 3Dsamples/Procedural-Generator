package plugins.engines;

/*
 * CacheWorley.java
 *
 * Created on 20 July 2003
 */

/*
 Copyright (c) 2003, David Burnett
 All rights reserved.

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice,
 this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following disclaimer
 in the documentation and/or other materials provided with the
 distribution.
 Neither the name of the copyright holder nor the names of its
 contributors may be used to endorse or promote products
 derived from this software without specific prior
 written permission.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
 NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
          SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
          OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 OF SUCH DAMAGE.
 */

import GUI.ExtendedHashBasedPanel;
import java.util.Hashtable;
import java.util.Random;


/**
 *
 * @author  David
 */
public class SolidWorley extends CacheWorley {


	protected double[] pointIds;
	protected Random pointIdGenerator;

	//private final Image icon = java.awt.Toolkit.getDefaultToolkit().getImage(getClass().getResource("/plugins/engines/images/worley.png"));

	/** Creates a new instance of CacheWorley */
	public SolidWorley() {

		String[] metricButtons = {"Euclidean", "Manhattan", "ChessBoard", "SineSquared", "QuasiEuclidean"};
	    
		panel = new ExtendedHashBasedPanel();
		panel.addTextBox("nth", "Neighbour", "1", "The distance from a point to the n'th nearest neighbour gives the noise value");
		panel.addTextBox("cellCount", "Points per Cell", "10", "The number of points in a cell, must be greater than the Neighbour value");
		panel.addRandomSeed("seed", "Seed", System.currentTimeMillis());
		panel.addDropDown("metric", "Metric", metricButtons, "The way the distance between points is measured");
		panel.addTextBox("xNoise", "Height", "10", "The number of cells per x coordinate");
		panel.addTextBox("yNoise", "Width", "10", "The number of cells per y coordinate, not relavent for 2D noise");
		panel.addTextBox("zNoise", "Depth", "10", "The number of cells per z coordinate");
		cells = new Hashtable<Double, double[][]>(100);
		storeSettings();
		pointIdGenerator = new Random();
	}

	public static void main(String[] args) {
		try {
			Class noiseClass = Class.forName("textures.engines.Fault");
			Utilities.NoiseEngine noise =
				(Utilities.NoiseEngine) noiseClass.newInstance();
			//            textures.engines.Perlin noise = new textures.engines.Perlin();
			noise.initNoise();
			//            octaves = panel.getOctaves();
			//            terrain = noise.CreateTerrain(50, 50, 0.5);
			//            noise.CreatePlanetPNG(1024, 1024, "D:\\test3Java.png" );
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.exit(99);
		}
	}

	public String name() {
		return "CacheWorley";
	}

	public String description() {
		return "Produces solid blocks.<br>" +
				"Worley based algorithm, distance to nth nearest neighbour<br>" +
				"Scaleable version with no tiling<br>";
	}

	public void Parameters() {
		
	}

	public void initNoise() {

		storeSettings();
		pointIdGenerator.setSeed(seed);

		if (metric.compareTo("Euclidean") == 0) {
			distanceCalc = new Euclidean();
		} else if (metric.compareTo("Manhattan") == 0) {
			distanceCalc = new Manhattan();
		} else if (metric.compareTo("ChessBoard") == 0) {
			distanceCalc = new ChessBoard();
		}else if (metric.compareTo("SineSquared") == 0) {
			distanceCalc = new SineSquared();
		}else if (metric.compareTo("QuasiEuclidean") == 0) {
			distanceCalc = new QuasiEuclidean();
		}
		
		cells.clear();
		tmp = new double[nth];
		pointIds = new double[nth];
	}



	protected double[] calculateDistanceArray(double x, double y, double z) {
		
		final double xFloorAddOne;
		final double xFloorSubOne;
		final double yFloorAddOne;
		final double zFloorAddOne;
		final double yFloorSubOne;
		final double zFloorSubOne;

		for(int i = 0; i < nth; i++) {
			tmp[i] = Double.POSITIVE_INFINITY;
		}
		
		double nthNearestSoFar = Double.POSITIVE_INFINITY;

		//find point in unit cube
		final double xFloor = Math.floor(x);
		final double yFloor = Math.floor(y);
		final double zFloor = Math.floor(z);

		xFloorAddOne = xFloor+1.0;
		xFloorSubOne = xFloor-1.0;

		yFloorAddOne = yFloor+1.0;
		yFloorSubOne = yFloor-1.0;
	
		zFloorAddOne = zFloor+1.0;
		zFloorSubOne = zFloor-1.0;
		

		try {

			nthNearestSoFar = FindNeighbours(x, y, z, xFloor, yFloor, zFloor, tmp, pointIds, nth);

			// find neighbours on the z plane, if the
			// nearest point on the toher cube is farther away
			// than the current nth neigbour then don't bother
			if (distanceCalc.compare(x, y, z, xFloorAddOne, y, z) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloor, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, y, z) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloor, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, x, y, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloor, yFloor, zFloorSubOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, x, y, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloor, yFloor, zFloorAddOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloorAddOne, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloor, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloor, z) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloor, tmp, pointIds, nth);
			}
			//      now for the z plane corners
			if (distanceCalc.compare(x, y, z, xFloorAddOne, y, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloorAddOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, y, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloorAddOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, y, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloor, zFloorSubOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, y, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloor, zFloorSubOne, tmp, pointIds, nth);
			}
			
			//		adjacent points for the top and bottom
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloorAddOne, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloor, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloorAddOne, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloor, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloor, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloor, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloor, z) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloor, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloorAddOne, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloorAddOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloorAddOne, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorAddOne, zFloorSubOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloor, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloorSubOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, x, yFloor, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloor, yFloorSubOne, zFloorAddOne, tmp, pointIds, nth);
			}
			//		finally the corner cubes
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloorAddOne, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
					FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloorAddOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloorAddOne, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloorAddOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloorAddOne, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorAddOne, zFloorSubOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloorAddOne, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorAddOne, zFloorSubOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloor, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloorAddOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloor, zFloorAddOne) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloorAddOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloor, yFloor, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorSubOne, yFloorSubOne, zFloorSubOne, tmp, pointIds, nth);
			}
			if (distanceCalc.compare(x, y, z, xFloorAddOne, yFloor, zFloor) < nthNearestSoFar) {
				nthNearestSoFar =
				FindNeighbours(x, y, z, xFloorAddOne, yFloorSubOne, zFloorSubOne, tmp, pointIds, nth);
			}

			return pointIds;  

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}


	protected double FindNeighbours(double x1, final double y1, final double z1, final double xFloor, final double yFloor, final double zFloor, final double[] distances, double[] pointIds, int index) {
		double distance, temp, tempPointId;
		double seed; 
		Double key;
		double[][] cellCache;
		
		index--;
			
		// genereate random seed
		seed = ((702395077*xFloor+915488749*yFloor+2120969693*zFloor) % HASH_MOD_VALUE);
		key = new Double(seed);

		if(cells.containsKey(key)) {
			cellCache = (double[][])cells.get(key);
		} else {
			rand.setSeed((long)seed);		
			cellCache= new double[cellCount][4];
			for (int i = 0; i < cellCount; i++) {
				cellCache[i][0] = rand.nextDouble() + xFloor;
				cellCache[i][1] = rand.nextDouble() + yFloor;
				cellCache[i][2] = rand.nextDouble() + zFloor;
				cellCache[i][3] = pointIdGenerator.nextDouble();
			}
			if(cells.size() == 100) {
				cells.clear();
			}
			cells.put(key, cellCache);
		}
		
		for (int i = 0; i < cellCount; i++) {
			distance =
				distanceCalc.compare(
					x1,
					y1,
					z1,
					cellCache[i][0],
					cellCache[i][1],
					cellCache[i][2]);
			if (distance < distances[index]) {
				distances[index] = distance;
				pointIds[index] = cellCache[i][3]; 
				int j = index;
				while (j > 0 && distances[j] < distances[j - 1]) {
					temp = distances[j - 1];
					tempPointId = pointIds[j - 1];
					distances[j - 1] = distances[j];
					pointIds[j - 1] = pointIds[j];
					distances[j] = temp;
					distances[j] = tempPointId;
					j--;
				}
			}
		}
	//	System.err.println( seed  + "==>" + distances[0] + " in cell " + xFloor + "," +  yFloor + "," +  zFloor);
		return distances[index];
	}


}
