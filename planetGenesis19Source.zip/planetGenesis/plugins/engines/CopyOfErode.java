package plugins.engines;

import java.awt.Graphics2D;
import java.awt.image.DataBuffer;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.nio.DoubleBuffer;
import java.nio.channels.FileChannel;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import GUI.ExtendedHashBasedPanel;
import GUI.Progress;
import Utilities.NoiseEngine;
import Utilities.Planet;
import Utilities.PostProcess;
import Utilities.Vertex;

public class CopyOfErode extends PostProcess {

	private double high = 1.0;
	private double low = 0.0;
	
	private double fromScale = 0.0;
	private double toScale = 0.0;
	
	private double erodeFactor = 0.05;
	
	private int terrainWidth, terrainHeight;
	private int startPos;

	
	ExtendedHashBasedPanel panel;
	
	public CopyOfErode() {
		
		panel = new ExtendedHashBasedPanel();
		panel.addTextBox("erode", "Erode Factor", "0.05", "Level of erosion");
		storeSettings();

	}
	
	public void initNoise() {
	
		storeSettings();		
		
	}
	
	
	protected void process(DoubleBuffer noiseMap, Progress progress) {

		double erodeX, erodeY, noiseValue;
		
		int vertexCount;

		
		if (terrain instanceof Planet) {
			startPos = 1;
			vertexCount = terrain.getVertexCount() - 2;
		} else {
			startPos = 0;
			vertexCount = terrain.getVertexCount();
		}

		
		terrainWidth = terrain.getXMesh() - 1;
		terrainHeight = terrain.getZMesh() - 1;
		
		try {
			File tmpdoubleFile = File.createTempFile("tmpDouble", null);
	
			FileChannel rwCh =
	            new RandomAccessFile(
	          		  tmpdoubleFile,"rw").
	                    getChannel();			
	
		    long fileSize = vertexCount * 8;
		    DoubleBuffer erosionMap = rwCh.map(
		        FileChannel.MapMode.READ_WRITE,
		                          0, fileSize).asDoubleBuffer();
			erosionMap.position(0); 	
			noiseMap.position(0);
			
			erosionMap.put(noiseMap);
			
	
			progress.setMaxValue(terrainHeight);
			progress.setProgressText("Processing " + name());
			progress.setProgressValue(0);
			
			
			for (int i = 0; i <=  terrainHeight; i++) {
				for (int j = 0; j <= terrainWidth; j++) {
					erode(noiseMap, erosionMap, j, i, noiseMap.get((i * terrainHeight) + terrainWidth + startPos));
				}	
				progress.setProgressValue(i);
			}
			
			for(int i=0; i<10; i++) {
				System.err.println(i + ", " + noiseMap.get(i));
			}
			
			noiseMap.position(0);
			erosionMap.position(0);
			noiseMap.put(erosionMap);

			for(int i=0; i<10; i++) {
				System.err.println(i + ", " + noiseMap.get(i));
			}

			
	
			rwCh.close();
			erosionMap = null;
			tmpdoubleFile.delete();

		} catch (Exception e) {
			e.printStackTrace();
		}

		
		return;
		
	}
	
	private void erode(DoubleBuffer noiseMap, DoubleBuffer erosionMap, int xPosition, int yPosition, double centreHeight) {
	
		int erodeX, erodeY;
		double erodeHeight;
		
		if(xPosition < 0 || yPosition < 0 || xPosition > terrainWidth || yPosition > terrainHeight) {
			return;
		} 
		
//		System.err.println("eroding " + xPosition + "," + yPosition);

		
		int position; 
		
		double positionHeight;
		
		erodeHeight = centreHeight;
		erodeX = xPosition;
		erodeY = yPosition;
		
		
		if(yPosition > 0 && xPosition > 0) {
			position = startPos + (terrainHeight * ( yPosition - 1)) + xPosition - 1;
			positionHeight = noiseMap.get(position);
			if(positionHeight < centreHeight) {					
				if(positionHeight < erodeHeight) {
					erodeHeight = positionHeight;
					erodeX = xPosition - 1;	
					erodeY = yPosition - 1;	
				}
			}
		}
			
		if(yPosition > 0 && xPosition > - 1) {
			position = (terrainHeight * ( yPosition - 1)) + xPosition;
			positionHeight = noiseMap.get(position);
			if(positionHeight < erodeHeight) {
				erodeHeight = positionHeight;
				erodeX = xPosition;	
				erodeY = yPosition - 1;	
			}
		}

		if(yPosition > 0 && xPosition < terrainWidth) {
			position = (terrainHeight * ( yPosition - 1)) + xPosition + 1;
			positionHeight = noiseMap.get(position);
			if(positionHeight < erodeHeight) {
				erodeHeight = positionHeight;
				erodeX = xPosition + 1;	
				erodeY = yPosition - 1;	
			}
		}
		
		if(yPosition >= 0 && xPosition > 0) {
			position = (terrainHeight * yPosition) + xPosition - 1;
			positionHeight = noiseMap.get(position);
			if(positionHeight < erodeHeight) {
				erodeHeight = positionHeight;
				erodeX = xPosition - 1;	
				erodeY = yPosition;	
			}
		}

		if(yPosition >= 0 && xPosition < terrainWidth) {
			position = (terrainHeight * yPosition) + xPosition + 1;
			positionHeight = noiseMap.get(position);
			if(positionHeight < erodeHeight) {
				erodeHeight = positionHeight;
				erodeX = xPosition + 1;	
				erodeY = yPosition;	
			}
		}
		
		if(yPosition < terrainHeight && xPosition > -1) {
			position = (terrainHeight * ( yPosition + 1)) + xPosition - 1;
			positionHeight = noiseMap.get(position);
			if(positionHeight < erodeHeight) {
				erodeHeight = positionHeight;
				erodeX = xPosition - 1;	
				erodeY = yPosition + 1;	
			}
		}
			
		if(yPosition < terrainHeight && xPosition > - 1) {
			position = (terrainHeight * ( yPosition + 1)) + xPosition;
			positionHeight = noiseMap.get(position);
			if(positionHeight < erodeHeight) {
				erodeHeight = positionHeight;
				erodeX = xPosition;	
				erodeY = yPosition + 1;	
			}
		}

		if(yPosition < terrainHeight && xPosition < terrainWidth) {
			position = (terrainHeight * ( yPosition + 1)) + xPosition + 1;
			positionHeight = noiseMap.get(position);
			if(positionHeight < erodeHeight) {
				erodeHeight = positionHeight;
				erodeX = xPosition + 1;	
				erodeY = yPosition + 1;	
			}
		}

		if(erodeHeight != centreHeight) {
			erode(noiseMap, erosionMap, 
					erodeX, erodeY, 
					erodeHeight);
			position = (terrainHeight * erodeY) + erodeX;
			erosionMap.put(position,erosionMap.get(position) - erodeFactor);
		}
		return;
	}
			



	public String description() {
		return "Scales the noise to between the supplied values";
	}
	
	public String getDetails() {
		return "<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" +
		"<table>" + "<tr><td><b><u>Details</u></b></td></tr>" +
		"<tr><td><b>New Low:</b> </td><td align=right>"+ low + "</td></tr>" +
		"<tr><td><b>New High:</b> </td><td align=right>"+ high + "</td></tr>" +
		"</table>";
	}

	public double getNoiseForVertex(Vertex vertex) {
		return 0;
	}

	public double getNoiseForVertex(int vertex) {
		return 0;
	}

	public JPanel getPanel() {
		return panel;
	}



	public void makePreview() {

		boolean nanWarning = false;
 		double scale, noiseValue;
		DataBuffer previewData = preview.getRaster().getDataBuffer();

		
		if(noise != null) {		
			DoubleBuffer previewNoiseMap = DoubleBuffer.wrap(noise.getPreviewNoise());
			DoubleBuffer erosionNoiseMap = DoubleBuffer.wrap(noise.getPreviewNoise());
			
			terrainWidth = 63;
			terrainHeight = 63;

			for(int i = 0; i < 64; i++){
				for(int j = 0; j < 64; j++){
//					System.err.println("Eroding Start Point " + i + "," + j);
					erode(previewNoiseMap, erosionNoiseMap, j, i,  previewNoiseMap.get((i*64) + j));
					noiseValue =  previewNoiseMap.get((i*64) + j);
					if(noiseValue > max) {
						max = noiseValue;
					}
					if(noiseValue < min) {
						min = noiseValue;
					}
					if(Double.isNaN(noiseValue)) {
						nanWarning = true;
					}
				}	
			}
			
			
			if(max == Double.POSITIVE_INFINITY || min == Double.NEGATIVE_INFINITY) {

				JOptionPane pane = new JOptionPane(name() + " produces infinity for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "Warning");
				dialog.setModal(false);
				dialog.setVisible(true);
			}

			if(nanWarning) {
				JOptionPane pane = new JOptionPane(name() + " results in complex numbers being generated for its current settings.\nAll images produced will be plain black.", JOptionPane.INFORMATION_MESSAGE);
				JDialog dialog = pane.createDialog(null, "NaN Warning");
				dialog.setModal(false);
				dialog.setVisible(true);				
			}
			
			scale = 255 / (max - min); 
			for(int i = 0; i < 64*64; i++) {
				previewData.setElem(i, (int)((erosionNoiseMap.get(i)  - min) * scale));			
			}
			
			erosionNoiseMap.get(previewNoise);

			erosionNoiseMap = null;
			previewNoiseMap = null;
		}
		
		
		return;
	}

	public String name() {
		return "Simple Erode";
	}

	public NoiseEngine copy() {
		return null;
	}
	
	
	public void storeSettings() {
		erodeFactor = panel.getDouble("erode");
	}

	public void restoreSettings() {	
		panel.setValue("erode", ""+erodeFactor);
	}
		

	public void save(ObjectOutputStream file) throws IOException {
		
		file.writeObject(this.getClass().getName());
		panel.save(file);
	
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		panel.load(file);
		storeSettings();
	}	
	
	public void paintIcon(Graphics2D g2, ImageObserver component) {
		//final Ellipse2D.Double ellipse = new Ellipse2D.Double(4,4,58,58);
		//g2.draw(ellipse);
		if(noise != null) {
			g2.drawImage(preview,0,0,component);
		}
		g2.drawString("Accurate", 6, 38);
	}

    @Override
    public double getScaledMovedNoiseForVertex(double x, double y, double z)
    {
        // TODO Auto-generated method stub
        return 0;
    }
	
	
}
