package plugins.noiseGen;

/*
 * author datta_sid
 */
import static java.lang.Math.abs;
import static java.lang.Math.floor;

import java.util.Random;

import properties.AutoPropertyException;

import Utilities.NoiseEngine;

public class CellNoiseEngine extends ManagedNoiseEngine
{
	
	public long seed;
	Random rand=new Random();
	
	public CellNoiseEngine()
	{
		super();
		
		setSeed(System.currentTimeMillis());
		rand.setSeed(seed);
		
		try
		{
			properties.registerRandomSeed("seed");
			
			properties.registerProperty("width");
			properties.registerProperty("height");
			properties.registerProperty("depth");
			
			properties.createGroup("Noise Size", true, "width", "height", "depth");
			
			panel=properties.createPanel();
		} catch (AutoPropertyException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		noiseName="CellNoise";
        noiseDescription="Generates discrete random values for for " +
                "integer coefficients<p>.Values will remain constant eg from " +
                "1, 1 to 2-delta, 2-delta";
	}
	
	@Override
	public void initNoise()
	{
		super.initNoise();
	}
	
	/**
	 * Setter for seed, for managed properties to use
	 * also uses
	 * @param seed
	 */
	public void setSeed(long seed)
	{
		this.seed=seed;
		rand.setSeed(seed);
		xOffset=rand.nextInt(200);
		yOffset=rand.nextInt(200);
		zOffset=rand.nextInt(200);
	}
	
	@Override
	public NoiseEngine copy()
	{
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public double getNoiseForVertex(double x, double y, double z)
	{
		//fx fy fz accounted for externally
		  int xi = (int)(floor(x));
		  int yi = (int)(floor(y));
		  int zi = (int)(floor(z));
		  int n = abs(xi + yi*1301 + zi*314159);
		  n ^= (n<<13);
		  return ((float)(n*(n*n*15731 + 789221) + 1376312589) / 4294967296.0);
	}

	@Override
	public String getDetails()
	{
		return
		"<table ><tr><td><b><u>Approx. Range</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" + 
		"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
		"<tr><td><b>Noise:</b> </td><td align=right>"+ noiseName + "</td></tr>" + 
		"<tr><td><b>Noise Size:</b> </td><td align=right>" + width + ", " + height + ", " +depth  + "</td></tr>" +
   		"<tr><td><b>Noise Offset:</b> </td><td align=right>" + xOffset + ", " + yOffset + ", " +zOffset  + "</td></tr>" +
		"<tr><td><b>Seed:</b> </td><td align=right>"+seed + "</td></tr></table>";
	}
	
//	public static void main(String[] args)
//	{
//		CellNoiseEngine c=new CellNoiseEngine();
//		System.out.println(c.name());
//	}
}
