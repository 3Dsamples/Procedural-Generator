package plugins.noiseGen;
/*
 * author datta_sid
 */
import static java.lang.Math.floor;
import properties.AutoPropertyException;
import Utilities.NoiseEngine;

public class BrickPatternEngine extends ManagedNoiseEngine
{
	public double mortarVal=.5;
	public double mortar=.1;
	static String[] types={"Black and white bricks", "White bricks", "Random bricks"};
	int type=0;
	
	public BrickPatternEngine()
	{
		super();
		
		try
		{
			
			properties.registerProperty("width");
			properties.registerProperty("height");
			properties.registerProperty("depth");
			
			properties.createGroup("Noise Size", true, "width", "height", "depth");
			properties.registerProperty("mortar", "Mortar percentage", "How much mortar");
//			properties.setPropertyStepSize("mortar", 1.0);
			properties.setPropertyStepSize("mortar", .1);
			
			properties.registerRadioProperty("type", "Brick type", "Brick type", types);
			
			panel=properties.createPanel();
		} catch (AutoPropertyException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		noiseName="Brick Pattern";
        noiseDescription="Creates a Bricklike pattern";
	}
	
	public String getType()
	{
		return types[type];
	}
	
	public void setType(String tp)
	{
//		System.out.println("Type set "+tp);
		for(int i=0; i<types.length; i++)
		{
			if(types[i].equals(tp))
			{
				type=i;
				break;
			}
		}
//		System.out.println("Set to "+type);
		
	}
	
	public double getMortar()
	{
		return this.mortar*2;
	}
	
	public void setMortar(double mortar)
	{
		if(mortar>1)
			mortar=1;
		if(mortar<0)
			mortar=0;
		
		this.mortar=mortar/2;
	}
	
	@Override
	public void initNoise()
	{
		super.initNoise();
	}
	
	
	@Override
	public NoiseEngine copy()
	{
		// TODO Auto-generated method stub
		return null;
	}


	public double getNoiseForVertex(double x, double y, double z)
	{
	  //fx fy fz accounted for externally
	  int xi = (int)(floor(x));
	  int yi = (int)(floor(y));
	  int zi = (int)(floor(z));
	  double xd=x-xi, zd=z-zi;
	  if(zd<mortar || zd>(1-mortar))
		  return .5;
	  int x2=xi; if(xd>.5){ x2++; xd=1-xd; }
	  int c=(zi&1);
	  if(xd<mortar && ((x2&1)==0 ^c==0))
		  return .5;
	  if(type==0)
	  {
		  int b=xi&1, a=(xi&2)>>1;
		  return ((a&c)|((~c)&(a^b)));
	  }
	  else if(type==1)
	  {
		  return 1;
	  }
	  else
	  {
		  return .8;//TODO : need to implement
	  }
	}

	@Override
	public String getDetails()
	{
		return
		"<table ><tr><td><b><u>Range</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ min + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + max + "</td></tr></table>" + 
		"<br>" + 
		"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
		"<tr><td><b>Noise:</b> </td><td align=right>"+ noiseName + "</td></tr>" + 
		"<tr><td><b>Noise Size:</b> </td><td align=right>" + width + ", " + height + ", " +depth  + "</td></tr>" +
   		"<tr><td><b>Noise Offset:</b> </td><td align=right>" + xOffset + ", " + yOffset + ", " +zOffset  + "</td></tr>";
	}
	
//	public static void main(String[] args)
//	{
//		CellNoiseEngine c=new CellNoiseEngine();
//		System.out.println(c.name());
//	}
}
