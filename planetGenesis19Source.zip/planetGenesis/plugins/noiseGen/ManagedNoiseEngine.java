package plugins.noiseGen;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import properties.AutoProperty;
import properties.AutoPropertyException;
import Utilities.NoiseEngine;
import Utilities.Vertex;

/**
 * Extending classes must override getNoiseForVertex(double x, double y, double z) 
 * or getNoiseForVertex(Vertex v) or an infinite loop and stack overflow will occur.
 * Better use the getNoiseForVertex(double x, double y, double z) version
 * @author sdatta
 *
 */
public abstract class ManagedNoiseEngine extends NoiseEngine
{

	public String noiseName="Managed AutoProperty Noise";
	public String noiseDescription="Abstract class for noise whose " +
			        "store, restore, save load are taken care of automatically";
	
	protected JPanel panel=null;
	protected AutoProperty properties;
	
	public double width=10, height=10, depth=10;
	public double xOffset=0, yOffset=0, zOffset=0;
	
	public ManagedNoiseEngine()
	{
		super();
		properties = new AutoProperty(this);
	}
	
	@Override
	public void initNoise()
	{
	}

	@Override
	public String description()
	{
		return noiseDescription;
	}

	@Override
	public JPanel getPanel()
	{
		if(panel==null)
			panel=properties.createPanel();
//		System.out.println("Getpanel returning "+panel.hashCode());
		return panel;
	}


	@Override
	public String name()
	{
		return noiseName;
	}

	private Vertex vTemp=new Vertex(0, 0, 0);
	public double getNoiseForVertex(double x, double y, double z)
	{
		vTemp.x=x; vTemp.y=y; vTemp.z=z;  
		return getNoiseForVertex(vTemp);
	}
	
	@Override
	public double getNoiseForVertex(Vertex vertex)
	{
		return getNoiseForVertex(vertex.x, vertex.y, vertex.z);
	}
	
	@Override
	public double getScaledMovedNoiseForVertex(double x, double y, double z)
	{
		return getNoiseForVertex(x*width+xOffset, y*height+yOffset, z*depth+zOffset);
	}

	@Override
	public double getNoiseForVertex(int vertex)
	{
		return getNoiseForVertex(terrain.getNoiseVertex(vertex));
	}
	
	public Vertex[] getPreviewVertices() {

		Vertex[]  vertices = new Vertex[64*64];
		int index;
		
		index = 0;	
		initNoise();	
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				vertices[index] = new Vertex((i * (width / 63.0)) + xOffset,
											 yOffset,
											 (j * (depth / 63.0)) + zOffset); 	
				index++;
			}
		}
		
		return vertices;
	}	
	
	public void makePreview() {
		int index = 0;
		double scale, x, y, z;

		initNoise();	
		
		max = Double.NEGATIVE_INFINITY;
		min = Double.POSITIVE_INFINITY;
		Vertex v=new Vertex(0., 0., 0.);
		for(int j = 0; j < 64; j++){
			for(int i = 0; i < 64; i++){
				v.x = (i * (width / 63.0)) + xOffset;
				v.y = yOffset;
				v.z = (j * (depth / 63.0)) + zOffset;
				previewNoise[index] = getNoiseForVertex(v);
				if(previewNoise[index] > max) {
					max = previewNoise[index];
				}
				if(previewNoise[index] < min) {
					min = previewNoise[index];
				}
				index++;
			}
		}
		
		scale = 255 / (max - min); 
		for(int i = 0; i < 64*64; i++) {
			preview.getRaster().getDataBuffer().setElem(i, (int)((previewNoise[i]  - min) * scale));			
		}
	
	}
	
	@Override
	public void restoreSettings()
	{
		properties.restoreSettimgs();
	}
	@Override
	public void storeSettings()
	{
		try {
		properties.storeSettings();
		} catch(AutoPropertyException e)
		{
			JOptionPane.showMessageDialog(panel, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
//			e.printStackTrace();
		}
	}
	@Override
	public void save(ObjectOutputStream file) throws IOException
	{
		file.writeObject(getClass().getName());
		for(String name:properties.getPropertyNames())
		{
			try
			{
				Object val=properties.getValue(name);
				file.writeObject(name);
				file.writeObject(val);
			} catch (AutoPropertyException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		file.writeObject("END");
	}
	@Override
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException
	{
		while(true)
		{
			try
			{
				String name=(String) file.readObject();
				if(name.equals("END"))
					break;
				Object val=file.readObject();
				properties.setValue(name, val);
			} catch (AutoPropertyException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		properties.restoreSettimgs();
	}

	@Override
	public Vertex getNoiseOffset()
	{
		return new Vertex(xOffset, yOffset, zOffset);
	}

	@Override
	public Vertex getNoiseSize()
	{
		return new Vertex(width, height, depth);
	}
	
	
}
