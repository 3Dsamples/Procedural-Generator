package plugins.noiseGen;

/*
 * author datta_sid
 */
import static java.lang.Math.floor;
import properties.AutoPropertyException;
import Utilities.NoiseEngine;

public class ChessPatternEngine extends ManagedNoiseEngine
{
	
	public ChessPatternEngine()
	{
		super();
		
		try
		{
			
			properties.registerProperty("width");
			properties.registerProperty("height");
			properties.registerProperty("depth");
			
			properties.createGroup("Noise Size", true, "width", "height", "depth");
			
			panel=properties.createPanel();
		} catch (AutoPropertyException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		noiseName="Chess Pattern";
        noiseDescription="Creates a Chess pattern";
	}
	
	@Override
	public void initNoise()
	{
		super.initNoise();
	}
	
	
	@Override
	public NoiseEngine copy()
	{
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public double getNoiseForVertex(double x, double y, double z)
	{
		//fx fy fz accounted for externally
		  int xi = (int)(floor(x));
		  int yi = (int)(floor(y));
		  int zi = (int)(floor(z));
		  return (xi&1)^(yi&1)^(zi&1);
	}

	@Override
	public String getDetails()
	{
		return
		"<table ><tr><td><b><u>Range</u></b></td></tr>" + 
		"<tr><td><b>Min:</b> </td><td align=right>"+ 0 + "</td></tr>" + 
		"<tr><td><b>Max:</b> </td><td align=right> " + 1 + "</td></tr></table>" + 
		"<br>" + 
		"<table ><tr><td><b><u>Details</u></b></td></tr>" + 
		"<tr><td><b>Noise:</b> </td><td align=right>"+ noiseName + "</td></tr>" + 
		"<tr><td><b>Noise Size:</b> </td><td align=right>" + width + ", " + height + ", " +depth  + "</td></tr>" +
   		"<tr><td><b>Noise Offset:</b> </td><td align=right>" + xOffset + ", " + yOffset + ", " +zOffset  + "</td></tr>";
	}
	
//	public static void main(String[] args)
//	{
//		CellNoiseEngine c=new CellNoiseEngine();
//		System.out.println(c.name());
//	}
}
