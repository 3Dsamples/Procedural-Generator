/*
 * perlin.java
 *
 * Created on 12 July 2003, 13:54
 */

/*
Copyright (c) 2003, David Burnett
Heavily based on code copyrighted by Ken Perlin
See http://mrl.nyu.edu/~perlin/noise/

All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the following disclaimer 
in the documentation and/or other materials provided with the 
distribution. 
Neither the name of the copyright holder nor the names of its 
contributors may be used to endorse or promote products 
derived from this software without specific prior 
written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT 
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

package plugins.noise;
import Utilities.*;
/**
 *
 * @author  David
 */
public class BillowyPerlin3D extends NoiseType {

	private int PERLIN_SIZE = 256;
	private int PERLIN_MASK = 255;
	//    private int octaves = 6;

	int[] perlin;

	/** Creates a new instance of perlin */
	public BillowyPerlin3D() {
		perlin = new int[(PERLIN_SIZE * 2) + 2];
	}

	String Name() {
		return "Perlin Noise";
	}

	String Description() {
		return "Uses Standard Perlin Noise to create terrains and planets";
	}

	private double lerp(double weight, double pointA, double pointB) {
		return pointA + weight * (pointB - pointA);
	}

	private double fade(double pointOffset) {
		return pointOffset
			* pointOffset
			* pointOffset
			* (pointOffset * (pointOffset * 6 - 15) + 10);
	}

	private double grad(int hash, double x, double y, double z) {
		// use Ken Perlin hashing algorithm. This fixed set of gradients
		// is designed to reduce the grid like artifacts you can can
		// it Ken's original algorithm.

		int h = hash & 15; // CONVERT LO 4 BITS OF HASH CODE
//			double u = h < 8 || h == 12 || h == 13 ? x : y,
		double u = h < 8 ? x : y,
		// INTO 12 GRADIENT DIRECTIONS.
	v = h < 4 || h == 12 || h == 13 ? y : z;
		return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
	}

	public void InitNoise(long seed) {
		int i, j, tmp;

		java.util.Random rand = new java.util.Random(seed);

		// Ken Perlin's reference code uses a fixed set of permutations
		// which makes it a little boring, so I'm sticking with
		// the orginal monte carlo randomised permutation table. 

		//init the perlin permutation table
		for (i = 0; i < PERLIN_SIZE; i++) {
			perlin[i] = i;
		}

		//stir the table up
		for (i = 0; i < PERLIN_SIZE; i++) {
			tmp = perlin[i];
			j = Math.abs(rand.nextInt()) % PERLIN_SIZE;
			//            System.out.println(j);
			perlin[i] = perlin[j];
			perlin[j] = tmp;
		}

		// extend the tables so we can cheat the indexing	
		for (i = 0; i < PERLIN_SIZE; i++) {
			perlin[PERLIN_SIZE + i] = perlin[i];
		}
	}

	// A tidied up version of Ken's reference code, with Ken's comments
	public double Noise(double x, double y, double z) {
		int X = (int) Math.floor(x) & PERLIN_MASK; // FIND UNIT CUBE THAT
		int Y = (int) Math.floor(y) & PERLIN_MASK; // CONTAINS POINT.
		int Z = (int) Math.floor(z) & PERLIN_MASK;

		x -= Math.floor(x); // FIND RELATIVE X,Y,Z
		y -= Math.floor(y); // OF POINT IN CUBE.
		z -= Math.floor(z);
		
		double u = fade(x); // COMPUTE FADE CURVES
		double v = fade(y); // FOR EACH OF X,Y,Z.
		double w = fade(z);
		
		int A = perlin[X] + Y;
		int AA = perlin[A] + Z;
		int	AB = perlin[A + 1] + Z;
		// HASH COORDINATES OF
		int B = perlin[X + 1] + Y;
		int BA = perlin[B] + Z; 
		int BB = perlin[B + 1] + Z;
		// THE 8 CUBE CORNERS,

		return 2 * Math.abs(lerp(w, 
					lerp(v, 
						lerp(u, grad(perlin[AA], x, y, z), // AND ADD
							grad(perlin[BA], x - 1, y, z)), // BLENDED
						lerp(u, grad(perlin[AB], x, y - 1, z), // RESULTS
							grad(perlin[BB], x - 1, y - 1, z))), // FROM  8
					lerp(v, lerp(u, grad(perlin[AA + 1], x, y, z - 1), // CORNERS
						grad(perlin[BA + 1], x - 1, y, z - 1)), // OF CUBE
					lerp(
						u,
						grad(perlin[AB + 1], x, y - 1, z - 1),
						grad(perlin[BB + 1], x - 1, y - 1, z - 1))))) - 1;
	}

}
