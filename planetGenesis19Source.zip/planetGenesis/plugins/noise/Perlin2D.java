/*
 * perlin.java
 *
 * Created on 05 March 2002, 19:08
 */


/*
Copyright (c) 2002, David Burnett
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the following disclaimer 
in the documentation and/or other materials provided with the 
distribution. 
Neither the name of the copyright holder nor the names of its 
contributors may be used to endorse or promote products 
derived from this software without specific prior 
written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT 
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/

package plugins.noise;
import Utilities.*;
/**
 *
 * @author  David
 */
public class Perlin2D extends NoiseType {
    
    private int PERLIN_SIZE = 256;
    private int PERLIN_MASK = 255;

//    private double planetRadius = 10;
    int[] perlin;
    Vector2D gradient[];
    
    /** Creates a new instance of perlin */
    public Perlin2D() {
        perlin = new int[PERLIN_SIZE];
        gradient = new Vector2D[PERLIN_SIZE];
    }
    
    String Name() {
        return "Perlin Noise";
    }
    
    String Description() {
        return "create 2D Perlin Noise";
    }
 
    public void InitNoise(long seed){
        int i, j, tmp;
        
        java.util.Random rand = new java.util.Random(seed);
        
        
        //init the perlin permutation table
        for(i=0; i<PERLIN_SIZE; i++) {
            perlin[i] = i;
        }

        //stir the table up
        for(i=0; i<PERLIN_SIZE; i++) {
            tmp = perlin[i];
            j = Math.abs(rand.nextInt()) % PERLIN_SIZE;
//            System.out.println(j);
            perlin[i] = perlin[j];
            perlin[j] = tmp;
        }

      // the permutation table now hold the values 
      // 0 to PERLIN_SIZE -1 in pseudo random order
      // now we need to create a bunch of normalized gradients

      i = 0;
      while(i<PERLIN_SIZE) {
        gradient[i] = new Vector2D((rand.nextDouble() * 2) - 1, (2 * rand.nextDouble())-1);
        gradient[i].Normalise();
        i++;
      }
    }
    public double Noise (double x, double y, double z) {

        int grid_x1, grid_x2;
        int grid_y1, grid_y2;

        double rx1, rx2;
        double ry1, ry2;

        int g1, g2, g3, g4;
        double i1, i2, i3, i4;
        double weight_x, weight_y;
        double ix1, ix2;
        //  fprintf(stderr, "%.3f %.3f %.3f\n", x, y, z);

        // for each co-ordinate take its neigbouring grid points
        grid_x1 = (int)Math.floor(x);
        grid_x2 = grid_x1 + 1;

        grid_y1 = (int)Math.floor(z);
        grid_y2 = grid_y1 + 1;

         // calculate the coordinates offsets from the grid points
        rx1 = x - grid_x1;
        rx2 = rx1 - 1;
        ry1 = z - grid_y1;
        ry2 = ry1 - 1;

        // make sure none of these fall outside the permutation array;

        grid_x1 = grid_x1 & PERLIN_MASK;
        grid_x2 = grid_x2 & PERLIN_MASK;
        grid_y1 = grid_y1 & PERLIN_MASK;
        grid_y2 = grid_y2 & PERLIN_MASK;

        // choose a 'random' gradient for each grid point
        g1 = perlin[(grid_y1 + perlin[grid_x1]) & PERLIN_MASK];
        g2 = perlin[(grid_y1 + perlin[grid_x2]) & PERLIN_MASK];
        g3 = perlin[(grid_y2 + perlin[grid_x1]) & PERLIN_MASK];
        g4 = perlin[(grid_y2 + perlin[grid_x2]) & PERLIN_MASK];


        //calculate the 'influence' of each point of the noise which is the dot product
        i1 = gradient[g1].x*rx1 + gradient[g1].z*ry1;
        i2 = gradient[g2].x*rx2 + gradient[g2].z*ry1;
        i3 = gradient[g3].x*rx1 + gradient[g3].z*ry2;
        i4 = gradient[g4].x*rx2 + gradient[g4].z*ry2;

        // now use the easy curve to calcualte the final value

        weight_x = (3 - (2 * rx1)) * rx1 * rx1;
        weight_y = (3 - (2 * ry1)) * ry1 * ry1;

        ix1 = i1  - weight_x * (i1 - i2);
        ix2 = i3  - weight_x * (i3 - i4);

        return ix1 - weight_y * (ix1 - ix2);  
    }
   
    /* uses inherited getSlice */
}
