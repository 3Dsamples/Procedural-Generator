package plugins.noise;

/**
 * @author su_liam
 *
 */
public class BillowySimplex3D extends SimplexNoise3D
{
	public double Noise(double x, double y, double z)
	{
		return 2 * Math.abs(super.Noise(x, y, z)) - 1;
	}
}