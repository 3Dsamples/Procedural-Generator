package plugins.noise;

/**
 * @author su_liam
 *
 */
public class RidgedSimplex3D extends SimplexNoise3D
{	
	public double Noise(double x, double y, double z)
	{
		return 1 - 2 * Math.abs(super.Noise(x, y, z));
	}
}
