/*
 * planetGenesis.java
 *
 * Created on 15 March 2002, 13:40
 */

/*
Copyright (c) 2002, David Burnett
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the following disclaimer 
in the documentation and/or other materials provided with the 
distribution. 
Neither the name of the copyright holder nor the names of its 
contributors may be used to endorse or promote products 
derived from this software without specific prior 
written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT 
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.UIManager;


import GUI.ComponentPanel;
import GUI.ComponentPanelKeyListener;
import GUI.HelpBox;
import GUI.PropertiesPanel;

/**
 *
 * @author  David
 */
public final class planetGenesis {
    
    /** Creates a new instance of planetGenesis */
    public planetGenesis() {
    }
    
    public static void main(String[] args) {
	
	    	UIManager.put("ProgressBar.repaintInterval", new Integer(1000)); 
	    	System.setProperty("apple.laf.useScreenMenuBar","true");
	    	
	    	if (args.length > 0) {
	    		if(args[0].compareTo("--batch") == 0) {
	    			batchRun(args[1]);
	    			System.exit(0);
	    		}
	    	}
	    	
		try {
			JFrame pG = new JFrame();
			
		    JMenuBar menuBar = new JMenuBar();

		    // Create a menu
		    JMenu menu = new JMenu("Help");
		    menuBar.add(menu);
		    
		    // Create a menu item
		    JMenuItem item = new JMenuItem("Quick Help");
		    item.addActionListener(new ActionListener() {
		        public void actionPerformed(ActionEvent e)
		        {
		           new HelpBox().setVisible(true);
		        }
		     });
		    menu.add(item);			
   
		    
		    pG.setJMenuBar(menuBar);

			
			JScrollPane scrollPane = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
	
			pG.setTitle("planetGenesis");
			pG.addWindowListener(new java.awt.event.WindowAdapter() {
				public void windowClosing(java.awt.event.WindowEvent evt) {
					System.exit(0);
				}
			});

			JSplitPane split=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
			split.setOneTouchExpandable(true);
//			split.setResizeWeight(1);
//			split.setDividerLocation(.8);
			
			PropertiesPanel props=new PropertiesPanel();
			ComponentPanel compPanel=new ComponentPanel(pG, props);
			compPanel.setFocusable(true);
			scrollPane.setViewportView(compPanel);
			
			props.addKeyListener(new ComponentPanelKeyListener(compPanel));
			
			Dimension minimumSize = new Dimension(100, 50);
			scrollPane.setMinimumSize(minimumSize);
			
			split.setLeftComponent(scrollPane);
			split.setRightComponent(props);
			
			pG.getContentPane().add(split);
			pG.pack();
			
			Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();       
			Dimension frameSize = new Dimension((int)(screenSize.width * 0.75), (int)(screenSize.height * 0.75));
			pG.setSize(frameSize);
	
			
			pG.setLocation(screenSize.width/2 - (frameSize.width/2),
								screenSize.height/2 - (frameSize.height/2));
			
			pG.setExtendedState(Frame.MAXIMIZED_BOTH);
			pG.setVisible(true);
        } catch (Exception e) {e.printStackTrace(); return;};
    }

    private static void batchRun(String file) {
    		ComponentPanel pG = new ComponentPanel(null, null);
    		pG.load(file);
    		pG.batchRun();
    			
    }

 
}
