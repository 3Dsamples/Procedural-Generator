/*
 * Created on Sep 13, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.Point;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import plugins.engines.ApplyFunction;
import plugins.functions.FunctionEngine;
import Utilities.NoiseEngine;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class FunctionComponent extends NoiseComponent {

	final private Ellipse2D.Double ellipse = new Ellipse2D.Double(4,4,58,58);
	final private Ellipse2D.Double shadowEllipse = new Ellipse2D.Double(7,7,61,61);
	final private Ellipse2D.Double inputSlot = new Ellipse2D.Double(29,4,8,8);
	final private Ellipse2D.Double outputSlot = new Ellipse2D.Double(29,54,8,8);
	
	private FunctionEngine function = (FunctionEngine) new ApplyFunction();
	private NoiseComponent inputComponent;
	final private NoisePanel panel = new NoisePanel();
	
	public FunctionComponent(JFrame owner, ComponentPanel componentPanel){
		super(owner, componentPanel);
		noiseEngine = (NoiseEngine) function;
	}
	
	public JoinComponent connectToComponent(NoiseComponent noise, Point noiseEnd, Point thisEnd) {
		// Connects components together. Only called when the connection drag ends on the component
		// This function has to be overriden!
		// Function components have both input and output slots
		if(noise == this || noise == null) {
			return null;
		}
		if(thisEnd.y < getLocation().y + 32) {
			if(noise instanceof PostProcessComponent) {
				return null;
			}
			// If the dragEnd is in the top half attempt to connect to the noises output slot			
			noise.connectToOutput(this, noiseEnd, thisEnd);	
			return new JoinComponent(this, noise);
		} else {
			// If the dragEnd is in the bottom half attempt to connect to the noises input slot
			releaseComponent(noise);
			noise.connectToInput(this, noiseEnd, thisEnd);
			if(componentConnectedToOutput.contains(noise) == false) {
				componentConnectedToOutput.add(noise);
			}	
			return new JoinComponent(noise, this);
		}

	}

	public boolean connectToInput(NoiseComponent component, Point thisEnd, Point noiseEnd) {
		// connects components together.
		// Functions have an input connection, keep NoiseEngine reference
		if(component instanceof PostProcessComponent) {
			/* 
			 * PostProcessComponents can only be the input for other PostProcessComponent
			 * and TerrainComponents;
			 */
			return false;
		}
		releaseComponent(component);  // avoid loops
		if(inputComponent != null) {
			inputComponent.releaseComponent(this);
		}
		inputComponent = component;	
		function.setNoiseEngine(inputComponent.getNoiseEngine());
		refreshDownStreamPreview();
		return true;
	}

	public void releaseComponent(NoiseComponent component) {
		// releases compoent if joined to a slot
		if(component == inputComponent) {
			inputComponent = null;
			function.setNoiseEngine(null);
		}
		componentConnectedToOutput.remove(component);
		
		return;
	}

	public boolean connectToOutput(NoiseComponent component, Point thisEnd, Point noiseEnd) {
		// connects components together.
		// Functions have an output connection, connect it to the components input
		if(component.connectToInput(this, noiseEnd, thisEnd)) {
			releaseComponent(component);
			if(componentConnectedToOutput.contains(component) == false) {
				componentConnectedToOutput.add(component);
			}
			return true;
		} 
		return false;
		
	}
	
	public Point getConnectionPoint(NoiseComponent noise) {
		if(noise == inputComponent) {
			return new Point(getLocation().x + 33, getLocation().y+4);
		}
		
		return new Point(getLocation().x + 33, getLocation().y+58);			
		
		
		
	}

	public void paintComponent(Graphics g) {
		// paints input and output slots
		Graphics2D g2 = (Graphics2D)g;
		
		AffineTransform saveAT = g2.getTransform();
		g2.translate(location.x, location.y);

		Shape clip =  g2.getClip();

		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setStroke(stroke);
		if(selected) {
			g2.setColor(shadowColor);
			g2.fill(shadowEllipse);
		}
		
		g2.setColor(Color.WHITE);
		g2.fill(ellipse);
			
		if(selected) {
			g2.setColor(Color.red);
		} else {
			g2.setColor(Color.black);			
		}
		
		g2.draw(ellipse);
		g2.clip(ellipse);
		g2.setPaint(Color.blue);
		function.paintIcon(g2, this);
		g2.setClip(clip);
		g2.setPaint(Color.white);
		g2.fill(inputSlot);
		g2.setPaint(Color.red);
		g2.fill(outputSlot);
		g2.setPaint(Color.black);
		g2.draw(inputSlot);
		g2.draw(outputSlot);
		
		g2.setTransform(saveAT);
	
	}
	
	public NoiseComponent[] getConnectedComponents() {
		/** returns the component providing input to the Function */
		if(inputComponent != null) {			
			NoiseComponent[] tmp = new NoiseComponent[1]; 
			tmp[0] = inputComponent; 
			return tmp;
		}
		
		return null;
			
	}
	
	public NoiseEngine getNoiseEngine() {
	/*	if(inputComponent != null) {
			function.setNoiseEngine(inputComponent.getNoiseEngine());
		}*/
		return (NoiseEngine) function;
	}
	
	public void releaseFromAll() {

		super.releaseFromAll();
		
		if(inputComponent != null) {
			inputComponent.releaseComponent(this);
		}
	}
	
	public void setFunction(FunctionMenuItem item) {
		function = (FunctionEngine) item.getNoiseEngine();
		name = item.getText();
		function.setFunction(name);
		noiseEngine=(NoiseEngine) function;
		return;
	}
	
	public JPopupMenu getPopUp(ActionListener actionListner, ComponentPanel componentPanel) {
		JPopupMenu menu = new JPopupMenu();
		JMenuItem menuItem = new JMenuItem("Properties...");
		JPanel tmpPanel = function.getPanel();
		 
		if(tmpPanel != null) {
			menuItem.addActionListener(actionListner);
		} else {
			menuItem.setEnabled(false);
		}
		menu.add(menuItem);
		FunctionMenu noiseMenu = new FunctionMenu(new FunctionMenuActionPerformed(), "Replace Function");
		menu.add(noiseMenu);
		
		menuItem = new JMenuItem("Delete");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		if(componentConnectedToOutput.isEmpty()) {
			menuItem = new JMenuItem("Detach");
			menuItem.setEnabled(false);
			menu.add(menuItem);
		} else {
			JMenu outputComponentMenu = new OutputComponentMenu(componentPanel);
			menu.add(outputComponentMenu);
		}
		menuItem = new JMenuItem("Preview");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		return menu;
		
	}

	private class FunctionMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			FunctionMenuItem item = (FunctionMenuItem)arg0.getSource();
			function = (FunctionEngine) item.getNoiseEngine();
			setFunction(item);
			if(inputComponent != null) {
				function.setNoiseEngine(inputComponent.getNoiseEngine());
			}
			componentPanel.propsPane.displayFor(FunctionComponent.this);
			refreshUpStreamPreview();
			refreshDownStreamPreview();
		}
	}
	
	public void save(ObjectOutputStream file) throws IOException {

		file.writeObject(this.getClass().getName());
		file.writeObject(this.getLocation());		
		function.save(file);	

	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		Point position = (Point)file.readObject();
		this.setLocation(position);
		String functionClassName = (String)file.readObject();
		try {
			Class functionClass = Class.forName(functionClassName);
			function = (FunctionEngine) functionClass.newInstance();               
		} catch (InstantiationException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();					
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		function.load(file);
		name = function.name();
//		function.makePreview();

	}	

	public void saveJoins(ObjectOutputStream file, ArrayList components ) throws IOException {

		
		file.writeObject("componentsConnectedToOutput");
		file.writeObject("" + componentConnectedToOutput.size() );
		for(int i = 0; i < componentConnectedToOutput.size(); i++) {
			file.writeObject(""+components.indexOf(componentConnectedToOutput.get(i)));
		}				
		file.writeObject(""+components.indexOf(inputComponent));
	}
	
	public NoiseComponent loadJoins(ObjectInputStream file, ArrayList<NoiseComponent> components, ArrayList<JoinComponent> joins) throws ClassNotFoundException, IOException {

		NoiseComponent connectedToTerrain = null;
		NoiseComponent component;
		
		String index = (String)file.readObject();
		if(index.compareTo("componentsConnectedToOutput") != 0) {
			int i = Integer.parseInt(index);
			if(i > -1) {
				component = components.get(i);
				componentConnectedToOutput.add(component);
				
	   			if(null == NoiseComponent.findJoin(joins, this, component) ) {
	   				joins.add(new JoinComponent(this, component));
	   			}
				if(i == 0) {
					connectedToTerrain = this;
				}				
			}
		} else {
			int j;
			index = (String)file.readObject();
			int count = Integer.parseInt(index);
			for(int i = 0; i < count; i++ ) {
				index = (String)file.readObject();
				j = Integer.parseInt(index);
				if(j > -1) {
					component = components.get(j);
					componentConnectedToOutput.add(component);
					
		   			if(null == NoiseComponent.findJoin(joins, this, component) ) {
		   				joins.add(new JoinComponent(this, component));
		   			}

					if(j == 0) {
						connectedToTerrain = this;
					}					}				
			}
		}
				
		index = (String)file.readObject();
		int i = Integer.parseInt(index);
		if(i > -1) {
			inputComponent = (NoiseComponent)components.get(i);
			function.setNoiseEngine(inputComponent.getNoiseEngine());	
		}

		return connectedToTerrain;
			
		
	}	

	private class OkayListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			function.storeSettings();
			refreshDownStreamPreview();
			frame.setVisible(false);
			owner.repaint();		
		}
	}

	private class ApplyListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			function.storeSettings();
			refreshDownStreamPreview();
			owner.repaint();		

		}
	}

	private class CancelListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			function.restoreSettings(); 
		}
	}

	public void showPanel() {
    	
		frame.setTitle(function.name());
		JPanel functionPanel = function.getPanel();
		if(functionPanel != null) {
			panel.addEnginePanel(functionPanel);
		} else {
			
			panel.removeAll();

			JPanel tmp = new javax.swing.JPanel();
			tmp.setBorder(new javax.swing.border.TitledBorder(null, "Properties", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 11), new java.awt.Color(255, 0, 0)));
			tmp.setForeground(new java.awt.Color(0, 0, 0));
			tmp.add(new JLabel("This function has no user defined properties."));
			panel.add(tmp);
		}

		OkApplyRestorePanel oacPanel = panel.getOacPanel();
		oacPanel.addOkayActionListener(new OkayListener());
		oacPanel.addApplyActionListener(new ApplyListener());
		oacPanel.addCancelActionListener(new CancelListener());

		frame.getContentPane().add(panel);
		frame.pack();
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		java.awt.Dimension frameSize = frame.getPreferredSize();
		frame.setSize(frame.getPreferredSize());
		frame.setLocation(screenSize.width/2 - (frameSize.width/2),
						screenSize.height/2 - (frameSize.height/2));
		frame.setVisible(true);
	}

	public void refreshUpStreamPreview() {
		
		
		if(inputComponent != null) {
			inputComponent.refreshUpStreamPreview();
			noiseEngine = inputComponent.getNoiseEngine();
		}
		
		if(function != null) {
			function.makePreview();
		}
		
		owner.repaint();		
		
	}

	public void refreshDownStreamPreview() {
		if(noiseEngine != null) {
			if(inputComponent != null) {
				function.setNoiseEngine(inputComponent.getNoiseEngine());	
			}
			function.makePreview();
//			if(getTopLevelAncestor() != null) {
//			getTopLevelAncestor().repaint();		
//			}
			
			owner.repaint();
		}
		
		NoiseComponent tmp;
		
		for(int i = 0; i < componentConnectedToOutput.size(); i++) {
			tmp = (NoiseComponent)componentConnectedToOutput.get(i);
			tmp.refreshDownStreamPreview();	
//			tmp.repaint();
		}
		
		owner.repaint();
		
	}	

	public String getToolTipText() {
		return "<b><u>" + function.name() + "</u></b><br><br>" + function.description() + "<br><br>" + function.getDetails();
	}
	
	public boolean acceptComponentAsInput(NoiseComponent component) {
		/* we can accept any type of input except our own output */
		if (this == component) {
			return false;
		}
		
		return true;
	}	
	
	public boolean acceptComponentForOutput(NoiseComponent component) {
		/* we can accept output any type of component except the same instance */
		if (component == this) {
			return false;
		}
		
		return true;
	}

	public NoiseComponent getInputComponentForPoint(Point basisPoint) {
		if(getBounds().contains(basisPoint)) {
			return inputComponent;
		}
		
		return null;
	}

	public int getComponentTypeForPoint(Point basisPoint) {		

		if(getBounds().contains(basisPoint)) {
			if(basisPoint.y < getLocation().y + 32) {	
				return POINT_SELECTS_INPUT_COMPONENT;
			} else {
				return POINT_SELECTS_OUTPUT_COMPONENT;
			}
		}	
	
		return POINT_OUT_OF_BOUNDS;
	
	}
	
}
