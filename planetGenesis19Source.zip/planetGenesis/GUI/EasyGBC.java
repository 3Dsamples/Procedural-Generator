package GUI;

import java.awt.GridBagConstraints;

/**
 * Easy GridBagConstaints
 */
public class EasyGBC extends GridBagConstraints
{

	public EasyGBC xy(int x, int y)
	{
		gridx=x;
		gridy=y;
		return this;
	}
	
	public EasyGBC nextRow()
	{
		gridy++;
		return this;
	}
	
	public EasyGBC nextCol()
	{
		gridx++;
		return this;
	}
	
	public EasyGBC wh(int w, int h)
	{
		gridwidth=w;
		gridheight=h;
		return this;
	}
	
	public EasyGBC xywh(int x, int y, int w, int h)
	{
		gridx=x;
		gridy=y;
		
		gridwidth=w;
		gridheight=h;
		
		return this;
	}
	
	public EasyGBC weight(double wt)
	{
		weightx=weighty=wt;
		return this;
	}
	
	public EasyGBC weight(double wx, int wy)
	{
		weightx=wx;
		weighty=wy;
		return this;
	}
	
	public EasyGBC insets(int top, int left, int bottom, int right)
	{
		insets.top=top;
		insets.left=left;
		insets.bottom=bottom;
		insets.right=right;
		return this;
	}
	
	public EasyGBC center()
	{
		anchor=CENTER;
		return this;
	}
	public EasyGBC left()
	{
		anchor=WEST;
		return this;
	}
	public EasyGBC right()
	{
		anchor=EAST;
		return this;
	}
	public EasyGBC anchor(int anchor)
	{
		this.anchor=anchor;
		return this;
	}
	public EasyGBC fillH()
	{
		this.fill=HORIZONTAL;
		return this;
	}
	public EasyGBC fillV()
	{
		this.fill=VERTICAL;
		return this;
	}
	public EasyGBC fillBoth()
	{
		this.fill=BOTH;
		return this;
	}
	public EasyGBC clone()
	{
		return (EasyGBC)super.clone();
	}
	
}
