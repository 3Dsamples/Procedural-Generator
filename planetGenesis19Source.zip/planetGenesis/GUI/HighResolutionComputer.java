package GUI;

import Utilities.NoiseEngine;
import Utilities.Preview3d;

/**
 * Should be only 1 instance of this class running 
 * @author sdatta
 *
 */
public class HighResolutionComputer extends Thread
{

	NoiseEngine theNoiseEngine;
	
	Preview3d preview;
	
	double[] hrNoise1; int side1;
	double[] hrNoise2; int sz2;
	
	public HighResolutionComputer(Preview3d preview)
	{
		this.preview=preview;
		theNoiseEngine=null;
		setDaemon(true);//exits when main exits
	}
	
	public void runForNoiseEngine(NoiseEngine ne)
	{
			theNoiseEngine=ne;
			System.out.println("Setting noiseengine "+ne);
			interrupt();
	}
	
	public void run()
	{
		while(theNoiseEngine==null)
		{
			try
			{
				Thread.sleep(1000);
			} catch (InterruptedException e)
			{
			}
		}
		while (true)
		{
			try
			{
				System.out.println("Running with "+theNoiseEngine);
				preview.setStatus("Computing for "+theNoiseEngine.name());
				double[] noise=theNoiseEngine.getPreviewNoise();
				int sz=noise.length; int side=pow2sqrt(sz);
				
				double xGap=0, zGap=0, x=0, z=0;
				int idx;
				
				side1=side<<1;
				hrNoise1=new double[side1*side1];
				
				long start = System.currentTimeMillis();
				xGap=zGap=1.0/(side1-1);
				x=z=0;
				idx=0;
				for(int i=0; i<side1; i++)
				{
					z=0;
					for(int j=0; j<side1; j++)
					{
//						System.out.println(i+" "+j);
//						if((i&1)==0 && (j&1)==0)
//						{
//							hrNoise1[idx]=noise[(i>>1)*side+(j>>1)];
//						}
//						else
							hrNoise1[idx]=theNoiseEngine.getScaledMovedNoiseForVertex(x, 0, z);
//						hrNoise1[idx]=theNoiseEngine.getNoiseForVertex(new Vertex(x, 0, z));
						z+=zGap;
						idx++;
					}
					x+=xGap;
				}
				long end=System.currentTimeMillis();
				
				preview.setStatus("Rez "+side1+"x"+side1+" done :"+(end-start)+" ms");
				preview.setHRNoise(1, hrNoise1);
				
				while (true)
				{
					Thread.sleep(100);
				}
			} catch (InterruptedException e)
			{
//				System.out.println("Interrupted !!!!!!!!!!!!!!!!!!!!!!!!!");
				continue;
			}
		}
	}

	/**
	 * Square root of power of 2 integers
	 * @param sz
	 * @return
	 */
	public int pow2sqrt(int i)
	{	
		return 1<<(Integer.numberOfTrailingZeros(i)>>1);
	}

	public NoiseEngine getTheNoiseEngine()
	{
		return theNoiseEngine;
	}

	protected void setTheNoiseEngine(NoiseEngine theNoiseEngine)
	{
		this.theNoiseEngine = theNoiseEngine;
	}
	
	public static void main(String[] args)
	{
		HighResolutionComputer hg=new HighResolutionComputer(null);
		long start=System.currentTimeMillis();
		System.out.println(hg.pow2sqrt(16));
		long end=System.currentTimeMillis();
		System.out.println(end-start);
		
		start=System.currentTimeMillis();
		System.out.println(Math.sqrt(16));
		end=System.currentTimeMillis();
		System.out.println(end-start);
	}
}
