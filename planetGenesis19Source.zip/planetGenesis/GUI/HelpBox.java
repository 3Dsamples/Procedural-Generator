package GUI;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

//
//	File:	AboutBox.java
//



public class HelpBox extends JFrame
                      implements ActionListener
{
    protected JButton okButton;
    protected JLabel aboutText;

    public HelpBox() {
        super();
        this.getContentPane().setLayout(new BorderLayout(15, 15));
        this.setFont(new Font ("SansSerif", Font.BOLD, 14));

        aboutText = new JLabel ();
        
        aboutText.setText("<html><h1>planetGenesis 1.7</h1><br><b>Copyright David Burnett 2002 - 2004</b><br><br>"
        		+ "planetGenesis is context menu driven.<br>Right Clicking on empty space gives you a menu"
				+ " that allows you to add new icons<br>for noise, functions and combiners<br><br>"
				+ "Left click and drag to move the icons around.<br>Right click to change properties.<br><br>Press shift and the left mouse button"
				+ " to join the icons together.<br>Make sure one is connected to the terrain icon,"
				+ " the blank icon you start off with.<br></html>");
 
//        aboutText.setText("<html>planetGenesis<b>Copyright David Burnett 2002 - 2004</b></html>");
        
        
        JPanel textPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        textPanel.add(aboutText);
        this.getContentPane().add (textPanel, BorderLayout.NORTH);
		
        okButton = new JButton("OK");
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        buttonPanel.add (okButton);
        okButton.addActionListener(this);
        this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        this.pack();
    }
	
    public void actionPerformed(ActionEvent newEvent) {
        setVisible(false);
    }	
	
}