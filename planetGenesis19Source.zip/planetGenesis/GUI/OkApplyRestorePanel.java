/*
 * Created on Aug 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;


import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class OkApplyRestorePanel extends JPanel {

	private JButton okay;
	private JButton apply;
	private JButton restore;
	


	public OkApplyRestorePanel() {

			initComponents();
			java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
			java.awt.Dimension frameSize = getPreferredSize();
			setLocation(screenSize.width/2 - (frameSize.width/2),
								screenSize.height/2 - (frameSize.height/2));

        
		}
    

	private void initComponents() {
	

		okay = new JButton("Okay");
		apply = new JButton("Apply");
		restore = new JButton("Restore");

		setLayout(new BoxLayout(this, javax.swing.BoxLayout.X_AXIS));

		add(okay);
		add(apply);
		add(restore);

	
	}

	public void addOkayActionListener(ActionListener action) {
		okay.addActionListener(action);
	}

	public void addApplyActionListener(ActionListener action) {
		apply.addActionListener(action);
	}

	public void addCancelActionListener(ActionListener action) {
		restore.addActionListener(action);
	}


}
