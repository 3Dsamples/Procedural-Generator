/*
 * Created on Aug 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class NoiseMenu extends JMenu {

	public NoiseMenu(ActionListener actionListener, String menuText) {

		JMenuItem  item;
		JMenu newMenu;
		
		setText(menuText);


		newMenu = new JMenu("Perlin");
		item = new JMenuItem("plugins.engines.MultiFractal");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.Perlin");
		item.addActionListener(actionListener);
		newMenu.add(item);
		//Added by su_liam 12-10-2007
		item = new JMenuItem("plugins.engines.ModifiedMultiFractal");
		item.addActionListener(actionListener);
		newMenu.add(item);
		//
		item = new JMenuItem("plugins.engines.PerlinWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.SummedPerlinWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		add(newMenu);

		
		newMenu = new JMenu("Worley");
		item = new JMenuItem("plugins.engines.BiasedWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.CacheWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.FastWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.CellBasis");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.PerlinWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.SolidWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.SummedPerlinWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.SummedWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.TileWorley");
		item.addActionListener(actionListener);
		newMenu.add(item);
		add(newMenu);

		
		newMenu = new JMenu("Fault Noise");
		item = new JMenuItem("plugins.engines.Fault");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.SmoothFault");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.SplineFault");
		item.addActionListener(actionListener);
		newMenu.add(item);
		add(newMenu);		

		
		newMenu = new JMenu("Terrain Features");		
		item = new JMenuItem("plugins.engines.Craters");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.LinearSandDunes");
		item.addActionListener(actionListener);
		newMenu.add(item);
		add(newMenu);
		
		
		newMenu = new JMenu("Gradients");
		item = new JMenuItem("plugins.engines.ConstantValue");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.Gradient");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.SphericalGradient");
		item.addActionListener(actionListener);
		newMenu.add(item);
		//
		item = new JMenuItem("plugins.engines.PositionX");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.PositionY");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.engines.PositionZ");
		item.addActionListener(actionListener);
		newMenu.add(item);
		//
		add(newMenu);

		
		newMenu = new JMenu("Random");		
		item = new JMenuItem("plugins.engines.RandomSplinePatch");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.noiseGen.CellNoiseEngine");
		item.addActionListener(actionListener);
		newMenu.add(item);
		add(newMenu);
		
		newMenu = new JMenu("Pattern");		
		item = new JMenuItem("plugins.noiseGen.ChessPatternEngine");
		item.addActionListener(actionListener);
		newMenu.add(item);
		item = new JMenuItem("plugins.noiseGen.BrickPatternEngine");
		item.addActionListener(actionListener);
		newMenu.add(item);
		add(newMenu);
		
	}




}
