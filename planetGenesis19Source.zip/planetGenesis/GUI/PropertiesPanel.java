package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import Utilities.NoiseEngine;

public class PropertiesPanel extends Box
{
	protected JPanel properties=null;

	protected NoiseEngine engine;
	protected NoiseComponent noiseComp;
	
	public static JPanel noProperties=new JPanel();

	protected JScrollPane sp;

	private JButton applyButton;

	private JButton restoreButton;
	
	static{
		noProperties.setLayout(new BoxLayout(noProperties, BoxLayout.Y_AXIS));
		noProperties.add(new JLabel("No Properties"));
		noProperties.add(new JLabel("are defined for"));
		noProperties.add(new JLabel("this object."));
	}
	
	public PropertiesPanel()
	{
		super(BoxLayout.Y_AXIS);
//		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		sp = new JScrollPane();
//		JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
//						JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JPanel buttonsPanel=new JPanel();
		applyButton = new JButton("Apply");
		buttonsPanel.add(applyButton);
		restoreButton = new JButton("Restore");
		buttonsPanel.add(restoreButton);
		
		applyButton.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e)
			{
				if(engine!=null)
				{
					engine.storeSettings();
					noiseComp.refreshDownStreamPreview();
				}
			}
		});
		
		restoreButton.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e)
			{
				if(engine!=null)
				{
					engine.restoreSettings();
				}
			}
		});

		add(sp);
		add(buttonsPanel);
		add(Box.createVerticalGlue());
	}
	
	public void displayFor(NoiseComponent nc)
	{
		System.out.println("display for "+((Object)nc));
		this.noiseComp=nc;
		
		if(nc == null) {
			sp.setViewportView(noProperties);
			applyButton.setEnabled(false);
			restoreButton.setEnabled(false);
			invalidate();
			validate();
			return;
		}
		if(nc instanceof TerrainComponent)
		{
			sp.setViewportView(((TerrainComponent)nc).getPanel());
			applyButton.setEnabled(false);
			restoreButton.setEnabled(false);
			validate();
		}
		else
		{
			this.engine=nc.getNoiseEngine();
			JPanel p=engine.getPanel();
			if(p==null)
				sp.setViewportView(noProperties);
			else
				sp.setViewportView(p);
			
			applyButton.setEnabled(true);
			restoreButton.setEnabled(true);
			invalidate();
			validate();
		}
	}
}
