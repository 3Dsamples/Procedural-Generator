/*
 * Created on Aug 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import javax.swing.BoxLayout;
import javax.swing.JPanel;


/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class NoisePanel extends JPanel {

	private final OkApplyRestorePanel oAC = new OkApplyRestorePanel();

	public NoisePanel() {
		setLayout(
			new BoxLayout(this, BoxLayout.Y_AXIS));
	}
	
	public void addEnginePanel(JPanel panel) {
		removeAll();
		add(panel);
		add(oAC);
	}

	/**
	 * @return
	 */
	public OkApplyRestorePanel getOacPanel() {
		return oAC;
	}



}
