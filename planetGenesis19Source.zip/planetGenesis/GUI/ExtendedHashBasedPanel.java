/*
 * Created on Apr 19, 2004
 *
 */
/*
Copyright (c) 2004, David Burnett
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products
derived from this software without specific prior
written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
         SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
         OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/


package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.swing.ButtonGroup;
import javax.swing.InputVerifier;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 * @author burnetd
 *
 * A Extesion of HashBasedPanel that allows more than TextBoxes 
 * 
 */

public class ExtendedHashBasedPanel extends HashBasedPanel {

	
	public ExtendedHashBasedPanel() {
		hash = new Hashtable<String, Object>();
		store = new Hashtable<String, Object>();

		setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));
		setBorder(new javax.swing.border.TitledBorder(null, "", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 3, 11), new java.awt.Color(255, 0, 0)));
	} 
	
	private JPanel addPanel(String name, String tooltip) {
		JPanel panel = new javax.swing.JPanel();
		panel.setBorder(new javax.swing.border.TitledBorder(null, name, javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 11), new java.awt.Color(255, 0, 0)));
		panel.setForeground(new java.awt.Color(0, 0, 0));
		panel.setToolTipText(tooltip);
		return panel;
	
	}
	
	public void addTextBox(String key, String name, String value, String tooltip) {

		JPanel panel = addPanel(name, tooltip);
		javax.swing.JTextField textField; 
		
		textField = new JTextField();
		textField.setHorizontalAlignment(JTextField.RIGHT);
		textField.setText(value);
		textField.setMinimumSize(new java.awt.Dimension(100, 20));
		textField.setPreferredSize(new java.awt.Dimension(100, 20));
		hash.put(key, textField);
		store.put(key, value);
		panel.add(textField);
		
		add(panel);
		
	}

	public void addTextBoxGroup(String groupLabel, String groupTooltip, String[] key, String[] name, String[] value, String[] tooltip) {

		JPanel groupPanel = addPanel(groupLabel, groupTooltip);
		groupPanel.setLayout(new javax.swing.BoxLayout(groupPanel, javax.swing.BoxLayout.Y_AXIS));
		
		
		for(int i=0; i<key.length; i++) {
			JPanel panel = new JPanel();
			JTextField textField; 
			JLabel label = new JLabel() ;
			
			label.setText(name[i]);
			textField = new JTextField();
			textField.setHorizontalAlignment(JTextField.RIGHT);
			textField.setText(value[i]);
			textField.setMinimumSize(new java.awt.Dimension(100, 20));
			textField.setPreferredSize(new java.awt.Dimension(100, 20));
			hash.put(key[i], textField);
			store.put(key[i], value);
			panel.add(label);
			panel.add(textField);
			groupPanel.add(panel);
		}
		
		add(groupPanel);
		
	}
	public void addDropDown(String key, String name, Object[] values, String tooltip) {

		JPanel panel = addPanel(name, tooltip);
		JComboBox component = new JComboBox();
		
		for(int i = 0 ; i < values.length; i++) {
			component.setAlignmentX(JComboBox.CENTER_ALIGNMENT);
			component.addItem(values[i]);
			component.setMinimumSize(new java.awt.Dimension(100, 30));
			component.setPreferredSize(new java.awt.Dimension(200, 30));
		}

		hash.put(key, component);
		store.put(key, values[0]);
		panel.add(component);
		
		
		add(panel);
	}

	public void addCheckBox(String key, String name, boolean value, String tooltip) {

		JPanel panel = addPanel(name, tooltip);
		JCheckBox component = new JCheckBox(); 
		
		component.setHorizontalAlignment(JCheckBox.CENTER);
		component.setText(name);
		component.setSelected(value);
		component.setMinimumSize(new java.awt.Dimension(100, 30));
		component.setPreferredSize(new java.awt.Dimension(200, 30));
		hash.put(key, component);
		store.put(key, Boolean.toString(value));
		panel.add(component);
		
		add(panel);
		
	}

	public void addRandomSeed(String key, String name, long seed) {

		SeedPanel panel = new SeedPanel();
		panel.setName(name);
		panel.setToolTipText("Seed value for random number generator.");
		panel.setText(""+seed);
		
		hash.put(key, panel);
		store.put(key, Long.toString(seed));
		
		add(panel);
		
	}

	public void addRadioButtonGroup(String key, String name, String[] buttons, String values[], String defaultValue, String tooltip) {

		JPanel panel = addPanel(name, tooltip);
		ButtonGroup bg = new ButtonGroup();

		
		for(int i=0; i < buttons.length; i++) {
		    JRadioButton component = new JRadioButton(); 
			component.setHorizontalAlignment(JRadioButton.CENTER);
			component.setName(values[i]);
			component.setText(buttons[i]);
			if(values[i].compareTo(defaultValue) == 0 ) {
				component.setSelected(true);			    
			}
			component.setMinimumSize(new java.awt.Dimension(100, 30));
			component.setPreferredSize(new java.awt.Dimension(100, 30));
			bg.add(component);
			panel.add(component);
			
		}
		hash.put(key, bg);
		store.put(key, defaultValue);
		
		add(panel);
		
	}
	
	
	public void addInputVerifier(String key, InputVerifier verifier) {
		
		JComponent temp = (JComponent)hash.get(key);

		if(temp instanceof JTextField) {
			((JTextField)temp).setInputVerifier(verifier); 
		}
		return;
	}

	public void addOkayApplyRestorePanel() {
		oac = new OkApplyRestorePanel();
		oac.addOkayActionListener(new OkayListener());
		oac.addApplyActionListener(new ApplyListener());
		oac.addCancelActionListener(new RestoreListener());
		add(oac);

	}
	
	public boolean validKey(String key)
	{
		return hash.containsKey(key);
	}
	
	public double getDouble(String key) {
		JTextField temp = (JTextField)hash.get(key);
		return Double.parseDouble(temp.getText()); 
	}

	public String getText(String key) {
		Object temp = hash.get(key);
		return getTextForObject(temp); 
	}

	public int getInt(String key) {
		Object temp = hash.get(key);
		if(temp instanceof JTextField) {
			return (int)Double.parseDouble(((JTextField)temp).getText()); 
		} else if(temp instanceof SeedPanel) {
			return (int)Double.parseDouble(((SeedPanel)temp).getText());
		} else if(temp instanceof ButtonGroup) {
			for (Enumeration e = ((ButtonGroup)temp).getElements() ; e.hasMoreElements() ;) {
			    JRadioButton jrb = (JRadioButton)e.nextElement(); 
				if(jrb.isSelected()) {
				    return (int)Double.parseDouble(jrb.getName());
				}
			}	
		    return 0;
		}else {
			return 0;
		}
	}

	public boolean getCheckBoxState(String key) {
		JCheckBox temp = (JCheckBox)hash.get(key);
		return temp.isSelected();	
	}
	
	public void setValue(String key, String value) {
		Object temp = hash.get(key);
		if(temp instanceof JTextField) {
			((JTextField )temp).setText(value);
		} else if(temp instanceof JComboBox) {
			((JComboBox )temp).setSelectedItem(value);
		} else if(temp instanceof JCheckBox) {
			if(value.compareTo("true") == 0) {
				((JCheckBox )temp).setSelected(true);		
			} else {
				((JCheckBox )temp).setSelected(false);					
			}
			
		}  else if(temp instanceof SeedPanel) {
			((SeedPanel)temp).setText(value);
		} else if(temp instanceof ButtonGroup) {
			for (Enumeration e = ((ButtonGroup)temp).getElements() ; e.hasMoreElements() ;) {
			    JRadioButton jrb = (JRadioButton)e.nextElement(); 
				if(value.compareTo(jrb.getName()) == 0) {
				    jrb.setSelected(true);
				}
			}			
		}
		return;
	}
	
	public static void main(String[] args) {
		
		String[] keys = new String[3];
		String[] name = new String[3];
		String[] defaults = new String[3];
		
		keys[0] = "f";
		keys[1] = "int";
		keys[2] = "text";

		name[0] = "Float";
		name[1] = "Integer";
		name[2] = "Text";

		defaults[0] = "3.147";
		defaults[1] = "4";
		defaults[2] = "Hello World";
		
		ExtendedHashBasedPanel panel = new ExtendedHashBasedPanel();
		panel.addRandomSeed("rand", "Random Seed", System.currentTimeMillis());
		panel.addRadioButtonGroup("bg", "Metrics", name, defaults, "4", "A button Goup");
		JFrame frame = new JFrame();
		frame.getContentPane().add(panel);
		frame.pack();
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		java.awt.Dimension frameSize = frame.getPreferredSize();
		frame.setSize(frame.getPreferredSize());
		frame.setLocation(screenSize.width/2 - (frameSize.width/2),
						screenSize.height/2 - (frameSize.height/2));
					
		frame.setVisible(true);
		
		System.out.println(panel.getInt("rand"));
		System.out.println(panel.getText("rand"));
		panel.setValue("rand", "100");
		System.out.println(panel.getText("bg"));
		panel.setValue("bg", "3.147");
		System.out.println(panel.getText("bg"));
	}
	


	private class OkayListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			String key;

			for (Enumeration e = hash.keys() ; e.hasMoreElements() ;) {
				key = (String)(e.nextElement());
				store.put(key, getText(key));
			}	
			
			getTopLevelAncestor().setVisible(false);

		}
	}

	private class ApplyListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			String key;
			
			for (Enumeration e = hash.keys() ; e.hasMoreElements() ;) {
				key = (String)(e.nextElement());
				store.put(key, getText(key));
			}	
		}
	}

	private class RestoreListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			String key;
			
			for (Enumeration e = hash.keys() ; e.hasMoreElements() ;) {
				key = (String)(e.nextElement());
				setValue(key, (String)store.get(key));
			}	
		
		}
	}

	public void save(ObjectOutputStream file) throws IOException
	 {
				
		String key;

		for (Enumeration e = hash.keys() ; e.hasMoreElements() ;) {
			key = (String)(e.nextElement());
			file.writeObject(key);
			file.writeObject(getText(key));
		}	
		file.writeObject("END");
			
	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		String value;
		String key = (String)file.readObject(); 

		while(key.compareTo("END") != 0) {
			value = (String)file.readObject();
			setValue(key, value);
			key = (String)file.readObject();		
		}	
	}


	public Hashtable getHash() {
	    return hash;
	}
    
    public void setValuesUsingHash(Hashtable newValues) {

        String key;
        Object temp;
        
        for (Enumeration e = newValues.keys() ; e.hasMoreElements() ;) {
			key = (String)(e.nextElement());
			temp = newValues.get(key);
			setValue(key, getTextForObject(temp));
		}	
        
    }
    
    String getTextForObject(Object temp) {
		if(temp instanceof JTextField) {
			return ((JTextField)temp).getText(); 
		} else if(temp instanceof JComboBox) {
			return (String)((JComboBox)temp).getSelectedItem(); 		
		} else if(temp instanceof JCheckBox) {
			return Boolean.toString(((JCheckBox)temp).isSelected());
		} else if(temp instanceof SeedPanel) {
			return ((SeedPanel)temp).getText();
		} else if(temp instanceof ButtonGroup) {
			for (Enumeration e = ((ButtonGroup)temp).getElements() ; e.hasMoreElements() ;) {
			    JRadioButton jrb = (JRadioButton)e.nextElement(); 
				if(jrb.isSelected()) {
				    return jrb.getName();
				}
			}			
		}
		return null;

    }
}
