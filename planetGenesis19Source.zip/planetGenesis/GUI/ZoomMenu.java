/*
 * Created on May 27, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JMenu;
import javax.swing.JRadioButtonMenuItem;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class ZoomMenu extends JMenu {

	public ZoomMenu(ActionListener actionListener, String menuText) {

		setText(menuText);

		ButtonGroup group = new ButtonGroup();
		JRadioButtonMenuItem tmp = new JRadioButtonMenuItem("50%");
		group.add(tmp);
		add(tmp);
		tmp.addActionListener(actionListener);
		
		tmp = new JRadioButtonMenuItem("100%");	
		tmp.setSelected(true);
		group.add(tmp);
		add(tmp);
		tmp.addActionListener(actionListener);
		
		tmp = new JRadioButtonMenuItem("150%");
		group.add(tmp);
		add(tmp);
		tmp.addActionListener(actionListener);
		
		tmp = new JRadioButtonMenuItem("200%");
		group.add(tmp);
		add(tmp);
		tmp.addActionListener(actionListener);
		
	}

	
}
