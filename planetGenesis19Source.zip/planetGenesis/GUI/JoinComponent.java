package GUI;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.Line2D;

public class JoinComponent {
	
	private NoiseComponent outputComponentToJoin;
	private NoiseComponent inputComponentToJoin;
	private boolean thisIsSelectedComponent;
	private boolean dragJoin;
	private Point mousePoint;
	
	final protected BasicStroke stroke = new BasicStroke(1.0f);

	
	public JoinComponent(NoiseComponent inputComponentToJoin, NoiseComponent outputComponentToJoin) {
		this.setInputComponentToJoin(inputComponentToJoin);
		this.setOutputComponentToJoin(outputComponentToJoin);
		thisIsSelectedComponent = false;
		dragJoin = false;

		Point input, output;
	
		input = getInputComponentToJoin().getConnectionPoint(getOutputComponentToJoin());
		output = getOutputComponentToJoin().getConnectionPoint(getInputComponentToJoin());


	}
	

	public void paintComponent(Graphics2D g2, Point mousePoint) {
	
		Point input, output;

		input = getInputComponentToJoin().getConnectionPoint(getOutputComponentToJoin());
		output = getOutputComponentToJoin().getConnectionPoint(getInputComponentToJoin());
		
/*		
		
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
 		g2.setStroke(stroke);
*/
		
		if(dragJoin) {
			
			g2.draw(new Line2D.Double(input, mousePoint));
			g2.draw(new Line2D.Double(mousePoint, output));
		} else {

			g2.draw(new Line2D.Double(input, output));
		

		}
	
	}

	void setInputComponentToJoin(NoiseComponent inputComponentToJoin) {
		this.inputComponentToJoin = inputComponentToJoin;
	}

	NoiseComponent getInputComponentToJoin() {
		return inputComponentToJoin;
	}
	
	void setOutputComponentToJoin(NoiseComponent outputComponentToJoin) {
		this.outputComponentToJoin = outputComponentToJoin;
	}

	NoiseComponent getOutputComponentToJoin() {
		return outputComponentToJoin;
	}
	
	public JoinComponent insertNoiseComponent(NoiseComponent noise, Point mousePoint) {
		
		NoiseComponent oldInputComponentToJoin;
		
		oldInputComponentToJoin = inputComponentToJoin;
			
		NoiseComponent componentToReplaceInJoin = noise.getInputComponentForPoint(mousePoint);
		noise.releaseComponent(componentToReplaceInJoin);

		
		outputComponentToJoin.connectToOutput(noise, 
											  outputComponentToJoin.getOutputConnectionPoint(), 
				                              noise.getInputConnectionPoint(mousePoint));
		
		inputComponentToJoin.connectToInput(noise, 
				  							inputComponentToJoin.getConnectionPoint(outputComponentToJoin), 
				  							noise.getOutputConnectionPoint());

		/* now I need to adjust this join  and create a new one */
		inputComponentToJoin = noise;
		return new JoinComponent(oldInputComponentToJoin, noise); 
	
		
	}

	public boolean contains (Point point) {
		
		Point input, output;

		input = getInputComponentToJoin().getConnectionPoint(getOutputComponentToJoin());
		output = getOutputComponentToJoin().getConnectionPoint(getInputComponentToJoin());

		return (new Line2D.Double(input, output)).intersects(point.x - 10, point.y - 10, 21.0, 21.0);
	}
	
	public void setSelected(boolean thisIsSelectedComponent) {
		this.thisIsSelectedComponent = thisIsSelectedComponent;
	}

	public boolean isSelected() {
		return thisIsSelectedComponent;
	}

	/**
	 * @param mousePoint the mousePoint to set
	 */
	public void setMousePoint(Point mousePoint) {
		this.mousePoint = mousePoint;
	}

	/**
	 * @param dragJoin the dragJoin to set
	 */
	public void setDragJoin(boolean dragJoin) {
		this.dragJoin = dragJoin;
	}


	public boolean joinsThisComponenet(NoiseComponent component) {
		
		if(component == inputComponentToJoin || component == outputComponentToJoin) {
			return true;
		}
		
		return false;
	}
	
	
	public boolean validateInsertion(NoiseComponent component) {
	

		if(inputComponentToJoin.acceptComponentAsInput(component) &&
				component.acceptComponentForOutput(inputComponentToJoin) &&
				outputComponentToJoin.acceptComponentForOutput(component) &&
				component.acceptComponentAsInput(outputComponentToJoin) ) {
			return true;
		}
	
		return false;
		
	}
}
