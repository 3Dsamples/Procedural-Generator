/*
 * Created on Apr 19, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class HashBasedPanel extends JPanel {
	
	protected Hashtable<String, Object> hash;
	protected Hashtable<String, Object> store;
	protected OkApplyRestorePanel oac;
	/**
	 *
	 * HashBasedPanel builds a panel of JTextBoxes
	 * The name array and key array should be the same length.
	 * The key can be used to access the textboxes using the acesor methods.  
	 */
	
	public HashBasedPanel() {
	}

	public HashBasedPanel(String[] keys, String[] names, String[] defaults, String[] tooltips) {

		javax.swing.JTextField textField; 
		JPanel panel;
		hash = new Hashtable<String, Object>(keys.length);
		store = new Hashtable<String, Object>(keys.length);

		setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));
		setBorder(new javax.swing.border.TitledBorder(null, "", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 3, 11), new java.awt.Color(255, 0, 0)));
			
		for(int i = 0; i < keys.length; i++) {
			panel = new javax.swing.JPanel();
			textField = new javax.swing.JTextField();
			panel.setBorder(new javax.swing.border.TitledBorder(null, names[i], javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 11), new java.awt.Color(255, 0, 0)));
			panel.setForeground(new java.awt.Color(0, 0, 0));
			panel.setToolTipText(tooltips[i]);
			textField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
			textField.setText(defaults[i]);
			textField.setMinimumSize(new java.awt.Dimension(100, 20));
			textField.setPreferredSize(new java.awt.Dimension(100, 20));
			hash.put(keys[i], textField);
			store.put(keys[i], defaults[i]);
			panel.add(textField);

			add(panel);

		}
		
		oac = new OkApplyRestorePanel();
		oac.addOkayActionListener(new OkayListener());
		oac.addApplyActionListener(new ApplyListener());
		oac.addCancelActionListener(new CancelListener());
		add(oac);

	} 
	
	public double getDouble(String key) {
		JTextField temp = (JTextField)hash.get(key);
		return Double.parseDouble(temp.getText()); 
	}

	public String getText(String key) {
		JTextField temp = (JTextField)hash.get(key);
		return temp.getText(); 
	}

	public int getInt(String key) {
		JTextField temp = (JTextField)hash.get(key);
		return (int)Double.parseDouble(temp.getText()); 
	}

	public void setValue(String key, String value) {
		JTextField temp = (JTextField)hash.get(key);
		temp.setText(value);
		return;
	}
	
	public static void main(String[] args) {
		
		String[] keys = new String[3];
		String[] name = new String[3];
		String[] defaults = new String[3];
		
		keys[0] = "f";
		keys[1] = "int";
		keys[2] = "text";

		name[0] = "Float";
		name[1] = "Integer";
		name[2] = "Text";

		defaults[0] = "3.147";
		defaults[1] = "4";
		defaults[2] = "Hello World";
		
		HashBasedPanel panel = new HashBasedPanel(keys, name, defaults, name);
		JFrame frame = new JFrame();
		frame.getContentPane().add(panel);
		frame.pack();
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		java.awt.Dimension frameSize = frame.getPreferredSize();
		frame.setSize(frame.getPreferredSize());
		frame.setLocation(screenSize.width/2 - (frameSize.width/2),
						screenSize.height/2 - (frameSize.height/2));
					
		frame.setVisible(true);
		
		System.out.println(panel.getDouble("f"));
		System.out.println(panel.getInt("int"));
		System.out.println(panel.getText("text"));
		panel.setValue("text", "GoodBye!");
		System.out.println(panel.getText("text"));
	}
	


	private class OkayListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			JTextField tmp;
			String key;

			for (Enumeration e = hash.keys() ; e.hasMoreElements() ;) {
				key = (String)(e.nextElement());
				tmp = (JTextField )hash.get(key);
				store.put(key, tmp.getText());
			}	
			
			getTopLevelAncestor().setVisible(false);

		}
	}

	private class ApplyListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			JTextField tmp;
			String key;
			
			for (Enumeration e = hash.keys() ; e.hasMoreElements() ;) {
				key = (String)(e.nextElement());
				tmp = (JTextField )hash.get(key);
				store.put(key, tmp.getText());
			}	
		}
	}

	private class CancelListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			JTextField tmp;
			String key;
			
			for (Enumeration e = hash.keys() ; e.hasMoreElements() ;) {
				key = (String)(e.nextElement());
				tmp = (JTextField )hash.get(key);
				tmp.setText((String)store.get(key));
			}	
			
		}
	}

	   public void save(ObjectOutputStream file) throws IOException {

		String key;

		for (Enumeration e = hash.keys(); e.hasMoreElements();) {
			key = (String) (e.nextElement());
			file.writeObject(key);
			file.writeObject(getText(key));
		}
		file.writeObject("END");

	}

	public void load(ObjectInputStream file) throws ClassNotFoundException,
			IOException {

		String value;
		String key = (String) file.readObject();

		while (key.compareTo("END") != 0) {
			value = (String) file.readObject();
			setValue(key, value);
			key = (String) file.readObject();
		}
	}
		
}
