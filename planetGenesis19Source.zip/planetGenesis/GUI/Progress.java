/*
 * ObjectType.java
 *
 * Created on 01 April 2002, 17:46
 */

/*
Copyright (c) 2002, David Burnett
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer. 
Redistributions in binary form must reproduce the above 
copyright notice, this list of conditions and the following disclaimer 
in the documentation and/or other materials provided with the 
distribution. 
Neither the name of the copyright holder nor the names of its 
contributors may be used to endorse or promote products 
derived from this software without specific prior 
written permission. 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT 
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL 
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; 
OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY 
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/
package GUI;

import javax.swing.JFrame;
import javax.swing.JProgressBar;

/**
 *
 * @author  David
 */
public class Progress /*  extends Thread */ {
	javax.swing.JDialog progressDialog;
	JProgressBar progressBar;
	private javax.swing.JPanel jPanel1;

    public Progress(String fileName, JFrame owner) {
        initComponents(fileName, owner);
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		java.awt.Dimension frameSize = progressDialog.getPreferredSize();
		progressDialog.setLocation(screenSize.width/2 - (frameSize.width/2),
							screenSize.height/2 - (frameSize.height/2));
        progressDialog.setVisible(true);
    }
    
    private void initComponents(String fileName, JFrame owner) {

        progressBar = new JProgressBar();
		jPanel1 = new javax.swing.JPanel();
		java.io.File file = new java.io.File(fileName);
        progressDialog = new javax.swing.JDialog(owner);
		progressDialog.setTitle(file.getName());

        progressDialog.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

		progressBar.setStringPainted(true);
		progressBar.setPreferredSize(new java.awt.Dimension(400, 60));
        jPanel1.add(progressBar);
		progressDialog.getContentPane().add(jPanel1, java.awt.BorderLayout.SOUTH);
		progressDialog.pack();
    }



    
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
		progressDialog.dispose();
	}
    
    public static void main(String args[]) {
    }
    
	public void setMaxValue(int maxValue) {
		progressBar.setMaximum(maxValue);
	}
	
	public void setProgressValue(final int value) {
//		System.err.println(value);
				progressBar.setValue(value);
	}

	public void setProgressText(final String value) {
//		System.err.println(value);
				progressBar.setString(value);
	}	

	
	public void dispose() {
		java.awt.Toolkit.getDefaultToolkit().beep();
		progressDialog.dispose();
	}
/*	public void run() {
		try {
		while(true) {
			sleep(100);
			progressBar.setValue(progressValue);
			progressBar.invalidate();
		}
		} catch (Exception e) {
		}
	} */
}
