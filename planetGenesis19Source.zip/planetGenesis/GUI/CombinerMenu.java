/*
 * Created on Aug 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class CombinerMenu extends JMenu {

	public CombinerMenu(ActionListener actionListener, String menuName) {

		setText(menuName);
		JMenuItem item = new JMenuItem("Add");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Subtract");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Multiply");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Divide");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Power");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Disturb");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Warp");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Turbulence");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Maximum");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Minimum");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Set X");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Set Y");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Set Z");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Warp X");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Warp Y");
		item.addActionListener(actionListener);
		add(item);
		item = new JMenuItem("Warp Z");
		item.addActionListener(actionListener);
		add(item);
	}




}
