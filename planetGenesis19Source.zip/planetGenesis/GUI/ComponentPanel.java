/*
 * Created on Sep 12, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Line2D;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.ToolTipManager;
import javax.swing.filechooser.FileFilter;

import Utilities.NoiseEngine;
import Utilities.Preview3d;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */


public class ComponentPanel extends JPanel implements MouseListener, MouseMotionListener {

	NoiseComponent selectedComponent;
	NoiseComponent focussedComponent;
	JoinComponent selectedJoin;
	
	private Point dragStart;
	private Point dragCurrent;
	private Point popUpPoint;	
	private ArrayList<NoiseComponent> noiseComponents;
	private ArrayList<JoinComponent> joinComponents;
	private ComponentPanel privateReference;
	private int dragMouse; 
	private String defaultToolTip;
	private double zoom = 1.0;
	final ZoomMenu zoomMenu = new ZoomMenu(new ZoomMenuActionPerformed(), "Zoom");
	private JFrame owner;
	Preview3d preview;
	
	private KeyListener noiseKeyListener;
	PropertiesPanel propsPane;
	
	public ComponentPanel(JFrame owner, PropertiesPanel props) {
		propsPane=props;
		
		NoiseComponent testComponent;

		setLayout(null);
		addMouseListener(this);
		addMouseMotionListener(this);
		noiseKeyListener=new ComponentPanelKeyListener(this);
		owner.addKeyListener(noiseKeyListener);
		this.addKeyListener(noiseKeyListener);
		
//		getInputMap(/*JComponent.WHEN_IN_FOCUSED_WINDOW*/).put(KeyStroke.getKeyStroke('P'), "P");
//		getActionMap().put("P", new AbstractAction(){
//
//			public void actionPerformed(ActionEvent e)
//			{
//				System.out.println("P");
//			}
//			
//		});
		
		Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		screenSize.width *= 0.75;
		screenSize.height *= 0.75;
		
		testComponent = new TerrainComponent(owner, this);
		testComponent.setLocation((screenSize.width / 2)-32, (int)(screenSize.height * 0.75));
		noiseComponents = new ArrayList<NoiseComponent>();
		noiseComponents.add(testComponent);
//(testComponent);

		joinComponents = new ArrayList<JoinComponent>();

		
		screenSize.width *= zoom;
		screenSize.height *= zoom;

		setSize(screenSize);
		setPreferredSize(screenSize);
		setMinimumSize(screenSize);
		setMaximumSize(screenSize);

		privateReference = this;
		dragMouse = MouseEvent.NOBUTTON;
		defaultToolTip = new String("<html><i><b>planetGenesis</b></i><br>Use the context menu to add new features.</html>");
		setToolTipText(defaultToolTip);
		ToolTipManager.sharedInstance().setDismissDelay(50000);

		this.owner = owner;	
		try {
			preview = new Preview3d();
		} catch (Error e) {
			// No Java 3D
			e.printStackTrace();
		}
		
	}
	
	public String getToolTipText(MouseEvent arg0) {

		NoiseComponent tmp = findComponent(scalePointForZoom(arg0.getPoint()));

		if(tmp != null) {
			return "<html>" + tmp.getToolTipText() + "</html>";
		}
		return defaultToolTip;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.MouseMotionListener#mouseDragged(java.awt.event.MouseEvent)
	 */
	public void mouseDragged(MouseEvent arg0) {
		requestFocusInWindow();
		if(arg0.getButton() != 1) {
			if(dragMouse != MouseEvent.BUTTON1) {
				/* 
				 * Yes, this works aroung a 'bug' in java.
				 * I've seen one version of java where the button
				 * for the mouse event is not set. (Sun 1.4.2 on Win 2000)
				 */
				return;
			}
		}
		
		if(selectedComponent != null)   {
			if(arg0.isShiftDown()) {
				dragCurrent = scalePointForZoom(arg0.getPoint());
			} else {
				if(selectedComponent != null) {
					Point zoomPoint = scalePointForZoom(arg0.getPoint());
					selectedComponent.setLocation((int)zoomPoint.getX()-32, (int)zoomPoint.getY()-32);
				}
			}
			repaint();
		} else if (selectedJoin != null) {
			dragCurrent = scalePointForZoom(arg0.getPoint());
			repaint();
		}

	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseMotionListener#mouseMoved(java.awt.event.MouseEvent)
	 */
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub
	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseClicked(java.awt.event.MouseEvent)
	 */
	public void mouseClicked(MouseEvent mEvt) {
		requestFocusInWindow();
		System.err.println("clicked " + mEvt.getButton() + " " + mEvt.getX() + " y " + mEvt.getY());

		/* 
		 * adding the panel to the side Propertiesl viewport messes up the properties window 
		 * from double clicks so display it from here after it's been added to the view port
		 *  
		 */
		
		if(mEvt.getButton() == 1) {
			clearSelected();
			selectedComponent = findComponent(mEvt.getPoint());
			setSelected(selectedComponent);
			if(mEvt.getClickCount() == 2) {
				showPanel();
			}
		}

	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseEntered(java.awt.event.MouseEvent)
	 */
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseExited(java.awt.event.MouseEvent)
	 */
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mousePressed(java.awt.event.MouseEvent)
	 */
	public void mousePressed(MouseEvent mEvt) {
		requestFocusInWindow();
		Point zoomPoint = scalePointForZoom(mEvt.getPoint());
		
		if(mEvt.isPopupTrigger()) {
			clearSelected();
			selectedComponent = findComponent(zoomPoint);
			setSelected(selectedComponent);			
			repaint();
			popUp(mEvt);
			return;
		}

		if(dragMouse == MouseEvent.NOBUTTON) {
			dragMouse = mEvt.getButton();
		}
		
		if(mEvt.getButton() == 1 && mEvt.isShiftDown()) {
			// find noiseComponet
			clearSelected();
			selectedComponent = findComponent(zoomPoint);
			setSelected(selectedComponent);
			if(selectedComponent != null) {			
				dragStart = zoomPoint;
				setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
			}
			System.err.println("pressed x " + zoomPoint.getX() + " y " + zoomPoint.getY());
		} else if (mEvt.getButton() == 1) {
			clearSelected();
			selectedComponent = findComponent(zoomPoint);
			if (selectedComponent != null) {
				setSelected(selectedComponent);
			} else {
				JoinComponent tmp = findJoin(zoomPoint);
				if(tmp != null) {
					tmp.setDragJoin(true);
					selectedJoin = tmp;
					tmp.setMousePoint(zoomPoint);
				}
			}
			setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		}
		
		

	}

	private void clearSelected()
	{
//		System.out.println("Clearing selected "+selectedComponent);
//		if(selectedComponent!=null)
//			selectedComponent.setSelected(false);
	}

	private void setSelected(NoiseComponent noise)
	{
//		System.out.println("Setting selected "+selectedComponent);
		if(noise==null)
			noise=selectedComponent;
		if(noise!=null)
		{
			if(focussedComponent!=null)
				focussedComponent.setSelected(false);
			focussedComponent=noise;
			focussedComponent.setSelected(true);
			if(propsPane!=null)
			{
//				if (noise instanceof FunctionComponent)
//				{
//					FunctionComponent new_name = (FunctionComponent) noise;
//					System.out.println("Func "+((ApplyFunction)new_name.function).math+" in "+((Object)noise.noiseEngine).toString());
//				}
				System.out.println("GetPanel");
				propsPane.displayFor(focussedComponent);
				
				
				
//				JPanel p=null;
//				if (focussedComponent instanceof TerrainComponent)
//				{
//					TerrainComponent terr = (TerrainComponent) focussedComponent;
//					p=terr.getPanel();
//				}
//				else
//				{
//					p=focussedComponent.noiseEngine.getPanel();
//				}
//				if(p!=null)
//					propsPane.setRightComponent(p);
//				else
//					propsPane.setRightComponent(PropertiesPanel.noProperties);
			}
//			System.out.println("focus "+focussedComponent.isFocusOwner()+" "+focussedComponent.isFocusable());
		}
	}
	/* (non-Javadoc)
	 * @see java.awt.event.MouseListener#mouseReleased(java.awt.event.MouseEvent)
	 */
	public void mouseReleased(MouseEvent arg0) {

		System.err.println("released " + arg0.getButton() + " " + arg0.getX() + " y " + arg0.getY());
		
		NoiseComponent tmp;

		setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

		if(dragMouse == arg0.getButton()) {
			dragMouse = MouseEvent.NOBUTTON;
		}


		if(arg0.getButton() == 3 && arg0.isPopupTrigger()) {
			popUp(arg0);
			return;
		}
		
		Point zoomPoint = scalePointForZoom(arg0.getPoint());
		
		/* join the components via join component. */
		
		if(arg0.getButton() == 1) {
			if (selectedJoin != null) { /* we must be dragging a join */
				selectedComponent = findComponent(zoomPoint);
				if(selectedComponent != null) {
					
					/* check its a valid join type */
								
					if(selectedJoin.validateInsertion(selectedComponent)) {
						/* remove the old joins */
						NoiseComponent componentToReplaceInJoin = selectedComponent.getInputComponentForPoint(zoomPoint);
						if(componentToReplaceInJoin != null) {
							JoinComponent oldJoin = findJoin(componentToReplaceInJoin,selectedComponent);
							if(oldJoin != null) {
								joinComponents.remove(oldJoin);
							}
						}	
						/*inserting new join creates a new join create new join */
						JoinComponent newJoin = selectedJoin.insertNoiseComponent(selectedComponent, zoomPoint);
						/* add the new one */
						joinComponents.add(newJoin);

					}	
				}	
				selectedJoin.setDragJoin(false);
				selectedJoin = null;
			} else {
				/* create a join */
				tmp = findComponent(zoomPoint);
				if(tmp != null && 
						tmp != selectedComponent && 
						selectedComponent.getComponentTypeForPoint(dragStart) != tmp.getComponentTypeForPoint(zoomPoint)) {
					if(null == findJoin(selectedComponent, tmp)) {
						
						/* create a new join */
						
						/* first get rid of any old input joins on the input component */
						
						NoiseComponent newInputComponent;
						
						if (selectedComponent.getComponentTypeForPoint(zoomPoint) == NoiseComponent.POINT_SELECTS_INPUT_COMPONENT) {
							newInputComponent = selectedComponent;
						} else {
							newInputComponent = tmp;							
						}
						
						if(newInputComponent != null) {
						
							NoiseComponent componentToReplaceInJoin = newInputComponent.getInputComponentForPoint(zoomPoint);
							if(componentToReplaceInJoin != null) {
								JoinComponent oldJoin = findJoin(componentToReplaceInJoin,newInputComponent);
								if(oldJoin != null) {
									joinComponents.remove(oldJoin);
								}
							}	
						}
						
						JoinComponent newJoin = tmp.connectToComponent(selectedComponent, dragStart, zoomPoint);
						if(newJoin != null) {
							joinComponents.add(newJoin);
						}
					}
				}			
			}
		}
		
/*	
		
		if(arg0.getButton() == 1) {
			tmp = findComponent(zoomPoint);
			if(tmp != null && tmp != selectedComponent) {
				tmp.connectToComponent(selectedComponent, dragStart, zoomPoint);
			}else if(tmp != null) {
				// double click -> Properties...
				if(arg0.getClickCount() 	== 2) {
					if(tmp instanceof TerrainComponent) {
						//Terrain panel			
						TerrainComponent xyz = (TerrainComponent)tmp;
						showPanel(xyz.getPanel(), xyz.getName());
					} else if(!(tmp instanceof CombinerComponent)) {
						//Noise panel, Function panel
						tmp.showPanel();
					}
				}
			}
		}
*/
		dragCurrent = null;
		repaint();
	}

	
	private void drawConnection(Graphics2D g, NoiseComponent noise) {
		
		NoiseComponent[] connected;
		connected = noise.getConnectedComponents();
		if(connected != null) {
			for(int i = 0; i < connected.length; i++) {
				if (connected[i] != null) {
					drawConnection(g, connected[i]);
					g.draw(new Line2D.Double(noise.getConnectionPoint(connected[i]), connected[i].getConnectionPoint(noise)));
				}
			}
		}
		
	}

	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
	//	g2.scale(zoom,zoom);
		super.paint(g2);
	}

	public void update(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
		//g2.scale(zoom,zoom);
		super.update(g2);
	}	

	public void paintComponent(Graphics g) {

		Graphics2D g2 = (Graphics2D)g;
			
		super.paintComponent(g2);
		
		g2.setPaint(java.awt.Color.white);
		g2.fillRect(0,0, getWidth(), getHeight());
		g2.setPaint(java.awt.Color.black);
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		g2.scale(zoom, zoom);
		

	
		
		/* paint the existing conected joins */
		
		ArrayList<JoinComponent> selectedJoins = new ArrayList<JoinComponent>();
		JoinComponent tmpJoin;

		for(int i=0; i < joinComponents.size(); i++) {

			tmpJoin = joinComponents.get(i);
			
			/* we want the joins connected to the selected component to be drawn on top 
			 * so store them and draw then later
			 */
			if(selectedComponent == null || ! tmpJoin.joinsThisComponenet(selectedComponent) ) {
				joinComponents.get(i).paintComponent(g2, dragCurrent);
			}
			
			if(tmpJoin.joinsThisComponenet(selectedComponent)) {
				selectedJoins.add(tmpJoin);
			}
			
		}

		NoiseComponent tmp;
		for(int i=0; i < noiseComponents.size(); i++) {
			tmp = noiseComponents.get(i);
			/* we want the selected component to be drawn on top 
			 * so store it and draw then later
			 */
			if(tmp != selectedComponent) {
				tmp.paintComponent(g2);
			}
		}
		
		
		/* drag the selected componet and its joins */
		if(selectedComponent != null) {
			for(int i=0; i < selectedJoins.size(); i++) {
				selectedJoins.get(i).paintComponent(g2, dragCurrent);
			}
			selectedComponent.paintComponent(g2);
		}

		/* if dragging a new join then draw the line */
		if(dragStart != null && dragCurrent != null && selectedComponent != null) {
			g2.draw(new Line2D.Double(dragStart, dragCurrent));
		}			
	
	}
	
	private NoiseComponent findComponent(Point point) {

		NoiseComponent tmp;

		for(int i=0; i < noiseComponents.size(); i++) {
			tmp = (NoiseComponent)noiseComponents.get(i);
			if(tmp.contains(point)) {
				return tmp;
			}
		}
		
		return null; 		
	} 

	private JoinComponent findJoin(Point point) {

		JoinComponent tmp;

		for(int i=0; i < joinComponents.size(); i++) {
			tmp = (JoinComponent)joinComponents.get(i);
			if(tmp.contains(point)) {
				return tmp;
			}
		}
		
		return null; 		
	} 
	public JPopupMenu getPopUp() {
	
		JPopupMenu menu = new JPopupMenu();

		NoiseMenu noiseMenu = new NoiseMenu(new NoiseMenuActionPerformed(), "Add Noise");
		menu.add(noiseMenu);

		FunctionMenu functionMenu = new FunctionMenu(new FunctionMenuActionPerformed(), "Add Function");
		menu.add(functionMenu);

		CombinerMenu combinerMenu = new CombinerMenu(new CombinerMenuActionPerformed(), "Add Combiner");
		menu.add(combinerMenu);

		PostProcessMenu ppMenu = new PostProcessMenu(new PostProcessMenuActionPerformed(), "Add Post Process");
		menu.add(ppMenu);

		JMenuItem tmp = new JMenuItem("Save...");
		tmp.addActionListener(new SaveMenuActionPerformed());
		menu.add(tmp);

		tmp = new JMenuItem("Load...");
		tmp.addActionListener(new LoadMenuActionPerformed());
		menu.add(tmp);
		
		menu.add(zoomMenu);

		return menu;
	}
	

	private void showPanel(javax.swing.JPanel panel, String name) {
    	
		JDialog frame = new JDialog(owner, name);
		frame.getContentPane().add(panel);
		frame.pack();
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		java.awt.Dimension frameSize = frame.getPreferredSize();
		frame.setSize(frame.getPreferredSize());
		frame.setLocation(screenSize.width/2 - (frameSize.width/2),
						screenSize.height/2 - (frameSize.height/2));
					
		frame.setVisible(true);
	}	
	
	private void popUp(MouseEvent arg0) {
		

		System.err.println("Pressed PopUpTrigger");
		Point zoomPoint = scalePointForZoom(arg0.getPoint());
		selectedComponent = findComponent(zoomPoint);
		popUpPoint = arg0.getPoint();
		if(selectedComponent != null) {
			JPopupMenu tmp = selectedComponent.getPopUp(new noiseListner(), this);
			tmp.show(this, arg0.getPoint().x, arg0.getPoint().y);
		} else {
			getPopUp().show(this, popUpPoint.x, popUpPoint.y);

		}
		return;


	}
	class noiseListner implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			
			JMenuItem source = (JMenuItem)(arg0.getSource());
			if(source.getText() == "Properties...") {
				showPanel();
/*				
				if(selectedComponent instanceof TerrainComponent) {
					TerrainComponent tmp = (TerrainComponent)selectedComponent;
					showPanel(tmp.getPanel(), "Terrain");
				} else {
				//	NoisePanel panel = (NoisePanel)selectedComponent.getNoiseEngine().getPanel();
					//showPanel(selectedComponent.getNoiseEngine().getPanel(), selectedComponent.getNoiseEngine().name());
					if(selectedComponent != null) {
						selectedComponent.showPanel();
					}
				}
				
*/				
			} else if(source.getText() == "Delete") {
				selectedComponent.releaseFromAll();
				noiseComponents.remove(selectedComponent);
//				remove(selectedComponent);
				
				JoinComponent tmp;
				
				Iterator<JoinComponent> itor = joinComponents.iterator();
				while(itor.hasNext()) {
					tmp = itor.next();
					if(tmp.joinsThisComponenet(selectedComponent)) {
						itor.remove();
					}
				}
				
				propsPane.displayFor(null);
				
				repaint();				
			}  else if(source.getText() == "Run") {
				TerrainComponent tmp = (TerrainComponent)selectedComponent;
				tmp.run(owner);
			} else if(source.getText() == "Copy") {
			    NoiseComponent tmp = (NoiseComponent)selectedComponent;
				NoiseComponent copy = tmp.copy();
				noiseComponents.add(copy);
				copy.setLocation(scalePointForZoom(popUpPoint));
//				add(copy);               
			}  else if(source.getText() == "Preview") {
				try {
//					Preview3d preview = new Preview3d();
					NoiseComponent noise = findComponent(scalePointForZoom(popUpPoint));
					preview.ShowGeometry(preview.makePreview(noise.getNoiseEngine()));
				} catch(NoClassDefFoundError e) {
					showPreviewError(e);
				} catch (Error e) {
						showPreviewError(e);
						
				}catch (Exception e) {
					showPreviewError(e);
					
				}
			}
			
			selectedComponent = null;
		}
	}
	
	private class ZoomMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			
			JRadioButtonMenuItem zoomItem = (javax.swing.JRadioButtonMenuItem)arg0.getSource();
			if(zoomItem.getText().compareTo("50%") == 0) {
				zoom = 0.5;
			} else if(zoomItem.getText().compareTo("100%") == 0) {
				zoom = 1.0;
			} else if(zoomItem.getText().compareTo("150%") == 0) {
				zoom = 1.5;
			} else if(zoomItem.getText().compareTo("200%") == 0) {
				zoom = 2.0;
			} 

			zoomItem.setSelected(true);
			Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
			screenSize.width *= 0.75;
			screenSize.height *= 0.75;
			screenSize.width *= zoom;
			screenSize.height *= zoom;

			setPreferredSize(screenSize);
			setMinimumSize(screenSize);
			setMaximumSize(screenSize);
			setSize(screenSize);

			repaint();
		}
	}	
	
	private class NoiseMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			NoiseEngine noiseEngine;
			Class noiseClass;
			javax.swing.JMenuItem cb = (javax.swing.JMenuItem)arg0.getSource();
			try {
				noiseClass = Class.forName(cb.getText());
				try {
					noiseEngine = (Utilities.NoiseEngine)noiseClass.newInstance();
					NoiseComponent noise = new NoiseComponent(owner, ComponentPanel.this);
					noise.setNoiseEngine(noiseEngine);
					noiseComponents.add(noise);
					noise.setLocation(scalePointForZoom(popUpPoint));
//					add(noise);
					setSelected(noise);
				} catch (InstantiationException e) {
					System.err.println(e.getMessage());
					e.printStackTrace();					
				}
			} catch (NullPointerException e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			} catch(Exception e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			}
			repaint();
		}
	}		
	
	private class FunctionMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			FunctionComponent function = new FunctionComponent(owner, ComponentPanel.this);
			function.setLocation(scalePointForZoom(popUpPoint));
			noiseComponents.add(function);
			FunctionMenuItem item = (FunctionMenuItem)arg0.getSource();
			function.setFunction(item);
//			add(function);
			setSelected(function);
			function.refreshDownStreamPreview();
			repaint();
			propsPane.displayFor(function);	

		}
	}

	private class CombinerMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			CombinerComponent function = new CombinerComponent(owner, ComponentPanel.this);
			function.setLocation(scalePointForZoom(popUpPoint));
			javax.swing.JMenuItem cb = (javax.swing.JMenuItem)arg0.getSource();
			function.setFunction(cb.getText());
			noiseComponents.add(function);
//			add(function);
			setSelected(function);
			function.refreshUpStreamPreview();
			repaint();
		}
	}

	private class PostProcessMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			PostProcessComponent function = new PostProcessComponent(owner, ComponentPanel.this);
			function.setLocation(scalePointForZoom(popUpPoint));
			noiseComponents.add(function);
			NoiseMenuItem item = (NoiseMenuItem)arg0.getSource();
			function.setPostProcess(item);
//			add(function);
			function.refreshDownStreamPreview();
			repaint();
		}
	}	
	
	public class SaveMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {		
			try {
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.addChoosableFileFilter(new savePGFilter());
				boolean notFinished = true;
				while(notFinished) {
					int returnVal = fileChooser.showSaveDialog(ComponentPanel.this);
					NoiseComponent tmp;
					if(returnVal == JFileChooser.APPROVE_OPTION) {
						String name = fileChooser.getSelectedFile().getAbsolutePath();
						if(!name.endsWith(".pg") && !name.endsWith(".pG") && !name.endsWith(".PG") && !name.endsWith(".Pg")) {
							name += ".pG";
						}
						
						File test = new File(name);	
						if(test.exists()) {
							int result = JOptionPane.showConfirmDialog(ComponentPanel.this, "This file already exists.\nDo you want to over write it?", "Overwrite File ?",  JOptionPane.YES_NO_OPTION);
							if(result != JOptionPane.YES_OPTION) {
								continue;
							}
						}
						
						notFinished = false;
						
						ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(name));
						out.writeObject("pG");
						for(int i = 0; i < noiseComponents.size(); i++) {
							tmp = (NoiseComponent)noiseComponents.get(i);
							tmp.save(out);
						}
						out.writeObject("END"); 
						for(int i = 0; i < noiseComponents.size(); i++) {
							tmp = (NoiseComponent)noiseComponents.get(i);
							tmp.saveJoins(out, noiseComponents);
						}
						
					} else {
						notFinished = false;						
					}
					
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
	}
		
	public class LoadMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {		


			JFileChooser fileChooser = new JFileChooser();
			fileChooser.addChoosableFileFilter(new loadPGFilter());
			int returnVal = fileChooser.showOpenDialog(privateReference);
			int startPoint = 1;
			
			joinComponents = new ArrayList<JoinComponent>();
			
			try {
				if(returnVal == JFileChooser.APPROVE_OPTION) {

					NoiseComponent tmp;
					String tmpString;
					Class noiseClass;
					Class[] dialogClass = new Class[2];
					Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		
					screenSize.width *= 0.75;
					screenSize.height *= 0.75;
					TerrainComponent testComponent = new TerrainComponent(owner, ComponentPanel.this);
					testComponent.setLocation((screenSize.width / 2)-32, (int)(screenSize.height * 0.75));
					privateReference.removeAll();
					noiseComponents = new ArrayList<NoiseComponent>();
					noiseComponents.add(testComponent);
//					privateReference.add(testComponent);
		
					ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileChooser.getSelectedFile().getAbsolutePath()));
					tmpString = (String)in.readObject(); 
					if(tmpString.compareTo("pG") == 0) {
						tmpString = (String)in.readObject(); 
						if(tmpString.compareTo("GUI.TerrainComponent") == 0) {
							testComponent.load(in);
							startPoint = 0;
							tmpString = (String)in.readObject(); 
						} 

	
						while(tmpString.compareTo("END") != 0) {
							noiseClass = Class.forName(tmpString);
							dialogClass[0] = Class.forName("javax.swing.JFrame");
							dialogClass[1] = Class.forName("GUI.ComponentPanel");
							Constructor ctor = noiseClass.getConstructor(dialogClass);
							Object[] args = new Object[2];
							args[0] = owner;
							args[1] = ComponentPanel.this;
							tmp = (NoiseComponent)ctor.newInstance(args);		
							tmp.load(in);
							noiseComponents.add(tmp);
//							privateReference.add(tmp);
							String newtmp =  (String)in.readObject();
							tmpString =  newtmp;
							
						}
						NoiseComponent connectedToTerrain = null;
						for(int i = startPoint; i < noiseComponents.size(); i++) {
							tmp = (NoiseComponent)noiseComponents.get(i);
							tmp = tmp.loadJoins(in, noiseComponents, joinComponents);
							if(tmp != null) {
								connectedToTerrain = tmp;
							}
						}
						if(connectedToTerrain != null) {
							connectedToTerrain.refreshUpStreamPreview();
						}
						for(int i = 0; i < noiseComponents.size(); i++) {
							tmp = (NoiseComponent)noiseComponents.get(i);
							if(tmp.componentConnectedToOutput.size() == 0) {
								tmp.refreshUpStreamPreview();
							}
						}
						
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			repaint();
		}
	}


	public class JoinRemovalListener implements ActionListener {
		
		JoinComponent join;
		
		public JoinRemovalListener() {
			super();
		}
		
		public void actionPerformed(ActionEvent arg0) {

			if (join != null) {
				joinComponents.remove(join);
				join.getOutputComponentToJoin().releaseComponent(join.getInputComponentToJoin());
				ComponentPanel.this.repaint();
			}
		
		}
		
		public void setComponents(NoiseComponent c1, NoiseComponent c2) {
			
			join = findJoin(c1, c2);
			
		}
	}


	private class loadPGFilter extends FileFilter {
	   public boolean accept(File file) {
			if (file != null && file.isFile()) {
					String name = file.getName();
					if(name.endsWith(".pg") || name.endsWith(".pG") || 
						name.endsWith(".PG") || name.endsWith(".Pg")) {
					 	return true;
					}
					return false;
			} 
			if (file != null && file.isDirectory()) {
				return true;
			}
			return false;
	   }

	   public String getDescription() {
			return "planetGenesis File";
	   }
	} 

	private class savePGFilter extends FileFilter {
	   public boolean accept(File file) {

			if(file.canWrite()) {
				return true;
			}
			return false;
	   }

	   public String getDescription() {
			return "planetGenesis File";
	   }
	} 

    private Point scalePointForZoom(Point point) {
		return new Point((int)(point.getX()/zoom), (int)(point.getY()/zoom));
    }

    public boolean load(String fileName) {
    	
		NoiseComponent tmp;
		String tmpString;
		Class noiseClass;
		Class[] dialogClass = new Class[1];

		int startPoint = 1;
		Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();

		screenSize.width *= 0.75;
		screenSize.height *= 0.75;
		TerrainComponent testComponent = new TerrainComponent(owner, this);
		testComponent.setLocation((screenSize.width / 2)-32, (int)(screenSize.height * 0.75));
		privateReference.removeAll();
		noiseComponents = new ArrayList<NoiseComponent>();
		noiseComponents.add(testComponent);
//		privateReference.add(testComponent);
		joinComponents = new ArrayList<JoinComponent>();


		try {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName));
			tmpString = (String)in.readObject(); 
			if(tmpString.compareTo("pG") == 0) {
				tmpString = (String)in.readObject(); 
				if(tmpString.compareTo("GUI.TerrainComponent") == 0) {
					testComponent.load(in);
					startPoint = 0;
					tmpString = (String)in.readObject(); 
				} 
	
	
				while(tmpString.compareTo("END") != 0) {
					noiseClass = Class.forName(tmpString);
					dialogClass[0] = Class.forName("javax.swing.JFrame");
					Constructor ctor = noiseClass.getConstructor(dialogClass);
					Object[] args = new Object[1];
					args[0] = owner;
					tmp = (NoiseComponent)ctor.newInstance(args);		
					tmp.load(in);
					noiseComponents.add(tmp);
//					privateReference.add(tmp);
					String newtmp =  (String)in.readObject();
					tmpString =  newtmp;
					
				}
				
				NoiseComponent connectedToTerrain = null;
				for(int i = startPoint; i < noiseComponents.size(); i++) {
					tmp = (NoiseComponent)noiseComponents.get(i);
					tmp = tmp.loadJoins(in, noiseComponents, joinComponents);
					if(tmp != null) {
						connectedToTerrain = tmp;
					}
				}
				
				if(connectedToTerrain != null) {
					connectedToTerrain.refreshUpStreamPreview();
				}
			} 
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
    
		return true;
    }
    
    public boolean batchRun() {
		TerrainComponent tmp = (TerrainComponent)noiseComponents.get(0);
		tmp.batchRun(owner);
		return true;
    }

	void showPreviewError(Throwable e)
	{
		String stackString = new String();
		StackTraceElement[] stack = e.getStackTrace();
		for(int i=0; i < stack.length; i++) {
			stackString += stack[i].toString();
			stackString += "\n";
		}
		
		JOptionPane pane = new JOptionPane("The preview option failed.\n" +
				"For a guess you have not got Java 3D installed.\n" +
				"The rest of planeGenesis is fully functional.\n" +
				"Finding Java 3D can be problematical, the best way to find it is by\n" +
				"searching for java3d windows or java3d linux or java3d apple in google\n or" +
				"check with http://www.j3d.org/download.html.\n"+
				"The Java error message is :" + e.getMessage() + "\n" +
				stackString, 
				JOptionPane.INFORMATION_MESSAGE);
		JDialog dialog = pane.createDialog(ComponentPanel.this, "Sorry!");
		dialog.setModal(true);
		dialog.setVisible(true);
		e.printStackTrace();
	}
	
	private void removeJoinsForNoiseComponent(NoiseComponent component) {

		/* get rid of old joins */
		Iterator<JoinComponent> itor = joinComponents.iterator();
		JoinComponent join;
		while(itor.hasNext()) {
			join = itor.next();
			if(join.joinsThisComponenet(component)) {
				itor.remove();
			}
		}

	}

	private JoinComponent findJoin(NoiseComponent c1, NoiseComponent c2) {

		/* get rid of old joins */
		Iterator<JoinComponent> itor = joinComponents.iterator();
		JoinComponent join;
		
		
		while(itor.hasNext()) {
			join = itor.next();
			if(join.joinsThisComponenet(c1) && join.joinsThisComponenet(c2)) {
				return join;
			}
		}
		
		return null;

	}


	void showPanel() {

		if(selectedComponent instanceof TerrainComponent) {
			TerrainComponent tmp = (TerrainComponent)selectedComponent;
			showPanel(tmp.getPanel(), "Terrain");
		} else {
		//	NoisePanel panel = (NoisePanel)selectedComponent.getNoiseEngine().getPanel();
			//showPanel(selectedComponent.getNoiseEngine().getPanel(), selectedComponent.getNoiseEngine().name());
			if(selectedComponent != null) {
				selectedComponent.showPanel();
			}
		}		
		
	}
	
}
