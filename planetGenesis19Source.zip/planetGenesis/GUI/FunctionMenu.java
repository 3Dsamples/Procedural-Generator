/*
 * Created on Aug 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.event.ActionListener;

import javax.swing.JMenu;
/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class FunctionMenu extends JMenu {


	public FunctionMenu(ActionListener actionListener, String menuText) {

		setText(menuText);
		FunctionMenuItem item = new FunctionMenuItem("Absolute", "plugins.engines.ApplyFunction");
		item.addActionListener(actionListener);
		add(item);
		//su_liam: added 07/22/08
		item = new FunctionMenuItem("Adjustments", "plugins.engines.Adjustments");
		item.addActionListener(actionListener);
		add(item);
		//"Items, girl, items!"
		
		item = new FunctionMenuItem("Clamp", "plugins.engines.ApplyFunction");
		item.addActionListener(actionListener);
		add(item);
		//su_liam: added 07/05/07
		item = new FunctionMenuItem("Range", "plugins.engines.Range");
		item.addActionListener(actionListener);
		add(item);
		//
		item = new FunctionMenuItem("Craterize", "plugins.engines.ApplyFunction");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Erode", "plugins.engines.PreviewVerticesFunction");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Invert", "plugins.engines.ApplyFunction");
		item.addActionListener(actionListener);
		add(item);
		//su_liam added 12/15/07
		item = new FunctionMenuItem("Reciprocal", "plugins.engines.InverseFunctions");
		item.addActionListener(actionListener);
		add(item);
		//	su_liam added 12/15/07
		item = new FunctionMenuItem("Complement", "plugins.engines.InverseFunctions");
		item.addActionListener(actionListener);
		add(item);
		
		item = new FunctionMenuItem("Mask", "plugins.engines.ApplyFunction");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("No Operation", "plugins.engines.ApplyFunction");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Rough Scale", "plugins.engines.ApplyFunction");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Sine", "plugins.engines.ApplyFunction");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Terrace", "plugins.engines.ApplyFunction");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Rotate", "plugins.engines.RotateFunction");
		item.addActionListener(actionListener);
		add(item);	
		item = new FunctionMenuItem("Splinify", "plugins.engines.BasedFunction");
		item.addActionListener(actionListener);
		add(item);	
		//su_liam: added 10/26/07
		item = new FunctionMenuItem("Logarithm", "plugins.engines.Logarithm");
		item.addActionListener(actionListener);
		add(item);

        // datta_sid: added 7/30/2008
        item = new FunctionMenuItem("MultiFractallize", "plugins.functions.MultiFractallizeFunction");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Musgrave MultiFractallize", "plugins.functions.MusgraveMultiFractallize");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Musgrave HeteroFractallize", "plugins.functions.MusgraveHeteroFractallize");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Musgrave HybridFractallize", "plugins.functions.MusgraveHybridFractallize");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Musgrave Ridged Fractallize", "plugins.functions.MusgraveRidgedFractallize");
		item.addActionListener(actionListener);
		add(item);
		item = new FunctionMenuItem("Noise Resize", "plugins.functions.ResizeNoiseFunction");
        item.addActionListener(actionListener);
        add(item);
        item = new FunctionMenuItem("Offset/Scale", "plugins.functions.AddScaleFunction");
        item.addActionListener(actionListener);
        add(item);
        item = new FunctionMenuItem("f(x)", "plugins.functions.FunctionFunction");
        item.addActionListener(actionListener);
        add(item);
		}




}
