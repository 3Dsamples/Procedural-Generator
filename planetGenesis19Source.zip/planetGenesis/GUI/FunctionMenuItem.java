/*
 * Created on Sep 30, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */


package GUI;



import javax.swing.JMenuItem;
import Utilities.NoiseEngine;


/**
 * @author burnetd
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class FunctionMenuItem extends JMenuItem {

	private String className;
	
	FunctionMenuItem(String functionName, String className) {
		super(functionName);
		this.className = className;
	}
	
	NoiseEngine getNoiseEngine() {
		try {
			return (NoiseEngine)(Class.forName(className).newInstance());
		} catch (ClassCastException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
//			e.getMessage();
			e.printStackTrace();
		}
		return null;
	}
	
	public static void main(String[] args) {
	}
}


