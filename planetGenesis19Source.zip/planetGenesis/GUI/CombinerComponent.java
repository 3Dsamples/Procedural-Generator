/*
 * Created on Sep 13, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.Point;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import Utilities.NoiseEngine;

import plugins.engines.MultiNoise;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class CombinerComponent extends NoiseComponent {

	final private Ellipse2D.Double ellipse = new Ellipse2D.Double(4,4,58,58);
	final private Ellipse2D.Double shadowEllipse = new Ellipse2D.Double(7,7,61,61);
	final private Ellipse2D.Double inputSlot1 = new Ellipse2D.Double(13,4,8,8);
	final private Ellipse2D.Double inputSlot2 = new Ellipse2D.Double(45,4,8,8);
	final private Ellipse2D.Double outputSlot = new Ellipse2D.Double(29,54,8,8);
	
	//final private MultiNoise noiseEngine = new MultiNoise();
	final private NoiseComponent[] inputComponent = new NoiseComponent[2];
	
	final private MultiNoise function = new MultiNoise(); 
		
	public CombinerComponent(JFrame owner, ComponentPanel componentPanel) {
		super(owner, componentPanel);
		noiseEngine = function;
	}
	
	public JoinComponent connectToComponent(NoiseComponent noise, Point noiseEnd, Point thisEnd) {
		// Connects components together. Only called when the connection drag ends on the component
		// This function has to be overriden!
		// Function components have both input and output slots
		if(thisEnd.y - getLocation().y < 32) {
			if(noise instanceof PostProcessComponent) {
				return null;
			}
			// If the dragEnd is in the top half attempt to connect to the noises output slot
			noise.connectToOutput(this, noiseEnd, thisEnd);	
			return new JoinComponent(this, noise);
		} else {
			// If the dragEnd is in the bottom half attempt to connect to the noises input slot
			releaseComponent(noise);	
			noise.connectToInput(this, noiseEnd, thisEnd);
			if(componentConnectedToOutput.contains(noise) == false) {
				componentConnectedToOutput.add(noise);
			}	
			return new JoinComponent(noise, this);
		}
	}

	public boolean connectToInput(NoiseComponent component, Point thisEnd, Point noiseEnd) {
		// connects components together.
		// Functions have an input connection, keep NoiseEngine reference
		if(component instanceof PostProcessComponent) {
			/* 
			 * PostProcessComponents can only be the input for other PostProcessComponent
			 * and TerrainComponents;
			 */
			return false;
		}
		releaseComponent(component);
		if(thisEnd.x - getLocation().x < 32) {
			if(inputComponent[0] != null) {
				inputComponent[0].releaseComponent(this);
			}
			inputComponent[0] = component;
			function.setNoiseEngine(component.getNoiseEngine(), 0);	
		} else {
			if(inputComponent[1] != null) {
				inputComponent[1].releaseComponent(this);
			}
			inputComponent[1] = component;	
			function.setNoiseEngine(component.getNoiseEngine(), 1);	
		}
		refreshDownStreamPreview();
		return true;
	}

	public boolean connectToOutput(NoiseComponent component, Point thisEnd, Point noiseEnd) {
		// connects components together.
		// Functions have an output connection, connect it to the components input
		releaseComponent(component);
		if(component.connectToInput(this, noiseEnd, thisEnd)) {
			if(componentConnectedToOutput.contains(component) == false) {
				componentConnectedToOutput.add(component);
			}	
			return true;
		}
		
		return false;
		
	}

	public void releaseComponent(NoiseComponent component) {
		// releases compoent if joined to a slot
		if(component == inputComponent[0]) {
			inputComponent[0] = null;
			function.setNoiseEngine(null, 0)	;			
		}
		if(component == inputComponent[1]) {
			inputComponent[1] = null;
			function.setNoiseEngine(null, 1);			
		}
		componentConnectedToOutput.remove(component);		
		return;
	}
	
	public Point getConnectionPoint(NoiseComponent noise) {
		if(noise == inputComponent[0]) {
			return new Point(getLocation().x + 17, getLocation().y+4);
		} else if(noise == inputComponent[1]) {
			return new Point(getLocation().x + 49, getLocation().y+4);
		} else {
			return new Point(getLocation().x + 33, getLocation().y+58);			
		}
		
	}

	public Point getInputConnectionPoint(Point basisPoint) {
		
		if(basisPoint.x - getLocation().x < 32) {
			/* return left hand point */
			return new Point(getLocation().x + 17, getLocation().y+4);
		} else {
			return new Point(getLocation().x + 49, getLocation().y+4);			
		}			
		
	}
	
	public void paintComponent(Graphics g) {
		// paints input and output slots
		
		Graphics2D g2 = (Graphics2D)g;
		
		AffineTransform saveAT = g2.getTransform();
		g2.translate(location.x, location.y);

		
		Shape clip =  g2.getClip();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setStroke(stroke);
		if(selected) {
			g2.setColor(shadowColor);
			g2.fill(shadowEllipse);
			g2.setColor(Color.WHITE);
			g2.fill(ellipse);
			g2.setColor(Color.red);
		}
		g2.draw(ellipse);
		g2.setClip(ellipse);
		g2.setPaint(Color.red);
		function.paintIcon(g2, this);
		g2.setClip(clip);
		g2.setPaint(Color.white);
		g2.fill(inputSlot1);
		g2.fill(inputSlot2);
		g2.setPaint(Color.red);
		g2.fill(outputSlot);
		g2.setPaint(Color.black);
		g2.draw(inputSlot1);
		g2.draw(inputSlot2);
		g2.draw(outputSlot);

		g2.setTransform(saveAT);
	
	}
	
	public NoiseComponent[] getConnectedComponents() {
		/** returns the component providing input to the Function */
			return inputComponent;
	}
	
	public NoiseEngine getNoiseEngine() {
		if(inputComponent[0] != null) {
			function.setNoiseEngine(inputComponent[0].getNoiseEngine(), 0);
		}
		if(inputComponent[1] != null) {
			function.setNoiseEngine(inputComponent[1].getNoiseEngine(), 1);
		}
		return function;
	}
	
	public void releaseFromAll() {


		super.releaseFromAll();
		
		if(inputComponent[0] != null) {
			inputComponent[0].releaseComponent(this);
		}
		if(inputComponent[1] != null) {
			inputComponent[1].releaseComponent(this);
		}
	}
	
	public void setFunction(String functionName) {
		name = functionName;
		function.setFunction(functionName) ;
		refreshDownStreamPreview();
		return;
	}

	public JPopupMenu getPopUp(ActionListener actionListner, ComponentPanel componentPanel) {
		JPopupMenu menu = new JPopupMenu();
		CombinerMenu noiseMenu = new CombinerMenu(new CombinerMenuActionPerformed(), "Replace Combiner");
		menu.add(noiseMenu);
		JMenuItem menuItem = new JMenuItem("Delete");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		if(componentConnectedToOutput.isEmpty()) {
			menuItem = new JMenuItem("Detach");
			menuItem.setEnabled(false);
			menu.add(menuItem);
		} else {
			JMenu outputComponentMenu = new OutputComponentMenu(componentPanel);
			menu.add(outputComponentMenu);
		}		
		menuItem = new JMenuItem("Preview");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		return menu;
	}

	private class CombinerMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			javax.swing.JMenuItem cb = (javax.swing.JMenuItem)arg0.getSource();
			setFunction(cb.getText());
			componentPanel.propsPane.displayFor(CombinerComponent.this);
			refreshUpStreamPreview();
			refreshDownStreamPreview();
		}
	}

	public void save(ObjectOutputStream file) throws IOException {

		file.writeObject(this.getClass().getName());
		file.writeObject(this.getLocation());		
		function.save(file);	

	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		Point position = (Point)file.readObject();
		this.setLocation(position);
		function.load(file);
		name = function.name();
//		function.makePreview();

	}	
	
	public void saveJoins(ObjectOutputStream file, ArrayList components ) throws IOException {

		
		file.writeObject("componentsConnectedToOutput");
		file.writeObject("" + componentConnectedToOutput.size() );
		for(int i = 0; i < componentConnectedToOutput.size(); i++) {
			file.writeObject(""+components.indexOf(componentConnectedToOutput.get(i)));
		}				
		
		file.writeObject(""+components.indexOf(inputComponent[0]));
		file.writeObject(""+components.indexOf(inputComponent[1]));
	}
	
	public NoiseComponent loadJoins(ObjectInputStream file, ArrayList<NoiseComponent> components, ArrayList<JoinComponent> joins) throws ClassNotFoundException, IOException {

		NoiseComponent connectedToTerrain = null;
		NoiseComponent component;
		
		String index = (String)file.readObject();
		if(index.compareTo("componentsConnectedToOutput") != 0) {
			int i = Integer.parseInt(index);
			if(i > -1) {

				component = components.get(i);
				componentConnectedToOutput.add(component);

				if(null == NoiseComponent.findJoin(joins, this, component) ) {
	   				joins.add(new JoinComponent(this, component));
	   			}
				
				
				if(i == 0) {
					connectedToTerrain = this;
				}	
			}
		} else {
			int j;
			index = (String)file.readObject();
			int count = Integer.parseInt(index);
			for(int i = 0; i < count; i++ ) {
				index = (String)file.readObject();
				j = Integer.parseInt(index);
				if(j > -1) {

					component = components.get(j);
					componentConnectedToOutput.add(component);

					if(null == NoiseComponent.findJoin(joins, this, component) ) {
		   				joins.add(new JoinComponent(this, component));
		   			}

					if(j == 0) {
						connectedToTerrain = this;
					}	
				}				
			}
		}
				
		index = (String)file.readObject();
		int i = Integer.parseInt(index);
		if(i > -1) {
			inputComponent[0] = (NoiseComponent)components.get(i);
			function.setNoiseEngine(inputComponent[0].getNoiseEngine(), 0);	
		}
		
		index = (String)file.readObject();
		i = Integer.parseInt(index);
		if(i > -1) {
			inputComponent[1] = (NoiseComponent)components.get(i);
			function.setNoiseEngine(inputComponent[1].getNoiseEngine(), 1);	
		}
		
		return connectedToTerrain;
		
	}	

	public void refreshUpStreamPreview() {
		
		
		if(inputComponent[0] != null) {
			inputComponent[0].refreshUpStreamPreview();
			function.setNoiseEngine(inputComponent[0].getNoiseEngine(), 0);	
		}

		if(inputComponent[1] != null) {
			inputComponent[1].refreshUpStreamPreview();
			function.setNoiseEngine(inputComponent[0].getNoiseEngine(), 0);	
		}
		
		function.makePreview();
		noiseEngine = function;
	
		owner.repaint();
		
	}

	public void refreshDownStreamPreview() {
		
		if(noiseEngine != null) {
			if(inputComponent[0] != null) {
				function.setNoiseEngine(inputComponent[0].getNoiseEngine(), 0);	
				if(inputComponent[1] != null) {
					function.setNoiseEngine(inputComponent[1].getNoiseEngine(), 1);	
					function.makePreview();
				}
			}
		}
		
		NoiseComponent tmp;
		
		for(int i = 0; i < componentConnectedToOutput.size(); i++) {
			tmp = (NoiseComponent)componentConnectedToOutput.get(i);
			tmp.refreshDownStreamPreview();	
//			tmp.repaint();
		}
		
//		if(getTopLevelAncestor() != null) {
	//		getTopLevelAncestor().repaint();		
//		}
		owner.repaint();
		
	}	
	
	public boolean acceptComponentAsInput(NoiseComponent component) {
		return true;
	}
	
	public boolean acceptComponentForOutput(NoiseComponent component) {
		return true;
	}

	public NoiseComponent getInputComponentForPoint(Point basisPoint) {

		if(!getBounds().contains(basisPoint)) {
			return null;
		}
		
		if(basisPoint.x - getLocation().x < 32) {
			/* return left hand point */
			return inputComponent[0];
		}

		return inputComponent[1];			
	}

	public int getComponentTypeForPoint(Point basisPoint) {		

		if(getBounds().contains(basisPoint)) {
			if(basisPoint.y < getLocation().y + 32) {	
				return POINT_SELECTS_INPUT_COMPONENT;
			} else {
				return POINT_SELECTS_OUTPUT_COMPONENT;
			}
		}	
	
		return POINT_OUT_OF_BOUNDS;
	
	}

	
}
