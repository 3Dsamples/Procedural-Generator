/*
 * Created on Sep 13, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.Point;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import Utilities.NoiseEngine;
import Utilities.PostProcess;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */

public class PostProcessComponent extends NoiseComponent {

	final private Ellipse2D.Double ellipse = new Ellipse2D.Double(4,4,58,58);
	final private Ellipse2D.Double inputSlot = new Ellipse2D.Double(29,4,8,8);
	final private Ellipse2D.Double outputSlot = new Ellipse2D.Double(29,54,8,8);
	final private Ellipse2D.Double shadowEllipse = new Ellipse2D.Double(7,7,61,61);
	
	private NoiseComponent inputComponent;
	
	public PostProcessComponent(JFrame owner, ComponentPanel componentPanel){
		super(owner, componentPanel);
	}
	
	public JoinComponent connectToComponent(NoiseComponent noise, Point noiseEnd, Point thisEnd) {
		// Connects components together. Only called when the connection drag ends on the component
		// This function has to be overriden!
		// Function components have both input and output slots
		if(noise == this || noise == null) {
			return null;
		}
		if(thisEnd.y < getLocation().y + 32) {
			// If the dragEnd is in the top half attempt to connect to the noises output slot			
			noise.connectToOutput(this, noiseEnd, thisEnd);	
			return new JoinComponent(this, noise);
		} else {
			// If the dragEnd is in the bottom half attempt to connect to the noises input slot
			// PostProcess can only connect its output to other PostProcess and Terrain
			if(noise instanceof PostProcessComponent || noise instanceof TerrainComponent ) {
				releaseComponent(noise);
				noise.connectToInput(this, noiseEnd, thisEnd);
				if(componentConnectedToOutput.contains(noise) == false) {
					componentConnectedToOutput.add(noise);
				}
				return new JoinComponent(noise, this);
			} else {
				return null;
			}
		}

	}

	public boolean connectToInput(NoiseComponent component, Point thisEnd, Point noiseEnd) {
		// connects components together.
		// Functions have an input connection, keep NoiseEngine reference
		
		
		releaseComponent(component);  // avoid loops
		if(inputComponent != null) {
			inputComponent.releaseComponent(this);
		}
		inputComponent = component;	
		PostProcess tmpEngine = (PostProcess)noiseEngine;
		tmpEngine.setNoiseEngine(component.getNoiseEngine());
		refreshDownStreamPreview();
		return true;
	}

	public void releaseComponent(NoiseComponent component) {
		// releases compoent if joined to a slot
		if(component == inputComponent) {
			inputComponent = null;
		}
		componentConnectedToOutput.remove(component);
		
		return;
	}

	public boolean connectToOutput(NoiseComponent component, Point thisEnd, Point noiseEnd) {
		// connects components together.
		// Functions have an output connection, connect it to the components input
		if(component.connectToInput(this, noiseEnd, thisEnd)) {
			releaseComponent(component);
			if(componentConnectedToOutput.contains(component) == false) {
				componentConnectedToOutput.add(component);
			}
			return true;
		} 
		return false;
		
	}
	
	public Point getConnectionPoint(NoiseComponent noise) {
		if(noise == inputComponent) {
			return new Point(getLocation().x + 33, getLocation().y+4);
		}
		
		return new Point(getLocation().x + 33, getLocation().y+58);			
		
		
		
	}

	public void paintComponent(Graphics g) {
		// paints input and output slots
		Graphics2D g2 = (Graphics2D)g;
		
		AffineTransform saveAT = g2.getTransform();
		g2.translate(location.x, location.y);
		
		Shape clip =  g2.getClip();


		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setStroke(stroke);
		if(selected) {
			g2.setColor(shadowColor);
			g2.fill(shadowEllipse);
			g2.setColor(Color.WHITE);
			g2.fill(ellipse);
			g2.setColor(Color.red);
		}
		g2.draw(ellipse);
		g2.clip(ellipse);
		g2.setPaint(Color.green);
 		noiseEngine.paintIcon(g2, this);
		g2.setClip(clip);
		g2.setPaint(Color.white);
		g2.fill(inputSlot);
		g2.setPaint(Color.red);
		g2.fill(outputSlot);
		g2.setPaint(Color.black);
		g2.draw(inputSlot);
		g2.draw(outputSlot);
		
		g2.setTransform(saveAT);

	}
	
	public NoiseComponent[] getConnectedComponents() {
		/** returns the component providing input to the Function */
		if(inputComponent != null) {			
			NoiseComponent[] tmp = new NoiseComponent[1]; 
			tmp[0] = inputComponent; 
			return tmp;
		}
		
		return null;
			
	}
	
	public NoiseEngine getNoiseEngine() {
		if(inputComponent != null) {
			PostProcess tmpEngine = (PostProcess)noiseEngine;
			tmpEngine.setNoiseEngine(inputComponent.getNoiseEngine());
		}
		return noiseEngine;
	}

	public void setNoiseEngine(NoiseEngine noiseEngine) {
		this.noiseEngine = noiseEngine;
		name = noiseEngine.name();
	//	noiseEngine.setComponent(this);
		refreshDownStreamPreview();
		System.err.println("Setting noise to " + this.noiseEngine.name());
	}
	
	
	public void releaseFromAll() {

		super.releaseFromAll();
		
		if(inputComponent != null) {
			inputComponent.releaseComponent(this);
		}
	}
	
	public void setPostProcess(NoiseMenuItem item) {
		setNoiseEngine( item.getNoiseEngine());
		return;
	}
	
	public JPopupMenu getPopUp(ActionListener actionListner, ComponentPanel componentPanel) {
		JPopupMenu menu = new JPopupMenu();
		JMenuItem menuItem = new JMenuItem("Properties...");
		JPanel tmpPanel = noiseEngine.getPanel();
		 
		if(tmpPanel != null) {
			menuItem.addActionListener(actionListner);
		} else {
			menuItem.setEnabled(false);
		}
		menu.add(menuItem);
		PostProcessMenu noiseMenu = new PostProcessMenu(new PostProcessMenuActionPerformed(), "Replace Process");
		menu.add(noiseMenu);
		
		menuItem = new JMenuItem("Delete");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		if(componentConnectedToOutput.isEmpty()) {
			menuItem = new JMenuItem("Detach");
			menuItem.setEnabled(false);
			menu.add(menuItem);
		} else {
			JMenu outputComponentMenu = new OutputComponentMenu(componentPanel);
			menu.add(outputComponentMenu);
		}
		menuItem = new JMenuItem("Preview");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		return menu;
		
	}

	private class PostProcessMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			NoiseMenuItem item = (NoiseMenuItem)arg0.getSource();
			setNoiseEngine(item.getNoiseEngine());
			componentPanel.propsPane.displayFor(PostProcessComponent.this);
			refreshUpStreamPreview();
			refreshDownStreamPreview();
		}
	}
	

	public void saveJoins(ObjectOutputStream file, ArrayList components ) throws IOException {

		
		file.writeObject("componentsConnectedToOutput");
		file.writeObject("" + componentConnectedToOutput.size() );
		for(int i = 0; i < componentConnectedToOutput.size(); i++) {
			file.writeObject(""+components.indexOf(componentConnectedToOutput.get(i)));
		}				
		file.writeObject(""+components.indexOf(inputComponent));
	}
	
	public NoiseComponent loadJoins(ObjectInputStream file, ArrayList<NoiseComponent> components, ArrayList<JoinComponent> joins) throws ClassNotFoundException, IOException {

		NoiseComponent connectedToTerrain = null;
		NoiseComponent component;
		
		String index = (String)file.readObject();
		if(index.compareTo("componentsConnectedToOutput") != 0) {
			int i = Integer.parseInt(index);
			if(i > -1) {
				
				component = components.get(i);
				componentConnectedToOutput.add(component);
				
	   			if(null == NoiseComponent.findJoin(joins, this, component) ) {
	   				joins.add(new JoinComponent(this, component));
	   			}

	   			if(i == 0) {
					connectedToTerrain = this;
				}				
			}
		} else {
			int j;
			index = (String)file.readObject();
			int count = Integer.parseInt(index);
			for(int i = 0; i < count; i++ ) {
				index = (String)file.readObject();
				j = Integer.parseInt(index);
				if(j > -1) {

					component = components.get(j);
					componentConnectedToOutput.add(component);
					
		   			if(null == NoiseComponent.findJoin(joins, this, component) ) {
		   				joins.add(new JoinComponent(component, this));
		   			}

					
					if(j == 0) {
						connectedToTerrain = this;
					}					}				
			}
		}
				
		index = (String)file.readObject();
		int i = Integer.parseInt(index);
		if(i > -1) {
			inputComponent = (NoiseComponent)components.get(i);
			PostProcess tmpEngine = (PostProcess)noiseEngine;
			tmpEngine.setNoiseEngine(inputComponent.getNoiseEngine());
		}

		return connectedToTerrain;
			
		
	}	

	private class OkayListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			noiseEngine.storeSettings();
			refreshDownStreamPreview();
			frame.setVisible(false);

		}
	}

	private class ApplyListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			noiseEngine.storeSettings();
			refreshDownStreamPreview();
		}
	}

	private class CancelListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			noiseEngine.restoreSettings(); 
		}
	}
	
	

	public void refreshUpStreamPreview() {
		
		
		if(inputComponent != null) {
			inputComponent.refreshUpStreamPreview();
		}
		
		if(noiseEngine != null) {
			noiseEngine.makePreview();
		}
		
		owner.repaint();		
		
	}

	public void refreshDownStreamPreview() {
		if(noiseEngine != null) {
			noiseEngine.makePreview();
//			if(getTopLevelAncestor() != null) {
//				getTopLevelAncestor().repaint();		
//			}
			owner.repaint();		
			

		}
		
		NoiseComponent tmp;
		
		for(int i = 0; i < componentConnectedToOutput.size(); i++) {
			tmp = (NoiseComponent)componentConnectedToOutput.get(i);
			tmp.refreshDownStreamPreview();	
//			tmp.repaint();
		}
		
		owner.repaint();
		
	}	

	public String getToolTipText() {
		return "<b><u>" + noiseEngine.name() + "</u></b><br><br>" + noiseEngine.description() + "<br><br>" + noiseEngine.getDetails();
	}
	
	public boolean acceptComponentAsInput(NoiseComponent component) {
		return true;
	}	
	
	public boolean acceptComponentForOutput(NoiseComponent component) {

		if(component instanceof PostProcessComponent || component instanceof TerrainComponent ) {
			return true;
		} 
		
		return false;
	}
	
	public NoiseComponent getInputComponentForPoint(Point basisPoint) {
		if(getBounds().contains(basisPoint)) {
			return inputComponent;
		}
		
		return null;
	}	

	public int getComponentTypeForPoint(Point basisPoint) {		

		if(getBounds().contains(basisPoint)) {
			if(basisPoint.y < getLocation().y + 32) {	
				return POINT_SELECTS_INPUT_COMPONENT;
			} else {
				return POINT_SELECTS_OUTPUT_COMPONENT;
			}
		}	
	
		return POINT_OUT_OF_BOUNDS;
	
	}

	
}
