/*
 * Created on Aug 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileFilter;

import Utilities.Factory;
import Utilities.Landscape;
import Utilities.MeshFactory;
import Utilities.PNGFactory;
import Utilities.SGIFactory;
import Utilities.Planet;
import Utilities.TerragenFactory;
import Utilities.Torus;

/**
 * @author vargol
 * 
 * To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Generation - Code and Comments
 */
public class OutputPanel extends JPanel {

	private JButton FactorySettings;

	private JButton browse;

	private JComboBox FactoryDropdown;

	private JPanel FactoryPanel;

	private JPanel FilePanel;

	private JTextField FileName;

	private Factory factory;

	private Landscape terrain;

	private String type;

	private JFrame owner;
	
	private static final int PNG = 0;
	private static final int POV = 1;
	private static final int TERRAGEN = 2;
	private static final int YAFRAY = 3;
	private static final int SGI = 4;
	private static final int WAVEFRONT = 5;
	
	private static final int LANDSCAPE = 0;
	private static final int PLANET = 1;
	private static final int TORUS = 2;

	public OutputPanel(JFrame owner) {

		initComponents();
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit()
				.getScreenSize();
		java.awt.Dimension frameSize = getPreferredSize();
		setLocation(screenSize.width / 2 - (frameSize.width / 2),
				screenSize.height / 2 - (frameSize.height / 2));

		FactoryDropdown.addItem(new TerrainFactoryComboItem("Landscape PNG", PNG, LANDSCAPE));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Planet PNG", PNG, PLANET));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Torus PNG", PNG, TORUS));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Landscape Mesh",POV, LANDSCAPE));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Planet Mesh", POV, PLANET));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Torus Mesh", POV, TORUS));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Landscape SGI", SGI, LANDSCAPE));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Planet SGI", SGI, PLANET));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Torus SGI", SGI, TORUS));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Terragen File", TERRAGEN, LANDSCAPE));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Wavefront Landscape Mesh", WAVEFRONT, LANDSCAPE));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Wavefront Planet Mesh", WAVEFRONT, PLANET));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("Wavefront Torus Mesh", WAVEFRONT, TORUS));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("YAFRAY Landscape Mesh", YAFRAY, LANDSCAPE));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("YAFRAY Planet Mesh", YAFRAY, PLANET));
		FactoryDropdown.addItem(new TerrainFactoryComboItem("YAFRAY Torus Mesh", YAFRAY, TORUS));
		this.owner = owner;
	}

	private void initComponents() {

		FactoryDropdown = new JComboBox();
		FactorySettings = new JButton();
		browse = new JButton();
		FactoryPanel = new JPanel();
		FilePanel = new JPanel();
		FileName = new JTextField();

		setLayout(new BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));
		FactoryPanel.setLayout(new BoxLayout(FactoryPanel,
				javax.swing.BoxLayout.Y_AXIS));
		FactoryPanel.setBorder(new TitledBorder(null, "Terrain Type.",
				TitledBorder.DEFAULT_JUSTIFICATION,
				TitledBorder.DEFAULT_POSITION, new Font("Dialog", 3, 11)));

		FactoryDropdown.setMaximumSize(new java.awt.Dimension(32767, 25));
		FactoryDropdown.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				factoryDropdownActionPerformed(evt);
			}
		});

		FactoryPanel.add(FactoryDropdown);

		FactorySettings.setText("Settings");
		FactorySettings.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				factorySettingsActionPerformed(evt);
			}
		});
		FactoryPanel.add(FactorySettings);
		add(FactoryPanel);

		FilePanel.setBorder(new javax.swing.border.TitledBorder(null,
				"File Name.",
				javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION,
				javax.swing.border.TitledBorder.DEFAULT_POSITION,
				new java.awt.Font("Dialog", 3, 11)));
		FileName.setText(System.getProperty("user.home")
				+ System.getProperty("file.separator") + "genesis.png");
		FileName.setPreferredSize(new java.awt.Dimension(300, 32));
		FilePanel.add(FileName);
		browse.setText("Browse");
		browse.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				browseButtonActionPerformed(evt);
			}
		});
		FilePanel.add(browse);

//		JButton okay = new JButton("Ok");
//		okay.addActionListener(new java.awt.event.ActionListener() {
//			public void actionPerformed(java.awt.event.ActionEvent evt) {
//				getTopLevelAncestor().setVisible(false);
//			}
//		});
		//dont need them for new properties system
		
		FactoryDropdown.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				factoryDropdownActionPerformed(evt);
			}
		});

		add(FilePanel);
//		add(okay);

	}

	private void factoryDropdownActionPerformed(java.awt.event.ActionEvent evt) {
		// Add your handling code here:
		JFileChooser fileChooser = new JFileChooser();
		TerrainFactoryComboItem selection = (TerrainFactoryComboItem) FactoryDropdown.getSelectedItem();
		String name = FileName.getText();

		switch (selection.terrainType) {
			case LANDSCAPE:
				terrain = new Landscape();
				break;
			case PLANET:
				terrain = new Planet();
				break;
			case TORUS:
				terrain = new Torus();
				break;		
		}

		switch (selection.outputType) {
		case PNG:
			factory = new PNGFactory(terrain);			
			if (!name.endsWith(".png") && !name.endsWith(".PNG")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".png";
			}
			type = "PNG";
			break;
		case POV:
			if (!name.endsWith(".pov") && !name.endsWith(".POV")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".pov";
			}
			factory = new MeshFactory();			
			type = "POV";
			break;
		case TERRAGEN:
			factory = new TerragenFactory();			
			if (!name.endsWith(".ter") && !name.endsWith(".TER")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".ter";
			}			
			type = "TERRAGEN";
			break;
		case YAFRAY:
			factory = new MeshFactory();
			if (!name.endsWith(".xml") && !name.endsWith(".XML")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".xml";
			}
			type = "YAFRAY";
			break;
		case SGI:
			factory = new SGIFactory();
			type = "SGI";
			if (!name.endsWith(".bw") && !name.endsWith(".BW")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".bw";
			}			
			break;
		case WAVEFRONT:
			factory = new MeshFactory();
			type = "WAVEFRONT";
			if (!name.endsWith(".obj") && !name.endsWith(".OBJ")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".obj";
			}			
			break;
		default:
			break;
		}
		
		factory.setLandscape(terrain);
		FileName.setText(name);

	}

	/*
	private void oldfactoryDropdownActionPerformed(java.awt.event.ActionEvent evt) {
		// Add your handling code here:
		JFileChooser fileChooser = new JFileChooser();
		String selection = (String) FactoryDropdown.getSelectedItem();
		String name = FileName.getText();

		if (selection.compareTo("Landscape PNG") == 0) {
			fileChooser.addChoosableFileFilter(new savePNGFilter());
			terrain = new Landscape();
			factory = new PNGFactory(terrain);
			if (!name.endsWith(".png") && !name.endsWith(".PNG")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".png";
			}
			type = "PNG";
		} else if (selection.compareTo("Landscape Mesh") == 0) {
			fileChooser.addChoosableFileFilter(new savePOVFilter());
			fileChooser.addChoosableFileFilter(new saveOBJFilter());
			terrain = new Landscape();
			factory = new MeshFactory();
			if (!name.endsWith(".pov") && !name.endsWith(".obj")
					&& !name.endsWith(".POV") && !name.endsWith(".OBJ")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".pov";
			}
			if (name.endsWith(".obj") || name.endsWith(".OBJ")) {
				type = "OBJ";
			} else if (name.endsWith(".pov") || name.endsWith(".inc")) {
				type = "POV";
			}
		} else if (selection.compareTo("Planet PNG") == 0) {
			fileChooser.addChoosableFileFilter(new savePNGFilter());
			terrain = new Planet();
			factory = new PNGFactory(terrain);
			if (!name.endsWith(".png") && !name.endsWith(".PNG")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".png";
			}
			type = "PNG";
		} else if (selection.compareTo("Planet Mesh") == 0) {
			fileChooser.addChoosableFileFilter(new savePOVFilter());
			fileChooser.addChoosableFileFilter(new saveOBJFilter());
			terrain = new Planet();
			factory = new MeshFactory();
			if (!name.endsWith(".pov") && !name.endsWith(".obj")
					&& !name.endsWith(".POV") && !name.endsWith(".OBJ")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".pov";
			}
			if (name.endsWith(".obj") || name.endsWith(".OBJ")) {
				type = "OBJ";
			} else if (name.endsWith(".pov") || name.endsWith(".inc")) {
				type = "POV";
			}
		} else if (selection.compareTo("Terragen File") == 0) {
			fileChooser.addChoosableFileFilter(new saveTerragenFilter());
			factory = new TerragenFactory();
			terrain = new Landscape();
			if (!name.endsWith(".ter") && !name.endsWith(".TER")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".ter";
			}
		} else if (selection.compareTo("YAFRAY Landscape Mesh") == 0) {
			fileChooser.addChoosableFileFilter(new saveYafRayFilter());
			terrain = new Landscape();
			factory = new MeshFactory();
			if (!name.endsWith(".xml") && !name.endsWith(".XML")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".xml";
			}
			type = "YAFRAY";
		} else if (selection.compareTo("YAFRAY Planet Mesh") == 0) {
			fileChooser.addChoosableFileFilter(new saveYafRayFilter());
			terrain = new Planet();
			factory = new MeshFactory();
			if (!name.endsWith(".xml") && !name.endsWith(".XML")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".xml";
			}
			type = "YAFRAY";
		} else if (selection.compareTo("Planet SGI") == 0) {
			fileChooser.addChoosableFileFilter(new saveSGIFilter());
			terrain = new Planet();
			factory = new SGIFactory();
			if (!name.endsWith(".bw") && !name.endsWith(".BW")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".bw";
			}
			type = "SGI";
		} else if (selection.compareTo("Landscape SGI") == 0) {
			fileChooser.addChoosableFileFilter(new saveSGIFilter());
			terrain = new Landscape();
			factory = new SGIFactory();
			if (!name.endsWith(".bw") && !name.endsWith(".BW")) {
				name = name.substring(0, name.lastIndexOf("."));
				name += ".bw";
			}
			type = "SGI";
		} 

		factory.setLandscape(terrain);
		FileName.setText(name);

	}
*/
	private void showDialog(JDialog frame, String name) {

		// frame.setDimensions(factory.getDimensions());
		frame.pack();
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit()
				.getScreenSize();
		java.awt.Dimension frameSize = frame.getPreferredSize();
		frame.setSize(frame.getPreferredSize());
		frame.setLocation(screenSize.width / 2 - (frameSize.width / 2),
				screenSize.height / 2 - (frameSize.height / 2));
		frame.setVisible(true);
	}

	private void factorySettingsActionPerformed(java.awt.event.ActionEvent evt) {
		showDialog(factory.getDialog(owner), factory.getName());
	}

	public String getFileName() {
		return FileName.getText();

	}

	public String getType() {
		return type;
	}

	public Factory getFactory() {
		return factory;
	}

	public Landscape getLandscape() {
		return terrain;
	}

	private class savePNGFilter extends FileFilter {
		public boolean accept(File file) {

			if (file.canWrite()) {
				String name = file.getAbsolutePath();
				return !name.endsWith(".png") && !name.endsWith(".PNG");
			}
			return false;
		}

		public String getDescription() {
			return "16bit GreyScale PNG File";
		}
	}

	private class saveSGIFilter extends FileFilter {
		public boolean accept(File file) {

			if (file.canWrite()) {
				String name = file.getAbsolutePath();
				return !name.endsWith(".bw") && !name.endsWith(".BW");
			}
			return false;
		}

		public String getDescription() {
			return "16bit GreyScale SGI File";
		}
	}	
	
	private class saveOBJFilter extends FileFilter {
		public boolean accept(File file) {

			if (file.canWrite()) {
				String name = file.getAbsolutePath();
				return !name.endsWith(".obj") && !name.endsWith(".OBJ");
			}
			return false;
		}

		public String getDescription() {
			return "Wavefront OBJ File";
		}
	}

	private class savePOVFilter extends FileFilter {
		public boolean accept(File file) {

			if (file.canWrite()) {
				String name = file.getAbsolutePath();
				return !name.endsWith(".pov") && !name.endsWith(".POV");
			}
			return false;
		}

		public String getDescription() {
			return "POV-RAY scene file";
		}
	}

	private class saveTerragenFilter extends FileFilter {
		public boolean accept(File file) {

			if (file.canWrite()) {
				String name = file.getAbsolutePath();
				return !name.endsWith(".ter") && !name.endsWith(".TER");
			}
			return false;
		}

		public String getDescription() {
			return "Terragen .ter file";
		}
	}

	private class saveYafRayFilter extends FileFilter {
		public boolean accept(File file) {

			if (file.canWrite()) {
				String name = file.getAbsolutePath();
				return !name.endsWith(".xml") && !name.endsWith(".XML");
			}
			return false;
		}

		public String getDescription() {
			return "YARFAY XML file";
		}
	}

	private void browseButtonActionPerformed(java.awt.event.ActionEvent evt) {
		// Add your handling code here:
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setSelectedFile(new File(FileName.getText()));

		
		TerrainFactoryComboItem selection = (TerrainFactoryComboItem) FactoryDropdown.getSelectedItem();
		
		switch (selection.outputType) {
		case PNG:
			fileChooser.addChoosableFileFilter(new savePNGFilter());
			break;
		case POV:
			fileChooser.addChoosableFileFilter(new savePOVFilter());
			break;
		case TERRAGEN:
			fileChooser.addChoosableFileFilter(new saveTerragenFilter());
			break;
		case YAFRAY:
			fileChooser.addChoosableFileFilter(new saveYafRayFilter());
			break;
		case SGI:
			fileChooser.addChoosableFileFilter(new saveSGIFilter());
			break;
		case WAVEFRONT:
			fileChooser.addChoosableFileFilter(new saveOBJFilter());
			break;
		default:
			break;
		}		
		
		factory.setLandscape(terrain);

		boolean notFinished = true;

		while (notFinished) {
			try {
				int returnVal = fileChooser.showSaveDialog(this);
				String name;
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					name = fileChooser.getSelectedFile().getAbsolutePath();
					if (fileChooser.getFileFilter() instanceof savePNGFilter) {
						if (!name.endsWith(".png") && !name.endsWith(".PNG")) {
							name += ".png";
						}
						type = "PNG";
					} else if (fileChooser.getFileFilter() instanceof saveOBJFilter) {
						if (!name.endsWith(".obj") && !name.endsWith(".OBJ")) {
							name += ".obj";
						}
						type = "OBJ";
					} else if (fileChooser.getFileFilter() instanceof savePOVFilter) {
						if (!name.endsWith(".pov") && !name.endsWith(".inc")) {
							name += ".pov";
						}
						type = "POV";
					} else if (fileChooser.getFileFilter() instanceof saveTerragenFilter) {
						if (!name.endsWith(".ter") && !name.endsWith(".TER")) {
							name += ".ter";
						}
						type = "POV";
					}

					File test = new File(name);
					if (test.exists()) {
						int result = JOptionPane
								.showConfirmDialog(
										this,
										"This file already exists.\nDo you want to over write it?",
										"Overwrite File ?",
										JOptionPane.YES_NO_OPTION);
						if (result == JOptionPane.YES_OPTION) {
							FileName.setText(name);
							notFinished = false;
						}
					} else {
						FileName.setText(name);
						notFinished = false;
					}
				} else {
					notFinished = false;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void save(ObjectOutputStream file) throws IOException {

		// save factory name
		file.writeObject(FactoryDropdown.getSelectedItem().toString());
		// save factory settings
		factory.save(file);
		// save file name
		file.writeObject(FileName.getText());

	}

	public void load(ObjectInputStream file) throws ClassNotFoundException,
			IOException {

		// load factory class name
		// create factory
		// pass file to factory settings
		// load file name

		String factoryClassName = (String) file.readObject();
		Object item = null;
		
		for(int i=0; i < FactoryDropdown.getItemCount(); i++) {
			if(FactoryDropdown.getItemAt(i).toString().compareTo(factoryClassName) == 0) {
				item = FactoryDropdown.getItemAt(i);
				break;
			}
		}
		
		if (item == null) {
			throw new IOException("Failed to load file, Terrian Type " + factoryClassName + " does not match expects types.")  ;
		}
		
		FactoryDropdown.setSelectedItem(item);
		factory.load(file);
		String fileName = (String) file.readObject();
		FileName.setText(fileName);

	}
	

}
