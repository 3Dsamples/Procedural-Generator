/*
 * Created on Aug 18, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.event.ActionListener;

import javax.swing.JMenu;
/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class PostProcessMenu extends JMenu {


	public PostProcessMenu(ActionListener actionListener, String menuText) {

		setText(menuText);
		NoiseMenuItem item = new NoiseMenuItem("Accurate Scale", "plugins.engines.AccurateScale");
		item.addActionListener(actionListener);
		add(item);
		item = new NoiseMenuItem("Simple Erode", "plugins.engines.Erode");
		item.addActionListener(actionListener);
		add(item);
		//Added by su_liam 12/28/07
		
		item = new NoiseMenuItem("Precipiton", "plugins.engines.Precipiton");
		item.addActionListener(actionListener);
		add(item);
		//*/	
	}




}
