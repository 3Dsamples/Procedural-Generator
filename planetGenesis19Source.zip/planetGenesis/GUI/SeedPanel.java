/*
 * Created on May 30, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
/*
Copyright (c) 2004, David Burnett

All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
Neither the name of the copyright holder nor the names of its
contributors may be used to endorse or promote products
derived from this software without specific prior
written permission.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT
NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
         SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
         OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/
package GUI;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JTextField;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public final class SeedPanel extends Box {
	final private JTextField seed = new JTextField();
	final private JButton randomize = new JButton("Randomize");
	final private Random rand = new Random();

	public SeedPanel() {
		super(BoxLayout.Y_AXIS);
 //       setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));
        setBorder(new javax.swing.border.TitledBorder(null, "Seed", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.TOP, new java.awt.Font("Dialog", 1, 11), new java.awt.Color(255, 0, 0)));
        setForeground(new java.awt.Color(0, 0, 0));
        seed.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        Dimension dimension = new Dimension(200, 20);
        seed.setMinimumSize(dimension);
        seed.setMaximumSize(new Dimension(4000, 20));
        seed.setPreferredSize(dimension);
        
        add(seed);
        randomize.addActionListener( new seedAction());
        add(randomize);
		add(Box.createVerticalGlue());
      

	}
	
	public String getText() {
		return seed.getText();
	}
	
	public void setText(String value) {
		seed.setText(value);
		return;
	}
	
	
	final private class seedAction implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			rand.setSeed(System.currentTimeMillis());
			seed.setText(""+rand.nextInt());  
		}	
	}
}
