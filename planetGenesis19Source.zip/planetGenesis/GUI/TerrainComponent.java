/*
 * Created on Sep 13, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.Point;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;


/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class TerrainComponent extends NoiseComponent {

	final private Ellipse2D.Double ellipse = new Ellipse2D.Double(4,4,58,58);
	final private Ellipse2D.Double shadowEllipse = new Ellipse2D.Double(7,7,61,61);
	final private Ellipse2D.Double inputSlot = new Ellipse2D.Double(29,4,8,8);

	private NoiseComponent inputComponent;
	private Utilities.Factory factory;
	final protected OutputPanel panel;
	
	TerrainComponent(JFrame owner, ComponentPanel componentPanel) {
		super(owner, componentPanel);
		name = "Terrain";
		panel = new OutputPanel(owner);
	}
	
	public JoinComponent connectToComponent(NoiseComponent noise, Point noiseEnd, Point thisEnd) {
		// connects components together. Only called when the connection drag ends on the component
		if(noise == null || noise == this) {
			return null;
		}
		
		// I'm a terrain component, so I can only connect to a output stream
		if(!noise.connectToOutput(this, noiseEnd, thisEnd)) {
			//throw an error dialog
			System.err.println("Could not connect to Output Stream");
			return null;
		}
		return new JoinComponent(this, noise);
	}

	public boolean connectToInput(NoiseComponent noise, Point dragEnd, Point noiseEnd) {
		// connects components together.
		// I have an input connection, connect it to the other noises output
		if(inputComponent != noise && inputComponent != null) {
			inputComponent.releaseComponent(this);
		}
		inputComponent = noise;
		return true;
	}


	public boolean connectToOutput(NoiseComponent noise, Point dragEnd, Point noiseEnd) {
		// connects components together.
		// I have no output connections
		return false;
	}
	
	public Point getConnectionPoint(NoiseComponent noise) {
		return new Point(getLocation().x + 33, getLocation().y+4);
	}

	public void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
		
		AffineTransform saveAT = g2.getTransform();
		g2.translate(location.x, location.y);

		
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setStroke(stroke);
		if(selected) {
			g2.setColor(shadowColor);
			g2.fill(shadowEllipse);
			g2.setColor(Color.WHITE);
			g2.fill(ellipse);
			g2.setColor(Color.red);
		}
		g2.draw(ellipse);
		g2.setPaint(Color.white);
		g2.fill(inputSlot);
		g2.setPaint(Color.black);
		g2.draw(inputSlot);

		g2.setTransform(saveAT);

	}
	
	public NoiseComponent[] getConnectedComponents() {
		if(inputComponent != null) {			
			NoiseComponent[] tmp = new NoiseComponent[1]; 
			tmp[0] = inputComponent; 
			return tmp;
		}
		
		return null;
			
	}

	public void releaseComponent(NoiseComponent component) {
		// releases component if joined to an input slot
		System.err.println("releaseComponent " + component);
		System.err.println("inputComponent " + inputComponent);
		if(component == inputComponent) {
			inputComponent = null;		
		}
		return;
	}

	public OutputPanel getPanel() {
		// releases component if joined to an input slot
		return panel;
	}

	public JPopupMenu getPopUp(ActionListener actionListner, ComponentPanel componentPanel) {
		JPopupMenu menu = new JPopupMenu();
		JMenuItem menuItem = new JMenuItem("Properties...");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		menuItem = new JMenuItem("Run");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		return menu;
	}

	public void run(final JFrame owner) {	
		factory = panel.getFactory();
		File test = new File(panel.getFileName());	
		if(test.exists()) {
			int result = JOptionPane.showConfirmDialog(owner, "This file already exists.\nDo you want to over write it?", "Overwrite File ?",  JOptionPane.YES_NO_OPTION);
			if(result != JOptionPane.YES_OPTION) {
				return;			
			}
		}
		
		factory.setFile(panel.getFileName(), panel.getType());
		factory.setEngine(inputComponent.getNoiseEngine());
		
		final GUI.Progress progress = new Progress(panel.getFileName(), owner);
		Thread make = new Thread () {
			public void run() {
				long time = factory.make(progress, true);  
				if(time >= 0) {
					JOptionPane.showMessageDialog(owner, panel.getFileName() + "\nCompletion time: " + (time / 1000) + " seconds.", "Finished", JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
		};
		make.start();

	}
	
	public void batchRun(final JFrame owner) {	
		factory = panel.getFactory();
	
		factory.setFile(panel.getFileName(), panel.getType());
		factory.setEngine(inputComponent.getNoiseEngine());
		
		final GUI.Progress progress = new Progress(panel.getFileName(), owner);
		factory.make(progress, true);  			

	}

	public String getToolTipText() {
		return "<b><i>Terrain</i></b><br><p><b>Type</b>: " + panel.getFactory().getName() + "</p>";
	};

	
	public void save(ObjectOutputStream file) throws IOException {
		 
		file.writeObject(this.getClass().getName());
         file.writeObject(this.getLocation());
         panel.save(file);
 
	}
 
    public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {
 
         Point position = (Point)file.readObject();
		this.setLocation(position);
		panel.load(file);
 
    }
 
   public void saveJoins(ObjectOutputStream file, ArrayList components ) throws IOException {
 
       	file.writeObject("componentsConnectedToOutput");
		file.writeObject("" + 0);
		file.writeObject("" + components.indexOf(inputComponent));
		
   }
 
   public NoiseComponent loadJoins(ObjectInputStream file, ArrayList<NoiseComponent> components, ArrayList<JoinComponent> joins) throws ClassNotFoundException, IOException {
 
   		String index = (String)file.readObject();
 
   		index = (String)file.readObject();
   		index = (String)file.readObject(); // yes this second one is required....
 
   		int i = Integer.parseInt(index);
   		if(i > -1) {
   			inputComponent = components.get(i);
   			if(null == NoiseComponent.findJoin(joins, this, inputComponent) ) {
   				joins.add(new JoinComponent(this, inputComponent));
   			}
   			
   		}
 
   		return inputComponent;	
   }

	public boolean acceptComponentAsInput(NoiseComponent component) {
		return true;
	}	
	
	public NoiseComponent getInputComponentForPoint(Point basisPoint) {
		if(getBounds().contains(basisPoint)) {
			return inputComponent;
		}
		
		return null;
	}	
	
	public int getComponentTypeForPoint(Point basisPoint) {		

		if(getBounds().contains(basisPoint)) {
			return POINT_SELECTS_INPUT_COMPONENT;
		}	
	
		return POINT_OUT_OF_BOUNDS;
	
	}
	
}
