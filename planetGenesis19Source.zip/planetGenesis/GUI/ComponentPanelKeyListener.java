package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import GUI.ComponentPanel.LoadMenuActionPerformed;
import GUI.ComponentPanel.SaveMenuActionPerformed;

public class ComponentPanelKeyListener extends KeyAdapter implements ActionListener
{
	ComponentPanel p;
	SaveMenuActionPerformed saver;
	LoadMenuActionPerformed loader;
	
	public ComponentPanelKeyListener(ComponentPanel panel)
	{
		p=panel;
		saver=p.new SaveMenuActionPerformed();
		loader=p.new LoadMenuActionPerformed();
//		System.out.println("created");
	}

	@Override
	public void keyTyped(KeyEvent e)
	{
		int k=Character.toUpperCase(e.getKeyChar());
		System.out.println("typed "+k+" "+KeyEvent.getModifiersExText(e.getModifiersEx()));
	
		if(k==KeyEvent.VK_TAB)// never triggered !
		{
			//change selected component
			System.out.println("tab");
		}
		else if(k==KeyEvent.VK_P)
		{
			try {
				if(p.focussedComponent!=null)
					p.preview.ShowGeometry(p.preview.makePreview(p.focussedComponent.getNoiseEngine()));
			}catch(Throwable err)
			{
				p.showPreviewError(err);
			}
		}
		else if(k==19)// ctrl s, HACK
		{
			saver.actionPerformed(new ActionEvent(p, e.getID(), "Save"));
		}
		else if(k==12)//ctrl l, HACK
		{
			loader.actionPerformed(new ActionEvent(p, e.getID(), "Load"));
		}
		super.keyTyped(e);
	}

	public void actionPerformed(ActionEvent e)
	{
		System.out.println("Comp List "+e.getActionCommand());
	}
	
	

}
