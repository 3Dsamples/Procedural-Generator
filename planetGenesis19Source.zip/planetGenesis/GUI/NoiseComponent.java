/*
 * Created on Sep 12, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package GUI;

import java.awt.Color;
//import java.awt.event.ActionEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.ImageObserver;
import java.awt.Point;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JDialog;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import GUI.ComponentPanel;
import GUI.ComponentPanel.JoinRemovalListener;
import Utilities.NoiseEngine;

/**
 * @author vargol
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class NoiseComponent /*extends JComponent*/ implements ImageObserver {
	
	final protected Rectangle2D.Double rect = new Rectangle2D.Double(0,0,63,63);
	final protected Rectangle2D.Double shadowRect = new Rectangle2D.Double(3,3,66,66);
	final protected BasicStroke stroke = new BasicStroke(2.0f);
	final protected Color selColor=Color.red;
	final protected Color shadowColor=new Color(0.0f, 0.0f, 0.0f, 0.3f);
	
	final private Ellipse2D.Double outputSlot = new Ellipse2D.Double(29,54,8,8);
//	final protected JFrame frame = new JFrame();
	final protected JDialog frame;
	final protected NoisePanel panel = new NoisePanel();

	final public static int POINT_OUT_OF_BOUNDS = 0;
	final public static int POINT_SELECTS_INPUT_COMPONENT = 1;
	final public static int POINT_SELECTS_OUTPUT_COMPONENT = 2;
	
	
	protected ArrayList<NoiseComponent> componentConnectedToOutput;
	protected NoiseEngine noiseEngine;	
	protected String name;	
	protected ComponentPanel componentPanel; 

	protected boolean selected=false;

	/* replacements for JComponent */
	protected Point location = new Point(0,0);
	protected Rectangle bounds= new Rectangle(0,0,0,0);
	protected JFrame owner;
	
	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */

	public NoiseComponent(JFrame owner, ComponentPanel componentPanel) { 
		this.owner = owner;
		this.componentPanel = componentPanel; 
		frame = new JDialog(owner);

//		setPreferredSize(new java.awt.Dimension(70,70));
		setSize(new java.awt.Dimension(70,70));
		componentConnectedToOutput = new ArrayList<NoiseComponent>(3);
	}

	/**
	 * @return
	 */
	public NoiseEngine getNoiseEngine() {
		return noiseEngine;
	}

	/**
	 * @param noiseEngine
	 */
	public void setNoiseEngine(NoiseEngine noiseEngine) {
		this.noiseEngine = noiseEngine;
		name = noiseEngine.name();
	//	noiseEngine.setComponent(this);
		refreshDownStreamPreview();
		System.err.println("Setting noise to " + this.noiseEngine.name());
	}


	public void paintComponent(Graphics g) {
		// CombinerComponent draws the output connector
		// In subclasses call super.paintComponent after drawing the classes
		// icon.
		
		Graphics2D g2 = (Graphics2D)g;
		
		AffineTransform saveAT = g2.getTransform();
		g2.translate(location.x, location.y);
		
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		if(selected) {
			g2.setColor(shadowColor);
			g2.fill(shadowRect);
		}
		g2.setStroke(stroke);
 		noiseEngine.paintIcon(g2, this);
		if(selected) {
			g2.setColor(selColor);
		}
		g2.draw(rect);
		g2.setPaint(Color.red);
		g2.fill(outputSlot);
		g2.setPaint(Color.black);
		g2.draw(outputSlot);
		
		g2.setTransform(saveAT);

	}
	
	public NoiseComponent[] getConnectedComponents() {
		return null;
	}

	public Point getConnectionPoint(NoiseComponent noise) {
		return new Point(getLocation().x + 33, getLocation().y + 60);
	}
	
	public JoinComponent connectToComponent(NoiseComponent noise, Point noiseEnd, Point thisEnd) {
		// connects components together. Only called when the connection drag ends on the component
		// I'm noise component, so I can only connect to a input stream
		if(noise == this) {
			return null;
		}
		
		releaseComponent(noise);
		if(!noise.connectToInput(this, noiseEnd, thisEnd)) {
			//throw an error dialog
			System.err.println("Could not connect to input Stream");
			return null;
		}

		if(componentConnectedToOutput.contains(noise) == false) {
			componentConnectedToOutput.add(noise);
		}
		return new JoinComponent(noise, this);
		
	}

	public boolean connectToInput(NoiseComponent component, Point thisEnd, Point noiseEnd) {
		// connects components together.
		// I have no input connections
			return false;
	}

	public boolean connectToOutput(NoiseComponent noise, Point thisEnd, Point noiseEnd) {
		// connects components together.
		// I have an output connection, connect it to the other noises input

		if(!noise.connectToInput(this, noiseEnd, thisEnd)) {
			//throw an error dialog
			System.err.println("Could not connect to input Stream");
			return false;
		}

		if(componentConnectedToOutput.contains(noise) == false) {
			componentConnectedToOutput.add(noise);
		}
		return true;
		
	}

	public void releaseComponent(NoiseComponent component) {
		// releases component if joined to an input slot
		if(componentConnectedToOutput.contains(component)) {
			componentConnectedToOutput.remove(component);
		}
		return;
	}
	
	public boolean contains (Point point) {
		return getBounds().contains(point);
	}
	
	public JPopupMenu getPopUp(ActionListener actionListner, ComponentPanel componentPanel) {
		JPopupMenu menu = new JPopupMenu();
		JMenuItem menuItem = new JMenuItem("Properties...");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		NoiseMenu noiseMenu = new NoiseMenu(new NoiseMenuActionPerformed(), "Replace Noise");
		menu.add(noiseMenu);
		menuItem.addActionListener(actionListner);
		menuItem = new JMenuItem("Copy");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		if(componentConnectedToOutput.isEmpty()) {
			menuItem = new JMenuItem("Detach");
			menuItem.setEnabled(false);
			menu.add(menuItem);
		} else {
			JMenu outputComponentMenu = new OutputComponentMenu(componentPanel);
			menu.add(outputComponentMenu);
		}
		menuItem = new JMenuItem("Delete");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		menuItem = new JMenuItem("Preview");
		menuItem.addActionListener(actionListner);
		menu.add(menuItem);
		return menu;
	}
	
	public void showPanel() {
    	
		frame.setTitle(noiseEngine.name());
		OkApplyRestorePanel oacPanel = this.panel.getOacPanel();
		oacPanel.addOkayActionListener(new OkayListener());
		oacPanel.addApplyActionListener(new ApplyListener());
		oacPanel.addCancelActionListener(new CancelListener());
		this.panel.addEnginePanel(noiseEngine.getPanel());
		frame.getContentPane().add(this.panel);
		frame.pack();
		java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
		java.awt.Dimension frameSize = frame.getPreferredSize();
		frame.setSize(frame.getPreferredSize());
		frame.setLocation(screenSize.width/2 - (frameSize.width/2),
						screenSize.height/2 - (frameSize.height/2));
		frame.setVisible(true);
	}
	
	public void releaseFromAll() {
		
		NoiseComponent tmp;
		
//		System.err.println("Noise release all");

		while(componentConnectedToOutput.size() > 0) {
			tmp = (NoiseComponent)componentConnectedToOutput.get(0);
			tmp.releaseComponent(this);
			componentConnectedToOutput.remove(0);
		}
	}
	
	public String getToolTipText() {
		return "<b><u>" + noiseEngine.name() + "</u></b><br><br>" + noiseEngine.description() + "<br><br>" + noiseEngine.getDetails();
	};

	private class NoiseMenuActionPerformed implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			NoiseEngine noiseEngine;
			Class noiseClass;
			javax.swing.JMenuItem cb = (javax.swing.JMenuItem)arg0.getSource();
			try {
				noiseClass = Class.forName(cb.getText());
				try {
					noiseEngine = (Utilities.NoiseEngine)noiseClass.newInstance();
					setNoiseEngine(noiseEngine);                
				} catch (InstantiationException e) {
					System.err.println(e.getMessage());
				}
			} catch(Exception e) {
				System.err.println(e.getMessage());
			}
			
			componentPanel.propsPane.displayFor(NoiseComponent.this);
			refreshUpStreamPreview();
			refreshDownStreamPreview();

//			repaint();
		}
	}	
	
	private class OkayListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			noiseEngine.storeSettings();
			refreshDownStreamPreview();
			frame.setVisible(false);

		}
	}

	private class ApplyListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			noiseEngine.storeSettings();
			refreshDownStreamPreview();
		}
	}

	private class CancelListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			noiseEngine.restoreSettings(); 
		}
	}
	
	public void refreshUpStreamPreview() {
		if(noiseEngine != null) {
			noiseEngine.makePreview();
		}
		
//		repaint();
		owner.repaint();
	}

	public void refreshDownStreamPreview() {
		
		NoiseComponent tmp;
		
		if(noiseEngine != null) {
			noiseEngine.makePreview();
		} 
		
		for(int i = 0; i < componentConnectedToOutput.size(); i++) {
			tmp = (NoiseComponent)componentConnectedToOutput.get(i);
			tmp.refreshDownStreamPreview();	
//			tmp.repaint();
		}
/*		
		repaint();
		if(getTopLevelAncestor() != null) {
			getTopLevelAncestor().repaint();		
		}
*/
		owner.repaint();
		
	}	
	
	
	public void save(ObjectOutputStream file) throws IOException {

		file.writeObject(this.getClass().getName());
		file.writeObject(this.getLocation());		
		noiseEngine.save(file);	

	}
	
	public void load(ObjectInputStream file) throws ClassNotFoundException, IOException {

		Class noiseClass;
		Point position = (Point)file.readObject();
		this.setLocation(position);
		String className = (String)file.readObject();
		try {
			noiseClass = Class.forName(className);
			try {
				noiseEngine = (Utilities.NoiseEngine)noiseClass.newInstance();
				setNoiseEngine(noiseEngine);
			} catch (InstantiationException e) {
				System.err.println(e.getMessage());
			}
		} catch(Exception e) {
			System.err.println(e.getMessage());
		}
		noiseEngine.load(file);
		name = noiseEngine.name();

		refreshUpStreamPreview();

	}
	
	public void saveJoins(ObjectOutputStream file, ArrayList components ) throws IOException {

		
		file.writeObject("componentsConnectedToOutput");
		file.writeObject("" + componentConnectedToOutput.size() );
		for(int i = 0; i < componentConnectedToOutput.size(); i++) {
			file.writeObject(""+components.indexOf(componentConnectedToOutput.get(i)));
		}				
		

	}
	
	public NoiseComponent loadJoins(ObjectInputStream file, ArrayList<NoiseComponent> components, ArrayList<JoinComponent> joins) throws ClassNotFoundException, IOException {

		NoiseComponent connectedToTerrain = null;
		NoiseComponent component;
		
		String index = (String)file.readObject();
		if(index.compareTo("componentsConnectedToOutput") != 0) {
			int i = Integer.parseInt(index);
			if(i > -1) {
				component = components.get(i);
				componentConnectedToOutput.add(component);

	   			if(null == NoiseComponent.findJoin(joins, this, component) ) {
	   				joins.add(new JoinComponent(this, component));
	   			}
				if(i == 0) {
					connectedToTerrain = this;
				}	
			}
		} else {
			int j;
			index = (String)file.readObject();
			int count = Integer.parseInt(index);
			for(int i = 0; i < count; i++ ) {
				index = (String)file.readObject();
				j = Integer.parseInt(index);
				if(j > -1) {
					
					component = components.get(j);
					componentConnectedToOutput.add(component);
					
		   			if(null == NoiseComponent.findJoin(joins, this, component) ) {
		   				joins.add(new JoinComponent(this, component));
		   			}
		   			
					if(j == 0) {
						connectedToTerrain = this;
					}	
				}				
			}
		}
		
		return connectedToTerrain;
	}	

	protected class removeComponentListener implements ActionListener {
		
		private NoiseComponent index; 
		
		removeComponentListener(NoiseComponent index) {
			this.index = index;
		}
		
		public void actionPerformed(ActionEvent arg0) {
			index.releaseComponent(NoiseComponent.this);
			releaseComponent(index);
//			NoiseComponent.this.getParent().repaint();
		}
	}
	
	protected class OutputComponentMenu extends JMenu	{

		OutputComponentMenu(ComponentPanel componentPanel) {
			setText("Detach");
			
			JMenuItem item;
			NoiseComponent tmp;
			
			for(int i = 0; i < componentConnectedToOutput.size(); i++) {
				tmp = (NoiseComponent)componentConnectedToOutput.get(i);
				item = new JMenuItem(tmp.getName());
					JoinRemovalListener newJoinRemovalListener = componentPanel.new JoinRemovalListener();
					newJoinRemovalListener.setComponents(NoiseComponent.this,tmp);
					item.addActionListener(newJoinRemovalListener);
					add(item);
			}
			
		}
	}	

    public NoiseComponent copy() {
        
        NoiseComponent copy = new NoiseComponent((JFrame)frame.getOwner(), componentPanel);
        copy.setNoiseEngine(getNoiseEngine().copy());
        return copy;
    }

	public boolean isSelected()
	{
		return selected;
	}

	public void setSelected(boolean selected)
	{
		this.selected = selected;
	}

	public Point getInputConnectionPoint(Point basisPoint) {
		
		return null;		
		
	}

	public Point getOutputConnectionPoint() {
		
		return new Point(getLocation().x + 33, getLocation().y+58);			
		
	}
	
	public boolean acceptComponentAsInput(NoiseComponent component) {
		return false;
	}

	public boolean acceptComponentForOutput(NoiseComponent component) {
		return true;
	}
	
	public NoiseComponent getInputComponentForPoint(Point basisPoint) {		
		return null;
	}	
	
	public int getComponentTypeForPoint(Point basisPoint) {		
		if(getBounds().contains(basisPoint)) {
			return POINT_SELECTS_OUTPUT_COMPONENT;
		}	
	
		return POINT_OUT_OF_BOUNDS;
	}
	
	protected static JoinComponent findJoin(ArrayList<JoinComponent> joinComponents, NoiseComponent c1, NoiseComponent c2) {

		/* get rid of old joins */
		Iterator<JoinComponent> itor = joinComponents.iterator();
		JoinComponent join;
		
		
		while(itor.hasNext()) {
			join = itor.next();
			if(join.joinsThisComponenet(c1) && join.joinsThisComponenet(c2)) {
				return join;
			}
		}
		
		return null;

	}	

	public java.awt.Point getLocation() {
		return location;
	}

	public void setLocation(java.awt.Point newLocation) {
		location.x = newLocation.x;
		location.y = newLocation.y;
		bounds.x = newLocation.x;
		bounds.y = newLocation.y;
	}

	public void setLocation(int x, int y) {
		location.x = x;
		location.y = y;
		bounds.x = x;
		bounds.y = y;
	}	
	public java.awt.Rectangle getBounds() {
		return bounds;
	}

	public void setBounds(java.awt.Rectangle newBounds) {
		bounds.x = newBounds.x;
		bounds.y = newBounds.y;
		bounds.width = newBounds.width;
		bounds.height = newBounds.height;
		location.x = newBounds.x;
		location.y = newBounds.y;
		
	}	

	public void setSize(Dimension dimension) {
		
		bounds.height = dimension.height;
		bounds.width = dimension.width;
		
	}	
	public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
		// TODO Auto-generated method stub
		return false;
	}	
	
}

