#ifndef ANL_LOADBINDINGS_H
#define ANL_LOADBINDINGS_H

#include <lua.h>

void loadANLBindings(lua_State *l);

#endif
