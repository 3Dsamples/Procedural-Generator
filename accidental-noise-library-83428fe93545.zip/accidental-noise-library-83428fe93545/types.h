#ifndef TYPES_H
#define TYPES_H

// #define ANL_DOUBLE_PRECISION

#ifdef ANL_DOUBLE_PRECISION
#define ANLFloatType double
#else
#define ANLFloatType float
#endif

#endif