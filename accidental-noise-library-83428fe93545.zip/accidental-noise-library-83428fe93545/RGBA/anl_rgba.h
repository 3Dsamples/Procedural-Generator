#ifndef ANL_RGBA_H
#define ANL_RGBA_H

#include "rgbamodulebase.h"
#include "rgbablend.h"
#include "rgbablendops.h"
#include "rgbacolorops.h"
#include "rgbaconstant.h"
#include "rgbacomposechannels.h"
#include "rgbacurve.h"
#include "rgbahsvtorgba.h"
#include "rgbaimplicitgrayscale.h"
#include "rgbanormalize.h"
#include "rgbargbatohsv.h"
#include "rgbarotatecolor.h"
#include "rgbaselect.h"


#endif

