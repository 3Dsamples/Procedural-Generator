#ifndef RGBA_H
#define RGBA_H
#include "vectortypes.h"
#include "../types.h"

namespace anl
{
    /*struct SRGBA
    {
        SRGBA()
        {
            for(int c=0; c<4; ++c) rgba[c]=0.0;
        }
        SRGBA(float r, float g, float b, float a)
        {
            rgba[0]=r;
            rgba[1]=g;
            rgba[2]=b;
            rgba[3]=a;
        }
        SRGBA(float v)
        {
            rgba[0]=v;
            rgba[1]=v;
            rgba[2]=v;
            rgba[3]=v;
        }


        float rgba[4];
    };*/


};
#endif

