/****************************************************************************
** Form implementation generated from reading ui file '.\AboutDialog.ui'
**
** Created: Sat Oct 16 16:36:06 2004
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "AboutDialog.h"

#include <qframe.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a AboutDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
AboutDlg::AboutDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "AboutDlg" );
    resize( 345, 370 ); 
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 345, 370 ) );
    setMaximumSize( QSize( 340, 370 ) );
    setBaseSize( QSize( 340, 370 ) );
    setCaption( tr( "About Window" ) );
    setSizeGripEnabled( TRUE );

    Frame = new QFrame( this, "Frame" );
    Frame->setGeometry( QRect( 9, 10, 324, 244 ) ); 
    Frame->setFrameShape( QFrame::WinPanel );
    Frame->setFrameShadow( QFrame::Sunken );

    TextLabel2 = new QLabel( this, "TextLabel2" );
    TextLabel2->setGeometry( QRect( 23, 291, 294, 25 ) ); 
    QFont TextLabel2_font(  TextLabel2->font() );
    TextLabel2_font.setFamily( "Arial" );
    TextLabel2_font.setPointSize( 10 );
    TextLabel2_font.setBold( TRUE );
    TextLabel2->setFont( TextLabel2_font ); 
    TextLabel2->setFrameShape( QLabel::MShape );
    TextLabel2->setFrameShadow( QLabel::MShadow );
    TextLabel2->setText( tr( "a Virtual landscape engine for MS-Windows " ) );
    TextLabel2->setAlignment( int( QLabel::AlignCenter ) );

    TextLabel1_2 = new QLabel( this, "TextLabel1_2" );
    TextLabel1_2->setGeometry( QRect( 70, 315, 183, 22 ) ); 
    QFont TextLabel1_2_font(  TextLabel1_2->font() );
    TextLabel1_2_font.setFamily( "Arial" );
    TextLabel1_2_font.setBold( TRUE );
    TextLabel1_2->setFont( TextLabel1_2_font ); 
    TextLabel1_2->setFrameShape( QLabel::WinPanel );
    TextLabel1_2->setFrameShadow( QLabel::Plain );
    TextLabel1_2->setText( tr( "build [9999][16-10-2004 00:00]" ) );
    TextLabel1_2->setAlignment( int( QLabel::AlignCenter ) );

    TextLabel3 = new QLabel( this, "TextLabel3" );
    TextLabel3->setGeometry( QRect( 5, 338, 333, 26 ) ); 
    QFont TextLabel3_font(  TextLabel3->font() );
    TextLabel3_font.setFamily( "Comic Sans MS" );
    TextLabel3_font.setPointSize( 9 );
    TextLabel3->setFont( TextLabel3_font ); 
    TextLabel3->setText( tr( "MicroTerra is created by Peter J. vd Sluis    (1998-2004)" ) );
    TextLabel3->setAlignment( int( QLabel::AlignCenter ) );

    TextLabel1 = new QLabel( this, "TextLabel1" );
    TextLabel1->setGeometry( QRect( 82, 261, 164, 29 ) ); 
    QFont TextLabel1_font(  TextLabel1->font() );
    TextLabel1_font.setFamily( "Arial" );
    TextLabel1_font.setPointSize( 14 );
    TextLabel1_font.setBold( TRUE );
    TextLabel1->setFont( TextLabel1_font ); 
    TextLabel1->setFrameShape( QLabel::WinPanel );
    TextLabel1->setFrameShadow( QLabel::Raised );
    TextLabel1->setText( tr( "MicroTerra 0.4.1" ) );
    TextLabel1->setAlignment( int( QLabel::AlignCenter ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
AboutDlg::~AboutDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool AboutDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont TextLabel2_font(  TextLabel2->font() );
	TextLabel2_font.setFamily( "Arial" );
	TextLabel2_font.setPointSize( 10 );
	TextLabel2_font.setBold( TRUE );
	TextLabel2->setFont( TextLabel2_font ); 
	QFont TextLabel1_2_font(  TextLabel1_2->font() );
	TextLabel1_2_font.setFamily( "Arial" );
	TextLabel1_2_font.setBold( TRUE );
	TextLabel1_2->setFont( TextLabel1_2_font ); 
	QFont TextLabel3_font(  TextLabel3->font() );
	TextLabel3_font.setFamily( "Comic Sans MS" );
	TextLabel3_font.setPointSize( 9 );
	TextLabel3->setFont( TextLabel3_font ); 
	QFont TextLabel1_font(  TextLabel1->font() );
	TextLabel1_font.setFamily( "Arial" );
	TextLabel1_font.setPointSize( 14 );
	TextLabel1_font.setBold( TRUE );
	TextLabel1->setFont( TextLabel1_font ); 
    }
    return ret;
}

