/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: roughendlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: roughendlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef ROUGHENDLHIMPL_H
#define ROUGHENDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "RoughenDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class RoughenDlgImpl : public RoughenDlg
{ 
    Q_OBJECT

public:
    RoughenDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~RoughenDlgImpl();

	float factor;
	bool  big;

public slots:
	void setFactor(int value);
	void bigClicked();

protected:
	void update_preview();

};

#endif // ROUGHENDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - created
 *
 ***********************************************************************************************************************/