/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: mainwindow.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: mainwindow
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/
#include <qvariant.h>
#include <qdialog.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QFrame;
class QGroupBox;
class QLineEdit;
class QPushButton;
class QRadioButton;
class QTabWidget;
class QTextView;
class QToolButton;
class QWidget;
class TerrainView;

class SizeManager;
class ChooserDlgImpl;
class genFaultDlgImpl;
class genPerDlgImpl;
class genSpectralDlgImpl;
class genSubDlgImpl;
class TTerrain;
class LevelConnectorDlgImpl;
class CratersDlgImpl;
class ErodeDlgImpl;
class DigitalDlgImpl;
class FillDlgImpl;
class FillBasinsDlgImpl;
class FlowmapDlgImpl;
class FoldDlgImpl;
class GaussianHillDlgImpl;
class MosaicDlgImpl;
class RadialScaleDlgImpl;
class RasterizeDlgImpl;
class RoughenDlgImpl;
class SmoothDlgImpl;
class SpericalmapDlgImpl;
class TerraceDlgImpl;
class TileDlgImpl;
class TransformDlgImpl;
class OptionsDlgImpl;

class FaultingData
{
public:
	FaultingData() : size(0), new_seed(false), seed(0) {};
	int     method;
	int     size;
	int     iterations;
	int     scale;
	float   cycle;
	bool    constant_size;
	bool    new_seed;
	int     seed;
};

class PerlinData
{
public:
	PerlinData() : size(0), new_seed(false), seed(0) {};
	bool    enabled[4];
	float   frequency[4];
	float   amplitude[4];
	int     iterations[4];
	int     filter[4];
	int     size;
	bool    new_seed;
	int     seed;
};

class SpectralData
{
public:
	SpectralData() : size(0), dimensions(0), invert(false), new_seed(false), seed(0) {};
	int     size;
	float   dimensions;
	bool    invert;
	bool    new_seed;
	int     seed;
};

class SubdivisionData
{
public:
	SubdivisionData() : method(0), size(0), scale(0), new_seed(false), seed(0) {};
	int   method;
	int   size;
	float scale;
	bool  new_seed;
	int   seed;
};

class MainWindow : public QDialog
{ 
    Q_OBJECT

public:
    MainWindow( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~MainWindow();

	TTerrain*    terrain;

    QPushButton* btn_options;
    QPushButton* btn_about;
    QPushButton* btn_help;
    QPushButton* btn_exit;
    QTabWidget* NoteBook;
    QWidget* page1;
    QFrame* Frame3;
    QGroupBox* THolder;
	TerrainView* View;
    QFrame* Frame4;
    QGroupBox* GroupBox4;
    QPushButton* btn_connect;
    QPushButton* btn_craters;
    QPushButton* btn_erode;
    QPushButton* btn_digitalfilter;
    QPushButton* btn_fill;
    QPushButton* btn_fillbasins;
    QPushButton* btn_flowmap;
    QPushButton* btn_fold;
    QPushButton* btn_gausianhill;
    QPushButton* btn_mosaic;
    QPushButton* btn_radialscale;
    QPushButton* btn_rasterize;
    QPushButton* btn_raughen;
    QPushButton* btn_smooth;
    QPushButton* btn_sphericalmap;
    QPushButton* btn_terrace;
    QPushButton* btn_tile;
    QPushButton* btn_transform;
    QGroupBox* GroupBox3;
    QRadioButton* rbtn_land;
    QRadioButton* rbtn_desert;
    QRadioButton* rbtn_heat;
    QRadioButton* rbtn_grayscale;
    QRadioButton* rbtn_wasteland;
    QGroupBox* GroupBox2;
    QRadioButton* rbtn_3dheight;
    QRadioButton* rbtn_3dlight;
    QRadioButton* rbtn_2dplane;
    QRadioButton* rbtn_2dcontour;
    QRadioButton* rbtn_3dwire;
    QFrame* Frame5;
    QToolButton* tbtn_open;
    QToolButton* tbtn_save;
    QToolButton* tbtn_saveas;
    QToolButton* tbtn_print;
    QGroupBox* GroupBox1;
    QPushButton* btn_random;
    QPushButton* btn_perlin;
    QPushButton* btn_faulting;
    QPushButton* btn_spectral;
    QPushButton* btn_subdivision;
    QPushButton* btn_chooser;
    QFrame* Frame1;
    QToolButton* tbtn2;
    QToolButton* tbtn3;
    QToolButton* tbtn4;
    QToolButton* tbtn5;
    QToolButton* tbtn6;
    QToolButton* tbtn7;
    QToolButton* tbtn8;
    QToolButton* tbtn1;
    QWidget* page2;
    QPushButton* btn_CmdRun;
    QPushButton* btn_CmdClear;
    QFrame* Frame2_1;
    QGroupBox* THolder2;
	TerrainView* View2;
    QGroupBox* GroupBox2_1;
    QPushButton* btn_subdivision_2;
    QPushButton* btn_runscript;
    QPushButton* btn_startlog;
    QPushButton* btn_show4;
    QPushButton* btn_show3d;
    QFrame* Frame2_3;
    QGroupBox* GroupBox2_2;
    QPushButton* btn_stack_copy1;
    QPushButton* btn_stack_copy2;
    QPushButton* btn_stack_paste;
    QPushButton* btn_stack_dup;
    QPushButton* btn_stack_swap;
    QPushButton* btn_stack_pop;
    QPushButton* btn_stack_rot;
    QPushButton* btn_stack_rot3;
    QPushButton* btn_stack_clear;
    QTextView* stack_view;
    QLineEdit* CmdLine;
    QTextView* ScriptLog;

private:
	SizeManager           *SM;
	ChooserDlgImpl        *choos_dlg;
	genFaultDlgImpl       *fault_dlg;
	genPerDlgImpl         *perlin_dlg;
	genSpectralDlgImpl    *spectral_dlg;
	genSubDlgImpl         *subdiv_dlg;
	LevelConnectorDlgImpl *levcon_dlg;
	CratersDlgImpl        *craters_dlg;
	ErodeDlgImpl          *erode_dlg;
	DigitalDlgImpl        *digit_dlg;
	FillDlgImpl           *fill_dlg;
	FillBasinsDlgImpl     *fillbas_dlg;
	FlowmapDlgImpl        *flowmap_dlg;
	FoldDlgImpl           *fold_dlg;
	GaussianHillDlgImpl   *hill_dlg;
	MosaicDlgImpl         *mosaic_dlg;
	RadialScaleDlgImpl    *radial_dlg;
	RasterizeDlgImpl      *rast_dlg;
	RoughenDlgImpl        *rough_dlg;
	SmoothDlgImpl         *smooth_dlg;
	SpericalmapDlgImpl    *speri_dlg;
	TerraceDlgImpl        *ter_dlg;
	TileDlgImpl           *tile_dlg;
	TransformDlgImpl      *tran_dlg;
	OptionsDlgImpl        *opt_dlg;

protected:
    virtual bool queryExit();
 
public slots:
    virtual void about();
    virtual void contour_Changed();
    virtual void desert_Changed();
    virtual void grayscale_Changed();
    virtual void wasteland_Changed();
    virtual void heat_Changed();
    virtual void height_Changed();
    virtual void help();
    virtual void land_Changed();
    virtual void light_Changed();
    virtual void tool8_Changed();
    virtual void newchooser();
    virtual void newfaulting();
    virtual void newrandom();
    virtual void newperlin();
    virtual void newspectral();
    virtual void newsubdevision();
    virtual void openfile();
    virtual void operconnect();
    virtual void opercraters();
    virtual void operdigitalfilter();
    virtual void opererode();
    virtual void operfill();
    virtual void operfillbasins();
    virtual void operflowmap();
    virtual void operfold();
    virtual void opergausianhill();
    virtual void opermosaic();
    virtual void operradialscale();
    virtual void operrasterize();
    virtual void operraughen();
    virtual void opersmooth();
    virtual void opersphericalmap();
    virtual void operterrace();
    virtual void opertile();
    virtual void opertransform();
    virtual void options();
    virtual void pageChanged();
    virtual void plane_Changed();
    virtual void print();
    virtual void saveasfile();
    virtual void savefile();
    virtual void tool1_Changed();
    virtual void tool2_Changed();
    virtual void tool3_Changed();
    virtual void tool4_Changed();
    virtual void tool5_Changed();
    virtual void tool6_Changed();
    virtual void tool7_Changed();
    virtual void wire_Changed();

private slots:
	void slotExit();

protected:
    bool event( QEvent* );
};

#endif // MAINWINDOW_H
/***********************************************************************************************************************
 * Version history:
 *  * 11-10-2004
 *   - created
 *
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/