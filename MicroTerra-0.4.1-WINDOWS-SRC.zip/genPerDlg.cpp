/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genperdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genperdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "genPerDlg.h"

#include <qcheckbox.h>
#include <qcombobox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a genPerDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
genPerDlg::genPerDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "genSpectralDlg" );
    resize( 422, 372 ); 
    setCaption( "Spectral Window" );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 110, 330, 210, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    generate = new QPushButton( privateLayoutWidget, "generate" );
    generate->setText( tr( "&Generate" ) );
    generate->setAutoDefault( TRUE );
    generate->setDefault( TRUE );
    Layout1->addWidget( generate );

    cancel = new QPushButton( privateLayoutWidget, "cancel" );
    cancel->setText( tr( "&Cancel" ) );
    cancel->setAutoDefault( TRUE );
    Layout1->addWidget( cancel );

    GroupBox3 = new QGroupBox( this, "GroupBox3" );
    GroupBox3->setGeometry( QRect( 10, 190, 401, 130 ) ); 
    GroupBox3->setTitle( tr( "General Parameters" ) );

    Line2 = new QFrame( GroupBox3, "Line2" );
    Line2->setGeometry( QRect( 11, 40, 380, 20 ) ); 
    Line2->setProperty( "frameShape", (int)QFrame::HLine );
    Line2->setFrameShadow( QFrame::Sunken );
    Line2->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line2->setProperty( "frameShape", (int)QFrame::HLine );

    TextLabel10 = new QLabel( GroupBox3, "TextLabel10" );
    TextLabel10->setGeometry( QRect( 120, 90, 30, 21 ) ); 
    TextLabel10->setText( tr( "Seed" ) );

    TextLabel9 = new QLabel( GroupBox3, "TextLabel9" );
    TextLabel9->setGeometry( QRect( 120, 20, 20, 21 ) ); 
    TextLabel9->setText( tr( "Size" ) );

    pn_size = new QSpinBox( GroupBox3, "pn_size" );
    pn_size->setGeometry( QRect( 160, 20, 61, 21 ) ); 
    pn_size->setButtonSymbols( QSpinBox::PlusMinus );
    pn_size->setMaxValue( 2000 );
    pn_size->setMinValue( 10 );
    pn_size->setLineStep( 1 );
    pn_size->setValue( 400 );

    seed = new QLineEdit( GroupBox3, "seed" );
    seed->setGeometry( QRect( 160, 90, 121, 22 ) ); 
    seed->setText( tr( "0" ) );

    new_seed = new QCheckBox( GroupBox3, "new_seed" );
    new_seed->setGeometry( QRect( 130, 60, 120, 21 ) ); 
    new_seed->setText( tr( "Generate new seed" ) );
    new_seed->setChecked( FALSE );

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 10, 10, 400, 170 ) ); 
    GroupBox2->setTitle( tr( "Perlin Parameters" ) );

    TextLabel5 = new QLabel( GroupBox2, "TextLabel5" );
    TextLabel5->setGeometry( QRect( 80, 21, 50, 20 ) ); 
    TextLabel5->setText( tr( "Frequency" ) );

    TextLabel6 = new QLabel( GroupBox2, "TextLabel6" );
    TextLabel6->setGeometry( QRect( 140, 20, 50, 21 ) ); 
    TextLabel6->setFrameShape( QLabel::MShape );
    TextLabel6->setFrameShadow( QLabel::MShadow );
    TextLabel6->setText( tr( "Amplitude" ) );

    TextLabel7 = new QLabel( GroupBox2, "TextLabel7" );
    TextLabel7->setGeometry( QRect( 200, 20, 51, 21 ) ); 
    TextLabel7->setFrameShape( QLabel::MShape );
    TextLabel7->setFrameShadow( QLabel::MShadow );
    TextLabel7->setText( tr( "Iterations" ) );

    TextLabel8 = new QLabel( GroupBox2, "TextLabel8" );
    TextLabel8->setGeometry( QRect( 310, 20, 30, 21 ) ); 
    TextLabel8->setFrameShape( QLabel::MShape );
    TextLabel8->setFrameShadow( QLabel::MShadow );
    TextLabel8->setText( tr( "Filter" ) );

    first = new QCheckBox( GroupBox2, "first" );
    first->setGeometry( QRect( 10, 50, 60, 20 ) ); 
    first->setText( tr( "1th order" ) );
    first->setChecked( TRUE );

    second = new QCheckBox( GroupBox2, "second" );
    second->setGeometry( QRect( 10, 80, 60, 20 ) ); 
    second->setText( tr( "2th order" ) );
    second->setChecked( FALSE );

    third = new QCheckBox( GroupBox2, "third" );
    third->setGeometry( QRect( 10, 110, 60, 20 ) ); 
    third->setText( tr( "3th order" ) );
    third->setChecked( FALSE );

    fourth = new QCheckBox( GroupBox2, "fourth" );
    fourth->setGeometry( QRect( 10, 140, 60, 20 ) ); 
    fourth->setText( tr( "4th order" ) );
    fourth->setChecked( FALSE );

    second_frequency = new QSpinBox( GroupBox2, "second_frequency" );
    second_frequency->setGeometry( QRect( 80, 80, 50, 21 ) ); 
    second_frequency->setButtonSymbols( QSpinBox::PlusMinus );
    second_frequency->setMaxValue( 2000 );
    second_frequency->setMinValue( 17 );
    second_frequency->setLineStep( 1 );
    second_frequency->setValue( 21 );

    third_frequency = new QSpinBox( GroupBox2, "third_frequency" );
    third_frequency->setGeometry( QRect( 80, 110, 50, 21 ) ); 
    third_frequency->setButtonSymbols( QSpinBox::PlusMinus );
    third_frequency->setMaxValue( 2000 );
    third_frequency->setMinValue( 17 );
    third_frequency->setLineStep( 1 );
    third_frequency->setValue( 23 );

    fourth_frequency = new QSpinBox( GroupBox2, "fourth_frequency" );
    fourth_frequency->setGeometry( QRect( 80, 140, 50, 21 ) ); 
    fourth_frequency->setButtonSymbols( QSpinBox::PlusMinus );
    fourth_frequency->setMaxValue( 2000 );
    fourth_frequency->setMinValue( 17 );
    fourth_frequency->setLineStep( 1 );
    fourth_frequency->setValue( 25 );

    fourth_iterations = new QSpinBox( GroupBox2, "fourth_iterations" );
    fourth_iterations->setGeometry( QRect( 200, 140, 50, 21 ) ); 
    fourth_iterations->setButtonSymbols( QSpinBox::PlusMinus );
    fourth_iterations->setMaxValue( 100 );
    fourth_iterations->setMinValue( 1 );
    fourth_iterations->setLineStep( 1 );
    fourth_iterations->setValue( 9 );

    third_iterations = new QSpinBox( GroupBox2, "third_iterations" );
    third_iterations->setGeometry( QRect( 200, 110, 50, 21 ) ); 
    third_iterations->setButtonSymbols( QSpinBox::PlusMinus );
    third_iterations->setMaxValue( 100 );
    third_iterations->setMinValue( 1 );
    third_iterations->setLineStep( 1 );
    third_iterations->setValue( 9 );

    second_iterations = new QSpinBox( GroupBox2, "second_iterations" );
    second_iterations->setGeometry( QRect( 200, 80, 50, 21 ) ); 
    second_iterations->setButtonSymbols( QSpinBox::PlusMinus );
    second_iterations->setMaxValue( 100 );
    second_iterations->setMinValue( 1 );
    second_iterations->setLineStep( 1 );
    second_iterations->setValue( 9 );

    first_iterations = new QSpinBox( GroupBox2, "first_iterations" );
    first_iterations->setGeometry( QRect( 200, 50, 50, 21 ) ); 
    first_iterations->setButtonSymbols( QSpinBox::PlusMinus );
    first_iterations->setMaxValue( 100 );
    first_iterations->setMinValue( 1 );
    first_iterations->setLineStep( 1 );
    first_iterations->setValue( 9 );

    fourth_amplitude = new QSpinBox( GroupBox2, "fourth_amplitude" );
    fourth_amplitude->setGeometry( QRect( 140, 140, 50, 21 ) ); 
    fourth_amplitude->setButtonSymbols( QSpinBox::PlusMinus );
    fourth_amplitude->setMaxValue( 10000 );
    fourth_amplitude->setMinValue( 0 );
    fourth_amplitude->setLineStep( 1 );
    fourth_amplitude->setValue( 8192 );

    third_amplitude = new QSpinBox( GroupBox2, "third_amplitude" );
    third_amplitude->setGeometry( QRect( 140, 110, 50, 21 ) ); 
    third_amplitude->setButtonSymbols( QSpinBox::PlusMinus );
    third_amplitude->setMaxValue( 10000 );
    third_amplitude->setMinValue( 0 );
    third_amplitude->setLineStep( 1 );
    third_amplitude->setValue( 8192 );

    second_amplitude = new QSpinBox( GroupBox2, "second_amplitude" );
    second_amplitude->setGeometry( QRect( 140, 80, 50, 21 ) ); 
    second_amplitude->setButtonSymbols( QSpinBox::PlusMinus );
    second_amplitude->setMaxValue( 10000 );
    second_amplitude->setMinValue( 0 );
    second_amplitude->setLineStep( 1 );
    second_amplitude->setValue( 8192 );

    first_amplitude = new QSpinBox( GroupBox2, "first_amplitude" );
    first_amplitude->setGeometry( QRect( 140, 50, 50, 21 ) ); 
    first_amplitude->setButtonSymbols( QSpinBox::PlusMinus );
    first_amplitude->setMaxValue( 10000 );
    first_amplitude->setMinValue( 0 );
    first_amplitude->setLineStep( 1 );
    first_amplitude->setValue( 8192 );

    first_frequency = new QSpinBox( GroupBox2, "first_frequency" );
    first_frequency->setGeometry( QRect( 80, 50, 50, 21 ) ); 
    first_frequency->setButtonSymbols( QSpinBox::PlusMinus );
    first_frequency->setMaxValue( 2000 );
    first_frequency->setMinValue( 17 );
    first_frequency->setLineStep( 1 );
    first_frequency->setValue( 17 );

    first_filter = new QComboBox( FALSE, GroupBox2, "first_filter" );
    first_filter->setGeometry( QRect( 260, 50, 131, 21 ) ); 
    first_filter->insertItem( "Plasma" );
    first_filter->insertItem( "Shiprock #1" );
    first_filter->insertItem( "Shiprock #2" );
    first_filter->insertItem( "Shiprock #3" );
    first_filter->insertItem( "Rounded Mountains #1" );
    first_filter->insertItem( "Rounded Mountains #2" );
    first_filter->insertItem( "Rounded Mountains #3" );
    first_filter->insertItem( "General Land #1" );
    first_filter->insertItem( "General Land #2" );
    first_filter->insertItem( "General Land #3" );
    first_filter->insertItem( "General Land #4" );
    first_filter->insertItem( "Permafrost #1" );
    first_filter->insertItem( "Permafrost #2" );
    first_filter->insertItem( "Rocky Mesas #1" );
    first_filter->insertItem( "Rocky Mesas #2" );
    first_filter->insertItem( "Rocky Mesas #3" );
    first_filter->insertItem( "Rocky Mesas #4" );
    first_filter->insertItem( "Rocky Mesas #5" );
    first_filter->insertItem( "Eroded Rivers #1" );
    first_filter->insertItem( "Eroded Rivers #2" );
    first_filter->insertItem( "Eroded Rivers #3" );
    first_filter->insertItem( "General Land II" );
    first_filter->insertItem( "Shiprock II" );

    second_filter = new QComboBox( FALSE, GroupBox2, "second_filter" );
    second_filter->setGeometry( QRect( 260, 80, 131, 21 ) ); 
    second_filter->insertItem( "Plasma" );
    second_filter->insertItem( "Shiprock #1" );
    second_filter->insertItem( "Shiprock #2" );
    second_filter->insertItem( "Shiprock #3" );
    second_filter->insertItem( "Rounded Mountains #1" );
    second_filter->insertItem( "Rounded Mountains #2" );
    second_filter->insertItem( "Rounded Mountains #3" );
    second_filter->insertItem( "General Land #1" );
    second_filter->insertItem( "General Land #2" );
    second_filter->insertItem( "General Land #3" );
    second_filter->insertItem( "General Land #4" );
    second_filter->insertItem( "Permafrost #1" );
    second_filter->insertItem( "Permafrost #2" );
    second_filter->insertItem( "Rocky Mesas #1" );
    second_filter->insertItem( "Rocky Mesas #2" );
    second_filter->insertItem( "Rocky Mesas #3" );
    second_filter->insertItem( "Rocky Mesas #4" );
    second_filter->insertItem( "Rocky Mesas #5" );
    second_filter->insertItem( "Eroded Rivers #1" );
    second_filter->insertItem( "Eroded Rivers #2" );
    second_filter->insertItem( "Eroded Rivers #3" );
    second_filter->insertItem( "General Land II" );
    second_filter->insertItem( "Shiprock II" );

    third_filter = new QComboBox( FALSE, GroupBox2, "third_filter" );
    third_filter->setGeometry( QRect( 260, 110, 131, 21 ) ); 
    third_filter->insertItem( "Plasma" );
    third_filter->insertItem( "Shiprock #1" );
    third_filter->insertItem( "Shiprock #2" );
    third_filter->insertItem( "Shiprock #3" );
    third_filter->insertItem( "Rounded Mountains #1" );
    third_filter->insertItem( "Rounded Mountains #2" );
    third_filter->insertItem( "Rounded Mountains #3" );
    third_filter->insertItem( "General Land #1" );
    third_filter->insertItem( "General Land #2" );
    third_filter->insertItem( "General Land #3" );
    third_filter->insertItem( "General Land #4" );
    third_filter->insertItem( "Permafrost #1" );
    third_filter->insertItem( "Permafrost #2" );
    third_filter->insertItem( "Rocky Mesas #1" );
    third_filter->insertItem( "Rocky Mesas #2" );
    third_filter->insertItem( "Rocky Mesas #3" );
    third_filter->insertItem( "Rocky Mesas #4" );
    third_filter->insertItem( "Rocky Mesas #5" );
    third_filter->insertItem( "Eroded Rivers #1" );
    third_filter->insertItem( "Eroded Rivers #2" );
    third_filter->insertItem( "Eroded Rivers #3" );
    third_filter->insertItem( "General Land II" );
    third_filter->insertItem( "Shiprock II" );

    fourth_filter = new QComboBox( FALSE, GroupBox2, "fourth_filter" );
    fourth_filter->setGeometry( QRect( 260, 140, 131, 21 ) ); 
    fourth_filter->insertItem( "Plasma" );
    fourth_filter->insertItem( "Shiprock #1" );
    fourth_filter->insertItem( "Shiprock #2" );
    fourth_filter->insertItem( "Shiprock #3" );
    fourth_filter->insertItem( "Rounded Mountains #1" );
    fourth_filter->insertItem( "Rounded Mountains #2" );
    fourth_filter->insertItem( "Rounded Mountains #3" );
    fourth_filter->insertItem( "General Land #1" );
    fourth_filter->insertItem( "General Land #2" );
    fourth_filter->insertItem( "General Land #3" );
    fourth_filter->insertItem( "General Land #4" );
    fourth_filter->insertItem( "Permafrost #1" );
    fourth_filter->insertItem( "Permafrost #2" );
    fourth_filter->insertItem( "Rocky Mesas #1" );
    fourth_filter->insertItem( "Rocky Mesas #2" );
    fourth_filter->insertItem( "Rocky Mesas #3" );
    fourth_filter->insertItem( "Rocky Mesas #4" );
    fourth_filter->insertItem( "Rocky Mesas #5" );
    fourth_filter->insertItem( "Eroded Rivers #1" );
    fourth_filter->insertItem( "Eroded Rivers #2" );
    fourth_filter->insertItem( "Eroded Rivers #3" );
    fourth_filter->insertItem( "General Land II" );
    fourth_filter->insertItem( "Shiprock II" );

    // tab order
    setTabOrder( first, first_frequency );
    setTabOrder( first_frequency, first_amplitude );
    setTabOrder( first_amplitude, first_iterations );
    setTabOrder( first_iterations, first_filter );
    setTabOrder( first_filter, second );
    setTabOrder( second, second_frequency );
    setTabOrder( second_frequency, second_amplitude );
    setTabOrder( second_amplitude, second_iterations );
    setTabOrder( second_iterations, second_filter );
    setTabOrder( second_filter, third );
    setTabOrder( third, third_frequency );
    setTabOrder( third_frequency, third_amplitude );
    setTabOrder( third_amplitude, third_iterations );
    setTabOrder( third_iterations, third_filter );
    setTabOrder( third_filter, fourth );
    setTabOrder( fourth, fourth_frequency );
    setTabOrder( fourth_frequency, fourth_amplitude );
    setTabOrder( fourth_amplitude, fourth_iterations );
    setTabOrder( fourth_iterations, fourth_filter );
    setTabOrder( fourth_filter, pn_size );
    setTabOrder( pn_size, new_seed );
    setTabOrder( new_seed, seed );
    setTabOrder( seed, generate );
    setTabOrder( generate, cancel );

    connect( generate, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( new_seed, SIGNAL( clicked() ), this, SLOT( seedClicked() ) );
    connect( first, SIGNAL( clicked() ), this, SLOT( firstClicked() ) );
    connect( second, SIGNAL( clicked() ), this, SLOT( secondClicked() ) );
    connect( third, SIGNAL( clicked() ), this, SLOT( thirdClicked() ) );
    connect( fourth, SIGNAL( clicked() ), this, SLOT( fourthClicked() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
genPerDlg::~genPerDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

void genPerDlg::seedClicked()
{
}

void genPerDlg::firstClicked()
{
}

void genPerDlg::secondClicked()
{
}

void genPerDlg::thirdClicked()
{
}

void genPerDlg::fourthClicked()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 29-12-2002
 *   - created
 *
 ***********************************************************************************************************************/