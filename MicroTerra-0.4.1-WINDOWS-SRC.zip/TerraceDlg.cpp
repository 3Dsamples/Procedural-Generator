/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: terracedlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: terracedlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "TerraceDlg.h"

#include <qcheckbox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a TerraceDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
TerraceDlg::TerraceDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "TerraceDlg" );
    resize( 499, 213 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Terrace" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 135 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 150, 498, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 175, 170, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 350, 135 ) ); 
    GroupBox2->setTitle( tr( "Parameters" ) );

    terrace_levels = new QSlider( GroupBox2, "terrace_levels" );
    terrace_levels->setGeometry( QRect( 135, 20, 150, 20 ) ); 
    terrace_levels->setMinValue( 1 );
    terrace_levels->setMaxValue( 50 );
    terrace_levels->setPageStep( 0 );
    terrace_levels->setValue( 10 );
    terrace_levels->setOrientation( QSlider::Horizontal );
    terrace_levels->setTickmarks( QSlider::NoMarks );

    terrace_tightness = new QSlider( GroupBox2, "terrace_tightness" );
    terrace_tightness->setGeometry( QRect( 135, 50, 150, 20 ) ); 
    terrace_tightness->setMaxValue( 100 );
    terrace_tightness->setPageStep( 0 );
    terrace_tightness->setValue( 50 );
    terrace_tightness->setOrientation( QSlider::Horizontal );
    terrace_tightness->setTickmarks( QSlider::NoMarks );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 20, 100, 20 ) ); 
    lbl1->setText( tr( "Number of levels" ) );
    lbl1->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl2 = new QLabel( GroupBox2, "lbl2" );
    lbl2->setGeometry( QRect( 10, 50, 100, 17 ) ); 
    lbl2->setText( tr( "Tightness factor" ) );
    lbl2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 295, 18, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "10" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    slid2 = new QLabel( GroupBox2, "slid2" );
    slid2->setGeometry( QRect( 295, 46, 35, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2_font.setBold( TRUE );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "0.50" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

    terrace_adjust_waterlevel = new QCheckBox( GroupBox2, "terrace_adjust_waterlevel" );
    terrace_adjust_waterlevel->setGeometry( QRect( 10, 80, 130, 21 ) ); 
    terrace_adjust_waterlevel->setText( tr( "Adjust waterlevel" ) );

	terra = NULL;

    // signals and slots connections
    connect( terrace_levels, SIGNAL(valueChanged(int)), this, SLOT(setLevel(int)) );
    connect( terrace_tightness, SIGNAL(valueChanged(int)), this, SLOT(setTight(int)) );
    connect( terrace_adjust_waterlevel, SIGNAL(clicked()), this, SLOT(adjustClicked()));
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
TerraceDlg::~TerraceDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool TerraceDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev );

    if ( ev->type() == QEvent::ApplicationFontChange )
	{
		QFont slid1_font(  slid1->font() );
		slid1_font.setPointSize( 10 );
		slid1_font.setBold( TRUE );
		slid1->setFont( slid1_font ); 
		QFont slid2_font(  slid2->font() );
		slid2_font.setPointSize( 10 );
		slid2_font.setBold( TRUE );
		slid2->setFont( slid2_font ); 
    }
    return ret;
}

void TerraceDlg::setLevel(int value)
{
}

void TerraceDlg::setTight(int value)
{
}

void TerraceDlg::adjustClicked()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/