/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: chooserdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: chooserdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "ChooserDlg.h"

#include <qframe.h>
#include <qgroupbox.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

/* 
 *  Constructs a ChooserDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
ChooserDlg::ChooserDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "ChooserDlg" );
    resize( 367, 423 ); 
    setCaption( tr( "Chooser Window" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 33, 380, 300, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    rand_btn = new QPushButton( privateLayoutWidget, "rand_btn" );
    rand_btn->setText( tr( "Random" ) );
    rand_btn->setAutoDefault( TRUE );
    rand_btn->setDefault( TRUE );
    Layout1->addWidget( rand_btn );
    ok_btn = new QPushButton( privateLayoutWidget, "ok_btn" );
    ok_btn->setText( tr( "OK" ) );
    ok_btn->setAutoDefault( TRUE );
    ok_btn->setDefault( TRUE );
    Layout1->addWidget( ok_btn );
    cancel_btn = new QPushButton( privateLayoutWidget, "cancel_btn" );
    cancel_btn->setText( tr( "Cancel" ) );
    cancel_btn->setAutoDefault( TRUE );
    cancel_btn->setDefault( TRUE );
    Layout1->addWidget( cancel_btn );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 7, 10, 350, 360 ) ); 
    GroupBox1->setTitle( tr( "Choose Terrain" ) );

    terrain1 = new QFrame( GroupBox1, "terrain1" );
    terrain1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    terrain1->setFrameShape( QFrame::WinPanel );
    terrain1->setFrameShadow( QFrame::Sunken );

	View1 = new TerrainView( terrain1, "View1" );
	View1->setGeometry( QRect( 2, 2, 100, 100 ) );
	View1->t_terrain_view_setMouseMode(T_MOUSE_CLICK);
	mm1 = 0;
	View1->show();

    terrain2 = new QFrame( GroupBox1, "terrain2" );
    terrain2->setGeometry( QRect( 120, 20, 104, 104 ) ); 
    terrain2->setFrameShape( QFrame::WinPanel );
    terrain2->setFrameShadow( QFrame::Sunken );

	View2 = new TerrainView( terrain2, "View2" );
	View2->setGeometry( QRect( 2, 2, 100, 100 ) );
	View2->t_terrain_view_setMouseMode(T_MOUSE_CLICK);
	mm2 = 0;
	View2->show();

    terrain3 = new QFrame( GroupBox1, "terrain3" );
    terrain3->setGeometry( QRect( 230, 20, 104, 104 ) ); 
    terrain3->setFrameShape( QFrame::WinPanel );
    terrain3->setFrameShadow( QFrame::Sunken );

	View3 = new TerrainView( terrain3, "View3" );
	View3->setGeometry( QRect( 2, 2, 100, 100 ) );
	View3->t_terrain_view_setMouseMode(T_MOUSE_CLICK);
	mm3 = 0;
	View3->show();

    terrain4 = new QFrame( GroupBox1, "terrain4" );
    terrain4->setGeometry( QRect( 10, 130, 104, 104 ) ); 
    terrain4->setFrameShape( QFrame::WinPanel );
    terrain4->setFrameShadow( QFrame::Sunken );

	View4 = new TerrainView( terrain4, "View4" );
	View4->setGeometry( QRect( 2, 2, 100, 100 ) );
	View4->t_terrain_view_setMouseMode(T_MOUSE_CLICK);
	mm4 = 0;
	View4->show();

    terrain5 = new QFrame( GroupBox1, "terrain5" );
    terrain5->setGeometry( QRect( 120, 130, 104, 104 ) ); 
    terrain5->setFrameShape( QFrame::WinPanel );
    terrain5->setFrameShadow( QFrame::Sunken );

	View5 = new TerrainView( terrain5, "View5" );
	View5->setGeometry( QRect( 2, 2, 100, 100 ) );
	View5->t_terrain_view_setMouseMode(T_MOUSE_CLICK);
	mm5 = 0;
	View5->show();

    terrain6 = new QFrame( GroupBox1, "terrain6" );
    terrain6->setGeometry( QRect( 230, 130, 104, 104 ) ); 
    terrain6->setFrameShape( QFrame::WinPanel );
    terrain6->setFrameShadow( QFrame::Sunken );

	View6 = new TerrainView( terrain6, "View6" );
	View6->setGeometry( QRect( 2, 2, 100, 100 ) );
	View6->t_terrain_view_setMouseMode(T_MOUSE_CLICK);
	mm6 = 0;
	View6->show();

    terrain7 = new QFrame( GroupBox1, "terrain7" );
    terrain7->setGeometry( QRect( 10, 240, 104, 104 ) ); 
    terrain7->setFrameShape( QFrame::WinPanel );
    terrain7->setFrameShadow( QFrame::Sunken );

	View7 = new TerrainView( terrain7, "View7" );
	View7->setGeometry( QRect( 2, 2, 100, 100 ) );
	View7->t_terrain_view_setMouseMode(T_MOUSE_CLICK);
	mm7 = 0;
	View7->show();

    terrain8 = new QFrame( GroupBox1, "terrain8" );
    terrain8->setGeometry( QRect( 120, 240, 104, 104 ) ); 
    terrain8->setFrameShape( QFrame::WinPanel );
    terrain8->setFrameShadow( QFrame::Sunken );

	View8 = new TerrainView( terrain8, "View8" );
	View8->setGeometry( QRect( 2, 2, 100, 100 ) );
	View8->t_terrain_view_setMouseMode(T_MOUSE_CLICK);
	mm8 = 0;
	View8->show();

    terrain9 = new QFrame( GroupBox1, "terrain9" );
    terrain9->setGeometry( QRect( 230, 240, 104, 104 ) ); 
    terrain9->setFrameShape( QFrame::WinPanel );
    terrain9->setFrameShadow( QFrame::Sunken );

	View9 = new TerrainView( terrain9, "View9" );
	View9->setGeometry( QRect( 2, 2, 100, 100 ) );
	View9->t_terrain_view_setMouseMode(T_MOUSE_CLICK);
	mm9 = 0;
	View9->show();

    // signals and slots connections
    connect( View1, SIGNAL( mouseCLICKED() ), this, SLOT( vt1Clicked() ) );
    connect( View2, SIGNAL( mouseCLICKED() ), this, SLOT( vt2Clicked() ) );
    connect( View3, SIGNAL( mouseCLICKED() ), this, SLOT( vt3Clicked() ) );
    connect( View4, SIGNAL( mouseCLICKED() ), this, SLOT( vt4Clicked() ) );
    connect( View5, SIGNAL( mouseCLICKED() ), this, SLOT( vt5Clicked() ) );
    connect( View6, SIGNAL( mouseCLICKED() ), this, SLOT( vt6Clicked() ) );
    connect( View7, SIGNAL( mouseCLICKED() ), this, SLOT( vt7Clicked() ) );
    connect( View8, SIGNAL( mouseCLICKED() ), this, SLOT( vt8Clicked() ) );
    connect( View9, SIGNAL( mouseCLICKED() ), this, SLOT( vt9Clicked() ) );
    connect( rand_btn, SIGNAL( clicked() ), this, SLOT( randClicked() ) );
    connect( ok_btn, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( cancel_btn, SIGNAL( clicked() ), this, SLOT( reject() ) );
    setMouseTracking(TRUE);	// and do let me know what pixel I'm at, eh?
}

/*  
 *  Destroys the object and frees any allocated resources
 */
ChooserDlg::~ChooserDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

void ChooserDlg::randClicked()
{
}

void ChooserDlg::vt1Clicked()
{
	switch (mm1)
	{
		case 0:
			mm1 = 1;
			terrain1->setFrameShape(QFrame::PopupPanel);
			mm2 = 0;
			mm3 = 0;
			mm4 = 0;
			mm5 = 0;
			mm6 = 0;
			mm7 = 0;
			mm8 = 0;
			mm9 = 0;
			break;
		case 1:
			mm1 = 0;
			terrain1->setFrameShape(QFrame::WinPanel);
			break;
	}

	terrain2->setFrameShape(QFrame::WinPanel);
    terrain3->setFrameShape(QFrame::WinPanel);
    terrain4->setFrameShape(QFrame::WinPanel);
    terrain5->setFrameShape(QFrame::WinPanel);
    terrain6->setFrameShape(QFrame::WinPanel);
    terrain7->setFrameShape(QFrame::WinPanel);
    terrain8->setFrameShape(QFrame::WinPanel);
    terrain9->setFrameShape(QFrame::WinPanel);
}

void ChooserDlg::vt2Clicked()
{
	switch (mm2)
	{
		case 0:
			mm2 = 1;
			terrain2->setFrameShape(QFrame::PopupPanel);
			mm1 = 0;
			mm3 = 0;
			mm4 = 0;
			mm5 = 0;
			mm6 = 0;
			mm7 = 0;
			mm8 = 0;
			mm9 = 0;
			break;
		case 1:
			mm2 = 0;
			terrain2->setFrameShape(QFrame::WinPanel);
			break;
	}

	terrain1->setFrameShape(QFrame::WinPanel);
    terrain3->setFrameShape(QFrame::WinPanel);
    terrain4->setFrameShape(QFrame::WinPanel);
    terrain5->setFrameShape(QFrame::WinPanel);
    terrain6->setFrameShape(QFrame::WinPanel);
    terrain7->setFrameShape(QFrame::WinPanel);
    terrain8->setFrameShape(QFrame::WinPanel);
    terrain9->setFrameShape(QFrame::WinPanel);
}

void ChooserDlg::vt3Clicked()
{
	switch (mm3)
	{
		case 0:
			mm3 = 1;
			terrain3->setFrameShape(QFrame::PopupPanel);
			mm2 = 0;
			mm1 = 0;
			mm4 = 0;
			mm5 = 0;
			mm6 = 0;
			mm7 = 0;
			mm8 = 0;
			mm9 = 0;
			break;
		case 1:
			mm3 = 0;
			terrain3->setFrameShape(QFrame::WinPanel);
			break;
	}

	terrain2->setFrameShape(QFrame::WinPanel);
    terrain1->setFrameShape(QFrame::WinPanel);
    terrain4->setFrameShape(QFrame::WinPanel);
    terrain5->setFrameShape(QFrame::WinPanel);
    terrain6->setFrameShape(QFrame::WinPanel);
    terrain7->setFrameShape(QFrame::WinPanel);
    terrain8->setFrameShape(QFrame::WinPanel);
    terrain9->setFrameShape(QFrame::WinPanel);
}

void ChooserDlg::vt4Clicked()
{
	switch (mm4)
	{
		case 0:
			mm4 = 1;
			terrain4->setFrameShape(QFrame::PopupPanel);
			mm2 = 0;
			mm3 = 0;
			mm1 = 0;
			mm5 = 0;
			mm6 = 0;
			mm7 = 0;
			mm8 = 0;
			mm9 = 0;
			break;
		case 1:
			mm4 = 0;
			terrain4->setFrameShape(QFrame::WinPanel);
			break;
	}

	terrain2->setFrameShape(QFrame::WinPanel);
    terrain3->setFrameShape(QFrame::WinPanel);
    terrain1->setFrameShape(QFrame::WinPanel);
    terrain5->setFrameShape(QFrame::WinPanel);
    terrain6->setFrameShape(QFrame::WinPanel);
    terrain7->setFrameShape(QFrame::WinPanel);
    terrain8->setFrameShape(QFrame::WinPanel);
    terrain9->setFrameShape(QFrame::WinPanel);
}

void ChooserDlg::vt5Clicked()
{
	switch (mm5)
	{
		case 0:
			mm5 = 1;
			terrain5->setFrameShape(QFrame::PopupPanel);
			mm2 = 0;
			mm3 = 0;
			mm4 = 0;
			mm1 = 0;
			mm6 = 0;
			mm7 = 0;
			mm8 = 0;
			mm9 = 0;
			break;
		case 1:
			mm5 = 0;
			terrain5->setFrameShape(QFrame::WinPanel);
			break;
	}

	terrain2->setFrameShape(QFrame::WinPanel);
    terrain3->setFrameShape(QFrame::WinPanel);
    terrain4->setFrameShape(QFrame::WinPanel);
    terrain1->setFrameShape(QFrame::WinPanel);
    terrain6->setFrameShape(QFrame::WinPanel);
    terrain7->setFrameShape(QFrame::WinPanel);
    terrain8->setFrameShape(QFrame::WinPanel);
    terrain9->setFrameShape(QFrame::WinPanel);
}

void ChooserDlg::vt6Clicked()
{
	switch (mm6)
	{
		case 0:
			mm6 = 1;
			terrain6->setFrameShape(QFrame::PopupPanel);
			mm2 = 0;
			mm3 = 0;
			mm4 = 0;
			mm5 = 0;
			mm1 = 0;
			mm7 = 0;
			mm8 = 0;
			mm9 = 0;
			break;
		case 1:
			mm6 = 0;
			terrain6->setFrameShape(QFrame::WinPanel);
			break;
	}

	terrain2->setFrameShape(QFrame::WinPanel);
    terrain3->setFrameShape(QFrame::WinPanel);
    terrain4->setFrameShape(QFrame::WinPanel);
    terrain5->setFrameShape(QFrame::WinPanel);
    terrain1->setFrameShape(QFrame::WinPanel);
    terrain7->setFrameShape(QFrame::WinPanel);
    terrain8->setFrameShape(QFrame::WinPanel);
    terrain9->setFrameShape(QFrame::WinPanel);
}

void ChooserDlg::vt7Clicked()
{
	switch (mm7)
	{
		case 0:
			mm7 = 1;
			terrain7->setFrameShape(QFrame::PopupPanel);
			mm2 = 0;
			mm3 = 0;
			mm4 = 0;
			mm5 = 0;
			mm6 = 0;
			mm1 = 0;
			mm8 = 0;
			mm9 = 0;
			break;
		case 1:
			mm7 = 0;
			terrain7->setFrameShape(QFrame::WinPanel);
			break;
	}

	terrain2->setFrameShape(QFrame::WinPanel);
    terrain3->setFrameShape(QFrame::WinPanel);
    terrain4->setFrameShape(QFrame::WinPanel);
    terrain5->setFrameShape(QFrame::WinPanel);
    terrain6->setFrameShape(QFrame::WinPanel);
    terrain1->setFrameShape(QFrame::WinPanel);
    terrain8->setFrameShape(QFrame::WinPanel);
    terrain9->setFrameShape(QFrame::WinPanel);
}

void ChooserDlg::vt8Clicked()
{
	switch (mm8)
	{
		case 0:
			mm8 = 1;
			terrain8->setFrameShape(QFrame::PopupPanel);
			mm2 = 0;
			mm3 = 0;
			mm4 = 0;
			mm5 = 0;
			mm6 = 0;
			mm7 = 0;
			mm1 = 0;
			mm9 = 0;
			break;
		case 1:
			mm8 = 0;
			terrain8->setFrameShape(QFrame::WinPanel);
			break;
	}

	terrain2->setFrameShape(QFrame::WinPanel);
    terrain3->setFrameShape(QFrame::WinPanel);
    terrain4->setFrameShape(QFrame::WinPanel);
    terrain5->setFrameShape(QFrame::WinPanel);
    terrain6->setFrameShape(QFrame::WinPanel);
    terrain7->setFrameShape(QFrame::WinPanel);
    terrain1->setFrameShape(QFrame::WinPanel);
    terrain9->setFrameShape(QFrame::WinPanel);
}

void ChooserDlg::vt9Clicked()
{
	switch (mm9)
	{
		case 0:
			mm9 = 1;
			terrain9->setFrameShape(QFrame::PopupPanel);
			mm2 = 0;
			mm3 = 0;
			mm4 = 0;
			mm5 = 0;
			mm6 = 0;
			mm7 = 0;
			mm8 = 0;
			mm1 = 0;
			break;
		case 1:
			mm9 = 0;
			terrain9->setFrameShape(QFrame::WinPanel);
			break;
	}

	terrain2->setFrameShape(QFrame::WinPanel);
    terrain3->setFrameShape(QFrame::WinPanel);
    terrain4->setFrameShape(QFrame::WinPanel);
    terrain5->setFrameShape(QFrame::WinPanel);
    terrain6->setFrameShape(QFrame::WinPanel);
    terrain7->setFrameShape(QFrame::WinPanel);
    terrain8->setFrameShape(QFrame::WinPanel);
    terrain1->setFrameShape(QFrame::WinPanel);
}
/***********************************************************************************************************************
 * Version history:
 *  * 26-08-2004
 *   -
 *
 ***********************************************************************************************************************/