/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: tiledlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: tiledlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "TileDlg.h"

#include <qcheckbox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a TileDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
TileDlg::TileDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "TileDlg" );
    resize( 500, 248 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Tile" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 350, 60 ) ); 
    GroupBox2->setTitle( tr( "Parameters" ) );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 20, 100, 20 ) ); 
    lbl1->setText( tr( "Edge tile offset" ) );
    lbl1->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    tile_offset = new QSlider( GroupBox2, "tile_offset" );
    tile_offset->setGeometry( QRect( 135, 20, 150, 20 ) ); 
    tile_offset->setMaxValue( 100 );
    tile_offset->setPageStep( 0 );
    tile_offset->setValue( 10 );
    tile_offset->setOrientation( QSlider::Horizontal );
    tile_offset->setTickmarks( QSlider::NoMarks );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 295, 18, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "0.10" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 170 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 175, 205, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 185, 498, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    GroupBox3 = new QGroupBox( this, "GroupBox3" );
    GroupBox3->setGeometry( QRect( 140, 70, 350, 110 ) ); 
    GroupBox3->setTitle( tr( "Terrain Assembly" ) );

    lbl2 = new QLabel( GroupBox3, "lbl2" );
    lbl2->setGeometry( QRect( 10, 50, 60, 20 ) ); 
    lbl2->setText( tr( "X Axis" ) );
    lbl2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl3 = new QLabel( GroupBox3, "lbl3" );
    lbl3->setGeometry( QRect( 10, 80, 110, 20 ) ); 
    lbl3->setText( tr( "Y Axis" ) );

    assemble_terrains = new QCheckBox( GroupBox3, "assemble_terrains" );
    assemble_terrains->setGeometry( QRect( 10, 20, 165, 21 ) ); 
    assemble_terrains->setText( tr( "Assemble Tiled Terrains" ) );

    assemble_terrains_x = new QSlider( GroupBox3, "assemble_terrains_x" );
    assemble_terrains_x->setGeometry( QRect( 135, 50, 150, 20 ) ); 
    assemble_terrains_x->setMinValue( 1 );
    assemble_terrains_x->setMaxValue( 10 );
    assemble_terrains_x->setPageStep( 0 );
    assemble_terrains_x->setValue( 1 );
    assemble_terrains_x->setOrientation( QSlider::Horizontal );
    assemble_terrains_x->setTickmarks( QSlider::NoMarks );

    assemble_terrains_y = new QSlider( GroupBox3, "assemble_terrains_y" );
    assemble_terrains_y->setGeometry( QRect( 135, 80, 150, 20 ) ); 
    assemble_terrains_y->setMinValue( 1 );
    assemble_terrains_y->setMaxValue( 10 );
    assemble_terrains_y->setPageStep( 0 );
    assemble_terrains_y->setValue( 1 );
    assemble_terrains_y->setOrientation( QSlider::Horizontal );
    assemble_terrains_y->setTickmarks( QSlider::NoMarks );

    slid3 = new QLabel( GroupBox3, "slid3" );
    slid3->setGeometry( QRect( 295, 76, 35, 20 ) ); 
    QFont slid3_font(  slid3->font() );
    slid3_font.setPointSize( 10 );
    slid3_font.setBold( TRUE );
    slid3->setFont( slid3_font ); 
    slid3->setText( tr( "1" ) );
    slid3->setAlignment( int( QLabel::AlignCenter ) );

    slid2 = new QLabel( GroupBox3, "slid2" );
    slid2->setGeometry( QRect( 295, 46, 35, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2_font.setBold( TRUE );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "1" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

	terra = NULL;

    // signals and slots connections
    connect( tile_offset, SIGNAL(valueChanged(int)), this, SLOT(setOffset(int)) );
    connect( assemble_terrains, SIGNAL(clicked()), this, SLOT(terasClicked()));
    connect( assemble_terrains_x, SIGNAL(valueChanged(int)), this, SLOT(setAssemX(int)) );
    connect( assemble_terrains_y, SIGNAL(valueChanged(int)), this, SLOT(setAssemY(int)) );
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
TileDlg::~TileDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool TileDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev );

    if ( ev->type() == QEvent::ApplicationFontChange )
	{
		QFont slid1_font(  slid1->font() );
		slid1_font.setPointSize( 10 );
		slid1_font.setBold( TRUE );
		slid1->setFont( slid1_font ); 
		QFont slid3_font(  slid3->font() );
		slid3_font.setPointSize( 10 );
		slid3_font.setBold( TRUE );
		slid3->setFont( slid3_font ); 
		QFont slid2_font(  slid2->font() );
		slid2_font.setPointSize( 10 );
		slid2_font.setBold( TRUE );
		slid2->setFont( slid2_font ); 
    }
    return ret;
}

void TileDlg::setOffset(int value)
{
}

void TileDlg::terasClicked()
{
}

void TileDlg::setAssemX(int value)
{
}

void TileDlg::setAssemY(int value)
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/