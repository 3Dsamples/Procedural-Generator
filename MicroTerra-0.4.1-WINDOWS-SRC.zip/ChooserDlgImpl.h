/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: chooserdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: chooserdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENCHOOSERDLHIMPL_H
#define GENCHOOSERDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "ChooserDlg.h"
#include "tterrain.h"
#include <qlineedit.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qlabel.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/
/**
 * @class ChooserDlgImpl
 * Dialog to set the properties of the perlin window.
 */
class ChooserDlgImpl : public ChooserDlg
{ 
    Q_OBJECT

public:
    ChooserDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~ChooserDlgImpl();
	TTerrain *getButtonChoice();

	TTerrain *bter1;
	TTerrain *bter2;
	TTerrain *bter3;
	TTerrain *bter4;
	TTerrain *bter5;
	TTerrain *bter6;
	TTerrain *bter7;
	TTerrain *bter8;
	TTerrain *bter9;
	TTerrain *ter1;
	TTerrain *ter2;
	TTerrain *ter3;
	TTerrain *ter4;
	TTerrain *ter5;
	TTerrain *ter6;
	TTerrain *ter7;
	TTerrain *ter8;
	TTerrain *ter9;

public slots:
	TTerrain *fixterrain(TTerrain *fter);
//	void vt1Clicked();
//	void vt2Clicked();
//	void vt3Clicked();
//	void vt4Clicked();
//	void vt5Clicked();
//	void vt6Clicked();
//	void vt7Clicked();
//	void vt8Clicked();
//	void vt9Clicked();
	void randClicked();

};

#endif // GENCHOOSERDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 26-08-2004
 *   - created
 *
 ***********************************************************************************************************************/