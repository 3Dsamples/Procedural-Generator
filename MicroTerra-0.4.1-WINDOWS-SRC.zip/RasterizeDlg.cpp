/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: rasterize.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: rasterize
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "RasterizeDlg.h"

#include <qcheckbox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a RasterizeDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
RasterizeDlg::RasterizeDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if (!name)
		setName("RasterizeDlg");
    resize(496, 221); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Rasterize" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 145 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 175, 180, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 160, 498, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 350, 145 ) ); 
    GroupBox2->setTitle( tr( "Parameters" ) );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 20, 60, 20 ) ); 
    lbl1->setText( tr( "Preview" ) );

    rasterize_xsize = new QSlider( GroupBox2, "rasterize_xsize" );
    rasterize_xsize->setGeometry( QRect( 135, 50, 150, 20 ) ); 
    rasterize_xsize->setMinValue( 1 );
    rasterize_xsize->setMaxValue( 50 );
    rasterize_xsize->setPageStep( 0 );
    rasterize_xsize->setValue( 10 );
    rasterize_xsize->setOrientation( QSlider::Horizontal );
    rasterize_xsize->setTickmarks( QSlider::NoMarks );

    rasterize_ysize = new QSlider( GroupBox2, "rasterize_ysize" );
    rasterize_ysize->setGeometry( QRect( 135, 80, 150, 20 ) ); 
    rasterize_ysize->setMinValue( 1 );
    rasterize_ysize->setMaxValue( 50 );
    rasterize_ysize->setPageStep( 0 );
    rasterize_ysize->setValue( 10 );
    rasterize_ysize->setOrientation( QSlider::Horizontal );
    rasterize_ysize->setTickmarks( QSlider::NoMarks );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 295, 50, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "10" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    slid2 = new QLabel( GroupBox2, "slid2" );
    slid2->setGeometry( QRect( 295, 76, 35, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2_font.setBold( TRUE );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "10" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

    rasterize_factor = new QSlider( GroupBox2, "rasterize_factor" );
    rasterize_factor->setGeometry( QRect( 135, 110, 150, 20 ) ); 
    rasterize_factor->setMinValue( 0 );
    rasterize_factor->setMaxValue( 100 );
    rasterize_factor->setPageStep( 0 );
    rasterize_factor->setValue( 50 );
    rasterize_factor->setOrientation( QSlider::Horizontal );
    rasterize_factor->setTickmarks( QSlider::NoMarks );

    slid3 = new QLabel( GroupBox2, "slid3" );
    slid3->setGeometry( QRect( 295, 109, 35, 17 ) ); 
    QFont slid3_font(  slid3->font() );
    slid3_font.setPointSize( 10 );
    slid3_font.setBold( TRUE );
    slid3->setFont( slid3_font ); 
    slid3->setText( tr( "0.50" ) );
    slid3->setAlignment( int( QLabel::AlignCenter ) );

    lbl2 = new QLabel( GroupBox2, "lbl2" );
    lbl2->setGeometry( QRect( 10, 50, 60, 20 ) ); 
    lbl2->setText( tr( "Width" ) );
    lbl2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl3 = new QLabel( GroupBox2, "lbl3" );
    lbl3->setGeometry( QRect( 10, 80, 60, 17 ) ); 
    lbl3->setText( tr( "Depth" ) );
    lbl3->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl4 = new QLabel( GroupBox2, "lbl4" );
    lbl4->setGeometry( QRect( 10, 110, 110, 20 ) ); 
    lbl4->setText( tr( "Tightness factor" ) );

    rasterize_do_adjust_size = new QCheckBox( GroupBox2, "rasterize_do_adjust_size" );
    rasterize_do_adjust_size->setGeometry( QRect( 135, 20, 150, 20 ) ); 
    rasterize_do_adjust_size->setText( tr( "Adjust size parameter" ) );
    rasterize_do_adjust_size->setChecked( TRUE );

	terra = NULL;

    // signals and slots connections
    connect( rasterize_do_adjust_size, SIGNAL(clicked()), this, SLOT(adjustClicked()));
    connect( rasterize_xsize, SIGNAL(valueChanged(int)), this, SLOT(setXsize(int)) );
    connect( rasterize_ysize, SIGNAL(valueChanged(int)), this, SLOT(setYsize(int)) );
    connect( rasterize_factor, SIGNAL(valueChanged(int)), this, SLOT(setFactor(int)) );
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
RasterizeDlg::~RasterizeDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool RasterizeDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont slid1_font(  slid1->font() );
	slid1_font.setPointSize( 10 );
	slid1_font.setBold( TRUE );
	slid1->setFont( slid1_font ); 
	QFont slid2_font(  slid2->font() );
	slid2_font.setPointSize( 10 );
	slid2_font.setBold( TRUE );
	slid2->setFont( slid2_font ); 
	QFont slid3_font(  slid3->font() );
	slid3_font.setPointSize( 10 );
	slid3_font.setBold( TRUE );
	slid3->setFont( slid3_font ); 
    }
    return ret;
}

void RasterizeDlg::adjustClicked()
{
}

void RasterizeDlg::setXsize(int value)
{
}

void RasterizeDlg::setYsize(int value)
{
}

void RasterizeDlg::setFactor(int value)
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - 
 *
 ***********************************************************************************************************************/