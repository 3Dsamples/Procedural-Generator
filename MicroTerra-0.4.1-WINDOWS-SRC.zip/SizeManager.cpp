/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: sizemanager.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: sizemanager
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "SizeManager.h"

#include <qapplication.h>
#include <qrect.h>

/** ***************************************************************************************************************** **/
/** 				     CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/

#define MAIN_WIDTH  960
#define MAIN_HEIGHT 500

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/****[ public members ]****/
/* 
 *  Constructs a SizeManager which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
SizeManager::SizeManager()
{
	geo_base = new (QRect);
/*
	geo_base->setRect(
                       (int)(QApplication::desktop()->width() - (QApplication::desktop()->width() - (QApplication::desktop()->width() / 2)) * 1.5) / 2,
                       (int)(QApplication::desktop()->height() - (QApplication::desktop()->height() - (QApplication::desktop()->height() / 2)) * 1.5) / 2,
                       (int)((QApplication::desktop()->width() - (QApplication::desktop()->width() / 2)) * 1.5),
                       (int)((QApplication::desktop()->height() - (QApplication::desktop()->height() / 2)) * 1.5));
*/
	geo_base->setRect(
						(int)(QApplication::desktop()->width() - MAIN_WIDTH) / 2,
						(int)(QApplication::desktop()->height() - MAIN_HEIGHT) / 2,
						MAIN_WIDTH, MAIN_HEIGHT);

	page1 = new SMterrain();
	page1->geo_notebook = new QRect();
	page1->geo_group1 = new QRect();
	page1->geo_terrain = new QRect();
	page1->geo_group2 = new QRect();
	page1->geo_group3 = new QRect();
	page1->geo_group4 = new QRect();
	page1->geo_group5 = NULL;
	page1->geo_group6 = NULL;
	page1->geo_group7 = NULL;
	page1->geo_notebook->setRect(10, 25, 940, 470);
	page1->geo_group1->setRect(5, 10, 35, 424);
	page1->geo_terrain->setRect(45, 10, 424, 424);
	page1->geo_group2->setRect(480, 10, 115, 424);
	page1->geo_group3->setRect(605, 10, 285, 424);
	page1->geo_group4->setRect(895, 10, 35, 424);

	page2 = new SMterrain();
	page2->geo_notebook = NULL;
	page2->geo_group1 = new QRect();
	page2->geo_terrain = new QRect();
	page2->geo_group2 = new QRect();
	page2->geo_group3 = new QRect();
	page2->geo_group4 = new QRect();
	page2->geo_group5 = new QRect();
	page2->geo_group6 = new QRect();
	page2->geo_group7 = new QRect();
	page2->geo_group1->setRect(5, 10, 35, 424);
	page2->geo_terrain->setRect(10, 10, 424, 424);
	page2->geo_group2->setRect(445, 5, 118, 230);  //command buttons
	page2->geo_group3->setRect(568, 12, 365, 252); // stack
	page2->geo_group4->setRect(445, 240, 40, 25); //button run
	page2->geo_group5->setRect(525, 240, 40, 25); //button clear
	page2->geo_group6->setRect(445, 270, 485, 22); //command line
	page2->geo_group7->setRect(445, 297, 485, 135); //messages

	current_page = SM_NOPAGE;
	firstTime = true;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
SizeManager::~SizeManager()
{
    // no need to delete child widgets, Qt does it all for us
}

int SizeManager::get_Page()
{
	switch (current_page)
	{
		case SM_NOPAGE:
			return 0;
			break;
		case SM_PAGE1:
			return 1;
			break;
		case SM_PAGE2:
			return 2;
			break;
		case SM_PAGE3:
			return 3;
			break;
	}

	return -1;
}

void SizeManager::set_Page(int page)
{
	switch (page)
	{
		case 1:
			current_page = SM_PAGE1;
			if (firstTime == true)
			{
				update_firsttime();
				firstTime = false;
			}
			else
				update_pageone();
			break;
		case 2:
			current_page = SM_PAGE2;
			if (firstTime == true)
			{
				update_firsttime();
				firstTime = false;
			}
			else
				update_pagetwo();
			break;
		case 3:
			current_page = SM_PAGE1;
			break;
		default:
			current_page = SM_NOPAGE;
			break;
	}
}

QRect *SizeManager::get_BaseGeometry()
{
	return geo_base;
}

void SizeManager::set_BaseGeometry(QRect *base)
{
	int w, h, x, y;

	base->rect(&x, &y, &w, &h);
	geo_base->setRect(x, y, w, h);
}

/****[ private members ]****/

void SizeManager::update_firsttime()
{
	int w, h, tx, ty;
	int zoom;

	geo_base->rect(&tx, &ty, &w, &h);
	zoom = (int)((QApplication::desktop()->width() - w) / 50);
	geo_base->setRect((int)(QApplication::desktop()->width() - (w + (zoom * 50))) / 2, (int)(QApplication::desktop()->height() - (h + (zoom * 50))) / 2, (w + (zoom * 50)), (h + (zoom * 50)));
	page1->geo_notebook->rect(&tx, &ty, &w, &h);
	page1->geo_notebook->setRect(10, 25, (w + (zoom * 50)), (h + (zoom * 50)));
	page1->geo_group1->rect(&tx, &ty, &w, &h);
	page1->geo_group1->setRect(5, 10, 35, (h + (zoom * 50)));
	page1->geo_terrain->rect(&tx, &ty, &w, &h);
	page1->geo_terrain->setRect(45, 10, (w + (zoom * 50)), (h + (zoom * 50)));
	page1->geo_group2->rect(&tx, &ty, &w, &h);
	page1->geo_group2->setRect((tx + (zoom * 50)), 10, 115, (h + (zoom * 50)));
	page1->geo_group3->rect(&tx, &ty, &w, &h);
	page1->geo_group3->setRect((tx + (zoom * 50)), 10, 285, (h + (zoom * 50)));
	page1->geo_group4->rect(&tx, &ty, &w, &h);
	page1->geo_group4->setRect((tx + (zoom * 50)), 10, 35, (h + (zoom * 50)));
	page2->geo_group1->rect(&tx, &ty, &w, &h);
	page2->geo_group1->setRect(5, 10, 35, (h + (zoom * 50)));
	page2->geo_terrain->rect(&tx, &ty, &w, &h);
	page2->geo_terrain->setRect(10, 10, (w + (zoom * 50)), (h + (zoom * 50)));
	page2->geo_group2->rect(&tx, &ty, &w, &h);
	page2->geo_group2->setRect((tx + (zoom * 50)), 5, 118, 230);
	page2->geo_group3->rect(&tx, &ty, &w, &h);
	page2->geo_group3->setRect((tx + (zoom * 50)), 12, 365, 252);
	page2->geo_group4->rect(&tx, &ty, &w, &h);
	page2->geo_group4->setRect((tx + (zoom * 50)), 240, 40, 25);
	page2->geo_group5->rect(&tx, &ty, &w, &h);
	page2->geo_group5->setRect((tx + (zoom * 50)), 240, 40, 25);
	page2->geo_group6->rect(&tx, &ty, &w, &h);
	page2->geo_group6->setRect((tx + (zoom * 50)), 270, 485, 22);
	page2->geo_group7->rect(&tx, &ty, &w, &h);
	page2->geo_group7->setRect((tx + (zoom * 50)), 297, 35, (h + (zoom * 50)));
}

void SizeManager::update_pageone()
{
	int w, h, tx, ty;
	int zoom;

	geo_base->rect(&tx, &ty, &w, &h);
	zoom = (int)((QApplication::desktop()->width() - w) / 50);
	geo_base->setRect((int)(QApplication::desktop()->width() - (w + (zoom * 50))) / 2, (int)(QApplication::desktop()->height() - (h + (zoom * 50))) / 2, (w + (zoom * 50)), (h + (zoom * 50)));
	page1->geo_notebook->rect(&tx, &ty, &w, &h);
	page1->geo_notebook->setRect(10, 25, (w + (zoom * 50)), (h + (zoom * 50)));
	page1->geo_group1->rect(&tx, &ty, &w, &h);
	page1->geo_group1->setRect(5, 10, 35, (h + (zoom * 50)));
	page1->geo_terrain->rect(&tx, &ty, &w, &h);
	page1->geo_terrain->setRect(45, 10, (w + (zoom * 50)), (h + (zoom * 50)));
	page1->geo_group2->rect(&tx, &ty, &w, &h);
	page1->geo_group2->setRect((tx + (zoom * 50)), 10, 115, (h + (zoom * 50)));
	page1->geo_group3->rect(&tx, &ty, &w, &h);
	page1->geo_group3->setRect((tx + (zoom * 50)), 10, 285, (h + (zoom * 50)));
	page1->geo_group4->rect(&tx, &ty, &w, &h);
	page1->geo_group4->setRect((tx + (zoom * 50)), 10, 35, (h + (zoom * 50)));
}

void SizeManager::update_pagetwo()
{
	int w, h, tx, ty;
	int zoom;

	geo_base->rect(&tx, &ty, &w, &h);
	zoom = (int)((QApplication::desktop()->width() - w) / 50);
	geo_base->setRect((int)(QApplication::desktop()->width() - (w + (zoom * 50))) / 2, (int)(QApplication::desktop()->height() - (h + (zoom * 50))) / 2, (w + (zoom * 50)), (h + (zoom * 50)));
	page2->geo_group1->rect(&tx, &ty, &w, &h);
	page2->geo_group1->setRect(5, 10, 35, (h + (zoom * 50)));
	page2->geo_terrain->rect(&tx, &ty, &w, &h);
	page2->geo_terrain->setRect(10, 10, (w + (zoom * 50)), (h + (zoom * 50)));
	page2->geo_group2->rect(&tx, &ty, &w, &h);
	page2->geo_group2->setRect((tx + (zoom * 50)), 5, 118, 230);
	page2->geo_group3->rect(&tx, &ty, &w, &h);
	page2->geo_group3->setRect((tx + (zoom * 50)), 12, 365, 252);
	page2->geo_group4->rect(&tx, &ty, &w, &h);
	page2->geo_group4->setRect((tx + (zoom * 50)), 240, 40, 25);
	page2->geo_group5->rect(&tx, &ty, &w, &h);
	page2->geo_group5->setRect((tx + (zoom * 50)), 240, 40, 25);
	page2->geo_group6->rect(&tx, &ty, &w, &h);
	page2->geo_group6->setRect((tx + (zoom * 50)), 270, 485, 22);
	page2->geo_group7->rect(&tx, &ty, &w, &h);
	page2->geo_group7->setRect((tx + (zoom * 50)), 297, 485, (h + (zoom * 50)));
}
/***********************************************************************************************************************
 * Version history:
 *  * 14-10-2004
 *   - created
 *
 ***********************************************************************************************************************/
