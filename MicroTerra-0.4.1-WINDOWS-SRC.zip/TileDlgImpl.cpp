/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: tiledlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: tiledlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "TileDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

TileDlgImpl::TileDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : TileDlg( parent, name, modal, fl )
{
	offset = (float)0.10;
	assemx = 1;
	assemy = 1;
	teras = false;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
TileDlgImpl::~TileDlgImpl()
{
}

void TileDlgImpl::update_preview()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	t_terrain_tiler(clone, offset);
	t_terrain_tile(clone, 2);

	PreView->t_terrain_view_set_terrain(clone);
}

void TileDlgImpl::setOffset(int value)
{
	char buf[15];

	offset = (float)(value/100.0);
	sprintf(buf,"%1.2f", offset);
	slid1->setText((char *)buf);
	update_preview();
}

void TileDlgImpl::setAssemX(int value)
{
	char buf[15];

	assemx = value;
	sprintf(buf,"%d", assemx);
	slid2->setText((char *)buf);
	update_preview();
}

void TileDlgImpl::setAssemY(int value)
{
	char buf[15];

	assemy = value;
	sprintf(buf,"%d", assemy);
	slid3->setText((char *)buf);
	update_preview();
}

void TileDlgImpl::terasClicked()
{
	teras = assemble_terrains->isChecked();
	update_preview();
}
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/