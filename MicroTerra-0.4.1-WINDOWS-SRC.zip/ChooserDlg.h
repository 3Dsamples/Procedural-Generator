/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: chooserdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: chooserdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef CHOOSERDLG_H
#define CHOOSERDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QFrame;
class QGroupBox;
class QPushButton;
#include "terrainview.h"

class ChooserDlg : public QDialog
{ 
    Q_OBJECT

public:
    ChooserDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~ChooserDlg();

    QPushButton* rand_btn;
    QPushButton* ok_btn;
    QPushButton* cancel_btn;
    QGroupBox* GroupBox1;
//	QButton* terrain1;
    QFrame* terrain1;
	TerrainView* View1;
    QFrame* terrain2;
	TerrainView* View2;
    QFrame* terrain3;
	TerrainView* View3;
    QFrame* terrain4;
	TerrainView* View4;
    QFrame* terrain5;
	TerrainView* View5;
    QFrame* terrain6;
	TerrainView* View6;
    QFrame* terrain7;
	TerrainView* View7;
    QFrame* terrain8;
	TerrainView* View8;
    QFrame* terrain9;
	TerrainView* View9;
	int mm1;
	int mm2;
	int mm3;
	int mm4;
	int mm5;
	int mm6;
	int mm7;
	int mm8;
	int mm9;

public slots:
	void vt1Clicked();
	void vt2Clicked();
	void vt3Clicked();
	void vt4Clicked();
	void vt5Clicked();
	void vt6Clicked();
	void vt7Clicked();
	void vt8Clicked();
	void vt9Clicked();
	virtual void randClicked();

protected:
    QHBoxLayout* Layout1;
};

#endif // CHOOSERDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 26-08-2004
 *   - created
 *
 ***********************************************************************************************************************/