/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: colormaps.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: colormaps
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <math.h>
#include "colormaps.h"

/** ***************************************************************************************************************** **/
/** 				     CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/

static const int colormap_land_data[15] =
{
  0x191970 /* MidnightBlue */,
  0x0000cd /* MediumBlue */,
  0x0000ff /* Blue */,
  0x1e90ff /* Dodger Blue */,
  0x00ee00 /* Green2 */,
  0x00cd00 /* Green3 */,
  0x00b800 /* Green4 */,
  0x6e8b3d /* DarkOliveGreen4 */,
  0xeedc82 /* LightGoldenrod2 */,
  0xcdbe70 /* LightGoldenrod3 */,
  0x8b814c /* LightGoldenrod4 */,
  0x8b8b7a /* LightYellow4 */,
  0x696969 /* DimGray */,
  0xbebebe /* Gray */,
  0xd3d3d3 /* LightGray */
};
static const int colormap_land_count = 15;
static const int colormap_land_boundary = 4;

static const int colormap_desert_data[6] =
{
  0xcdbe70 /* LightGoldenrod3 */,
  0x8b814c /* LightGoldenrod4 */,
  0x696969 /* DimGray */,
  0x778899 /* LightSlateGray */,
  0xbebebe /* Gray */,
  0xd3d3d3 /* LightGray */
};
static const int colormap_desert_count = 6;
static const int colormap_desert_boundary = 1;

static const int colormap_heat_data[12] =
{
  0xaf00af /* Purple */,
  0xff00ff /* Purple */,
  0xaf00af /* Purple */,
  0x0000ff /* Blue */,
  0x00ffff /* Cyan */,
  0x00afaf /* Cyan */,
  0x00ffff /* Cyan */,
  0x00ff00 /* Green */,
  0xafaf00 /* Yellow */,
  0xffff00 /* Yellow */,
  0xafaf00 /* Yellow */,
  0xff0000 /* Red */
};
static const int colormap_heat_count = 12;

static const int colormap_wasteland_data[51] =
  {
    0x006bef,
    0x00a0f0,
    0x00ccf0,
    0x00e0ef,
    0x00d0e0,
    0x00b0b3,
    0x009090,
    0x006f5f,
    0x3b7f60,
    0x5b9070,
    0x709070,
    0x8c9f70,
    0x9ca07f,
    0xa0af7f,
    0xa09f7f,
    0x9f9f6f,
    0x908f70,
    0x8f8f6f,
    0x7f7f63,
    0x7f7f60,
    0x73735f,
    0x707061,
    0x6f6f50,
    0x60604f,
    0x5f5f51,
    0x505040,
    0x4f4f3f,
    0x433f30,
    0x3f3f2f,
    0x2f2f23,
    0x2f2f1f,
    0x2f2f1f,
    0x2f301f,
    0x2f2e1f,
    0x313f1f,
    0x20401f,
    0x20401f,
    0x204f1f,
    0x20501f,
    0x20501f,
    0x20601f,
    0x206f20,
    0x208c30,
    0x1e9e2e,
    0x3abf4c,
    0x7bd040,
    0xbcd040,
    0xd0df50,
    0xe0e060,
    0xe0e052,
    0xeff0b5
  };
static const int colormap_wasteland_count = 51;
 
/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

ColorMaps::ColorMaps()
{
	colmap = new int[768];
}

ColorMaps::~ColorMaps()
{
}

void ColorMaps::colormap_gradient(int    start,
                                  int    stop,
                                  int    r1,
                                  int    g1,
                                  int    b1,
                                  int    r2,
                                  int    g2,
                                  int    b2)
{
  int i;
  int delta;
  float g_r1, g_g1, g_b1;
  float g_r2, g_g2, g_b2;

  g_r1 = (float)pow(r1 / 255.0, 1.6);
  g_g1 = (float)pow(g1 / 255.0, 1.6);
  g_b1 = (float)pow(b1 / 255.0, 1.6);
  g_r2 = (float)pow(r2 / 255.0, 1.6);
  g_g2 = (float)pow(g2 / 255.0, 1.6);
  g_b2 = (float)pow(b2 / 255.0, 1.6);

  g_r1 = (float)(r1 / 255.0);
  g_g1 = (float)(g1 / 255.0);
  g_b1 = (float)(b1 / 255.0);
  g_r2 = (float)(r2 / 255.0);
  g_g2 = (float)(g2 / 255.0);
  g_b2 = (float)(b2 / 255.0);

  delta = stop - start;
  for (i = 0; i < delta; i++)
    {
      float r, g, b;

      r = (float)(g_r1 + i * (g_r2 - g_r1) / delta);
      g = (float)(g_g1 + i * (g_g2 - g_g1) / delta);
      b = (float)(g_b1 + i * (g_b2 - g_b1) / delta);

      r = (float)pow(r, 1.6);
      g = (float)pow(g, 1.6);
      b = (float)pow(b, 1.6);

      colmap[(start + i) * 3 + 0] = (int)(r * 255.0 + 0.5);
      colmap[(start + i) * 3 + 1] = (int)(g * 255.0 + 0.5);
      colmap[(start + i) * 3 + 2] = (int)(b * 255.0 + 0.5);
    }
}

void ColorMaps::colormap_gradient_bands(int index_start, int index_stop, int num_points, int offset)
{
  int i;
  int num_divisions;

  num_divisions = num_points - 1;
  for (i = 0; i < num_divisions; i++)
  {
      int start, stop;

      start = index_start + i * (index_stop - index_start + 1) / num_divisions;
      stop = index_start + (i + 1) *
             (index_stop - index_start + 1) / num_divisions;

      if (cmore)
	  {
	    colormap_gradient (start, stop, (colors[i+offset] >> 16) & 0xff, (colors[i+offset] >> 8) & 0xff, colors[i+offset] & 0xff, (colors[(i+offset) + 1] >> 16) & 0xff, (colors[(i+offset) + 1] >> 8) & 0xff, colors[(i+offset) + 1] & 0xff);
	  } else {
	    colormap_gradient (start, stop, (colors[i] >> 16) & 0xff, (colors[i] >> 8) & 0xff, colors[i] & 0xff, (colors[i + 1] >> 16) & 0xff, (colors[i + 1] >> 8) & 0xff, colors[i + 1] & 0xff);
	  }
  }
}

void ColorMaps::colormap_land_bands(int        num_bands,
                                    float      water_level,
                                    int        land_level)
{
  int middle_index;

  middle_index = (int)MIN (MAX (((int) (water_level * 255.0 + 0.5)), 0), 255);

  cmore = false;
  colormap_gradient_bands (0, middle_index, land_level + 1, land_level);
  cmore = true;
  colormap_gradient_bands (middle_index + 1, 255, num_bands - land_level, land_level);
}

void ColorMaps::colormap_new(TColormapType which_colormap, float water_level)
{
  switch (which_colormap)
    {
    case T_COLORMAP_LAND: 
      colors = colormap_land_data;
	  colormap_land_bands (colormap_land_count, water_level, colormap_land_boundary);
      break;

    case T_COLORMAP_DESERT: 
      colors = colormap_desert_data;
      cmore = false;
      colormap_gradient_bands (0, 255, colormap_desert_count, 0);
      break;

    case T_COLORMAP_GRAYSCALE:
      colormap_gradient (0, 255, 0, 0, 0, 255, 255, 255);
      break;

    case T_COLORMAP_HEAT:
      colors = colormap_heat_data;
      cmore = false;
      colormap_gradient_bands (0, 255, colormap_heat_count, 0);
      break;
    case T_COLORMAP_WASTELAND:
      colors = colormap_wasteland_data;
      cmore = false;
      colormap_gradient_bands (0, 255, colormap_wasteland_count, 0);
      break;

    default: /* T_COLORMAP_GRAYSCALE */
      colormap_gradient (0, 255, 0, 0, 0, 255, 255, 255);
      break;
    }
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   -
 *
 ***********************************************************************************************************************/