/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: transformdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: transformdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef TRANSFORMDLHIMPL_H
#define TRANSFORMDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "TransformDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class TransformDlgImpl : public TransformDlg
{ 
    Q_OBJECT

public:
    TransformDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~TransformDlgImpl();

	float threshold;
	float depth;
	float dropoff;
	float above;
	float below;

public slots:
	void setThreshold(int value);
	void setDepth(int value);
	void setDropoff(int value);
	void setAbove(int value);
	void setBelow(int value);

protected:
	void update_preview();

};

#endif // TRANSFORMDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/