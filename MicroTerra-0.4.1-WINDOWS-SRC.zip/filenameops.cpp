/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: filenameops.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: filenameops
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "qstring.h"
#include "mt.h"
#include "filenameops.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

FilenameOps::FilenameOps()
{
}

FilenameOps::~FilenameOps()
{
}

/**
 * filename_age: parse a filename and attempt to either update an existing 
 * 	versioning scheme or insert a new one into the string. All memory is 
 * 	allocated using malloc and the returned pointer should be disposed of 
 * 	using free(), not the C++ delete.
 * 
 * The Naming convention used is as follows: 
 * 	name-version.extension
 * where something like "filename-01.tga" becomes "filename-02.tga" and 
 * something like "filename.tga" becomes "filename-01.tga" 
 *
 * This is actually plain C code (regardless of the *.cc file it's in)
 */ 
char *FilenameOps::filename_age(char *name)
{
	char 	*lMinus,				/* location of Minus sign */
		*lDot,					/* location of Dot */
		*dst,					/* destination string */
		*s; 
	char	version[80];				/* actual version part of string */
	int	val;
	int	insert=false;

	if (!name) 
		return NULL;

	lMinus = strchr(name, '-');
	lDot = strchr(name, '.');

	if (!lDot) 					/* should at least be able to find the dot */
		return NULL;

	if (!lMinus) 					/* no minus -> insert a new one */
		insert = true;

	dst = (char *)malloc(strlen(name)+16);
	if (!dst)
		return NULL;

	if (insert)					/* insert a new version */
		{
		strncpy(dst, name, lDot-name);
		dst[lDot-name] = '\0';
		strcat(dst, "-01");
		strcat(dst, lDot);
		}
	else						/* update existing version */
		{
		s = lMinus+1;
		while (s < lDot)
			{
			if (!isdigit(*s))
				break;
			s++;
			}

		if (s != lDot)				/* break, it's not all numbers */
			return NULL;

		strncpy(version, lMinus+1, lDot-lMinus);
		version[lDot-lMinus] = '\0';
		val = atoi (version);
		sprintf(version, "-%02d", val+1);
		strncpy(dst, name, lMinus-name);
		dst[lMinus-name] = '\0';
		strcat(dst, version);
		strcat(dst, lDot);
		}

	/* printf ("%s ---> %s\n", name, dst); */
	return (dst);
}


/*
 * filename_new_extension:  Return a new filename by replacing the
 * extension of the filename passed in.  If it has no extension, add one.
 * The extension parameter should not have a preceding dot-- it will be added.
 * If extension == NULL, then a new extension is not added.
 */

char *FilenameOps::filename_new_extension(char *name, char *extension)
{
	char *dot, *slash;
	char *temp, *dummy;

	temp = strdup(name);

	dot = strrchr(temp, '.');
	slash = strrchr(temp, '/');

	if (dot != NULL && dot > slash)
    {
		/* Filename has an extension, remove it. */
		*dot = '\0';
    }

	if (extension != NULL)
    {
		QString out;
		out.sprintf("%s.%s", temp, extension);
		dummy = strdup((char *)out.latin1());
		return dummy;
    }

	return temp;
}

/*
 * filename_get_base: Return the base filename minus the paths.
 */

char *FilenameOps::filename_get_base(char *name)
{
	char *slash;

	slash = strrchr(name, '/');
	if (slash != NULL)
		return strdup(&slash[1]);

	return strdup(name);
}

/*
 * strip_extension: remove the extension from a filename
 */

char *FilenameOps::strip_extension(char *name)
{
	char *dot;
  
	dot = strrchr(name, '.');

	if (dot != NULL)
    {
		int  l = strlen(name);
		char buf[256];
		int  len = l - (dot-name) + 1;

		strncpy(buf, name, len);
		buf[len] = '\0';
		return strdup(buf);
    }

	return strdup(name);
}

char *FilenameOps::filename_get_without_extension(char *name)
{
  return strip_extension(name);
}

char *FilenameOps::filename_get_base_without_extension(char *name)
{
  char *base = filename_get_base(name);
  char *out = strip_extension(base);

  delete base;
  return out;
}

/*
 * filename_get_friendly: Return a user-friendly filename.
 */

char *FilenameOps::filename_get_friendly(char *name)
{
  char *friendly, *pos;
  int   first;

  friendly = filename_get_base(name);

  first = 1;
  pos = friendly;
  while (*pos != '\0')
    {
      if (first)
        *pos = toupper (*pos);

      if (*pos == '.')
        *pos = '\0';

      if (*pos == '_')
        *pos = ' ';

      first = (*pos == ' ');
      pos++;
    }

  return friendly;
}

char *FilenameOps::filename_get_extension(char *name)
{
  char *dot, *slash;

  dot = strrchr(name, '.');
  slash = strrchr(name, '/');

  if (dot == NULL || dot < slash)
    return strdup("");

  return strdup(&dot[1]);
}

TFileType FilenameOps::filename_determine_type(char *name) /* case-insnsitive */
{
  TFileType  type;
  char      *extension;

  type = FILE_UNKNOWN;
  extension = filename_get_extension(name);

  if (strcasecmp(extension, "mt") == 0)
    type = FILE_NATIVE;
  else if (strcasecmp(extension, "bmp") == 0)
    type = FILE_BMP;
  else if (strcasecmp(extension, "pov") == 0)
    type = FILE_POV;
  else if (strcasecmp(extension, "tga") == 0)
    type = FILE_TGA;
  else if (strcasecmp(extension, "pgm") == 0)
    type = FILE_PGM;
  else if (strcasecmp(extension, "pg8") == 0)
    type = FILE_PG8;
  else if (strcasecmp(extension, "mat") == 0)
    type = FILE_MAT;
  else if (strcasecmp(extension, "oct") == 0)
    type = FILE_OCT;
  else if (strcasecmp(extension, "ac") == 0)
    type = FILE_AC;
  else if (strcasecmp(extension, "dem") == 0 || strcasecmp(extension, "hdr") == 0)
    type = FILE_GTOPO;
  else if (strcasecmp(extension, "grd") == 0)
    type = FILE_GRD;
  else if (strcasecmp(extension, "gif") == 0)
    type = FILE_GIF;
  else if (strcasecmp(extension, "ico") == 0)
    type = FILE_ICO;
  else if (strcasecmp(extension, "jpg") == 0)
    type = FILE_JPG;
  else if (strcasecmp(extension, "png") == 0)
    type = FILE_PNG;
  else if (strcasecmp(extension, "ras") == 0)
    type = FILE_RAS;
  else if (strcasecmp(extension, "tif") == 0)
    type = FILE_TIF;
  else if (strcasecmp(extension, "xbm") == 0)
    type = FILE_XBM;
  else if (strcasecmp(extension, "xpm") == 0)
    type = FILE_XPM;
  else if (strcasecmp(extension, "vrml") == 0)
    type = FILE_VRML;
  else if (strcasecmp(extension, "ter") == 0 || strcasecmp(extension, "terragen") == 0)
    type = FILE_TERRAGEN;
  else if (strcasecmp(extension, "xyz") == 0)
    type = FILE_XYZ;
  else if (strcasecmp(extension, "dxf") == 0)
    type = FILE_DXF;
  else if (strcasecmp(extension, "bna") == 0)
    type = FILE_BNA;
  else if (strcasecmp(extension, "bt") == 0)
    type = FILE_BT;
  else if (strcasecmp(extension, "dted") == 0)
    type = FILE_DTED;
  else if (strcasecmp(extension, "e00" ) == 0)
    type = FILE_E00;

  return type;
}

/* POV-Ray doesn't like certain characters to exist in filenames. */
char *FilenameOps::filename_povray_safe(char *name)
{
	char *safe;
	int   i;

	safe = strdup(name);
	for (i = 0; safe[i] != '\0'; i++)
		if (safe[i] == ' ' || safe[i] == '\"')
			safe[i] = '_';

	return safe;
}

int FilenameOps::strcasecmp(const char *s1, const char *s2)
{
	int c1, c2;

	while (*s1 && *s2)
    {
		/* According to A. Cox, some platforms have islower's that
		 * don't work right on non-uppercase
		 */
		c1 = isupper ((uchar)*s1) ? tolower ((uchar)*s1) : *s1;
		c2 = isupper ((uchar)*s2) ? tolower ((uchar)*s2) : *s2;
		if (c1 != c2)
			return (c1 - c2);
		s1++; s2++;
    }

	return (((int)(uchar) *s1) - ((int)(uchar) *s2));
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/