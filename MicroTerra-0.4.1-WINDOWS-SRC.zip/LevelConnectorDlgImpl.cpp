/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: levelconnectordlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: levelconnectordlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "LevelConnectorDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

LevelConnectorDlgImpl::LevelConnectorDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : LevelConnectorDlg( parent, name, modal, fl )
{
}

/*  
 *  Destroys the object and frees any allocated resources
 */
LevelConnectorDlgImpl::~LevelConnectorDlgImpl()
{
}

void LevelConnectorDlgImpl::iterChanged()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	iterations = count->value();
	t_terrain_connect(clone, iterations);
	PreView->t_terrain_view_set_terrain(clone);
}
/***********************************************************************************************************************
 * Version history:
 *  * 01-12-2004
 *   - created
 *
 ***********************************************************************************************************************/