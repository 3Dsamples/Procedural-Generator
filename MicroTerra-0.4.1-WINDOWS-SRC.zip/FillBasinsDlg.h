/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: fillbasinsdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: fillbasinsdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef FILLBASINSDLG_H
#define FILLBASINSDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;

class FillBasinsDlg : public QDialog
{ 
    Q_OBJECT

public:
    FillBasinsDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~FillBasinsDlg();

    QFrame* Line1;
    QPushButton* OK;
    QPushButton* CANCEL;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QSlider* iterations;
    QLabel* slid1;
    QCheckBox* big_grid;
	TTerrain *terra;

public slots:
	virtual void setIter(int value);
	virtual void biggridClicked();

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // FILLBASINSDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/