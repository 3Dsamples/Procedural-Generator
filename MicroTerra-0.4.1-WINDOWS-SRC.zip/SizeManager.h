/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: sizemanager.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: sizemanager
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef SIZEMANAGER_H
#define SIZEMANAGER_H

/** ***************************************************************************************************************** **/
/** 				      GLOBAL DATATYPES			                                                                  **/
/** ***************************************************************************************************************** **/

enum SMPageActive
{
  SM_NOPAGE,
  SM_PAGE1,
  SM_PAGE2,
  SM_PAGE3
};
 
/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QRect;

class SMterrain
{
public:
	QRect *geo_notebook;
	QRect *geo_group1;
	QRect *geo_terrain;
	QRect *geo_group2;
	QRect *geo_group3;
	QRect *geo_group4;
	QRect *geo_group5;
	QRect *geo_group6;
	QRect *geo_group7;
};

class SizeManager
{ 
public:
    SizeManager();
    ~SizeManager();
	void set_Page(int page);
	int get_Page();
	QRect *get_BaseGeometry();
	void set_BaseGeometry(QRect *base);

	QRect        *geo_base;
	SMterrain    *page1;
	SMterrain    *page2;
	SMPageActive  current_page;
	bool          firstTime;

private:
	void update_firsttime();
	void update_pageone();
	void update_pagetwo();
};

#endif // SIZEMANAGER_H
/***********************************************************************************************************************
 * Version history:
 *  * 14-10-2004
 *   - created
 *
 ***********************************************************************************************************************/
