/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: optionsdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: optionsdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include <qfiledialog.h>
#include "OptionsDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

OptionsDlgImpl::OptionsDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : OptionsDlg( parent, name, modal, fl )
{
	lightwave_path = "";
	ac3d_path = "";
	povray_path = "";
	microterra_path = "";
}

/*  
 *  Destroys the object and frees any allocated resources
 */
OptionsDlgImpl::~OptionsDlgImpl()
{
}

void OptionsDlgImpl::progslightwave_Changed()
{
	if (progs_lightwave->isChecked())
	{
		progs_ac3d->setChecked(false);
		progs_povray->setChecked(false);
	}
	if (progs_lightwave->isChecked() == false && progs_ac3d->isChecked() == false && progs_povray->isChecked() == false)
		progs_lightwave->setChecked(true);
}

void OptionsDlgImpl::progsac3d_Changed()
{
	if (progs_ac3d->isChecked())
	{
		progs_lightwave->setChecked(false);
		progs_povray->setChecked(false);
	}
	if (progs_lightwave->isChecked() == false && progs_ac3d->isChecked() == false && progs_povray->isChecked() == false)
		progs_ac3d->setChecked(true);
}

void OptionsDlgImpl::progspovray_Changed()
{
	if (progs_povray->isChecked())
	{
		progs_lightwave->setChecked(false);
		progs_ac3d->setChecked(false);
	}
	if (progs_lightwave->isChecked() == false && progs_ac3d->isChecked() == false && progs_povray->isChecked() == false)
		progs_povray->setChecked(true);
}

char *OptionsDlgImpl::getExePath()
{
#ifndef QT_NO_FILEDIALOG
    QString fn = QFileDialog::getOpenFileName( QString::null, "3D (*.exe)", this );
    if ( !fn.isEmpty() )
		return strdup((char *)fn.latin1());
#endif
	return NULL;
}

void OptionsDlgImpl::lightwavebrowse()
{
	lightwave_path = getExePath();
	exe_lightwave->setText(lightwave_path);
	delete lightwave_path;
}

void OptionsDlgImpl::ac3dbrowse()
{
	ac3d_path = getExePath();
	exe_ac3d->setText(ac3d_path);
	delete ac3d_path;
}

void OptionsDlgImpl::povraybrowse()
{
	povray_path = getExePath();
	exe_povray->setText(povray_path);
	delete povray_path;
}

void OptionsDlgImpl::setGamma(int value)
{
	char buf[15];

	GammaView->gamma_preview_update(value);
	sprintf(buf,"%1.2f", (float)(value/100.0));
	slid1->setText((char *)buf);
}

void OptionsDlgImpl::defaultsizeChanged()
{
}

void OptionsDlgImpl::randgenfaultingClicked()
{
}

void OptionsDlgImpl::randgenperlinClicked()
{
}

void OptionsDlgImpl::randgenspectralClicked()
{
}

void OptionsDlgImpl::randgensubdivClicked()
{
}

void OptionsDlgImpl::microterrabrowse()
{
#ifndef QT_NO_FILEDIALOG
    QString fn = QFileDialog::getExistingDirectory( QString::null, this, "", "MicroTerra", false );
    if ( !fn.isEmpty() )
		microterra_path = strdup((char *)fn.latin1());
#endif
	dir_microterra->setText(microterra_path);
	delete microterra_path;
}

void OptionsDlgImpl::setXscale(int value)
{
	char buf[15];

	sprintf(buf,"%d", value);
	slid2->setText((char *)buf);
}

void OptionsDlgImpl::setZscale(int value)
{
	char buf[15];

	sprintf(buf,"%d", value);
	slid3->setText((char *)buf);
}

void OptionsDlgImpl::setYscalefactor(int value)
{
	char buf[15];

	sprintf(buf,"%1.2f", (float)(value/100.0));
	slid4->setText((char *)buf);
}

void OptionsDlgImpl::filledseaClicked()
{
}

void OptionsDlgImpl::setSealevel(int value)
{
	char buf[15];

	sprintf(buf,"%1.2f", (float)(value/100.0));
	slid5->setText((char *)buf);
}

void OptionsDlgImpl::setClarity(int value)
{
	char buf[15];

	sprintf(buf,"%1.2f", (float)(value/100.0));
	slid6->setText((char *)buf);
}

void OptionsDlgImpl::setWireframeResolution(int value)
{
	char buf[15];

	sprintf(buf,"%d", value);
	slid7->setText((char *)buf);
}

void OptionsDlgImpl::setCameraHeightFactor(int value)
{
	char buf[15];

	sprintf(buf,"%1.2f", (float)(value/100.0));
	slid8->setText((char *)buf);
}

void OptionsDlgImpl::setLevels(int value)
{
	char buf[15];

	sprintf(buf,"%d", value);
	slid9->setText((char *)buf);
}
/***********************************************************************************************************************
 * Version history:
 *  * 07-12-2004
 *   - created
 *
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/