/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gensubdiv.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gensubdiv
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <math.h>
#include "gensubdiv.h"
//#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/

#define EMPTY           0.0
#define STILL_NORMAL    1
#define STILL_SEAMLESS  0

/** ***************************************************************************************************************** **/
/**				         MACROS				                                                                          **/
/** ***************************************************************************************************************** **/

#define ABS(x)       (((x) >= 0) ? (x) : (-(x)))

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

genSub::genSub( TTerrain* terra )
{
	terrain = terra;
}

genSub::~genSub()
{
}

void genSub::t_terrain_generate_subdiv(int method, int size, float scale, int seed)
{
  t_terrain_generate_subdiv_seed (method, size, scale, seed, -1, -1, -1, -1);
}


void genSub::t_terrain_generate_subdiv_seed(int method, int n, float scale, int seed, int sel_x1, int sel_y1, int sel_w, int sel_h)
{
  t_terrain_generate_subdiv_seed_ns (method, n, n, scale, seed, sel_x1, sel_y1, sel_w, sel_h);
}


/*
 * t_terrain_generate_subdiv_seed_ns: generate to non_square size
 * Even though we only generate square terrains we're passing size_x and 
 * size_y here so that we can return an appropriately sized terrain 
 * when we zoom
 */
void genSub::t_terrain_generate_subdiv_seed_ns(int method, int size_x, int size_y, float scale, int seed, int sel_x1, int sel_y1, int sel_w, int sel_h)
{
  bool doinit = true;
  int  size = preferred_size(MAX(size_x, size_y));

  int lim=size*size;
  int rc=-1; 
  int i=0;

  if (terrain->heightfield != NULL)
  {
    rc = terrain->t_terrain_seed(size, size, sel_x1, sel_y1, sel_w, sel_h);

    if (rc == 0)
    {
      doinit = false;

      // scale seeded points
      for (i=0; i<lim; i++)
        if (terrain->heightfield[i] != EMPTY)
          terrain->heightfield[i] *= size;
    } else {
      return;
    }
  } else {
	delete terrain->heightfield;
	terrain->heightfield = 0;
	terrain->heightfield = new float[lim];
  }
 
  gauss = new TRandom(seed);

  switch (method)
  {
      case 0: /* Recursive Square */
        t_terrain_generate_recursive_square(size, scale, doinit);
        break;

      case 1: /* Recursive Diamond */
        t_terrain_generate_recursive_diamond(size, scale, doinit);
        break;

      case 2: /* Recursive Plasma */
        t_terrain_generate_recursive_plasma(size, scale, doinit);
        break;

      case 3: /* Offset */
        t_terrain_generate_offset(size, scale);
        break;

      case 4: /* Midpoint */
        t_terrain_generate_midpoint(size, scale);
        break;

      case 5: /* Diamond square */
        t_terrain_generate_diamond_square(size, scale);
        break;

      default:
        break;
  }

  delete gauss;
  gauss = 0;

  if (size != size_x || size != size_y)
  {
    int off_x = (size - size_x)/2;
    int off_y = (size - size_y)/2;

    terrain->t_terrain_crop(off_x, off_y, size_x + off_x - 1, size_y + off_y - 1);
  }

  terrain->t_terrain_normalize(false);
  terrain->t_terrain_set_modified(true);
}

void genSub::t_terrain_generate_recursive_square(int size, float scale_factor, bool doinit)
{ 
  int    center;
  float  init_delta;
  float *data;

  data = terrain->heightfield;
  init_delta = size;
  center = (size - 1) >> 1;

  if (doinit)
  {
    data[0] = gauss->t_random_gauss() * init_delta;
    data[center + center * size] = gauss->t_random_gauss() * init_delta;
    data[center * size] = gauss->t_random_gauss() * init_delta;
    data[center] = gauss->t_random_gauss() * init_delta;
    data[center + (size - 1) * size] = gauss->t_random_gauss() * init_delta;
    data[(size - 1) + center * size] = gauss->t_random_gauss() * init_delta;
    data[size * size - 1] = gauss->t_random_gauss() * init_delta;
  }

  // process subsquares recursively
  process_recursive_square (0, 0, center, center, init_delta, scale_factor);
  process_recursive_square (center, 0, size - 1, center, init_delta, scale_factor);
  process_recursive_square (0, center, center, size - 1, init_delta, scale_factor);
  process_recursive_square (center, center, size - 1, size - 1, init_delta, scale_factor);
}

void genSub::t_terrain_generate_recursive_diamond(int size, float scale_factor, bool doinit)
{
  int    center;
  float  init_delta;
  float *data;

  data = terrain->heightfield;
  init_delta = size;
  center = (size - 1) >> 1;

  if (doinit)
  {
    data[0] = gauss->t_random_gauss () * init_delta;
    data[(size - 1) * size] = gauss->t_random_gauss() * init_delta;
    data[size - 1] = gauss->t_random_gauss() * init_delta;
    data[(size - 1) * size + (size - 1)] = gauss->t_random_gauss() * init_delta;
  }

  process_recursive_diamond(0, 0, size - 1, size - 1, init_delta, scale_factor);
}

/*
 *  gereateRecursivePlasma: subdivide and assign
 *      taken from an old Usenet posting, original author unknown
*/

void genSub::t_terrain_generate_recursive_plasma(int size, float scale_factor, bool doinit)
{
  float  init_delta = size;
  float *data = terrain->heightfield;
  int    type = STILL_NORMAL;  /* Type can be either STILL_NORMAL or STILL_SEAMLESS */


  if (doinit)
  {
    data[0] = gauss->t_random_gauss() * init_delta;
    data[size - 1] = gauss->t_random_gauss() * init_delta;
    data[(size - 1) * terrain->width] = gauss->t_random_gauss() * init_delta;
    data[(size - 1) * terrain->width + (size - 1)] = gauss->t_random_gauss() * init_delta;
  }

  /* Call recursive function */
  process_recursive_plasma(0, 0, size - 1, size - 1, init_delta, scale_factor, type);
}

/**
 * Plasma example - offset square midpoint subdivision on a grid.
 * This method is similar to standard subdivision, but it is 'offset'
 * in that the new points at each level are offset from the previous
 * level by half the square size.  The original corner points at level
 * x are only used once to form a weighted average, and then become the
 * center points of the new squares:
 *
 * It should be clear that this method includes some non-local context
 * when calculating new heights.  With standard subdivision, the only
 * heights that can ever influence the area inside the original square
 * are the original corner points.  With offset squares, most of the
 * new corner points lie outside the original square and therefore
 * are influenced by more distant points.  This feature can be a problem,
 * because if you don't want the map to be toroidal (wrapped in both
 * x and y), you need to generate a large number of points outside the
 * final terrain area.  For this example, I just wrap x and y.
 *
 * Original copyright notice:
 * This code was inspired by looking at Tim Clark's (?) Mars demo. You are 
 * free to use my code, my ideas, whatever. I have benefited enormously from 
 * the free information on the Internet, and I would like to keep that 
 * process going. James McNeill (mcneja@wwc.edu)
 */

void genSub::t_terrain_generate_offset(int size, float scale_factor)
{
  int    x1, y1; 
  int    square_size; 
  int    row_offset;
  float  max_delta = size;
  int    width = terrain->width;
  float *data = terrain->heightfield;;

  row_offset = 0;  /* start at zero for first row */
  for (square_size = size; square_size > 1; square_size /= 2)
  {
      for (x1 = row_offset; x1 < size; x1 += square_size)
      {
          for (y1 = row_offset; y1 < size; y1 += square_size)
          {
              // Get the four corner points.
              int x2 = (x1 + square_size) & (size - 1);
              int y2 = (y1 + square_size) & (size - 1);
              int x3, y3;

              float i1 = data[y1 * width + x1];
              float i2 = data[y1 * width + x2];
              float i3 = data[y2 * width + x1];
              float i4 = data[y2 * width + x2];

              /* Obtain new points by averaging the corner points. */
              float p1 = ((i1 * 9) + (i2 * 3) + (i3 * 3) + (i4)) / 16;
              float p2 = ((i1 * 3) + (i2 * 9) + (i3) + (i4 * 3)) / 16;
              float p3 = ((i1 * 3) + (i2) + (i3 * 9) + (i4 * 3)) / 16;
              float p4 = ((i1) + (i2 * 3) + (i3 * 3) + (i4 * 9)) / 16;
    
              /* Add a random offset to each new point. */
              p1 += gauss->t_random_gauss() * max_delta;
              p2 += gauss->t_random_gauss() * max_delta;
              p3 += gauss->t_random_gauss() * max_delta;
              p4 += gauss->t_random_gauss() * max_delta;
    
              // Write out the generated points.
              x3 = (x1 + square_size / 4) & (size - 1);
              y3 = (y1 + square_size / 4) & (size - 1);
              x2 = (x3 + square_size / 2) & (size - 1);
              y2 = (y3 + square_size / 2) & (size - 1);
    
              data[y3 * width + x3] = p1;
              data[y3 * width + x2] = p2;
              data[y2 * width + x3] = p3;
              data[y2 * width + x2] = p4;
          }
      }
      row_offset = square_size / 4;  /* set offset for next row */
      max_delta *= scale_factor;
  }
}

void genSub::t_terrain_generate_midpoint(int size, float scale_factor)
{
  int    i, j, i2, j2, i3, j3, h, h2;
  float  a, b, c, d;
  float  max_delta = size;
  int    width = terrain->width;
  float *data = terrain->heightfield;

  for (h = size; h > 1; h = h2)
  {
      h2 = h / 2;
      for (i = 0; i < size; i += h)
      {
          i2 = ((i + h) & (size - 1));
          for (j = 0; j < size; j += h)
          {
              j2 = ((j + h) & (size - 1));
              i3 = i + h2; 
              j3 = j + h2;

              a = data[j * width + i];
              b = data[j * width + i2];
              c = data[j2 * width + i];
              d = data[j2 * width + i2];

              /* center */
              data[j3 * width + i3] =
                (a + b + c + d) * 0.25 +
                gauss->t_random_gauss() * max_delta;

              /* top, left, right, bottom */
              if (i == 0)
                data[j * width + i3] =
                  (a + b) * 0.5 +
                  gauss->t_random_gauss() * max_delta;

              if (j == 0)
                data[j3 * width + i] =
                  (a + c) * 0.5 +
                  gauss->t_random_gauss() * max_delta;

              data[j3 * width + i2] =
                (b + d) * 0.5 +
                gauss->t_random_gauss() * max_delta;

              data[j2 * width + i3] =
                (c + d) * 0.5 +
                gauss->t_random_gauss() * max_delta;
          }
      }

      max_delta *= scale_factor;
  }
}

/**
 * Plasma example - diamond-square midpoint subdivision on a grid.
 * The surface is iteratively computed by calculating the center point of
 * the initial square (where the four corners of the surface are the
 * corners of the square), then of the resulting diamonds, then of
 * squares again, etc.
 * 
 * Code adapted from 'fillSurf' example posted to Usenet by
 * Paul Martz (pmartz@dsd.es.com).  
 * 
 * Original copyright notice:
 * Use this code anyway you want as long as you don't sell it for money.
 */

void genSub::t_terrain_generate_diamond_square(int size, float scale_factor)
{
  int    x, y, strut, tstrut; 
  bool   oddline; 
  float  max_delta = size;
  float *data = terrain->heightfield;;

  /* initialize things */
  strut = size / 2;
    
  /* create fractal surface from seeded values */
  tstrut = strut;
  while (tstrut > 0)
  {
      oddline = false;
      for (x = 0; x < size; x += tstrut)
      {
          oddline = !oddline;

          y = oddline ? tstrut : 0;
          for (; y < size; y += tstrut)
          {
              data[y * size + x] = avg (x, y, tstrut) + gauss->t_random_gauss() * max_delta;
              y += tstrut;
          }
      }

      if (tstrut / 2 != 0)
        for (x = tstrut / 2; x < size; x += tstrut)
          for (y = tstrut / 2; y < size; y += tstrut)
            data[y * size + x] = avg2 (x, y, tstrut) + gauss->t_random_gauss() * max_delta;

      tstrut /= 2;
      max_delta *= scale_factor;
  }
}

/********************************************************************************/

int genSub::preferred_size(int n)
{
  int v;

  for (v = 1; v < n; v <<= 1);

  return v;
}

void genSub::process_recursive_square(int x1, int y1, int x2, int y2, float max_delta, float scale_factor)
{
  int    cx = (x1 + x2) / 2;      /* center   */
  int    cy = (y1 + y2) / 2;
  int    dx = ABS (x2 - x1);      /* distance */
  int    dy = ABS (y2 - y1);
  int    pos;

  float *data = terrain->heightfield;
  int    width = terrain->width;

  /* square has reached minimum size; we're done */
  if (dx <= 1 && dy <= 1)
    return;

  /* center point */
  data[cy * width + cx] =
    (data[y1 * width + x1] + data[y2 * width + x1] +
     data[y2 * width + x2] + data[y1 * width + x2]) * 0.25 +
     gauss->t_random_gauss() * max_delta;

  /* process vertex points which haven't been touched yet */
  pos = cy * width + x1;
  if (data[pos] == EMPTY)
    data[pos] = (data[y1 * width + x1] + data[y2 * width + x1]) * 0.5 +
                gauss->t_random_gauss() * max_delta;

  pos = y1 * width + cx;
  if (data[pos] == EMPTY)
    data[pos] = (data[y1 * width + x1] + data[y1 * width + x2]) * 0.5 +
                gauss->t_random_gauss() * max_delta;

  pos = y2 * width + cx;
  if (data[pos] == EMPTY)
    data[pos] = (data[y2 * width + x1] + data[y2 * width + x2]) * 0.5 +
                gauss->t_random_gauss() * max_delta;

  pos = cy * width + x2;
  if (data[pos] == EMPTY)
    data[pos] = (data[y1 * width + x2] + data[y2 * width + x2]) * 0.5 +
                gauss->t_random_gauss() * max_delta;

  /* process subsquares recursively */
  process_recursive_square(x1, y1, cx, cy, max_delta * scale_factor, scale_factor);
  process_recursive_square(cx, y1, x2, cy, max_delta * scale_factor, scale_factor);
  process_recursive_square(x1, cy, cx, y2, max_delta * scale_factor, scale_factor);
  process_recursive_square(cx, cy, x2, y2, max_delta * scale_factor, scale_factor);
}

void genSub::random_dot_recursive_diamond(int x1, int y1, int x2, int y2, float max_delta)
{
  int    cx = (x1 + x2) / 2;
  int    cy = (y1 + y2) / 2;
  int    noise = 20;
  float *data;

  data = terrain->heightfield;

  /* We don't want to overwrite anything. If you want to know why,
   * just remove the if statement and see what happens. It won't
   * kill your computer, I swear.
   */
  if (data[cy * terrain->width + cx] == EMPTY)
    {
      double dist, average;

      /* Calculate the distance between the two points. */
      dist = sqrt ((y2 - y1) * (y2 - y1) + (x2 - x1) * (x2 - x1));

      /* Multiply with the roughness factor. */
      dist = sqrt (dist * noise);

      /* Get the average value. */
      average = (data [y1 * terrain->width + x1] +
                 data [y2 * terrain->width + x2]) * 0.5;

      /* Add random disturbance. */
      average += gauss->t_random_gauss() * max_delta;

      data[cy * terrain->width + cx] = average;
    }
}

/*
 *  process_recursive_diamond: process a given square recursiveley
 *  Xs are the existing points. 1-5 are the points we're going
 *   to add, and A-D are the four new quadrants.
 *
 *    X   1   X
 *      A   B
 *    2   5   3
 *      C   D
 *    X   4   X
 */
void genSub::process_recursive_diamond(int x1, int y1, int x2, int y2, float max_delta, float scale_factor)
{
  int cx = (x1 + x2) >> 1;
  int cy = (y1 + y2) >> 1;

  /* Add the points */
  random_dot_recursive_diamond(x1, y1, x2, y1, max_delta); /* 1 */
  random_dot_recursive_diamond(x1, y1, x1, y2, max_delta); /* 2 */
  random_dot_recursive_diamond(x2, y1, x2, y2, max_delta); /* 3 */
  random_dot_recursive_diamond(x1, y2, x2, y2, max_delta); /* 4 */

  /* 5th/center point */
  switch ((int)(gauss->t_random_gauss() * 2.0))
    {
      case 0:
        random_dot_recursive_diamond(x1, y1, x2, y2, max_delta);
        break;

      default:
        random_dot_recursive_diamond(x1, y2, x2, y1, max_delta);
        break;
    }

  /* If we haven't hit the bottom yet, recurse. */
  if (x2 - x1 > 2)
    {
      process_recursive_diamond(x1, y1, cx, cy, max_delta * scale_factor, scale_factor); /* A */
      process_recursive_diamond(cx, y1, x2, cy, max_delta *scale_factor, scale_factor); /* B */
      process_recursive_diamond(x1, cy, cx, y2, max_delta * scale_factor, scale_factor); /* C */
      process_recursive_diamond(cx, cy, x2, y2, max_delta * scale_factor, scale_factor); /* D */
    }
}

void genSub::process_recursive_plasma(int x1, int y1, int x2, int y2, float max_delta, float scale_factor, int type)
{
  int    cx, cy;
  int    width, height;
  int    last_line;
  float *data;

  data = terrain->heightfield;
  width = terrain->width;
  height = terrain->height;
  cx = (x1 + x2) / 2;
  cy = (y1 + y2) / 2;
  last_line = (height - 1) * width;

  if (cx > x1)
    {
      if (data[y1 * width + x1] == EMPTY)
        {
          data[y1 * width + cx] =
            (data[y1 * width + x2] + data[y1 * width + x2]) * 0.5 +
            gauss->t_random_gauss() * max_delta;

          if (y1 == 0)
            if (type == STILL_SEAMLESS)
              data[last_line + cx] = data[y1 * width + cx];
        }

      if (y1 < y2 && data[y2 * width + cx] == EMPTY)
        data[y2 * width + cx] =
          (data[y2 * width + x1] + data[y2 * width + x2]) * 0.5 +
          gauss->t_random_gauss() * max_delta;
    }

  if (cy > y1) 
    {
      if (data[cy * width + x1] == EMPTY)
        {
          data[cy * width + x1] =
            (data[y1 * width + x1] + data[y2 * width + x1]) * 0.5 +
            gauss->t_random_gauss() * max_delta;

          if (x1 == 0)
            if (type == STILL_SEAMLESS)
              data[cy * width + (width - 1)] = data[cy * width + x1];
        }

      if (x1 < x2 && data[cy * width + x2] == EMPTY)
        data[cy * width + x2] =
          (data[y1 * width + x2] + data[y2 * width + x2]) * 0.5 +
          gauss->t_random_gauss() * max_delta;
    }

  if (cx > x1 && cy > y1)
    {
      if (data[cy * width + cx] == EMPTY)
        data[cy * width + cx] =
          (data[y1 * width + x1] + data[y2 * width + x1] +
           data[y1 * width + x2] + data[y2 * width + x2]) * 0.25 +
           gauss->t_random_gauss() * ((y2 - y1) + (x2 - x1));
    }

  if ((cx > x1 && cx < x2) || (cy > y1 && cy < y2))
    {
      process_recursive_plasma(x1, y1, cx, cy, max_delta * scale_factor, scale_factor, type);
      process_recursive_plasma(x1, cy, cx, y2, max_delta * scale_factor, scale_factor, type);
      process_recursive_plasma(cx, y1, x2, cy, max_delta * scale_factor, scale_factor, type);
      process_recursive_plasma(cx, cy, x2, y2, max_delta * scale_factor, scale_factor, type);
    }
}

/*
 *  avg: used by Diamond generation routine
 */
float genSub::avg(int x, int y, int strut)
{
  float *data = terrain->heightfield;
  int    width = terrain->width;
  int    mask = width - 1;
  int    height = terrain->height;

  if (x == 0)
    return (data[((y - strut) & mask) * width + x] +
            data[((y + strut) & mask) * width + x] +
            data[y * width + ((x + strut) & mask)]) / 3.0;
  else if (x == width - 1)
    return (data[((y - strut) & mask) * width + x] +
            data[((y + strut) & mask) * width + x] +
            data[y * width + ((x - strut) & mask)]) / 3.0;
  else if (y == 0)
    return (data[y * width + ((x - strut) & mask)] +
            data[y * width + ((x + strut) & mask)] +
            data[((y + strut) & mask) * width + x]) / 3.0;
  else if (y == height - 1)
    return (data[y * width + ((x - strut) & mask)] +
            data[y * width + ((x + strut) & mask)] +
            data[((y - strut) & mask) * width + x]) / 3.0;
  else
    return (data[y * width + ((x - strut) & mask)] +
            data[y * width + ((x + strut) & mask)] +
            data[((y - strut) & mask) * width + x] +
            data[((y + strut) & mask) * width + x]) / 4.0;
}

/*
 *  avg2: used by Diamond generation routine
 */
float genSub::avg2(int i, int j, int strut)
{
  int     tstrut = strut / 2;
  int     width = terrain->width;
  int     mask = width - 1;
  float *data = terrain->heightfield;

  return (data[((j - tstrut) & mask) * width + ((i - tstrut) & mask)] +
          data[((j + tstrut) & mask) * width + ((i - tstrut) & mask)] +
          data[((j - tstrut) & mask) * width + ((i + tstrut) & mask)] +
          data[((j + tstrut) & mask) * width + ((i + tstrut) & mask)]) * 0.25;
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/