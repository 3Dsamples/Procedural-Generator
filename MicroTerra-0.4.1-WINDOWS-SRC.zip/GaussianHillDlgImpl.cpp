/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gaussianhilldlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gaussianhilldlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "GaussianHillDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

GaussianHillDlgImpl::GaussianHillDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : GaussianHillDlg( parent, name, modal, fl )
{
	centerX = (float)0.50;
	centerY = (float)0.50;
	radius = (float)0.50;
	scale = (float)1.50;
	radfac = (float)0.33;
	smooth = (float)0.50;
	delta = (float)0.10;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
GaussianHillDlgImpl::~GaussianHillDlgImpl()
{
}

void GaussianHillDlgImpl::update_preview(bool cxy)
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);

	t_terrain_gaussian_hill(clone, centerX, centerY, radius, radfac, scale, smooth, delta);
	clone->t_terrain_normalize(true);
	if (cxy == true)
		PreView->t_terrain_view_set_crosshair(centerX, centerY);
	PreView->t_terrain_view_set_terrain(clone);
}

void GaussianHillDlgImpl::setCenterX(int value)
{
	char buf[15];

	centerX = (float)(value/100.0);
	sprintf(buf,"%1.2f", centerX);
	slid1->setText((char *)buf);
	update_preview(true);
}

void GaussianHillDlgImpl::setCenterY(int value)
{
	char buf[15];

	centerY = (float)(value/100.0);
	sprintf(buf,"%1.2f", centerY);
	slid2->setText((char *)buf);
	update_preview(true);
}

void GaussianHillDlgImpl::setRadius(int value)
{
	char buf[15];

	radius = (float)(value/100.0);
	sprintf(buf,"%1.2f", radius);
	slid3->setText((char *)buf);
	update_preview(false);
}

void GaussianHillDlgImpl::setScale(int value)
{
	char buf[15];

	scale = (float)(value/100.0);
	sprintf(buf,"%1.2f", scale);
	slid4->setText((char *)buf);
	update_preview(false);
}

void GaussianHillDlgImpl::setRadfac(int value)
{
	char buf[15];

	radfac = (float)(value/100.0);
	sprintf(buf,"%1.2f", radfac);
	slid5->setText((char *)buf);
	update_preview(false);
}

void GaussianHillDlgImpl::setSmooth(int value)
{
	char buf[15];

	smooth = (float)(value/100.0);
	sprintf(buf,"%1.2f", smooth);
	slid6->setText((char *)buf);
	update_preview(false);
}

void GaussianHillDlgImpl::setDelta(int value)
{
	char buf[15];

	delta = (float)(value/100.0);
	sprintf(buf,"%1.2f", delta);
	slid7->setText((char *)buf);
	update_preview(false);
}
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/