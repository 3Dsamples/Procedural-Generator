/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: roughendlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: roughendlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "RoughenDlg.h"

#include <qcheckbox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a RoughenDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
RoughenDlg::RoughenDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "RoughenDlg" );
    resize( 499, 213 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Roughen" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 135 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 350, 135 ) ); 
    GroupBox2->setTitle( tr( "Options" ) );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 38, 110, 20 ) ); 
    lbl1->setText( tr( "Adjustment factor" ) );
    lbl1->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 295, 35, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "0.50" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    roughen_factor = new QSlider( GroupBox2, "roughen_factor" );
    roughen_factor->setGeometry( QRect( 135, 37, 150, 20 ) ); 
    roughen_factor->setMaxValue( 100 );
    roughen_factor->setValue( 50 );
    roughen_factor->setOrientation( QSlider::Horizontal );
    roughen_factor->setTickmarks( QSlider::NoMarks );

    roughen_big = new QCheckBox( GroupBox2, "roughen_big" );
    roughen_big->setGeometry( QRect( 10, 77, 120, 21 ) ); 
    roughen_big->setText( tr( "Big sampling grid" ) );

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 150, 498, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 175, 170, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

	terra = NULL;

    // signals and slots connections
    connect( roughen_factor, SIGNAL(valueChanged(int)), this, SLOT(setFactor(int)) );
    connect( roughen_big, SIGNAL(clicked()), this, SLOT(bigClicked()));
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
RoughenDlg::~RoughenDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool RoughenDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont slid1_font(  slid1->font() );
	slid1_font.setPointSize( 10 );
	slid1_font.setBold( TRUE );
	slid1->setFont( slid1_font ); 
    }
    return ret;
}

void RoughenDlg::setFactor(int value)
{
}

void RoughenDlg::bigClicked()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - created
 *
 ***********************************************************************************************************************/