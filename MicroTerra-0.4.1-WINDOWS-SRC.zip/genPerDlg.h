/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genperdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genperdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENPERLINDLG_H
#define GENPERLINDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QComboBox;
class QFrame;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QSpinBox;

class genPerDlg : public QDialog
{ 
    Q_OBJECT

public:
    genPerDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~genPerDlg();

    QGroupBox* GroupBox2;
    QLabel* TextLabel5;
    QLabel* TextLabel6;
    QLabel* TextLabel7;
    QLabel* TextLabel8;
    QCheckBox* first;
    QCheckBox* second;
    QCheckBox* third;
    QCheckBox* fourth;
    QSpinBox* first_frequency;
    QSpinBox* second_frequency;
    QSpinBox* third_frequency;
    QSpinBox* fourth_frequency;
    QSpinBox* first_amplitude;
    QSpinBox* second_amplitude;
    QSpinBox* third_amplitude;
    QSpinBox* fourth_amplitude;
    QSpinBox* first_iterations;
    QSpinBox* second_iterations;
    QSpinBox* third_iterations;
    QSpinBox* fourth_iterations;
    QComboBox* fourth_filter;
    QComboBox* third_filter;
    QComboBox* second_filter;
    QComboBox* first_filter;
    QPushButton* generate;
    QPushButton* cancel;
    QGroupBox* GroupBox3;
    QFrame* Line2;
    QLabel* TextLabel10;
    QLabel* TextLabel9;
    QSpinBox* pn_size;
    QLineEdit* seed;
    QCheckBox* new_seed;

public slots:
	virtual void firstClicked();
	virtual void secondClicked();
	virtual void thirdClicked();
	virtual void fourthClicked();
	virtual void seedClicked();

protected:
    QHBoxLayout* Layout1;
};

#endif // GENPERLINDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 29-12-2002
 *   - created
 *
 ***********************************************************************************************************************/