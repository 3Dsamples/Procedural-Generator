/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: optionsdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: optionsdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef OPTIONSDLHIMPL_H
#define OPTIONSDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "OptionsDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>
#include <qradiobutton.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class OptionsDlgImpl : public OptionsDlg
{ 
    Q_OBJECT

public:
    OptionsDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~OptionsDlgImpl();

public slots:
	void progslightwave_Changed();
	void progsac3d_Changed();
	void progspovray_Changed();
	void lightwavebrowse();
	void ac3dbrowse();
	void povraybrowse();
	void setGamma(int value);
	void defaultsizeChanged();
	void randgenfaultingClicked();
	void randgenperlinClicked();
	void randgenspectralClicked();
	void randgensubdivClicked();
	void microterrabrowse();
	void setXscale(int value);
	void setZscale(int value);
	void setYscalefactor(int value);
	void filledseaClicked();
	void setSealevel(int value);
	void setClarity(int value);
	void setWireframeResolution(int value);
	void setCameraHeightFactor(int value);
	void setLevels(int value);

private:
	char *lightwave_path;
	char *ac3d_path;
	char *povray_path;
	char *microterra_path;

protected:
	char *getExePath();

};

#endif // OPTIONSDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 07-12-2004
 *   - created
 *
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/