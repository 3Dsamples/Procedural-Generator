/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: mainwindow.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: mainwindow
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "MainWindow.h"

#include <qapplication.h>
#include <qfiledialog.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qpushbutton.h>
#include <qradiobutton.h>
#include <qtabwidget.h>
#include <qtoolbutton.h>
#include <qwidget.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "SizeManager.h"
#include "terrainview.h"
#include "tterrain.h"
#include "ksimpleconfig.h"
#include "ChooserDlgImpl.h"
#include "genrandom.h"
#include "genFaultDlgImpl.h"
#include "genfault.h"
#include "genPerDlgImpl.h"
#include "genPerlin.h"
#include "genSpectralDlgImpl.h"
#include "genSpectral.h"
#include "genSubDlgImpl.h"
#include "gensubdiv.h"
#include "trandom.h"
#include "fftn.h"
#include "filters.h"
#include "AboutDlg.h"
#include "helpwindow.h"
#include "reader.h"
#include "writer.h"
#include "LevelConnectorDlgImpl.h"
#include "CratersDlgImpl.h"
#include "ErodeDlgImpl.h"
#include "DigitalDlgImpl.h"
#include "FillDlgImpl.h"
#include "FillBasinsDlgImpl.h"
#include "FlowmapDlgImpl.h"
#include "FoldDlgImpl.h"
#include "GaussianHillDlgImpl.h"
#include "MosaicDlgImpl.h"
#include "RadialScaleDlgImpl.h"
#include "RasterizeDlgImpl.h"
#include "RoughenDlgImpl.h"
#include "SmoothDlgImpl.h"
#include "SpericalmapDlgImpl.h"
#include "TerraceDlgImpl.h"
#include "TileDlgImpl.h"
#include "TransformDlgImpl.h"
#include "OptionsDlgImpl.h"

#include "pixmaps/fileopen.xpm"
#include "pixmaps/filesave.xpm"
#include "pixmaps/filesaveas.xpm"
#include "pixmaps/fileprint.xpm"
#include "pixmaps/arrow.xpm"
#include "pixmaps/rectangle.xpm"
#include "pixmaps/circle.xpm"
#include "pixmaps/zoom.xpm"
#include "pixmaps/crop.xpm"
#include "pixmaps/seed.xpm"
#include "pixmaps/replace.xpm"
#include "pixmaps/add.xpm"
#include "pixmaps/subtract.xpm"
#include "pixmaps/microterra_logo.xpm"
 
/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a MainWindow which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
MainWindow::MainWindow( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
	int tx, ty, w, h;

	SM = new SizeManager();
    QPixmap image0((const char**)fileopen);
    QPixmap image1((const char**)filesave);
    QPixmap image2((const char**)filesaveas);
    QPixmap image3((const char**)fileprint);
    QPixmap image4((const char**)rectangle_xpm);
    QPixmap image5((const char**)circle_xpm);
    QPixmap image6((const char**)zoom_xpm);
    QPixmap image7((const char**)crop_xpm);
    QPixmap image8((const char**)add_xpm);
    QPixmap image9((const char**)subtract_xpm);
    QPixmap image10((const char**)replace_xpm);
    QPixmap image11((const char**)arrow_xpm);
	QPixmap paicon((const char**)microterra_logo_xpm);
	KSimpleConfig aConfig("./microterra.cfg");
    if ( !name )
		setName( "MainWindow" );
//    resize( 960, 500 ); 
//    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, sizePolicy().hasHeightForWidth() ) );
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    f.setBold( TRUE );
    setFont( f ); 
    setCaption( tr( "[Qt]    MicroTerra - Untitled" ) );
	setIcon(paicon);
 
    btn_options = new QPushButton( this, "btn_options" );
    btn_options->setGeometry( QRect( 130, 0, 110, 25 ) ); 
    btn_options->setText( tr( "Options" ) );

    btn_about = new QPushButton( this, "btn_about" );
    btn_about->setGeometry( QRect( 250, 0, 110, 25 ) ); 
    btn_about->setText( tr( "About" ) );

    btn_help = new QPushButton( this, "btn_help" );
    btn_help->setGeometry( QRect( 370, 0, 110, 25 ) ); 
    btn_help->setText( tr( "Help" ) );

    btn_exit = new QPushButton( this, "btn_exit" );
    btn_exit->setGeometry( QRect( 10, 0, 110, 25 ) ); 
    btn_exit->setText( tr( "Exit" ) );

    NoteBook = new QTabWidget( this, "NoteBook" );
//    NoteBook->setGeometry( QRect( 10, 25, 940, 470 ) ); 
    NoteBook->setTabShape( QTabWidget::Rounded );

    page1 = new QWidget( NoteBook, "page1" );

    Frame3 = new QFrame( page1, "Frame3" );
//    THolder->setGeometry( QRect( 45, 10, 424, 424 ) ); 
    Frame3->setFrameShape( QFrame::WinPanel );
    Frame3->setFrameShadow( QFrame::Raised );

    THolder = new QGroupBox( Frame3, "THolder" );
//    THolder->setGeometry( QRect( 10, 10, 404, 404 ) ); 
    THolder->setFrameShape( QGroupBox::WinPanel );
    THolder->setFrameShadow( QGroupBox::Sunken );

	View = new TerrainView( THolder, "View" );
//	View->setGeometry( QRect( 2, 2, w-154, h-94 ) );
//	View->show();

    Frame4 = new QFrame( page1, "Frame4" );
//    Frame4->setGeometry( QRect( 605, 10, 285, 424 ) ); 
    Frame4->setFrameShape( QFrame::WinPanel );
    Frame4->setFrameShadow( QFrame::Raised );

    GroupBox4 = new QGroupBox( Frame4, "GroupBox4" );
    GroupBox4->setGeometry( QRect( 10, 125, 266, 235 ) ); 
    GroupBox4->setTitle( tr( "Operations" ) );

    btn_connect = new QPushButton( GroupBox4, "btn_connect" );
    btn_connect->setGeometry( QRect( 15, 20, 75, 25 ) ); 
    btn_connect->setText( tr( "Connect" ) );

    btn_craters = new QPushButton( GroupBox4, "btn_craters" );
    btn_craters->setGeometry( QRect( 95, 20, 75, 25 ) ); 
    btn_craters->setText( tr( "Craters" ) );

    btn_erode = new QPushButton( GroupBox4, "btn_erode" );
    btn_erode->setGeometry( QRect( 175, 20, 75, 25 ) ); 
    btn_erode->setText( tr( "Erode" ) );

    btn_digitalfilter = new QPushButton( GroupBox4, "btn_digitalfilter" );
    btn_digitalfilter->setGeometry( QRect( 15, 50, 155, 25 ) ); 
    btn_digitalfilter->setText( tr( "Digital Filter" ) );

    btn_fill = new QPushButton( GroupBox4, "btn_fill" );
    btn_fill->setGeometry( QRect( 175, 50, 75, 25 ) ); 
    btn_fill->setText( tr( "Fill" ) );

    btn_fillbasins = new QPushButton( GroupBox4, "btn_fillbasins" );
    btn_fillbasins->setGeometry( QRect( 15, 80, 75, 25 ) ); 
    btn_fillbasins->setText( tr( "Fill Basins" ) );

    btn_flowmap = new QPushButton( GroupBox4, "btn_flowmap" );
    btn_flowmap->setGeometry( QRect( 95, 80, 75, 25 ) ); 
    btn_flowmap->setText( tr( "Flowmap" ) );

    btn_fold = new QPushButton( GroupBox4, "btn_fold" );
    btn_fold->setGeometry( QRect( 175, 80, 75, 25 ) ); 
    btn_fold->setText( tr( "Fold" ) );

    btn_gausianhill = new QPushButton( GroupBox4, "btn_gausianhill" );
    btn_gausianhill->setGeometry( QRect( 15, 110, 75, 25 ) ); 
    btn_gausianhill->setText( tr( "Gausian Hill" ) );

    btn_mosaic = new QPushButton( GroupBox4, "btn_mosaic" );
    btn_mosaic->setGeometry( QRect( 95, 110, 75, 25 ) ); 
    btn_mosaic->setText( tr( "Mosaic" ) );

    btn_radialscale = new QPushButton( GroupBox4, "btn_radialscale" );
    btn_radialscale->setGeometry( QRect( 175, 110, 75, 25 ) ); 
    btn_radialscale->setText( tr( "Radial Scale" ) );

    btn_rasterize = new QPushButton( GroupBox4, "btn_rasterize" );
    btn_rasterize->setGeometry( QRect( 15, 140, 75, 25 ) ); 
    btn_rasterize->setText( tr( "Rasterize" ) );

    btn_raughen = new QPushButton( GroupBox4, "btn_raughen" );
    btn_raughen->setGeometry( QRect( 95, 140, 75, 25 ) ); 
    btn_raughen->setText( tr( "Roughen" ) );

    btn_smooth = new QPushButton( GroupBox4, "btn_smooth" );
    btn_smooth->setGeometry( QRect( 175, 140, 75, 25 ) ); 
    btn_smooth->setText( tr( "Smooth" ) );

    btn_sphericalmap = new QPushButton( GroupBox4, "btn_sphericalmap" );
    btn_sphericalmap->setGeometry( QRect( 15, 170, 235, 25 ) ); 
    btn_sphericalmap->setText( tr( "Spherical Map" ) );

    btn_terrace = new QPushButton( GroupBox4, "btn_terrace" );
    btn_terrace->setGeometry( QRect( 15, 200, 75, 25 ) ); 
    btn_terrace->setText( tr( "Terrace" ) );

    btn_tile = new QPushButton( GroupBox4, "btn_tile" );
    btn_tile->setGeometry( QRect( 95, 200, 75, 25 ) ); 
    btn_tile->setText( tr( "Tile" ) );

    btn_transform = new QPushButton( GroupBox4, "btn_transform" );
    btn_transform->setGeometry( QRect( 175, 200, 75, 25 ) ); 
    btn_transform->setText( tr( "Transform" ) );

    GroupBox3 = new QGroupBox( Frame4, "GroupBox3" );
    GroupBox3->setGeometry( QRect( 10, 65, 265, 60 ) ); 
    QFont GroupBox3_font(  GroupBox3->font() );
    GroupBox3->setFont( GroupBox3_font ); 
    GroupBox3->setTitle( tr( "Colormap" ) );

    rbtn_land = new QRadioButton( GroupBox3, "rbtn_land" );
    rbtn_land->setGeometry( QRect( 5, 15, 85, 20 ) ); 
    rbtn_land->setText( tr( "Land" ) );
    rbtn_land->setChecked( TRUE );

    rbtn_desert = new QRadioButton( GroupBox3, "rbtn_desert" );
    rbtn_desert->setGeometry( QRect( 90, 15, 85, 20 ) ); 
    rbtn_desert->setText( tr( "Desert" ) );

    rbtn_heat = new QRadioButton( GroupBox3, "rbtn_heat" );
    rbtn_heat->setGeometry( QRect( 5, 35, 85, 20 ) ); 
    rbtn_heat->setText( tr( "Heat" ) );

    rbtn_grayscale = new QRadioButton( GroupBox3, "rbtn_grayscale" );
    rbtn_grayscale->setGeometry( QRect( 90, 35, 85, 20 ) ); 
    rbtn_grayscale->setText( tr( "Grayscale" ) );

    rbtn_wasteland = new QRadioButton( GroupBox3, "rbtn_wasteland" );
    rbtn_wasteland->setGeometry( QRect( 175, 15, 85, 20 ) ); 
    rbtn_wasteland->setText( tr( "Wasteland" ) );

    GroupBox2 = new QGroupBox( Frame4, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 10, 5, 265, 60 ) ); 
    QFont GroupBox2_font(  GroupBox2->font() );
    GroupBox2->setFont( GroupBox2_font ); 
    GroupBox2->setFrameShape( QGroupBox::Box );
    GroupBox2->setFrameShadow( QGroupBox::Sunken );
    GroupBox2->setTitle( tr( "View" ) );

    rbtn_3dheight = new QRadioButton( GroupBox2, "rbtn_3dheight" );
    rbtn_3dheight->setGeometry( QRect( 90, 15, 85, 20 ) ); 
    rbtn_3dheight->setText( tr( "3D Height" ) );

    rbtn_3dlight = new QRadioButton( GroupBox2, "rbtn_3dlight" );
    rbtn_3dlight->setGeometry( QRect( 175, 15, 85, 21 ) ); 
    rbtn_3dlight->setText( tr( "3D Light" ) );

    rbtn_2dplane = new QRadioButton( GroupBox2, "rbtn_2dplane" );
    rbtn_2dplane->setGeometry( QRect( 5, 35, 85, 20 ) ); 
    rbtn_2dplane->setText( tr( "2D Plane" ) );
    rbtn_2dplane->setChecked( TRUE );

    rbtn_2dcontour = new QRadioButton( GroupBox2, "rbtn_2dcontour" );
    rbtn_2dcontour->setGeometry( QRect( 90, 35, 90, 21 ) ); 
    rbtn_2dcontour->setText( tr( "2D Countour" ) );

    rbtn_3dwire = new QRadioButton( GroupBox2, "rbtn_3dwire" );
    rbtn_3dwire->setGeometry( QRect( 5, 15, 85, 20 ) ); 
    rbtn_3dwire->setText( tr( "3D Wire" ) );

    Frame5 = new QFrame( page1, "Frame5" );
//    Frame5->setGeometry( QRect( 895, 10, 35, 425 ) ); 
    Frame5->setFrameShape( QFrame::WinPanel );
    Frame5->setFrameShadow( QFrame::Raised );

    tbtn_open = new QToolButton( Frame5, "tbtn_open" );
    tbtn_open->setGeometry( QRect( 5, 10, 26, 26 ) ); 
    tbtn_open->setText( tr( "" ) );
    tbtn_open->setPixmap( image0 );
    tbtn_open->setUsesBigPixmap( TRUE );

    tbtn_save = new QToolButton( Frame5, "tbtn_save" );
    tbtn_save->setGeometry( QRect( 5, 50, 26, 26 ) ); 
    tbtn_save->setText( tr( "" ) );
    tbtn_save->setPixmap( image1 );
    tbtn_save->setUsesBigPixmap( TRUE );

    tbtn_saveas = new QToolButton( Frame5, "tbtn_saveas" );
    tbtn_saveas->setGeometry( QRect( 5, 90, 26, 26 ) ); 
    tbtn_saveas->setText( tr( "" ) );
    tbtn_saveas->setPixmap( image2 );
    tbtn_saveas->setUsesBigPixmap( TRUE );

    tbtn_print = new QToolButton( Frame5, "tbtn_print" );
    tbtn_print->setGeometry( QRect( 5, 130, 26, 26 ) ); 
    tbtn_print->setText( tr( "" ) );
    tbtn_print->setPixmap( image3 );
    tbtn_print->setUsesBigPixmap( TRUE );

    GroupBox1 = new QGroupBox( page1, "GroupBox1" );
//    GroupBox1->setGeometry( QRect( 480, 10, 115, 425 ) ); 
    GroupBox1->setTitle( tr( "New Terrain" ) );

    btn_random = new QPushButton( GroupBox1, "btn_random" );
    btn_random->setGeometry( QRect( 15, 70, 80, 25 ) ); 
    btn_random->setText( tr( "Random" ) );

    btn_perlin = new QPushButton( GroupBox1, "btn_perlin" );
    btn_perlin->setGeometry( QRect( 15, 110, 80, 25 ) ); 
    btn_perlin->setText( tr( "Perlin" ) );

    btn_faulting = new QPushButton( GroupBox1, "btn_faulting" );
    btn_faulting->setGeometry( QRect( 15, 150, 80, 25 ) ); 
    btn_faulting->setText( tr( "Faulting" ) );

    btn_spectral = new QPushButton( GroupBox1, "btn_spectral" );
    btn_spectral->setGeometry( QRect( 15, 190, 80, 25 ) ); 
    btn_spectral->setText( tr( "Spectral" ) );

    btn_subdivision = new QPushButton( GroupBox1, "btn_subdivision" );
    btn_subdivision->setGeometry( QRect( 15, 230, 80, 25 ) ); 
    btn_subdivision->setText( tr( "Sub Devision" ) );

    btn_chooser = new QPushButton( GroupBox1, "btn_chooser" );
    btn_chooser->setGeometry( QRect( 15, 30, 80, 25 ) ); 
    btn_chooser->setText( tr( "Chooser" ) );

    Frame1 = new QFrame( page1, "Frame1" );
//    Frame1->setGeometry( QRect( 5, 10, 35, 425 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Raised );

    tbtn2 = new QToolButton( Frame1, "tbtn2" );
    tbtn2->setGeometry( QRect( 5, 35, 26, 26 ) ); 
    tbtn2->setText( tr( "" ) );
    tbtn2->setPixmap( image4 );
    tbtn2->setToggleButton( TRUE );
    tbtn2->setUsesBigPixmap( TRUE );
    tbtn2->setToggleButton( TRUE );

    tbtn3 = new QToolButton( Frame1, "tbtn3" );
    tbtn3->setGeometry( QRect( 4, 65, 26, 26 ) ); 
    tbtn3->setText( tr( "" ) );
    tbtn3->setPixmap( image5 );
    tbtn3->setToggleButton( TRUE );
    tbtn3->setUsesBigPixmap( TRUE );
    tbtn3->setToggleButton( TRUE );

    tbtn4 = new QToolButton( Frame1, "tbtn4" );
    tbtn4->setGeometry( QRect( 5, 95, 26, 26 ) ); 
    tbtn4->setText( tr( "" ) );
    tbtn4->setPixmap( image6 );
    tbtn4->setToggleButton( TRUE );
    tbtn4->setUsesBigPixmap( TRUE );
    tbtn4->setToggleButton( TRUE );

    tbtn5 = new QToolButton( Frame1, "tbtn5" );
    tbtn5->setGeometry( QRect( 5, 125, 26, 26 ) ); 
    tbtn5->setText( tr( "" ) );
    tbtn5->setPixmap( image7 );
    tbtn5->setToggleButton( TRUE );
    tbtn5->setUsesBigPixmap( TRUE );
    tbtn5->setToggleButton( TRUE );

    tbtn6 = new QToolButton( Frame1, "tbtn6" );
    tbtn6->setGeometry( QRect( 5, 155, 26, 26 ) ); 
    tbtn6->setText( tr( "" ) );
    tbtn6->setPixmap( image8 );
    tbtn6->setToggleButton( TRUE );
    tbtn6->setOn( TRUE );
    tbtn6->setUsesBigPixmap( TRUE );
    tbtn6->setToggleButton( TRUE );
    tbtn6->setOn( TRUE );

    tbtn7 = new QToolButton( Frame1, "tbtn7" );
    tbtn7->setGeometry( QRect( 5, 185, 26, 26 ) ); 
    tbtn7->setText( tr( "" ) );
    tbtn7->setPixmap( image9 );
    tbtn7->setToggleButton( TRUE );
    tbtn7->setUsesBigPixmap( TRUE );
    tbtn7->setToggleButton( TRUE );

    tbtn8 = new QToolButton( Frame1, "tbtn8" );
    tbtn8->setGeometry( QRect( 5, 215, 26, 26 ) ); 
    tbtn8->setText( tr( "" ) );
    tbtn8->setPixmap( image10 );
    tbtn8->setToggleButton( TRUE );
    tbtn8->setUsesBigPixmap( TRUE );
    tbtn8->setToggleButton( TRUE );

    tbtn1 = new QToolButton( Frame1, "tbtn1" );
    tbtn1->setGeometry( QRect( 5, 5, 26, 26 ) ); 
    tbtn1->setText( tr( "" ) );
    tbtn1->setPixmap( image11 );
    tbtn1->setToggleButton( TRUE );
    tbtn1->setOn( TRUE );
    tbtn1->setUsesBigPixmap( TRUE );
    tbtn1->setToggleButton( TRUE );
    tbtn1->setOn( TRUE );
    NoteBook->insertTab( page1, tr( "Terrain Creating" ) );

    page2 = new QWidget( NoteBook, "page2" );

    btn_CmdRun = new QPushButton( page2, "btn_CmdRun" );
    //btn_CmdRun->setGeometry( QRect( 445, 240, 40, 25 ) ); 
    btn_CmdRun->setText( tr( "Run" ) );

    btn_CmdClear = new QPushButton( page2, "btn_CmdClear" );
    //btn_CmdClear->setGeometry( QRect( 525, 240, 40, 25 ) ); 
    btn_CmdClear->setText( tr( "Clear" ) );

    Frame2_1 = new QFrame( page2, "Frame2_1" );
    //Frame2_1->setGeometry( QRect( 10, 10, 424, 424 ) ); 
    Frame2_1->setFrameShape( QFrame::StyledPanel );
    Frame2_1->setFrameShadow( QFrame::Raised );

    THolder2 = new QGroupBox( Frame2_1, "THolder2" );
    //THolder2->setGeometry( QRect( 10, 10, 404, 404 ) ); 
    THolder2->setFrameShape( QGroupBox::WinPanel );
    THolder2->setFrameShadow( QGroupBox::Sunken );
    THolder2->setTitle( tr( "" ) );

	View2 = new TerrainView( THolder2, "View2" );

    GroupBox2_1 = new QGroupBox( page2, "GroupBox2_1" );
    //GroupBox2_1->setGeometry( QRect( 445, 5, 118, 230 ) ); 
    GroupBox2_1->setTitle( tr( "" ) );

    btn_subdivision_2 = new QPushButton( GroupBox2_1, "btn_subdivision_2" );
    btn_subdivision_2->setEnabled( FALSE );
    btn_subdivision_2->setGeometry( QRect( 30, 190, 60, 25 ) ); 
    btn_subdivision_2->setText( tr( "" ) );

    btn_runscript = new QPushButton( GroupBox2_1, "btn_runscript" );
    btn_runscript->setGeometry( QRect( 10, 20, 100, 25 ) ); 
    btn_runscript->setText( tr( "Run Script" ) );

    btn_startlog = new QPushButton( GroupBox2_1, "btn_startlog" );
    btn_startlog->setGeometry( QRect( 10, 55, 100, 25 ) ); 
    btn_startlog->setText( tr( "Start Log" ) );

    btn_show4 = new QPushButton( GroupBox2_1, "btn_show4" );
    btn_show4->setGeometry( QRect( 30, 110, 60, 25 ) ); 
    btn_show4->setText( tr( "Show 4" ) );

    btn_show3d = new QPushButton( GroupBox2_1, "btn_show3d" );
    btn_show3d->setGeometry( QRect( 30, 150, 60, 25 ) ); 
    btn_show3d->setText( tr( "Show 3d" ) );

    Frame2_3 = new QFrame( page2, "Frame2_3" );
    //Frame2_3->setGeometry( QRect( 568, 12, 365, 252 ) ); 
    Frame2_3->setFrameShape( QFrame::WinPanel );
    Frame2_3->setFrameShadow( QFrame::Raised );

    GroupBox2_2 = new QGroupBox( Frame2_3, "GroupBox2_2" );
    GroupBox2_2->setGeometry( QRect( 10, 5, 345, 90 ) ); 
    GroupBox2_2->setTitle( tr( "Height Field Stack" ) );

    btn_stack_copy1 = new QPushButton( GroupBox2_2, "btn_stack_copy1" );
    btn_stack_copy1->setGeometry( QRect( 10, 20, 75, 25 ) ); 
    btn_stack_copy1->setText( tr( "Copy1" ) );

    btn_stack_copy2 = new QPushButton( GroupBox2_2, "btn_stack_copy2" );
    btn_stack_copy2->setGeometry( QRect( 95, 20, 75, 25 ) ); 
    btn_stack_copy2->setText( tr( "Copy2" ) );

    btn_stack_paste = new QPushButton( GroupBox2_2, "btn_stack_paste" );
    btn_stack_paste->setGeometry( QRect( 260, 20, 75, 25 ) ); 
    btn_stack_paste->setText( tr( "Paste" ) );

    btn_stack_dup = new QPushButton( GroupBox2_2, "btn_stack_dup" );
    btn_stack_dup->setGeometry( QRect( 10, 55, 35, 25 ) ); 
    btn_stack_dup->setText( tr( "Dup" ) );

    btn_stack_swap = new QPushButton( GroupBox2_2, "btn_stack_swap" );
    btn_stack_swap->setGeometry( QRect( 50, 55, 35, 25 ) ); 
    btn_stack_swap->setText( tr( "Swap" ) );

    btn_stack_pop = new QPushButton( GroupBox2_2, "btn_stack_pop" );
    btn_stack_pop->setGeometry( QRect( 90, 55, 35, 25 ) ); 
    btn_stack_pop->setText( tr( "Pop" ) );

    btn_stack_rot = new QPushButton( GroupBox2_2, "btn_stack_rot" );
    btn_stack_rot->setGeometry( QRect( 130, 55, 35, 25 ) ); 
    btn_stack_rot->setText( tr( "Rot" ) );

    btn_stack_rot3 = new QPushButton( GroupBox2_2, "btn_stack_rot3" );
    btn_stack_rot3->setGeometry( QRect( 170, 55, 35, 25 ) ); 
    btn_stack_rot3->setText( tr( "Rot3" ) );

    btn_stack_clear = new QPushButton( GroupBox2_2, "btn_stack_clear" );
    btn_stack_clear->setGeometry( QRect( 290, 55, 45, 25 ) ); 
    btn_stack_clear->setText( tr( "Clear" ) );

    stack_view = new QTextView( Frame2_3, "stack_view" );
    stack_view->setGeometry( QRect( 10, 100, 345, 145 ) ); 
    stack_view->setFrameShape( QTextView::WinPanel );

    CmdLine = new QLineEdit( page2, "CmdLine" );
    //CmdLine->setGeometry( QRect( 445, 270, 485, 22 ) ); 

    ScriptLog = new QTextView( page2, "ScriptLog" );
    //ScriptLog->setGeometry( QRect( 445, 297, 485, 135 ) ); 
    ScriptLog->setFrameShape( QTextView::WinPanel );
    NoteBook->insertTab( page2, tr( "2D Modelling" ) );

    // signals and slots connections
	/**-->[page 1]<--**/
    connect( btn_chooser, SIGNAL( clicked() ), this, SLOT( newchooser() ) );
    connect( btn_random, SIGNAL( clicked() ), this, SLOT( newrandom() ) );
    connect( btn_perlin, SIGNAL( clicked() ), this, SLOT( newperlin() ) );
    connect( btn_faulting, SIGNAL( clicked() ), this, SLOT( newfaulting() ) );
    connect( btn_spectral, SIGNAL( clicked() ), this, SLOT( newspectral() ) );
    connect( btn_subdivision, SIGNAL( clicked() ), this, SLOT( newsubdevision() ) );
    connect( tbtn_open, SIGNAL( clicked() ), this, SLOT( openfile() ) );
    connect( tbtn_save, SIGNAL( clicked() ), this, SLOT( savefile() ) );
    connect( tbtn_saveas, SIGNAL( clicked() ), this, SLOT( saveasfile() ) );
    connect( tbtn_print, SIGNAL( clicked() ), this, SLOT( print() ) );
    connect( NoteBook, SIGNAL( currentChanged(QWidget*) ), this, SLOT( pageChanged() ) );
    connect( tbtn1, SIGNAL( clicked() ), this, SLOT( tool1_Changed() ) );
    connect( tbtn2, SIGNAL( clicked() ), this, SLOT( tool2_Changed() ) );
    connect( tbtn3, SIGNAL( clicked() ), this, SLOT( tool3_Changed() ) );
    connect( tbtn4, SIGNAL( clicked() ), this, SLOT( tool4_Changed() ) );
    connect( tbtn5, SIGNAL( clicked() ), this, SLOT( tool5_Changed() ) );
    connect( tbtn6, SIGNAL( clicked() ), this, SLOT( tool6_Changed() ) );
    connect( tbtn7, SIGNAL( clicked() ), this, SLOT( tool7_Changed() ) );
    connect( tbtn8, SIGNAL( clicked() ), this, SLOT( tool8_Changed() ) );
    connect( rbtn_3dwire, SIGNAL( clicked() ), this, SLOT( wire_Changed() ) );
    connect( rbtn_3dheight, SIGNAL( clicked() ), this, SLOT( height_Changed() ) );
    connect( rbtn_3dlight, SIGNAL( clicked() ), this, SLOT( light_Changed() ) );
    connect( rbtn_2dplane, SIGNAL( clicked() ), this, SLOT( plane_Changed() ) );
    connect( rbtn_2dcontour, SIGNAL( stateChanged(int) ), this, SLOT( contour_Changed() ) );
    connect( rbtn_land, SIGNAL( clicked() ), this, SLOT( land_Changed() ) );
    connect( rbtn_desert, SIGNAL( stateChanged(int) ), this, SLOT( desert_Changed() ) );
    connect( rbtn_heat, SIGNAL( clicked() ), this, SLOT( heat_Changed() ) );
    connect( rbtn_grayscale, SIGNAL( stateChanged(int) ), this, SLOT( grayscale_Changed() ) );
    connect( rbtn_wasteland, SIGNAL( stateChanged(int) ), this, SLOT( wasteland_Changed() ) );
    connect( btn_connect, SIGNAL( clicked() ), this, SLOT( operconnect() ) );
    connect( btn_craters, SIGNAL( clicked() ), this, SLOT( opercraters() ) );
    connect( btn_erode, SIGNAL( clicked() ), this, SLOT( opererode() ) );
    connect( btn_digitalfilter, SIGNAL( clicked() ), this, SLOT( operdigitalfilter() ) );
    connect( btn_fill, SIGNAL( clicked() ), this, SLOT( operfill() ) );
    connect( btn_fillbasins, SIGNAL( clicked() ), this, SLOT( operfillbasins() ) );
    connect( btn_flowmap, SIGNAL( clicked() ), this, SLOT( operflowmap() ) );
    connect( btn_fold, SIGNAL( clicked() ), this, SLOT( operfold() ) );
    connect( btn_gausianhill, SIGNAL( clicked() ), this, SLOT( opergausianhill() ) );
    connect( btn_mosaic, SIGNAL( clicked() ), this, SLOT( opermosaic() ) );
    connect( btn_radialscale, SIGNAL( clicked() ), this, SLOT( operradialscale() ) );
    connect( btn_rasterize, SIGNAL( clicked() ), this, SLOT( operrasterize() ) );
    connect( btn_raughen, SIGNAL( clicked() ), this, SLOT( operraughen() ) );
    connect( btn_smooth, SIGNAL( clicked() ), this, SLOT( opersmooth() ) );
    connect( btn_sphericalmap, SIGNAL( clicked() ), this, SLOT( opersphericalmap() ) );
    connect( btn_terrace, SIGNAL( clicked() ), this, SLOT( operterrace() ) );
    connect( btn_tile, SIGNAL( clicked() ), this, SLOT( opertile() ) );
    connect( btn_transform, SIGNAL( clicked() ), this, SLOT( opertransform() ) );
    connect( btn_options, SIGNAL( clicked() ), this, SLOT( options() ) );
    connect( btn_about, SIGNAL( clicked() ), this, SLOT( about() ) );
    connect( btn_help, SIGNAL( clicked() ), this, SLOT( help() ) );
    connect(btn_exit, SIGNAL(clicked()), this, SLOT(slotExit()));
	/**-->[page 2]<--**/
    connect(btn_CmdRun, SIGNAL(clicked()), this, SLOT(slotCmdRun()));
    connect(btn_CmdClear, SIGNAL(clicked()), this, SLOT(slotCmdClear()));

	SM->set_Page(1);
	setGeometry(*SM->geo_base);
	NoteBook->setGeometry(*SM->page1->geo_notebook);
	/**-->[page 1]--**/
	Frame1->setGeometry(*SM->page1->geo_group1);	//  tool buttons
	Frame3->setGeometry(*SM->page1->geo_terrain);	//  the terrain
	SM->page1->geo_terrain->rect(&tx, &ty, &w, &h);
    THolder->setGeometry(QRect(10, 10, (w - 20), (h - 20)) ); 
	View->setGeometry(QRect(2, 2, (w - 24), (h - 24)));
	GroupBox1->setGeometry(*SM->page1->geo_group2); //  new terrain
	Frame4->setGeometry(*SM->page1->geo_group3);	//  operations
	Frame5->setGeometry(*SM->page1->geo_group4);	//  file buttons
	/**-->[page 2]--**/
	Frame2_1->setGeometry(*SM->page2->geo_terrain);	//  the terrain
	SM->page2->geo_terrain->rect(&tx, &ty, &w, &h);
    THolder2->setGeometry(QRect(10, 10, (w - 20), (h - 20)) ); 
	View2->setGeometry(QRect(2, 2, (w - 24), (h - 24)));
	GroupBox2_1->setGeometry(*SM->page2->geo_group2); // command buttons
	Frame2_3->setGeometry(*SM->page2->geo_group3);  // stack
	btn_CmdRun->setGeometry(*SM->page2->geo_group4);  // run button
	btn_CmdClear->setGeometry(*SM->page2->geo_group5);  // clear button
	CmdLine->setGeometry(*SM->page2->geo_group6);  // command line
	ScriptLog->setGeometry(*SM->page2->geo_group7);  // messages

	terrain = NULL;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
MainWindow::~MainWindow()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool MainWindow::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont GroupBox3_font(  GroupBox3->font() );
	GroupBox3->setFont( GroupBox3_font ); 
	QFont GroupBox2_font(  GroupBox2->font() );
	GroupBox2->setFont( GroupBox2_font ); 
    }
    return ret;
}

/*************************************-->[mainwindow]<--****************************************************************/

void MainWindow::pageChanged()
{
	int tx, ty, w, h;
	int page;
    
	page = NoteBook->currentPageIndex() + 1;
	if (SM->get_Page() == page)
		return;
	SM->set_Page(page);
	switch (page)
	{
		case 1:
			/**-->[page 1]--**/
			Frame1->setGeometry(*SM->page1->geo_group1);	//  tool buttons
			Frame3->setGeometry(*SM->page1->geo_terrain);	//  the terrain
			SM->page1->geo_terrain->rect(&tx, &ty, &w, &h);
			THolder->setGeometry(QRect(10, 10, (w - 20), (h - 20)) ); 
			View->setGeometry(QRect(2, 2, (w - 24), (h - 24)));
			GroupBox1->setGeometry(*SM->page1->geo_group2); //  new terrain
			Frame4->setGeometry(*SM->page1->geo_group3);	//  operations
			Frame5->setGeometry(*SM->page1->geo_group4);	//  file buttons
			break;
		case 2:
			/**-->[page 2]--**/
			Frame2_1->setGeometry(*SM->page2->geo_terrain);	//  the terrain
			SM->page2->geo_terrain->rect(&tx, &ty, &w, &h);
			THolder2->setGeometry(QRect(10, 10, (w - 20), (h - 20)) ); 
			View2->setGeometry(QRect(2, 2, (w - 24), (h - 24)));
			GroupBox2_1->setGeometry(*SM->page2->geo_group2); // command buttons
			Frame2_3->setGeometry(*SM->page2->geo_group3);  // stack
			btn_CmdRun->setGeometry(*SM->page2->geo_group4);  // run button
			btn_CmdClear->setGeometry(*SM->page2->geo_group5);  // clear button
			CmdLine->setGeometry(*SM->page2->geo_group6);  // command line
			ScriptLog->setGeometry(*SM->page2->geo_group7);  // messages
			break;
		case 3:
			break;
		default:
			break;
	}
}

void MainWindow::options()
{
	KSimpleConfig aConfig("./microterra.cfg");
 	int        result;

	opt_dlg = new OptionsDlgImpl(this, "OptionsWindow", true);
	aConfig.setGroup("System");
	opt_dlg->dir_microterra->setText(aConfig.readEntry("microterra_dirpath", ""));
	aConfig.setGroup("Options");
	opt_dlg->exe_lightwave->setText(aConfig.readEntry("lightwave_path", ""));
	opt_dlg->exe_ac3d->setText(aConfig.readEntry("ac3d_path", ""));
	opt_dlg->exe_povray->setText(aConfig.readEntry("povray_path", ""));
	opt_dlg->progs_lightwave->setChecked(aConfig.readBoolEntry("lightwave", false));
	opt_dlg->progs_ac3d->setChecked(aConfig.readBoolEntry("ac3d", false));
	opt_dlg->progs_povray->setChecked(aConfig.readBoolEntry("povray", true));
	opt_dlg->max_undo->setValue(aConfig.readNumEntry("max_undo", 5));
	opt_dlg->gamma->setValue(aConfig.readNumEntry("gamma", 150));
	opt_dlg->default_size->setValue(aConfig.readNumEntry("terrain_size", 400));
	opt_dlg->rand_gen_faulting->setChecked(aConfig.readBoolEntry("rand_gen_faulting", true));
	opt_dlg->rand_gen_perlin->setChecked(aConfig.readBoolEntry("rand_gen_perlin", true));
	opt_dlg->rand_gen_spectral->setChecked(aConfig.readBoolEntry("rand_gen_spectral", true));
	opt_dlg->rand_gen_subdiv->setChecked(aConfig.readBoolEntry("rand_gen_subdiv", true));
	opt_dlg->scale_x->setValue(aConfig.readNumEntry("scale_x", 1000));
	opt_dlg->scale_z->setValue(aConfig.readNumEntry("scale_z", 1000));
	opt_dlg->y_scale_factor->setValue(aConfig.readNumEntry("y_scale_factor", 33));
	opt_dlg->filled_sea->setChecked(aConfig.readBoolEntry("filled_sea", true));
	opt_dlg->sealevel->setValue(aConfig.readNumEntry("sealevel", 33));
	opt_dlg->clarity->setValue(aConfig.readNumEntry("clarity", 65));
	opt_dlg->wireframe_resolution->setValue(aConfig.readNumEntry("wireframe_resolution", 10));
	opt_dlg->camera_height_factor->setValue(aConfig.readNumEntry("camera_height_factor", 33));
	opt_dlg->levels->setValue(aConfig.readNumEntry("levels", 10));
	
	result = opt_dlg->exec();

	if (result)
	{
		aConfig.setGroup("System");
		aConfig.writeEntry("microterra_dirpath", (char *)opt_dlg->dir_microterra->text().latin1());
		aConfig.setGroup("Options");
		aConfig.writeEntry("lightwave_path", (char *)opt_dlg->exe_lightwave->text().latin1());
		aConfig.writeEntry("ac3d_path", (char *)opt_dlg->exe_ac3d->text().latin1());
		aConfig.writeEntry("povray_path", (char *)opt_dlg->exe_povray->text().latin1());
		aConfig.writeEntry("lightwave", opt_dlg->progs_lightwave->isChecked());
		aConfig.writeEntry("ac3d", opt_dlg->progs_ac3d->isChecked());
		aConfig.writeEntry("povray", opt_dlg->progs_povray->isChecked());
		aConfig.writeEntry("max_undo", opt_dlg->max_undo->value());
		aConfig.writeEntry("gamma", opt_dlg->gamma->value());
		aConfig.writeEntry("rand_gen_faulting", opt_dlg->rand_gen_faulting->isChecked());
		aConfig.writeEntry("rand_gen_perlin", opt_dlg->rand_gen_perlin->isChecked());
		aConfig.writeEntry("rand_gen_spectral", opt_dlg->rand_gen_spectral->isChecked());
		aConfig.writeEntry("rand_gen_subdiv", opt_dlg->rand_gen_subdiv->isChecked());
		aConfig.writeEntry("scale_x", opt_dlg->scale_x->value());
		aConfig.writeEntry("scale_z", opt_dlg->scale_z->value());
		aConfig.writeEntry("y_scale_factor", opt_dlg->y_scale_factor->value());
		aConfig.writeEntry("filled_sea", opt_dlg->filled_sea->isChecked());
		aConfig.writeEntry("sealevel", opt_dlg->sealevel->value());
		aConfig.writeEntry("clarity", opt_dlg->clarity->value());
		aConfig.writeEntry("wireframe_resolution", opt_dlg->wireframe_resolution->value());
		aConfig.writeEntry("camera_height_factor", opt_dlg->camera_height_factor->value());
		aConfig.writeEntry("levels", opt_dlg->levels->value());
		aConfig.sync();
	}
}

void MainWindow::about()
{
	AboutDlg* aboutwin = new AboutDlg(this, "AboutDlg", true, Qt::WDestructiveClose);
    aboutwin->setCaption("[Qt] About");
	aboutwin->exec();
}

void MainWindow::help()
{
   QString home;
   home = QString("./help/index.html");

   HelpWindow *help = new HelpWindow(home, ".", 0, "MicroTerra - help viewer");
   help->setCaption("[Qt]   MicroTerra - HelpViewer");
   help->show();
}

/*************************************-->[page 1]<--********************************************************************/

void MainWindow::plane_Changed()
{
	if (rbtn_2dplane->isChecked())
	{
		View->t_terrain_view_set_model(T_VIEW_2D_PLANE);
		rbtn_2dcontour->setChecked(false);
		rbtn_3dwire->setChecked(false);
		rbtn_3dlight->setChecked(false);
		rbtn_3dheight->setChecked(false);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::contour_Changed()
{
	if (rbtn_2dcontour->isChecked())
	{
		View->t_terrain_view_set_model(T_VIEW_2D_CONTOUR);
		rbtn_2dplane->setChecked(false);
		rbtn_3dwire->setChecked(false);
		rbtn_3dlight->setChecked(false);
		rbtn_3dheight->setChecked(false);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::wire_Changed()
{
	if (rbtn_3dwire->isChecked())
	{
		View->t_terrain_view_set_model(T_VIEW_3D_WIRE);
		rbtn_2dplane->setChecked(false);
		rbtn_2dcontour->setChecked(false);
		rbtn_3dlight->setChecked(false);
		rbtn_3dheight->setChecked(false);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::height_Changed()
{
	if (rbtn_3dheight->isChecked())
	{
		View->t_terrain_view_set_model(T_VIEW_3D_HEIGHT);
		rbtn_2dplane->setChecked(false);
		rbtn_2dcontour->setChecked(false);
		rbtn_3dwire->setChecked(false);
		rbtn_3dlight->setChecked(false);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::light_Changed()
{
	if (rbtn_3dlight->isChecked())
	{
		View->t_terrain_view_set_model(T_VIEW_3D_LIGHT);
		rbtn_2dplane->setChecked(false);
		rbtn_2dcontour->setChecked(false);
		rbtn_3dwire->setChecked(false);
		rbtn_3dheight->setChecked(false);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::land_Changed()
{
	if (rbtn_land->isChecked())
	{
		rbtn_desert->setChecked(false);
		rbtn_heat->setChecked(false);
		rbtn_grayscale->setChecked(false);
		rbtn_wasteland->setChecked(false);
		View->t_terrain_view_set_colormap(T_COLORMAP_LAND);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::desert_Changed()
{
	if (rbtn_desert->isChecked())
	{
		rbtn_land->setChecked(false);
		rbtn_heat->setChecked(false);
		rbtn_grayscale->setChecked(false);
		rbtn_wasteland->setChecked(false);
		View->t_terrain_view_set_colormap(T_COLORMAP_DESERT);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::heat_Changed()
{
	if (rbtn_heat->isChecked())
	{
		rbtn_land->setChecked(false);
		rbtn_desert->setChecked(false);
		rbtn_grayscale->setChecked(false);
		rbtn_wasteland->setChecked(false);
		View->t_terrain_view_set_colormap(T_COLORMAP_HEAT);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::grayscale_Changed()
{
	if (rbtn_grayscale->isChecked())
	{
		rbtn_land->setChecked(false);
		rbtn_desert->setChecked(false);
		rbtn_heat->setChecked(false);
		rbtn_wasteland->setChecked(false);
		View->t_terrain_view_set_colormap(T_COLORMAP_GRAYSCALE);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::wasteland_Changed()
{
	if (rbtn_wasteland->isChecked())
	{
		rbtn_land->setChecked(false);
		rbtn_desert->setChecked(false);
		rbtn_heat->setChecked(false);
		rbtn_grayscale->setChecked(false);
		View->t_terrain_view_set_colormap(T_COLORMAP_WASTELAND);
		View->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::tool8_Changed()
{
    qWarning( "MainWindow::tool8_Changed(): Not implemented yet!" );
}

void MainWindow::newchooser()
{
	TTerrain   *out;
	int         y;
	int         pos;
	int         w, h, tx, ty;
	int         result;

	SM->page1->geo_terrain->rect(&tx, &ty, &w, &h);
	choos_dlg = new ChooserDlgImpl(this, "ChooserWindow", true);

	result = choos_dlg->exec();

	if (result)
	{
		terrain = t_terrain_clone(choos_dlg->getButtonChoice());
		if (terrain)
		{
			if ((terrain->width != (w-24)) || (terrain->height != (h-24)))
			{
				out = new TTerrain((w-24), (h-24));
				pos = 0;
				for (y = 0; y < out->height; y++)
				{
					int x;
					int count;
					int prev_pos;

					prev_pos = y * terrain->height / out->height * terrain->width;
					count = 0;
					for (x = 0; x < out->width; x++)
					{
						out->heightfield[pos] = terrain->heightfield[prev_pos];
						//if (out->selection != NULL)
						//	out->selection[pos] = terrain->selection[prev_pos];

						pos++;
						count += terrain->width;
						while (count >= out->width)
						{
							count -= out->width;
							prev_pos++;
						}
					}
				}
				delete terrain;
				terrain = out;
			}
			View->t_terrain_view_set_terrain(terrain);
			View2->t_terrain_view_set_terrain(terrain);
		}
	}

	delete choos_dlg;
}

void MainWindow::newfaulting()
{
	FaultingData  *data = NULL;
	TTerrain   *out;
	int         y;
	int         pos;
	int         w, h, tx, ty;
	int         result;
	int         dum;
	bool        ok;

	SM->page1->geo_terrain->rect(&tx, &ty, &w, &h);
	fault_dlg = new genFaultDlgImpl(this, "FaultingWindow", true);
	fault_dlg->setSize(400);
	fault_dlg->setNewSeed(false);
	fault_dlg->setSeed("");

	result = fault_dlg->exec();

	if (result)
	{
		data = new FaultingData();

		data->size = fault_dlg->getSize();
		dum = fault_dlg->getSize();
		data->method = fault_dlg->getMethod();
		data->iterations = fault_dlg->getIter();
		data->scale = fault_dlg->getScale();
		data->cycle = (fault_dlg->getCycle() / 100.0);
		data->constant_size = fault_dlg->getCSize();
		data->new_seed = fault_dlg->getNewSeed();
		data->seed = fault_dlg->getSeed().toInt(&ok, 10);
		if (!ok)
			data->seed = -1;
	}
	delete fault_dlg;
	if (result)
	{
		if (terrain != NULL)
		{
			delete terrain;
			terrain = new TTerrain(data->size, data->size);
		} else {
			terrain = new TTerrain(data->size, data->size);
		}
		genFault* genfaulting = new genFault( terrain );
		genfaulting->t_terrain_generate_fault(data->method, data->size, data->iterations, data->seed, data->scale, data->cycle, data->constant_size);
		delete genfaulting;
		genfaulting = 0;
		if (terrain)
		{
			if ((terrain->width != (w-24)) || (terrain->height != (h-24)))
			{
				out = new TTerrain((w-24), (h-24));
				pos = 0;
				for (y = 0; y < out->height; y++)
				{
					int x;
					int count;
					int prev_pos;

					prev_pos = y * terrain->height / out->height * terrain->width;
					count = 0;
					for (x = 0; x < out->width; x++)
					{
						out->heightfield[pos] = terrain->heightfield[prev_pos];
						//if (out->selection != NULL)
						//	out->selection[pos] = terrain->selection[prev_pos];

						pos++;
						count += terrain->width;
						while (count >= out->width)
						{
							count -= out->width;
							prev_pos++;
						}
					}
				}
				delete terrain;
				terrain = out;
			}
			View->t_terrain_view_set_terrain(terrain);
			View2->t_terrain_view_set_terrain(terrain);
		}
	}
	delete data;
}

void MainWindow::newrandom()
{
	TTerrain   *out;
	int         y;
	int         pos;
	int         w, h, tx, ty;

	SM->page1->geo_terrain->rect(&tx, &ty, &w, &h);
	if (terrain != NULL)
	{
		delete terrain;
		terrain = new TTerrain(400, 400);
	} else {
		terrain = new TTerrain(400, 400);
	}
 	genRan* genrandom = new genRan( terrain );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	if (terrain)
	{
		if ((terrain->width != (w-24)) || (terrain->height != (h-24)))
		{
			out = new TTerrain((w-24), (h-24));
			pos = 0;
			for (y = 0; y < out->height; y++)
			{
				int x;
				int count;
				int prev_pos;

				prev_pos = y * terrain->height / out->height * terrain->width;
				count = 0;
				for (x = 0; x < out->width; x++)
				{
					out->heightfield[pos] = terrain->heightfield[prev_pos];
					//if (out->selection != NULL)
					//	out->selection[pos] = terrain->selection[prev_pos];

					pos++;
					count += terrain->width;
					while (count >= out->width)
					{
						count -= out->width;
						prev_pos++;
					}
				}
			}
			delete terrain;
			terrain = out;
		}
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::newperlin()
{
	PerlinData *data = NULL;
	TTerrain   *out;
	int         y;
	int         pos;
	int         w, h, tx, ty;
	int         result;
	int         dum;
	bool        ok;

	SM->page1->geo_terrain->rect(&tx, &ty, &w, &h);
	perlin_dlg = new genPerDlgImpl(this, "PerlinWindow", true);
	perlin_dlg->setSize(400);
	perlin_dlg->setNewSeed(false);
	perlin_dlg->setSeed("");

	result = perlin_dlg->exec();

	if (result)
	{
		data = new PerlinData();

		data->size = perlin_dlg->getSize();
		dum = perlin_dlg->getSize();
		data->enabled[0] = perlin_dlg->getFirst();
		data->enabled[1] = perlin_dlg->getSecond();
		data->enabled[2] = perlin_dlg->getThird();
		data->enabled[3] = perlin_dlg->getFourth();
		data->frequency[0] = (perlin_dlg->getFreq1() / 1000.0);
		data->frequency[1] = (perlin_dlg->getFreq2() / 1000.0);
		data->frequency[2] = (perlin_dlg->getFreq3() / 1000.0);
		data->frequency[3] = (perlin_dlg->getFreq4() / 1000.0);
		data->amplitude[0] = perlin_dlg->getAmp1();
		data->amplitude[1] = perlin_dlg->getAmp2();
		data->amplitude[2] = perlin_dlg->getAmp3();
		data->amplitude[3] = perlin_dlg->getAmp4();
		data->iterations[0] = perlin_dlg->getIter1();
		data->iterations[1] = perlin_dlg->getIter2();
		data->iterations[2] = perlin_dlg->getIter3();
		data->iterations[3] = perlin_dlg->getIter4();
		data->filter[0] = perlin_dlg->getFilter1();
		data->filter[1] = perlin_dlg->getFilter2();
		data->filter[2] = perlin_dlg->getFilter3();
		data->filter[3] = perlin_dlg->getFilter4();
		data->new_seed = perlin_dlg->getNewSeed();
		data->seed = perlin_dlg->getSeed().toInt(&ok, 10);
		if (!ok)
			data->seed = -1;
	}
	delete perlin_dlg;
	if (result)
	{
		if (terrain != NULL)
		{
			delete terrain;
			terrain = new TTerrain(data->size, data->size);
		} else {
			terrain = new TTerrain(data->size, data->size);
		}
		genPer* genperlin = new genPer( terrain );
		genperlin->t_terrain_generate_perlin(data->size, data->size, data->seed, data->enabled, data->frequency, data->amplitude, data->iterations, data->filter);
		delete genperlin;
		genperlin = 0;
		if (terrain)
		{
			if ((terrain->width != (w-24)) || (terrain->height != (h-24)))
			{
				out = new TTerrain((w-24), (h-24));
				pos = 0;
				for (y = 0; y < out->height; y++)
				{
					int x;
					int count;
					int prev_pos;

					prev_pos = y * terrain->height / out->height * terrain->width;
					count = 0;
					for (x = 0; x < out->width; x++)
					{
						out->heightfield[pos] = terrain->heightfield[prev_pos];
						//if (out->selection != NULL)
						//	out->selection[pos] = terrain->selection[prev_pos];

						pos++;
						count += terrain->width;
						while (count >= out->width)
						{
							count -= out->width;
							prev_pos++;
						}
					}
				}
				delete terrain;
				terrain = out;
			}
			View->t_terrain_view_set_terrain(terrain);
			View2->t_terrain_view_set_terrain(terrain);
		}
	}
	delete data;
}

void MainWindow::newspectral()
{
	SpectralData *data = NULL;
	TTerrain     *out;
	int       y;
	int       pos;
	int w, h, tx, ty;
	int result;
	int dum;
	bool ok;

	SM->page1->geo_terrain->rect(&tx, &ty, &w, &h);
	spectral_dlg = new genSpectralDlgImpl(this, "SpectralWindow", true);
	spectral_dlg->setSize(400);
	spectral_dlg->setFracDim(0);
	spectral_dlg->setTrigoFuncs(false);
	spectral_dlg->setNewSeed(false);
	spectral_dlg->setSeed("");

	result = spectral_dlg->exec();

	if (result)
	{
		data = new SpectralData();
		data->size = spectral_dlg->getSize();
		dum = spectral_dlg->getSize();
		data->dimensions = (spectral_dlg->getFracDim() / 100.0);
		data->invert = spectral_dlg->getTrigoFuncs();
		data->new_seed = spectral_dlg->getNewSeed();
		data->seed = spectral_dlg->getSeed().toInt(&ok, 10);
		if (!ok)
			data->seed = -1;
	}
	delete spectral_dlg;
	if (result)
	{
		if (terrain != NULL)
		{
			delete terrain;
			terrain = new TTerrain(data->size, data->size);
		} else {
			terrain = new TTerrain(data->size, data->size);
		}
		genSpec* genspec = new genSpec( terrain );
		genspec->t_terrain_generate_spectral(data->size, 3.0 - data->dimensions, data->seed, data->invert);
		delete genspec;
		genspec = 0;
		if (terrain)
		{
			setCaption(terrain->filename);

			if ((terrain->width != (w-24)) || (terrain->height != (h-24)))
			{
				out = new TTerrain((w-24), (h-24));
				pos = 0;
				for (y = 0; y < out->height; y++)
				{
					int x;
					int count;
					int prev_pos;

					prev_pos = y * terrain->height / out->height * terrain->width;
					count = 0;
					for (x = 0; x < out->width; x++)
					{
						out->heightfield[pos] = terrain->heightfield[prev_pos];
						//if (out->selection != NULL)
						//	out->selection[pos] = terrain->selection[prev_pos];

						pos++;
						count += terrain->width;
						while (count >= out->width)
						{
							count -= out->width;
							prev_pos++;
						}
					}
				}
				delete terrain;
				terrain = out;
			}
			View->t_terrain_view_set_terrain(terrain);
			View2->t_terrain_view_set_terrain(terrain);
		}
	}
//	delete data;
}

void MainWindow::newsubdevision()
{
	SubdivisionData *data = NULL;
	TTerrain     *out;
	int		      y;
	int           pos;
	int           w, h, tx, ty;
	int           result;
	float         scale = 0.0;
	bool          ok;
	
	SM->page1->geo_terrain->rect(&tx, &ty, &w, &h);
	subdiv_dlg = new genSubDlgImpl(this, "SubdivisionWindow", true);
	subdiv_dlg->setMethod(0);
	subdiv_dlg->setSize(400);
	subdiv_dlg->setScale(5);
	subdiv_dlg->setNewSeed(true);
	subdiv_dlg->setSeed("1000");

	result = subdiv_dlg->exec();
	if (result)
	{
		data = new SubdivisionData();
		data->method = subdiv_dlg->getMethod();
		data->size = subdiv_dlg->getSize();
		scale = subdiv_dlg->getScale() / 10.0;
		data->scale = scale;
		data->new_seed = subdiv_dlg->getNewSeed();
		data->seed = subdiv_dlg->getSeed().toInt(&ok, 10);
		if (!ok)
			data->seed = -1;
	}
	delete subdiv_dlg;
	if (result)
	{
		if (terrain != NULL)
		{
			delete terrain;
			terrain = new TTerrain(data->size, data->size);
		} else {
			terrain = new TTerrain(data->size, data->size);
		}
		delete terrain->heightfield;
		terrain->heightfield = 0;
		genSub* gensub = new genSub( terrain );
		gensub->t_terrain_generate_subdiv(data->method, data->size, data->scale, data->seed);
		delete gensub;
		gensub = 0;
		if (terrain)
		{
			if ((terrain->width != (w-24)) || (terrain->height != (h-24)))
			{
				out = new TTerrain((w-24), (h-24));
				pos = 0;
				for (y = 0; y < out->height; y++)
				{
					int x;
					int count;
					int prev_pos;

					prev_pos = y * terrain->height / out->height * terrain->width;
					count = 0;
					for (x = 0; x < out->width; x++)
					{
						out->heightfield[pos] = terrain->heightfield[prev_pos];
						//if (out->selection != NULL)
						//	out->selection[pos] = terrain->selection[prev_pos];

						pos++;
						count += terrain->width;
						while (count >= out->width)
						{
							count -= out->width;
							prev_pos++;
						}
					}
				}
				delete terrain;
				terrain = out;
			}
			View->t_terrain_view_set_terrain(terrain);
			View2->t_terrain_view_set_terrain(terrain);
		}
	}

	delete data;
}

void MainWindow::operconnect()
{
	TTerrain   *level;
	int         result;

	if (terrain == NULL)
		return;

	levcon_dlg = new LevelConnectorDlgImpl(this, "LevelConnectorWindow", true);
	level = t_terrain_clone_preview(terrain);
	levcon_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_connect(level, 1);
	levcon_dlg->iterations = 1;
	levcon_dlg->PreView->t_terrain_view_set_terrain(level);

	result = levcon_dlg->exec();

	if (result)
	{
		t_terrain_connect(terrain, levcon_dlg->iterations);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::opercraters()
{
	TTerrain   *crater;
	int         result;

	if (terrain == NULL)
		return;

	craters_dlg = new CratersDlgImpl(this, "CratersWindow", true);
	crater = t_terrain_clone_preview(terrain);
	craters_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_craters(crater, 
					  craters_dlg->Count, 
					  craters_dlg->Wrap, 
					  craters_dlg->Height, 
					  craters_dlg->Radius, 
					  craters_dlg->Cover, 
					  craters_dlg->Seed, 
					  craters_dlg->centerX, 
					  craters_dlg->centerY);
	crater->t_terrain_normalize(true);
	craters_dlg->PreView->t_terrain_view_set_crosshair(craters_dlg->centerX, craters_dlg->centerY);
	craters_dlg->PreView->t_terrain_view_set_terrain(crater);

	result = craters_dlg->exec();

	if (result)
	{
		t_terrain_craters(terrain, 
						  craters_dlg->Count, 
					      craters_dlg->Wrap, 
					      craters_dlg->Height, 
					      craters_dlg->Radius, 
					      craters_dlg->Cover, 
					      craters_dlg->Seed, 
					      craters_dlg->centerX, 
					      craters_dlg->centerY);
		terrain->t_terrain_normalize(true);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::opererode()
{
	TTerrain   *level;
	int         result;

	if (terrain == NULL)
		return;

	erode_dlg = new ErodeDlgImpl(this, "ErodeWindow", true);
	level = t_terrain_clone_preview(terrain);
	erode_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_erode(level, 
		            erode_dlg->iterations,
					erode_dlg->flowage,
					erode_dlg->flowmaptimes,
					erode_dlg->threshold,
					NULL,
					NULL,
					erode_dlg->count,
					erode_dlg->trim,
					erode_dlg->direction,
					!erode_dlg->sealevel);
	erode_dlg->PreView->t_terrain_view_set_terrain(level);

	result = erode_dlg->exec();

	if (result)
	{
		t_terrain_erode(terrain, 
		            erode_dlg->iterations,
					erode_dlg->flowage,
					erode_dlg->flowmaptimes,
					erode_dlg->threshold,
					NULL,
					NULL,
					erode_dlg->count,
					erode_dlg->trim,
					erode_dlg->direction,
					!erode_dlg->sealevel);
		terrain->t_terrain_normalize(true);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::operdigitalfilter()
{
	TTerrain  *digi;
 	int        result;

	if (terrain == NULL)
		return;

	digit_dlg = new DigitalDlgImpl(this, "DigitalWindow", true);
	digi = t_terrain_clone_preview(terrain);
	digit_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_digital_filter(digi, digit_dlg->filter, FLEN, digit_dlg->elv_min, digit_dlg->elv_max); 
	digit_dlg->PreView->t_terrain_view_set_terrain(digi);

	result = digit_dlg->exec();

	if (result)
	{
		t_terrain_digital_filter(terrain, digit_dlg->filter, FLEN, digit_dlg->elv_min, digit_dlg->elv_max); 
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::operfill()
{
	TTerrain  *fill;
 	int        result;

	if (terrain == NULL)
		return;

	fill_dlg = new FillDlgImpl(this, "FillWindow", true);
	fill = t_terrain_clone_preview(terrain);
	fill_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_fill(fill, fill_dlg->fill_elev, fill_dlg->fill_tight); 
	fill_dlg->PreView->t_terrain_view_set_terrain(fill);

	result = fill_dlg->exec();

	if (result)
	{
		t_terrain_fill(terrain, fill_dlg->fill_elev, fill_dlg->fill_tight); 
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::operfillbasins()
{
	TTerrain  *fillbas;
 	int        result;

	if (terrain == NULL)
		return;

	fillbas_dlg = new FillBasinsDlgImpl(this, "FillBasinsWindow", true);
	fillbas = t_terrain_clone_preview(terrain);
	fillbas_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_fill_basins(fillbas, fillbas_dlg->iters, fillbas_dlg->bigG);
	fillbas_dlg->PreView->t_terrain_view_set_terrain(fillbas);

	result = fillbas_dlg->exec();

	if (result)
	{
		t_terrain_fill_basins(terrain, fillbas_dlg->iters, fillbas_dlg->bigG);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::operflowmap()
{
	TTerrain  *flowmap;
	TTerrain  *clone;
 	int        result;

	if (terrain == NULL)
		return;

	flowmap_dlg = new FlowmapDlgImpl(this, "FlowmapWindow", true);
	clone = t_terrain_clone_preview(terrain);
	flowmap_dlg->terra = t_terrain_clone_preview(terrain);;
	flowmap = t_terrain_flowmap(clone, flowmap_dlg->direction, !flowmap_dlg->sealevel, (float)1.0);
	t_terrain_copy_heightfield(flowmap, clone); 
	
	flowmap_dlg->PreView->t_terrain_view_set_terrain(clone);

	result = flowmap_dlg->exec();

	if (result)
	{
		flowmap = t_terrain_flowmap(terrain, flowmap_dlg->direction, !flowmap_dlg->sealevel, (float)1.0);
		t_terrain_copy_heightfield(flowmap, terrain); 
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::operfold()
{
	TTerrain  *fold;
	int        margin;
 	int        result;

	if (terrain == NULL)
		return;

	fold_dlg = new FoldDlgImpl(this, "FoldWindow", true);
	fold = t_terrain_clone_preview(terrain);
	fold_dlg->terra = t_terrain_clone_preview(terrain);;
	margin = fold_dlg->offset * MIN(fold->width, fold->height);
	t_terrain_fold(fold, margin);
	fold_dlg->PreView->t_terrain_view_set_terrain(fold);

	result = fold_dlg->exec();

	if (result)
	{
		margin = fold_dlg->offset * MIN(terrain->width, terrain->height);
		t_terrain_fold(terrain, margin);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::opergausianhill()
{
	TTerrain  *hill;
 	int        result;

	if (terrain == NULL)
		return;

	hill_dlg = new GaussianHillDlgImpl(this, "GaussianHillWindow", true);
	hill = t_terrain_clone_preview(terrain);
	hill_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_gaussian_hill(hill, hill_dlg->centerX, hill_dlg->centerY, hill_dlg->radius, hill_dlg->radfac, hill_dlg->scale, hill_dlg->smooth, hill_dlg->delta);
	hill->t_terrain_normalize(true);
	hill_dlg->PreView->t_terrain_view_set_crosshair(hill_dlg->centerX, hill_dlg->centerY);
	hill_dlg->PreView->t_terrain_view_set_terrain(hill);

	result = hill_dlg->exec();

	if (result)
	{
		t_terrain_gaussian_hill(terrain, hill_dlg->centerX, hill_dlg->centerY, hill_dlg->radius, hill_dlg->radfac, hill_dlg->scale, hill_dlg->smooth, hill_dlg->delta);
		terrain->t_terrain_normalize(true);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::opermosaic()
{
	TTerrain  *mosaic;
 	int        result;

	if (terrain == NULL)
		return;

	mosaic_dlg = new MosaicDlgImpl(this, "MosaicWindow", true);
	mosaic = t_terrain_clone_preview(terrain);
	mosaic_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_mosaic(mosaic, mosaic_dlg->X_size, mosaic_dlg->Y_size); 
	mosaic_dlg->PreView->t_terrain_view_set_terrain(mosaic);

	result = mosaic_dlg->exec();

	if (result)
	{
		t_terrain_mosaic(terrain, mosaic_dlg->X_size, mosaic_dlg->Y_size); 
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::operradialscale()
{
	TTerrain   *radial;
	int         result;

	if (terrain == NULL)
		return;

	radial_dlg = new RadialScaleDlgImpl(this, "RadialScaleWindow", true);
	radial = t_terrain_clone_preview(terrain);
	radial_dlg->terra = t_terrain_clone_preview(terrain);
	if (radial_dlg->b_invert == true)
		radial_dlg->scale = 1.0 / radial_dlg->scale;
	t_terrain_radial_scale(radial,
						   radial_dlg->centerX,
						   radial_dlg->centerY,
						   radial_dlg->scale,
						   radial_dlg->start,
						   radial_dlg->end,
						   1-radial_dlg->smooth,
						   radial_dlg->freq);
	radial->t_terrain_normalize(true);
	radial_dlg->PreView->t_terrain_view_set_crosshair(radial_dlg->centerX, radial_dlg->centerY);
	radial_dlg->PreView->t_terrain_view_set_terrain(radial);

	result = radial_dlg->exec();

	if (result)
	{
		if (radial_dlg->b_invert == true)
			radial_dlg->scale = 1.0 / radial_dlg->scale;
		t_terrain_radial_scale(terrain,
						   radial_dlg->centerX,
						   radial_dlg->centerY,
						   radial_dlg->scale,
						   radial_dlg->start,
						   radial_dlg->end,
						   1-radial_dlg->smooth,
						   radial_dlg->freq);
		terrain->t_terrain_normalize(true);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::operrasterize()
{
	TTerrain  *rast;
 	int        result;

	if (terrain == NULL)
		return;

	rast_dlg = new RasterizeDlgImpl(this, "RasterizeWindow", true);
	rast = t_terrain_clone_preview(terrain);
	rast_dlg->terra = t_terrain_clone_preview(terrain);
	rast_dlg->main_terra = terrain;
	if (rast_dlg->adjust)
	{
		int       org_x = terrain->width;
		int       org_y = terrain->height;
		int       new_x = rast->width;
		int       new_y = rast->height;
		float     f = sqrt((float)(new_x+new_y) / (float)(org_x+org_y));

		rast_dlg->xsize = (int)(rast_dlg->xsize*f);
		if (rast_dlg->xsize == 0)
			rast_dlg->xsize = 1;
      
		rast_dlg->ysize = (int)(rast_dlg->ysize*f);
		if (rast_dlg->ysize == 0)
			rast_dlg->ysize = 1;
	}
	t_terrain_rasterize(rast, rast_dlg->xsize, rast_dlg->ysize, rast_dlg->factor); 
	rast_dlg->PreView->t_terrain_view_set_terrain(rast);

	result = rast_dlg->exec();

	if (result)
	{
		if (rast_dlg->adjust)
		{
			int       org_x = terrain->width;
			int       org_y = terrain->height;
			int       new_x = terrain->width;
			int       new_y = terrain->height;
			float     f = sqrt((float)(new_x+new_y) / (float)(org_x+org_y));

			rast_dlg->xsize = (int)(rast_dlg->xsize*f);
			if (rast_dlg->xsize == 0)
				rast_dlg->xsize = 1;
      
			rast_dlg->ysize = (int)(rast_dlg->ysize*f);
			if (rast_dlg->ysize == 0)
				rast_dlg->ysize = 1;
		}
		t_terrain_rasterize(terrain, rast_dlg->xsize, rast_dlg->ysize, rast_dlg->factor); 
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::operraughen()
{
	TTerrain  *rough;
 	int        result;

	if (terrain == NULL)
		return;

	rough_dlg = new RoughenDlgImpl(this, "RoughenWindow", true);
	rough = t_terrain_clone_preview(terrain);
	rough_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_roughen_smooth(rough, TRUE, rough_dlg->big, rough_dlg->factor); 
	rough_dlg->PreView->t_terrain_view_set_terrain(rough);

	result = rough_dlg->exec();

	if (result)
	{
		t_terrain_roughen_smooth(terrain, TRUE, rough_dlg->big, rough_dlg->factor);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::opersmooth()
{
	TTerrain  *smooth;
 	int        result;

	if (terrain == NULL)
		return;

	smooth_dlg = new SmoothDlgImpl(this, "SmoothWindow", true);
	smooth = t_terrain_clone_preview(terrain);
	smooth_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_roughen_smooth(smooth, false, smooth_dlg->big, smooth_dlg->factor); 
	smooth_dlg->PreView->t_terrain_view_set_terrain(smooth);

	result = smooth_dlg->exec();

	if (result)
	{
		t_terrain_roughen_smooth(terrain, false, smooth_dlg->big, smooth_dlg->factor);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::opersphericalmap()
{
	TTerrain  *speri;
 	int        result;

	if (terrain == NULL)
		return;

	speri_dlg = new SpericalmapDlgImpl(this, "SpericalmapWindow", true);
	speri = t_terrain_clone_preview(terrain);
	speri_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_spherical(speri, speri_dlg->offs);
	speri_dlg->PreView->t_terrain_view_set_terrain(speri);

	result = speri_dlg->exec();

	if (result)
	{
		t_terrain_spherical(terrain, speri_dlg->offs);
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::operterrace()
{
	TTerrain  *ter;
 	int        result;

	if (terrain == NULL)
		return;

	ter_dlg = new TerraceDlgImpl(this, "TerraceWindow", true);
	ter = t_terrain_clone_preview(terrain);
	ter_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_terrace(ter, ter_dlg->level, ter_dlg->tight, ter_dlg->adjust); 
	ter_dlg->PreView->t_terrain_view_set_terrain(ter);

	result = ter_dlg->exec();

	if (result)
	{
		t_terrain_terrace(terrain, ter_dlg->level, ter_dlg->tight, ter_dlg->adjust); 
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::opertile()
{
	TTerrain  *tile;
 	int        result;

	if (terrain == NULL)
		return;

	tile_dlg = new TileDlgImpl(this, "TileWindow", true);
	tile = t_terrain_clone_preview(terrain);
	tile_dlg->terra = t_terrain_clone_preview(terrain);;
	t_terrain_tiler(tile, tile_dlg->offset);
	t_terrain_tile(tile, 2);
	tile_dlg->PreView->t_terrain_view_set_terrain(tile);

	result = tile_dlg->exec();

	if (result)
	{
		t_terrain_tiler(terrain, tile_dlg->offset);
		/* if we're dealing with the terrain window, check the aeembly paramters */
		if (tile_dlg->teras)
		{
			TTerrain *tnew = NULL;
			int num_x = tile_dlg->assemx;
			int num_y = tile_dlg->assemy;

			if (num_x > 1 || num_y > 1)
				tnew = terrain->t_terrain_tile_new(num_x, num_y);

			if (tnew != NULL)
			{
				delete terrain;
				terrain = tnew;
			}
		}
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::opertransform()
{
	TTerrain  *tran;
 	int        result;

	if (terrain == NULL)
		return;

	tran_dlg = new TransformDlgImpl(this, "TransformWindow", true);
	tran = t_terrain_clone_preview(terrain);
	tran_dlg->terra = t_terrain_clone_preview(terrain);;
	tran_dlg->Transfer->trans = new TTrans();
	tran_dlg->Transfer->model = T_VIEW_TRANSFORM;
	tran_dlg->Transfer->t_terrain_draw_transform(tran_dlg->threshold,
												 tran_dlg->depth,
												 tran_dlg->dropoff,
												 tran_dlg->above,
												 tran_dlg->below);
	tran->sealevel = tran_dlg->threshold;
	t_terrain_transform(tran,
						tran_dlg->threshold,
						tran_dlg->depth,
						tran_dlg->dropoff,
						tran_dlg->above,
						tran_dlg->below);
	tran->sealevel = tran_dlg->depth; 
	tran_dlg->PreView->t_terrain_view_set_terrain(tran);

	result = tran_dlg->exec();

	if (result)
	{
		terrain->sealevel = tran_dlg->threshold;
		t_terrain_transform(terrain,
							tran_dlg->threshold,
							tran_dlg->depth,
							tran_dlg->dropoff,
							tran_dlg->above,
							tran_dlg->below);
		terrain->sealevel = tran_dlg->depth; 
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::print()
{
    qWarning( "MainWindow::print(): Not implemented yet!" );
}

void MainWindow::saveasfile()
{
    qWarning( "MainWindow::saveasfile(): Not implemented yet!" );
}

void MainWindow::openfile()
{
	TTerrain *out;
	int       y;
	int       pos;
	int       w, h, tx, ty;

	SM->page1->geo_terrain->rect(&tx, &ty, &w, &h);
#ifndef QT_NO_FILEDIALOG
    QString fn = QFileDialog::getOpenFileName( QString::null, "MicroTerra (*.bmp;*.mt;*.ter;*.tga)", this );
    if ( !fn.isEmpty() )
	{
		TReader *load = new TReader();
		terrain = load->t_terrain_load((char *)fn.latin1(), FILE_AUTO);
		delete load;
	}
#endif
	if (terrain)
	{
		if ((terrain->width != (w-24)) || (terrain->height != (h-24)))
		{
			out = new TTerrain((w-24), (h-24));
			pos = 0;
			for (y = 0; y < out->height; y++)
			{
				int x;
				int count;
				int prev_pos;

				prev_pos = y * terrain->height / out->height * terrain->width;
				count = 0;
				for (x = 0; x < out->width; x++)
				{
					out->heightfield[pos] = terrain->heightfield[prev_pos];
					//if (out->selection != NULL)
					//	out->selection[pos] = terrain->selection[prev_pos];

					pos++;
					count += terrain->width;
					while (count >= out->width)
					{
						count -= out->width;
						prev_pos++;
					}
				}
			}
			delete terrain;
			terrain = out;
		}
		View->t_terrain_view_set_terrain(terrain);
		View2->t_terrain_view_set_terrain(terrain);
	}
}

void MainWindow::savefile()
{
//	TTerrain *terra;
	char buf[256]="";

//	terra = t_terrain_clone_resize(terrain, 256, 256, false);
#ifndef QT_NO_FILEDIALOG
    QString fn = QFileDialog::getSaveFileName( QString::null, "MicroTerra (*.ac;*.mt;*.ter)", this );
    if ( !fn.isNull() )
	{
		TWriter *save = new TWriter();
		View->col->colormap_new(T_COLORMAP_GRAYSCALE, terrain->sealevel);
		View->UpdateBuf();
		save->twriter_set_raster(View->raster);
		save->t_terrain_save(terrain, FILE_AUTO, ((char *)fn.latin1()));
		View->col->colormap_new(View->colormap, terrain->sealevel);
		View->UpdateBuf();
		FilenameOps *fno = new FilenameOps();
		terrain->filename = fno->filename_get_base(((char *)fn.latin1()));
		sprintf(buf, "[Qt]          MicroTerra - %s", terrain->filename);
		setCaption((char *)buf);
		delete fno;
		delete save;
	}
#endif
}

void MainWindow::tool1_Changed()
{
    qWarning( "MainWindow::tool1_Changed(): Not implemented yet!" );
}

void MainWindow::tool2_Changed()
{
    qWarning( "MainWindow::tool2_Changed(): Not implemented yet!" );
}

void MainWindow::tool3_Changed()
{
    qWarning( "MainWindow::tool3_Changed(): Not implemented yet!" );
}

void MainWindow::tool4_Changed()
{
    qWarning( "MainWindow::tool4_Changed(): Not implemented yet!" );
}

void MainWindow::tool5_Changed()
{
    qWarning( "MainWindow::tool5_Changed(): Not implemented yet!" );
}

void MainWindow::tool6_Changed()
{
    qWarning( "MainWindow::tool6_Changed(): Not implemented yet!" );
}

void MainWindow::tool7_Changed()
{
    qWarning( "MainWindow::tool7_Changed(): Not implemented yet!" );
}

/*************************************-->[page 2]<--********************************************************************/

/****[ private slots ]**************************************************************************************************/

void MainWindow::slotExit()
{
    (void) queryExit();
	QApplication::exit();
}
 
/****[ protected members ]**********************************************************************************************/

bool MainWindow::queryExit()
{
	KSimpleConfig aConfig("./microterra.cfg");
	QRect *geo;
	int w;
	int h;
	int tx;
	int ty;

	geo = SM->get_BaseGeometry();
	geo->rect(&tx, &ty, &w, &h);
	aConfig.setGroup("System");
	aConfig.writeEntry("topx", tx);
	aConfig.writeEntry("topy", ty);
	aConfig.writeEntry("width", w);
	aConfig.writeEntry("height", h);
	aConfig.sync();

    return true;
}
/***********************************************************************************************************************
 * Version history:
 *  * 11-10-2004
 *   - created
 *
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/