/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genperdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genperdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENPERLINDLHIMPL_H
#define GENPERLINDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "genPerDlg.h"
#include <qlineedit.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qlabel.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/
class genPerDlgImpl : public genPerDlg
{ 
    Q_OBJECT

public:
    genPerDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~genPerDlgImpl();

    bool getFirst() { return cbfi; };
    void setFirst(bool fi) { cbfi = fi; };
    int getFreq1() { return first_frequency->value(); };
    void setFreq1(int f1) { first_frequency->setValue(f1); };
    int getAmp1() { return first_amplitude->value(); };
    void setAmp1(int a1) { first_amplitude->setValue(a1); };
    int getIter1() { return first_iterations->value(); };
    void setIter1(int i1) { first_iterations->setValue(i1); };
    int getFilter1() { return first_filter->currentItem(); };
    void setFilter1(int index) { first_filter->setCurrentItem(index); };

    bool getSecond() { return cbse; };
    void setSecond(bool se) { cbse = se; };
    int getFreq2() { return second_frequency->value(); };
    void setFreq2(int f2) { second_frequency->setValue(f2); };
    int getAmp2() { return second_amplitude->value(); };
    void setAmp2(int a2) { second_amplitude->setValue(a2); };
    int getIter2() { return second_iterations->value(); };
    void setIter2(int i2) { second_iterations->setValue(i2); };
    int getFilter2() { return second_filter->currentItem(); };
    void setFilter2(int index) { second_filter->setCurrentItem(index); };

    bool getThird() { return cbth; };
    void setThird(bool th) { cbns = th; };
    int getFreq3() { return third_frequency->value(); };
    void setFreq3(int f3) { third_frequency->setValue(f3); };
    int getAmp3() { return third_amplitude->value(); };
    void setAmp3(int a3) { third_amplitude->setValue(a3); };
    int getIter3() { return third_iterations->value(); };
    void setIter3(int i3) { third_iterations->setValue(i3); };
    int getFilter3() { return third_filter->currentItem(); };
    void setFilter3(int index) { third_filter->setCurrentItem(index); };

    bool getFourth() { return cbfo; };
    void setFourth(bool fo) { cbns = fo; };
    int getFreq4() { return fourth_frequency->value(); };
    void setFreq4(int f4) { fourth_frequency->setValue(f4); };
    int getAmp4() { return fourth_amplitude->value(); };
    void setAmp4(int a4) { fourth_amplitude->setValue(a4); };
    int getIter4() { return fourth_iterations->value(); };
    void setIter4(int i4) { fourth_iterations->setValue(i4); };
    int getFilter4() { return fourth_filter->currentItem(); };
    void setFilter4(int index) { fourth_filter->setCurrentItem(index); };

    int getSize() { return pn_size->value(); };
    void setSize(int size) { pn_size->setValue(size); };
    bool getNewSeed() { return cbns; };
    void setNewSeed(bool ns) { cbns = ns; };
    QString getSeed() { return seed->text(); };
    void setSeed(QString s) { seed->setText(s); };

public slots:
	void firstClicked();
	void secondClicked();
	void thirdClicked();
	void fourthClicked();
	void seedClicked();

//private:
public:
	bool cbns;
	bool cbfi;
	bool cbse;
	bool cbth;
	bool cbfo;
};

#endif // GENPERLINDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 29-12-2002
 *   - created
 *
 ***********************************************************************************************************************/