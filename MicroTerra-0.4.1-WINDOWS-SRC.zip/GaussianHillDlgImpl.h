/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gaussianhilldlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gaussianhilldlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GAUSSIANHILLDLHIMPL_H
#define GAUSSIANHILLDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "GaussianHillDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class GaussianHillDlgImpl : public GaussianHillDlg
{ 
    Q_OBJECT

public:
    GaussianHillDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~GaussianHillDlgImpl();

	float centerX;
	float centerY;
	float radius;
	float scale;
	float radfac;
	float smooth;
	float delta;

public slots:
	void setCenterX(int value);
	void setCenterY(int value);
	void setRadius(int value);
	void setScale(int value);
	void setRadfac(int value);
	void setSmooth(int value);
	void setDelta(int value);

protected:
	void update_preview(bool cxy);

};

#endif // GAUSSIANHILLDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/