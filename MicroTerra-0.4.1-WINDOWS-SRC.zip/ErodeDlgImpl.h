/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: erodedlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: erodedlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef ERODEDLHIMPL_H
#define ERODEDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "ErodeDlg.h"
#include "tterrain.h"
#include <qspinbox.h>
#include <qlabel.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class ErodeDlgImpl : public ErodeDlg
{ 
    Q_OBJECT

public:
    ErodeDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~ErodeDlgImpl();

	int    iterations;
	int    flowage;
	int    flowmaptimes;
	float  threshold;
	bool   trim;
	char  *anim;
	char  *flow;
	bool   saveanim;
	bool   saveflow;
	int    count;
	bool   direction;
	bool   sealevel;
 
public slots:
	void update_view();
	void setIteration(int value);
	void setMaxFlowmapAge(int value);
	void setAgeFlowmapTimes(int value);
	void setThreshold(int value);
	void trimClicked();
	void saveflowmapClicked();
	void saveanimClicked();
	void framecountChanged();
	void single_Changed();
	void multiple_Changed();
	void sealevelClicked();
};

#endif // ERODEDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - created
 *
 ***********************************************************************************************************************/