/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genspectral.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genspectral
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENSPECTRALDLG_H
#define GENSPECTRALDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include <qlineedit.h>
#include <qspinbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;

class genSpectralDlg : public QDialog
{ 
    Q_OBJECT

public:
    genSpectralDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~genSpectralDlg();

    QPushButton* pb_generate;
    QPushButton* pb_cancel;
    QGroupBox* GroupBox1;
    QFrame* Line1;
    QLabel* sizelbl;
    QLabel* fracdimlbl;
    QLabel* seedlbl;
    QSpinBox* sb_size;
    QSpinBox* sb_fracdim;
    QCheckBox* cb_trigofuncs;
    QCheckBox* cb_newseed;
    QLineEdit* le_seed;

public slots:
	virtual void trigoClicked();
	virtual void seedClicked();

protected:
    QHBoxLayout* Layout1;
};

#endif // GENSPECTRALDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 29-12-2002
 *   - created
 *
 ***********************************************************************************************************************/