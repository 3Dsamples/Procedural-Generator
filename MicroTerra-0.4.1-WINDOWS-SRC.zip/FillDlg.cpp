/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: filldlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: filldlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "FillDlg.h"

#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a FillDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
FillDlg::FillDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "FillDlg" );
    resize( 508, 212 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Fill" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 150, 506, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 170, 170, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 135 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 356, 135 ) ); 
    GroupBox2->setTitle( tr( "Options" ) );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 40, 131, 20 ) ); 
    lbl1->setText( tr( "Elevation to fill up to" ) );
    lbl1->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl2 = new QLabel( GroupBox2, "lbl2" );
    lbl2->setGeometry( QRect( 10, 70, 130, 20 ) ); 
    lbl2->setText( tr( "Tightness factor" ) );

    fill_elevation = new QSlider( GroupBox2, "fill_elevation" );
    fill_elevation->setGeometry( QRect( 150, 40, 150, 20 ) ); 
    fill_elevation->setMaxValue( 100 );
    fill_elevation->setValue( 33 );
    fill_elevation->setOrientation( QSlider::Horizontal );

    fill_tightness = new QSlider( GroupBox2, "fill_tightness" );
    fill_tightness->setGeometry( QRect( 151, 70, 150, 20 ) ); 
    fill_tightness->setMaxValue( 100 );
    fill_tightness->setValue( 50 );
    fill_tightness->setOrientation( QSlider::Horizontal );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 310, 39, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "0.33" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    slid2 = new QLabel( GroupBox2, "slid2" );
    slid2->setGeometry( QRect( 310, 69, 35, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2_font.setBold( TRUE );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "0.50" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

	terra = NULL;

    // signals and slots connections
    connect( fill_elevation, SIGNAL(valueChanged(int)), this, SLOT(setFillElev(int)) );
    connect( fill_tightness, SIGNAL(valueChanged(int)), this, SLOT(setFillTight(int)) );
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
FillDlg::~FillDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool FillDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 

    if ( ev->type() == QEvent::ApplicationFontChange )
	{
		QFont slid1_font(  slid1->font() );
		slid1_font.setPointSize( 10 );
		slid1_font.setBold( TRUE );
		slid1->setFont( slid1_font ); 
		QFont slid2_font(  slid2->font() );
		slid2_font.setPointSize( 10 );
		slid2_font.setBold( TRUE );
		slid2->setFont( slid2_font ); 
    }
    return ret;
}

void FillDlg::setFillElev(int value)
{
}

void FillDlg::setFillTight(int value)
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/