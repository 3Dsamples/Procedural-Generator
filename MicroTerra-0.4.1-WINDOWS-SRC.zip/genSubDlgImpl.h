/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gensubdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gensubdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENSUBDLGIMPL_H
#define GENSUBDLGIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qlineedit.h>
#include <qspinbox.h>
#include <qcombobox.h>
#include <qlabel.h>
#include "genSubDlg.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class genSubDlgImpl : public genSubDlg
{ 
    Q_OBJECT

public:
    genSubDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~genSubDlgImpl();

    int getMethod() { return ComboBox1->currentItem(); };
    void setMethod(int index) { ComboBox1->setCurrentItem(index); };

    int getSize() { return sb_size->value(); };
    void setSize(int size) { sb_size->setValue(size); };

    int getScale() { return sb_scale->value(); };
    void setScale(int fd) { sb_scale->setValue(fd); };

    bool getNewSeed() { return cbns; };
    void setNewSeed(bool ns) { cbns = ns; }
    QString getSeed() { return le_seed->text(); };
    void setSeed(QString s) { le_seed->setText(s); };

public slots:
	void seedClicked();

public:
	bool cbns;
};

#endif // GENSUBDLGIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-01-2003
 *   - 
 *
 ***********************************************************************************************************************/