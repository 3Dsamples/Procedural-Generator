/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: filenameops.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: filenameops
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef __FILENAMEOPS_H__
#define __FILENAMEOPS_H__

/** ************************************************************************ **/
/** 				  GLOBAL DATATYPES			     **/
/** ************************************************************************ **/

typedef enum TFileType
{
  FILE_UNKNOWN,
  FILE_AUTO,
  FILE_NATIVE,
  FILE_TGA,
  FILE_POV,
  FILE_BMP,
  FILE_BMP_BW,
  FILE_GTOPO,
  FILE_GRD,
  FILE_PGM,
  FILE_PG8,
  FILE_MAT,
  FILE_OCT,
  FILE_AC,
  FILE_GIF,
  FILE_ICO,
  FILE_JPG,
  FILE_PNG,
  FILE_RAS,
  FILE_TIF,
  FILE_XBM,
  FILE_XPM,
  FILE_VRML,
  FILE_TERRAGEN,
  FILE_XYZ,
  FILE_DXF,
  FILE_BNA,
  FILE_BT,
  FILE_DTED,
  FILE_E00
} TFileType;

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class FilenameOps
{
public:
	FilenameOps();
	~FilenameOps();
	char     *filename_age(char *name);
	char     *filename_new_extension(char *name, char *extension);
	char     *filename_get_base(char *name);
	char     *filename_get_without_extension(char *name);
	char     *filename_get_base_without_extension(char *name);
	char     *filename_get_friendly(char *name);
	char     *filename_get_extension(char *name);
	TFileType  filename_determine_type(char *name);
	char     *filename_povray_safe(char *name);
	char     *strip_extension(char *name);

private:
	int strcasecmp(const char *s1, const char *s2);
};

#endif /* __FILENAMEOPS_H__ */
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/