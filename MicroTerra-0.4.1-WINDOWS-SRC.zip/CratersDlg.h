/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: cratersdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: cratersdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef CRATERSDLG_H
#define CRATERSDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QSlider;

class CratersDlg : public QDialog
{ 
    Q_OBJECT

public:
    CratersDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~CratersDlg();

    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QSlider* center_y;
    QSlider* center_x;
    QFrame* Line2;
    QLabel* lbl2;
    QFrame* Line3;
    QSlider* count;
    QSlider* radius;
    QSlider* height;
    QSlider* coverage;
    QCheckBox* wrap;
    QCheckBox* new_seed;
    QLineEdit* seed;
    QLabel* lbl3;
    QLabel* lbl4;
    QLabel* lbl5;
    QLabel* lbl6;
    QLabel* lbl7;
    QLabel* slid1;
    QLabel* slid2;
    QLabel* slid4;
    QLabel* slid3;
    QLabel* slid5;
    QLabel* slid6;
    QPushButton* OK;
    QPushButton* CANCEL;
    QFrame* Line1;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
	TTerrain *terra;

public slots:
	virtual void setCenterX(int value);
	virtual void setCenterY(int value);
	virtual void setCount(int value);
	virtual void setRadius(int value);
	virtual void setHeight(int value);
	virtual void setCoverage(int value);
	virtual void newseedClicked();
	virtual void wrapClicked();

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // CRATERSDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - craeted
 *
 ***********************************************************************************************************************/