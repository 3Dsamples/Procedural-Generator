/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: base64.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: base64
 *  last changed		: 27-17-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "base64.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

int base64_encoded_length(int decoded_length)
{
  return decoded_length * 4 / 3 + 5;
}

void base64_encode(uchar *in, int in_length, uchar *out)
{
  int  in_pos;
  int  num, a, b, c, d;
  uchar encode[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

  in_pos = 0;
  c = 0;
  d = 0;
  while (in_pos < in_length)
    {
      num = 1;
      a = in[in_pos];

      in_pos++;
      if (in_pos < in_length)
        {
          b = in[in_pos];
          num++;
        }
      else
        b = 0;

      in_pos++;
      if (in_pos < in_length)
        {
          c = in[in_pos];
          num++;
        }

      in_pos++;
      if (in_pos < in_length)
        {
          d = in[in_pos];
          num++;
        }

      *out++ = encode[a >> 2];
      *out++ = encode[(a & 0x3) << 4 | (b >> 4)];
      *out++ = (num >= 2) ? encode[(b & 0xf) << 2 | (c >> 6)] : '=';
      *out++ = (num >= 3) ? encode[c & 0x3f] : '=';
    }

  *out = '\0';
}

static bool base64_is_valid_char(uchar c)
{
  return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '+' || c == '/';
}

static int base64_char_to_int(uchar c)
{
  if (c >= 'A' && c <= 'Z')
    return c - 'A';
  else if (c >= 'a' && c <= 'z')
    return c - 'a' + 26;
  else if (c >= '0' && c <= '9')
    return c - '0' + 52;
  else if (c == '+')
    return 62;
  else if (c == '/')
    return 63;

  return -1;
}

int base64_decode(uchar *in, uchar *out, int out_length)
{
  int a, b, c, d;
  int num, pos;

  pos = 0;
  while (base64_is_valid_char(*in))
    {
      num = 1;

      a = base64_char_to_int(*in++);

      b = base64_char_to_int(*in);
      if (*in && *in != '=')
        in++, num++;

      c = base64_char_to_int(*in);
      if (*in && *in != '=')
        in++, num++;

      d = base64_char_to_int(*in);
      if (*in && *in != '=')
        in++, num++;

      if (num >= 2)
        {
          if (pos == out_length)
            return -1;

          out[pos++] = (a << 2) | (b >> 4);
        }

      if (num >= 3)
        {
          if (pos == out_length)
            return -1;

          out[pos++] = (b << 4) | (c >> 2);
        }

      if (num >= 4)
        {
          if (pos == out_length)
            return -1;

          out[pos++] = (c << 6) | d;
        }
    }

  return pos;
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   -
 *
 ***********************************************************************************************************************/