/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genrandom.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genrandom
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "genfault.h"
#include "genperlin.h"
#include "gensubdiv.h"
#include "genspectral.h"
#include "genrandom.h"
#include "trandom.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

genRan::genRan( TTerrain* terra )
{
	terrain = terra;
}

genRan::~genRan()
{
}

void genRan::t_terrain_generate_random(int size, float factor, int gen_bits)
{
	int     i;
	int     r;
	bool    enabled[4];
	int     octaves[4];
	float   frequency[4];
	float   amplitude[4];
	int     filter[4];

	if (gen_bits != GEN_TYPE_NONE)
		gen_bits = fix_gen_bits (gen_bits);

	if (gen_bits == GEN_TYPE_NONE)
		gen_bits = GEN_TYPE_ALL;

	TRandom *ns = new TRandom(-1);
	srand(ns->new_seed());
	delete ns;

//  while (terrain == NULL)
//    {
    r = rand () % 11;
    //printf ("%d, %d\n", r, gen_bits); fflush (stdout);

		switch (r)
		{
			case 0:
			case 1:
			case 2:
			case 3: 
			case 4: 
				if (gen_bits & GEN_TYPE_1)
				{
					genFault* genfaulting = new genFault( terrain );
					genfaulting->t_terrain_generate_fault(rand()%NUM_METHODS_FAULTING, size, 1000, -1, factor, rand()%20+1, rand()%2);
					delete genfaulting;
					genfaulting = 0;
				}
				break;
			case 5: 
				if (gen_bits & GEN_TYPE_2)
				{
					for (i = 0; i < 4; i++)
					{
						enabled[i] = rand() & 1;
						frequency[i] = (rand() % 100) / 100 + 0.017;
						amplitude[i] = (rand() % 4096) + 4096;
						octaves[i] = (rand() % 10) + 1;
						filter[i] = rand() % 23;
					}
					enabled[0] = TRUE;
					genPer* genperlin = new genPer( terrain );
					genperlin->t_terrain_generate_perlin(size, size, -1, enabled, frequency, amplitude, octaves, filter);
					delete genperlin;
					genperlin = 0;
				}
				break;
			case 6:
				if (gen_bits & GEN_TYPE_3)
				{
					genSpec* genspec = new genSpec( terrain );
					genspec->t_terrain_generate_spectral(size, factor, -1, false);
					delete genspec;
					genspec = 0;
				}
				break;
			case 7: 
			case 8: 
			case 9: 
			case 10: 
				if (gen_bits & GEN_TYPE_4)
				{
					delete terrain->heightfield;
					terrain->heightfield = 0;
					genSub* gensub = new genSub( terrain );
					gensub->t_terrain_generate_subdiv(rand () % NUM_METHODS_SUBDIV, size, factor, -1);
					delete gensub;
					gensub = 0;
				}
				break;
		}
//    }
}


/* make sure we only have GEN_TYPE_BITS_USED bits set */
int genRan::fix_gen_bits (int gen_bits)
{
  int i;
  int mask = 0;

  for (i=0; i<GEN_TYPE_BITS_USED; i++)
    mask += pow (2, i);

  gen_bits = gen_bits & mask;

  return gen_bits;
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/