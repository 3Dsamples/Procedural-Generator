/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: flowmapdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: flowmapdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "FlowmapDlg.h"

#include <qcheckbox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qpushbutton.h>
#include <qradiobutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a FlowmapDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
FlowmapDlg::FlowmapDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "FlowmapDlg" );
    resize( 321, 220 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Flowmap" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 150, 320, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 80, 175, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 135 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 170, 85 ) ); 
    GroupBox2->setTitle( tr( "Flowmap Type" ) );

    flowmap_single = new QRadioButton( GroupBox2, "flowmap_single" );
    flowmap_single->setGeometry( QRect( 10, 20, 155, 20 ) ); 
    flowmap_single->setText( tr( "Single flow direction" ) );
    flowmap_single->setChecked( TRUE );

    flowmap_multiple = new QRadioButton( GroupBox2, "flowmap_multiple" );
    flowmap_multiple->setGeometry( QRect( 10, 50, 155, 20 ) ); 
    flowmap_multiple->setText( tr( "Multiple flow direction" ) );

    flowmap_sealevel = new QCheckBox( this, "flowmap_sealevel" );
    flowmap_sealevel->setGeometry( QRect( 140, 105, 135, 21 ) ); 
    flowmap_sealevel->setText( tr( "Observe sealevel" ) );
    flowmap_sealevel->setChecked( FALSE );

	terra = NULL;

    // signals and slots connections
    connect( flowmap_single, SIGNAL( clicked() ), this, SLOT( single_Changed() ) );
    connect( flowmap_multiple, SIGNAL( clicked() ), this, SLOT( multiple_Changed() ) );
    connect( flowmap_sealevel, SIGNAL(clicked()), this, SLOT(sealevelClicked()));
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
FlowmapDlg::~FlowmapDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

void FlowmapDlg::single_Changed()
{
}

void FlowmapDlg::multiple_Changed()
{
}

void FlowmapDlg::sealevelClicked()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/