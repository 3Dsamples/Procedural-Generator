/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: tterrain.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: tterrain
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef __TTERRAIN_H__
#define __TTERRAIN_H__

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qstring.h>
#include <math.h>
#include <qvector.h>

/** ***************************************************************************************************************** **/
/** 				      GLOBAL DATATYPES			                                                                  **/
/** ***************************************************************************************************************** **/

enum TComposeOp
{
  T_COMPOSE_NONE,
  T_COMPOSE_REPLACE,
  T_COMPOSE_ADD,
  T_COMPOSE_SUBTRACT
};

/** ********************************************************************************************************************/
/** 				      CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/

#define MIN(x,y)     (((x) < (y)) ? (x) : (y))
#define MAX(x,y)     (((x) > (y)) ? (x) : (y))

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class TTerrainRiverCoords
{
public:
	float x;
	float y;
};

typedef QVector<TTerrainRiverCoords> AR_River; 

class TTerrainObject
{
public:
	int     ox;
	int     oy;
	float   x;
	float   y;
	float   angle;
	float   scale_x;
	float   scale_y;
	float   scale_z;
	QString name;
};

typedef QVector<TTerrainObject>	AR_Object; 

class TTerrainOptRender
{
public:
  bool           do_clouds;
  bool           do_fog;
  bool           do_ground_fog;
  bool           do_observe_sealevel;
  bool           do_rainbow;
  float          camera_x, camera_y, camera_z;
  float          lookat_x, lookat_y, lookat_z;
  float          elevation_offset;
  float          fog_alt;
  float          fog_density;
  float          fog_offset;
  float          fog_turbulence;
  float          north_direction;
  float          time_of_day;
  float          water_clarity;
  int            render_width; 
  int            render_scale_x;
  int            render_scale_y;       /* is derived from ysf and (x,y) */
  int            render_scale_z;

  /* POVRay specific options */
  QString        atmosphere_file;
  QString        cloud_file;
  QString        image_size_string;
  QString        povray_filename;
  QString        sky_file;
  QString        star_file;
  QString        texture_file;
  QString        water_file;

  bool           do_custom_size;
  bool           do_jitter;            /* aa specific */
  bool           do_aa;
  int            filetype;
  int            image_width;
  int            image_height;
  int            render_quality;
  int            aa_type;              /* 0 = type 1, 1 = type 2 */
  float          aa_threshold;
  float          aa_depth;
  float          jitter_amount;
};

//void t_terrain_object_clear (TTerrainObject *object);

//#define T_TYPE_TERRAIN            (t_terrain_get_type ())
//#define T_TERRAIN(obj)            (GTK_CHECK_CAST ((obj), T_TYPE_TERRAIN, TTerrain))
//#define T_TERRAIN_CLASS(klass)    (GTK_CHECK_CLASS_CAST ((klass), T_TYPE_TERRAIN, TTerrain))
//#define T_IS_TERRAIN(obj)         (GTK_CHECK_TYPE ((obj), T_TYPE_TERRAIN))
//#define T_IS_TERRAIN_CLASS(klass) (GTK_CHECK_CLASS_TYPE ((klass), T_TYPE_TERRAIN))


//struct TTerrainClass
//{
//  GtkObjectClass object_class;

  /* Signals */
//  void           (*heightfield_modified) (GtkObject *object);
//  void           (*title_modified)       (GtkObject *object);
//  void           (*selection_modified)   (GtkObject *object);
//  void           (*object_added)         (GtkObject *object,
//                                          gint       item);
//  void           (*object_modified)      (GtkObject *object,
//                                          gint       item);
//  void           (*object_deleted)       (GtkObject *object,
//                                          gint       item);
//};

class TTerrain
{
public:
	TTerrain();
	TTerrain( int, int );
	~TTerrain();
	void t_terrain_set_filename(char *fname);
	void t_terrain_normalize(bool never_grow);
	void t_terrain_set_modified(bool modifi);
	void t_terrain_crop(int x1, int y1, int x2, int y2);
	int t_terrain_seed_data(float *data, int w, int h);
	int t_terrain_seed(int new_width, int new_height, int sel_x, int sel_y, int sel_width, int sel_height);
	void t_terrain_set_size(int w, int h);
	TTerrain *t_terrain_tile_new(int num_x, int num_y);
	
	char             *filename;
	bool              modified;
	bool              autogenned; /* Set true if filename is auto generated. */

	int               width, height;
	float            *heightfield;
	float            *selection;

	bool              do_filled_sea;
	int               contour_levels;
	int               wireframe_resolution;
	float             camera_height_factor;
	float             sealevel;
	float             y_scale_factor;

	/* objects is a QVector of TTerrainObjects */
	AR_Object        *objects;

	/* river data */
	float            *riverfield;
	AR_River         *riversources;

	/* option structs */
	TTerrainOptRender render_options;

private:
	void t_terrain_init();
};

TTerrain *t_terrain_clone_resize(TTerrain *ter, int width, int height, bool terrain_only);
TTerrain *t_terrain_clone(TTerrain *terrain);
TTerrain *t_terrain_clone_preview(TTerrain *terrain);
void t_terrain_copy_heightfield(TTerrain *from, TTerrain *to);


//extern guint title_modified_signal;
//extern guint heightfield_modified_signal;
//extern guint selection_modified_signal;
//extern guint object_added_signal;
//extern guint object_modified_signal;
//extern guint object_deleted_signal;

//GtkType    t_terrain_get_type             (void);
//GtkObject *t_terrain_new                  (gint        width,
//                                           gint        height);

//void       t_terrain_set_filename         (TTerrain   *terrain,
//                                           gchar      *filename);
//gchar     *t_terrain_get_title            (TTerrain   *terrain);

//gdouble    t_terrain_get_height           (TTerrain   *terrain,
//                                           gdouble     x,
//                                           gdouble     y);
//void       t_terrain_heightfield_modified (TTerrain   *terrain);
//void       t_terrain_selection_modified   (TTerrain   *terrain);
//TTerrain  *t_terrain_clone                (TTerrain   *terrain);
//TTerrain  *t_terrain_clone_resize         (TTerrain   *terrain,
//                                           gint        width,
//                                           gint        height,
//					   gboolean    terrain_only);
//void       t_terrain_set_size             (TTerrain   *terrain,
//                                           gint        width,
//                                           gint        height);
//TTerrain  *t_terrain_clone_preview        (TTerrain   *terrain);
//gint      *t_terrain_histogram            (TTerrain   *terrain, gint n_intervals, gint scale);
//TTerrain  *t_terrain_clone_histogram      (TTerrain   *terrain, gfloat display_yscale);
//void       t_terrain_copy_heightfield     (TTerrain   *from,
//                                           TTerrain   *to);
//void       t_terrain_copy_heightfield_and_extras (TTerrain   *from,
//                                                  TTerrain   *to);
//void       t_terrain_normalize            (TTerrain   *terrain,
//                                           gboolean    never_grow);
//TTerrain  *t_terrain_crop_new             (TTerrain   *terrain,
//                                           gint        x1,
//                                           gint        y1,
//                                           gint        x2,
//                                           gint        y2);
//void       t_terrain_invert               (TTerrain   *terrain);
//
//void       t_terrain_pack_terrain_options (TTerrain   *terrain,
//                                           GtkWidget  *options);
//void       t_terrain_unpack_terrain_options(TTerrain   *terrain,
//                                           GtkWidget  *options);
//void       t_terrain_pack_scene_options   (TTerrain   *terrain,
//                                           GtkWidget  *options);
//void       t_terrain_unpack_scene_options (TTerrain   *terrain,
//                                           GtkWidget  *options);
//void       t_terrain_pack_povray_options  (TTerrain   *terrain,
//					   GtkWidget  *options);
//void       t_terrain_unpack_povray_options(TTerrain   *terrain,
//					   GtkWidget  *options);
//void       t_terrain_print_contour_map    (TTerrain   *terrain,
//                                           GnomePrintContext *context);

//void       t_terrain_ref                  (TTerrain   *terrain);
//void       t_terrain_unref                (TTerrain   *terrain);

//TTerrain  *t_terrain_import_heightfield   (gchar      *filename);
//void       t_terrain_export_heightfield   (TTerrain   *terrain,
//                                           gchar      *filename);
//void       t_terrain_select_by_height     (TTerrain  *terrain,
//                                           gfloat     floor,
//                                           gfloat     ceil,
//                                           TComposeOp op);
//void       t_terrain_select               (TTerrain   *terrain,
//                                           gfloat      x1,
//                                           gfloat      y1,
//                                           gfloat      x2,
//                                           gfloat      y2,
//                                           TSelectionType type,
//                                           TComposeOp  op);
//void       t_terrain_select_destroy       (TTerrain   *terrain);
//gint       t_terrain_add_object           (TTerrain   *terrain,
//                                           gint        ox,
//                                           gint        oy,
//                                           gfloat      x,
//                                           gfloat      y,
//                                           gfloat      angle,
//                                           gfloat      scale_x,
//                                           gfloat      scale_y,
//                                           gfloat      scale_z,
//                                           gchar      *object_name);
//void       t_terrain_move_object          (TTerrain   *terrain,
//                                           gint        item,
//                                           gfloat      x,
//                                           gfloat      y);
//void       t_terrain_rotate_object        (TTerrain   *terrain,
//                                           gint        item,
//                                           gfloat      angle);
//void       t_terrain_remove_object        (TTerrain   *terrain,
//                                           gint        item);
//void       t_terrain_remove_objects       (TTerrain   *terrain);
//TTerrain  *t_terrain_tile_new             (TTerrain   *terrain,
//                                           gint        num_x, 
//                                           gint        num_y); 


#endif /* __TTERRAIN_H__ */
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/