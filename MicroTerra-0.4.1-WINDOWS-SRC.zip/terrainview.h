/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: terrainview.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: terrainview
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef TERRAINVIEW_H
#define TERRAINVIEW_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qwidget.h>
#include <qpainter.h>

#include "tterrain.h"
#include "colormaps.h"
#include "contour.h"

/** ***************************************************************************************************************** **/
/** 				      GLOBAL DATATYPES			                                                                  **/
/** ***************************************************************************************************************** **/

enum TViewModel
{
	T_VIEW_2D_PLANE,
	T_VIEW_2D_CONTOUR,
	T_VIEW_3D_WIRE,
	T_VIEW_3D_HEIGHT,
	T_VIEW_3D_LIGHT,
	T_VIEW_HISTOGRAM,
	T_VIEW_HISTOGRAM2,
	T_VIEW_TRANSFORM
};

enum TToolMode
{
	T_TOOL_NONE = -1,
	T_TOOL_MOVE,
	T_TOOL_SELECT_RECTANGLE,
	T_TOOL_SELECT_ELLIPSE,
	T_TOOL_SELECT_SQUARE_ZOOM,
	T_TOOL_SELECT_CROP_NEW, 
	T_TOOL_SELECT_SQUARE_SEED
};

enum TMouseMode
{
	T_MOUSE_NONE = 0,
	T_MOUSE_CLICK = 1
};

/*
 * define the coding of end points
 */
typedef unsigned int clip_code;
enum {TOP = 0x1, BOTTOM = 0x2, RIGHT = 0x4, LEFT = 0x8};

/*
 * a rectangle is defined by 4 sides
 */
typedef struct {
	int xmin, ymin, xmax, ymax;
} rectangle;

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class GdkPoint
{
public:
	int x;
	int y;
};

class TTrans
{
public:
	float sea_threshold;
	float sea_depth;
	float sea_dropoff;
	float above_power;
	float below_power;
};

class TerrainView : public QWidget
{
    Q_OBJECT

public:
    TerrainView( QWidget *parent=0, const char *name=0, int wFlags=0 );
    ~TerrainView();
//	TTerrain *t_terrain_view_get_terrain();
	void t_terrain_view_set_terrain(TTerrain *terra);
	void t_terrain_view_setMouseMode(TMouseMode mm);
	TViewModel t_terrain_view_get_model();
	void t_terrain_view_set_model(TViewModel mdl);
	void t_terrain_view_set_colormap(TColormapType  colmap);
	void t_terrain_view_set_crosshair(float x, float y);
	void t_terrain_view_unset_crosshair();
	void terrain_print();
	void t_terrain_draw_transform(float threshold, float depth, float dropoff, float above, float below);

	TMouseMode   mouse_mode;
	int          mouse_mclick;

	bool           contour_dirty;
	bool           dirty;

	int            size;
	unsigned int   rotate_timeout;
	TTerrain      *terrain;
	TViewModel     model;
	TColormapType  colormap;
	float          angle;
	float          elevation;
	bool           auto_rotate;
	bool           do_tile;

	float          crosshair_x;
	float          crosshair_y;

	/* Where the mouse button was first pressed. */
	int            anchor_x;
	int            anchor_y;
	int            anchor_object;
	int           *raster;

	/* contour_lines is a GList of GArrays of a gfloat height + gfloat pairs */
    GList *contour_lines;

	/* Ids of signal connections made to TTerrain object */
	unsigned int   heightfield_modified_id;
	unsigned int   selection_modified_id;
	unsigned int   object_added_id;
	unsigned int   object_modified_id;
	unsigned int   object_deleted_id;

	/* Modes of user interaction */
	TToolMode      tool_mode;
//  TComposeOp     compose_op;

	ColorMaps     *col;
	CContour      *contour;

	TTrans *trans;

	void UpdateBuf();
	void t_terrain_paint();

protected:
	void draw_line_add_aa(int vcol, int x1, int y1, int x2, int y2);
	void draw_crosshair(QPainter *p);
	void draw_arrow(QPainter *p, int x1, int y1, int x2, int y2);
	void drawColorWheel( QPainter * );
	void drawPlane( QPainter * );
	void draw_2d_contour(QPainter *p);
	clip_code compute_clip_code(double x, double y, rectangle r);
	bool clip_line(double *x0, double *y0, double *x1, double *y1, rectangle clip_rect);
	bool clip_line_int(int *x0, int *y0, int *x1, int *y1, rectangle clip_rect);
	void draw_3d_wire(QPainter *p);
	//int point_comparison(const void *point_1, const void *point_2);
	void fill_triangle(QPainter *pixbuf, GdkPoint *points);
	void draw_3d_light(QPainter *p);
	void draw_3d_height(QPainter *p);
	void drawHistogram( QPainter *p );
	void drawTransform(QPainter *p);
    void drawIt( QPainter * );
    void paintEvent( QPaintEvent * );
	virtual void mousePressEvent(QMouseEvent * );
	virtual void mouseReleaseEvent(QMouseEvent * );
    void resizeEvent( QResizeEvent * );

private:
    int     drawindex;
    int     maxindex;
	bool    terraOK;
	bool    histOK;
	bool    hist2OK;
	bool    crosshair;

signals:
	void mouseCLICKED();
};

#endif // TERRAINVIEW_H
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/