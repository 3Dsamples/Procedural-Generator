/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: mosaicdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: mosaicdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "MosaicDlg.h"

#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a MosaicDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
MosaicDlg::MosaicDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "MosaicDlg" );
    resize( 366, 212 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Mosaic" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 150, 364, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 100, 170, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 215, 135 ) ); 
    GroupBox2->setTitle( tr( "Options" ) );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 40, 60, 21 ) ); 
    lbl1->setText( tr( "Cell width" ) );
    lbl1->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl2 = new QLabel( GroupBox2, "lbl2" );
    lbl2->setGeometry( QRect( 10, 75, 60, 20 ) ); 
    lbl2->setText( tr( "Cell depth" ) );

    lbl3 = new QLabel( GroupBox2, "lbl3" );
    lbl3->setGeometry( QRect( 147, 40, 63, 20 ) ); 
    lbl3->setText( tr( "grid units" ) );

    lbl4 = new QLabel( GroupBox2, "lbl4" );
    lbl4->setGeometry( QRect( 147, 75, 63, 20 ) ); 
    lbl4->setText( tr( "grid units" ) );

    x_mosaicsize = new QSpinBox( GroupBox2, "x_mosaicsize" );
    x_mosaicsize->setGeometry( QRect( 80, 40, 55, 20 ) ); 
    x_mosaicsize->setButtonSymbols( QSpinBox::PlusMinus );
    x_mosaicsize->setMaxValue( 100 );
    x_mosaicsize->setMinValue( 1 );
    x_mosaicsize->setValue( 10 );

    y_mosaicsize = new QSpinBox( GroupBox2, "y_mosaicsize" );
    y_mosaicsize->setGeometry( QRect( 80, 75, 55, 20 ) ); 
    y_mosaicsize->setMaxValue( 100 );
    y_mosaicsize->setMinValue( 1 );
    y_mosaicsize->setValue( 10 );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 135 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

	terra = NULL;

    // signals and slots connections
    connect( x_mosaicsize, SIGNAL(valueChanged(int)), this, SLOT(xsizeChanged()) );
    connect( y_mosaicsize, SIGNAL(valueChanged(int)), this, SLOT(ysizeChanged()) );
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
MosaicDlg::~MosaicDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

void MosaicDlg::xsizeChanged()
{
}

void MosaicDlg::ysizeChanged()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - created
 *
 ***********************************************************************************************************************/