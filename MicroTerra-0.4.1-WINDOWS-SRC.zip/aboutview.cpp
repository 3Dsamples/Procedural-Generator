/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: aboutview.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: aboutview
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <qpixmap.h>
#include <qcolor.h>
#include "aboutview.h"
#include "ksimpleconfig.h"
#include "mt.h"

/** ***************************************************************************************************************** **/
/** 				     CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/

#define ANIMATION_STEPS 16
#define ANIMATION_SIZE   2

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

AboutView::AboutView( QWidget *parent, const char *name, int wFlags )
	: QWidget( parent, name, wFlags )
{
	active = false;
	do_animation = false;
	frame = 0;
	offset = 0;
	timer = NULL;
	dissolve_map = NULL;
	dissolve_width;
	dissolve_height;
	logo_width = 0;
	logo_height = 0; 
	setBackgroundColor(white);
	if (!timer)
	{
		timer = new QTimer(this);
		connect(timer, SIGNAL(timeout()), this, SLOT(about_dlg_timer()));
	}
}

AboutView::~AboutView()
{
}

void AboutView::drawPlane(QPainter *p)
{
	int i, j, k;
    int x, xp, xs, y, ys;

	if (do_animation)
    {
		for (i = 0, k = 0; i < dissolve_height; i++)
		{
			for (j = 0; j < dissolve_width; j++, k++)
			{
				if (frame == dissolve_map[k])
				{
					xs = j * ANIMATION_SIZE;
					xp = j * ANIMATION_SIZE;
					ys = i * ANIMATION_SIZE;
					for (y = ys; y <(ANIMATION_SIZE+ys); y++)
					{
						for (x=xs; x<((ANIMATION_SIZE)+xs); x++, xp++)
						{
							QRgb pix = aimg.pixel(x, y);

							int as = qAlpha(pix);

							int r = qRed(pix);
							int g = qGreen(pix);
							int b = qBlue(pix);

							about_img.setPixel(x, y, qRgba(r,g,b,as)); 
						}
					} 
				}
			}
		}

		frame += 1;

		if (frame == ANIMATION_STEPS)
		{
			do_animation = FALSE;
			frame = 0;
		} else {
			timer->start(100, true);
		}
    }
	p->drawImage(0, 0, about_img);
}

void AboutView::paintEvent( QPaintEvent * )
{
	QPainter paint(this);

	drawPlane(&paint);
}

bool AboutView::about_dlg_load_logo()
{
	KSimpleConfig  aConfig("./microterra.cfg");
	char           buf[256];
	int            count; 
	int            i, j, k;
	char           path[256];

	aConfig.setGroup("System");
	sprintf(path,"%s", (char *)aConfig.readEntry("microterra_dirpath", "").latin1());
	for (i=0; i<(int)aConfig.readEntry("microterra_dirpath", "").length(); i++)
	{
		if (path[i] == 0x5c)
			path[i] = '/';
	}
	sprintf(buf,"%s%s", (char *)path, "pixmaps/mt_about.bmp");
    if (!apix.load((char *)buf))
		return FALSE;

	aimg = apix.convertToImage();
	aimg.setAlphaBuffer(true);
	logo_width = aimg.width();
	logo_height = aimg.height();
	about_img.create(logo_width, logo_height, 32);
	about_img.setAlphaBuffer(true);
	count = ((logo_width * logo_height) * 3);
	
	dissolve_width = (logo_width / ANIMATION_SIZE) + (logo_width % ANIMATION_SIZE == 0 ? 0 : 1);
	dissolve_height = (logo_height / ANIMATION_SIZE) + (logo_height % ANIMATION_SIZE == 0 ? 0 : 1);

	count = dissolve_width * dissolve_height;
	dissolve_map = new int[count];
	for (i=0; i<count; i++)
	{
		dissolve_map[i] = 0;
	}

	srand(time(NULL));

	for (i = 0, k = 0; i < dissolve_height; i++)
	{
		for (j = 0; j < dissolve_width; j++, k++)
		{
			dissolve_map[k] = rand() % ANIMATION_STEPS;
		}
	}
	do_animation = true;

	return true;
}

void AboutView::about_dlg_timer()
{
	repaint();
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/