/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: radialscaledlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: radialscaledlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "RadialScaleDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

RadialScaleDlgImpl::RadialScaleDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : RadialScaleDlg( parent, name, modal, fl )
{
	centerX = (float)0.50;
	centerY = (float)0.50;
	start = (float)0.15;
	end = (float)0.35;
	freq = 1;
	scale = (float)1.50;
	smooth = (float)0.90;
	b_invert = false;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
RadialScaleDlgImpl::~RadialScaleDlgImpl()
{
}

void RadialScaleDlgImpl::update_preview(bool cxy)
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	if (b_invert == true)
		scale = 1.0 / scale;
	t_terrain_radial_scale(clone, centerX, centerY, scale, start, end, 1-smooth, freq);
	clone->t_terrain_normalize(true);
	if (cxy == true)
		PreView->t_terrain_view_set_crosshair(centerX, centerY);
	PreView->t_terrain_view_set_terrain(clone);
}

void RadialScaleDlgImpl::setCenterX(int value)
{
	char buf[15];

	centerX = (float)(value/100.0);
	sprintf(buf,"%1.2f", centerX);
	slid1->setText((char *)buf);
	update_preview(true);
}

void RadialScaleDlgImpl::setCenterY(int value)
{
	char buf[15];

	centerY = (float)(value/100.0);
	sprintf(buf,"%1.2f", centerY);
	slid2->setText((char *)buf);
	update_preview(true);
}

void RadialScaleDlgImpl::setStart(int value)
{
	char buf[15];

	start = (float)(value/100.0);
	sprintf(buf,"%1.2f", start);
	slid3->setText((char *)buf);
	update_preview(false);
}

void RadialScaleDlgImpl::setEnd(int value)
{
	char buf[15];

	end = (float)(value/100.0);
	sprintf(buf,"%1.2f", end);
	slid4->setText((char *)buf);
	update_preview(false);
}

void RadialScaleDlgImpl::setFreq(int value)
{
	char buf[15];

	freq = value;
	sprintf(buf,"%d", freq);
	slid5->setText((char *)buf);
	update_preview(false);
}

void RadialScaleDlgImpl::setScale(int value)
{
	char buf[15];

	scale = (float)(value/100.0);
	sprintf(buf,"%1.2f", scale);
	slid6->setText((char *)buf);
	update_preview(false);
}

void RadialScaleDlgImpl::setSmooth(int value)
{
	char buf[15];

	smooth = (float)(value/100.0);
	sprintf(buf,"%1.2f", smooth);
	slid7->setText((char *)buf);
	update_preview(false);
}

void RadialScaleDlgImpl::invertClicked()
{
	b_invert = invert->isChecked();
	update_preview(false);
}
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   -
 *
 ***********************************************************************************************************************/