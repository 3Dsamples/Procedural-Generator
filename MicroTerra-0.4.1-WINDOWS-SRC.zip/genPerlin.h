/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genperlin.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genperlin
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        : The 4-layered Perlin noise generation code is taken/adapted from
 *                        John Ratcliff (jratcliff@verant.com) who placed his code under
 *                        the public domain.
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENPERLIN_H
#define GENPERLIN_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvector.h>
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/** 				      GLOBAL DATATYPES			                                                                  **/
/** ***************************************************************************************************************** **/

typedef enum EquationType
{
	MF_NULL,
	MF_SQUARED,
	MF_SIN,
	MF_COS,
	MF_TAN,
	MF_SINH,
	MF_COSH,
	MF_TANH,
	MF_ASIN,
	MF_ACOS,
	MF_ATAN,
	MF_EXP,
	MF_LOG,
	MF_SQRT,
	MF_LAST
} EquationType;

typedef enum EnvelopeType
{
	ET_NULL,      // 0 do nothing, leave it as is.
	ET_SQUARED1,  // 1
	ET_SQUARED2,  // 2
	ET_SQUARED3,  // 3
	ET_ATAN1,     // 4 (arc tangent 1)
	ET_ATAN2,     // 5 (arc tangent 2)
	ET_ATAN3,     // 6 (arc tangent 3)
	ET_ACOS1,     // 7 (arc cosine 1)
	ET_ACOS2,     // 8 (arc cosine 2)
	ET_ACOS3,     // 9 (arc cosine 3)
	ET_ACOS4,     // 10 (arc cosine 4)
	ET_COS1,      // 11
	ET_COS2,      // 12
	ET_EXP1,      // 13
	ET_EXP2,      // 14
	ET_EXP3,      // 15
	ET_EXP4,      // 16
	ET_EXP5,      // 17
	ET_LOG1,      // 18
	ET_LOG2,      // 19
	ET_LOG3,      // 20
	ET_TANH,      // 21 (hyperbolic tangent)
	ET_SQRT,      // 22
	ET_LAST
} EnvelopeType;

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class Equation
{
public:
	EquationType func;
	float        constant;
	float        scaler;
	float        min;
	float        max;
};

class Octave
{
public:
	int    amplitude;
	int    width;
	int    height;
	int    u;
	int    v;
	int    du;
	int    dv;
	int    scan_y;
	int   *scan_line;
	int   *random1;
	int   *random2;
};

typedef QVector<Octave>	Per_Octaves; 

//class Octaves
//{
//	Octave *octs;
//	int     octave_count;
//};

class genPer
{
public:
	genPer(TTerrain* terra);
	~genPer();
    void t_terrain_generate_perlin (int width, int height, int seed, bool b[4], float f[4], float a[4], int o[4], int e[4]);

private:
	TTerrain *terrain;
	Octave   *octaves;
	int       octave_count;


	Equation *equation_new(EquationType func, float constant, float scaler, float min, float max);
	Equation *equation_envelope_new(EnvelopeType  type);
	void equation_free(Equation *equation);
	float equation_get(Equation *equation, float x);

	Octave *octave_new(int width, int height, int u, int v, int du, int dv, int amplitude, int seed);
	void octave_free(Octave *octave);
	int octave_get(Octave *octave, int x, int y);
	void octave_generate (Octave *octave, int y);

	Per_Octaves *octaves_new(int octave_count, int width, int height, int u, int v, float frequency, int base, int amplitude, float freq_decay, float amp_decay, int seed);
	void octaves_free(Per_Octaves *octaves);
	int octaves_get(Per_Octaves *octaves, int x, int y);
};

#endif // GENPERLIN_H
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/