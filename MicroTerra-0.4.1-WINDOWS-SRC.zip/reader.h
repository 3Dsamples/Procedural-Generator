/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: reader.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: reader
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef __READER_H__
#define __READER_H__

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "tterrain.h"
#include "filenameops.h"

/** ***************************************************************************************************************** **/
/** 				      CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 * Definitions used by both reader.c and writer.c
 */
#define MAX_16_BIT 65535.0

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/
/* binary terrain format as desribed @ 
 * http://vterrain.org/Implementation/BT.html
 */
class bt_header
{
public:
  char   marker[10];
  short  width;
  short  width_b2;
  short  height;
  short  height_b2;
  short  data_size;       /* in bytes; either 2 or 4 */
  short  floating_point;  /* 0: Integers; 1: floating point; anything else: Integer */
  short  projection;      /* 0: Geographic; 1: Universal Transverse Mercator (UTM */
  short  utm_zone;        /* 1-60: negative zone numbers for southern hemisphere */
  short  datum;           /* datum values from lookup table */
  double left_extent;
  double right_extent;
  double bottom_extent;
  double top_extent;
  short  external_projection;
  char   pad[194];        /* padding */
};

class TReader
{
public:
	TReader();
	~TReader();
	TTerrain *t_terrain_load(char *filename, TFileType type);

private:
	TTerrain *t_terrain_load_native(char *filename);
	TTerrain *t_terrain_import_bmp(char *filename);
	TTerrain *t_terrain_import_gtopo(char *filename, int scale);
	TTerrain *t_terrain_import_mat(char *filename);
	TTerrain *t_terrain_import_oct(char *filename);
	TTerrain *t_terrain_import_tga(char *filename);
	TTerrain *t_terrain_import_pgm(char *filename);
	TTerrain *t_terrain_import_gdk_pixbuf(char *filename);
	TTerrain *t_terrain_import_terragen(char *filename);
	TTerrain *t_terrain_import_grd(char *filename);
	TTerrain *t_terrain_import_xyz(char *filename);
	TTerrain *t_terrain_import_dxf(char *filename);
	TTerrain *t_terrain_import_bna(char *filename);
	TTerrain *t_terrain_import_bt(char *filename);
	TTerrain *t_terrain_import_dted(char *filename);
	TTerrain *t_terrain_import_e00grid(char *filename);
	void heightfield_load_data(float **heightfield, int width, int height, FILE *fp);
	TTerrain *heightfield_load(FILE *fp);
};

#endif //__READER_H__
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/