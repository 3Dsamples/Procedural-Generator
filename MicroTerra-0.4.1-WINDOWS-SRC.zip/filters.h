/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: filters.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: filters
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef FILTERS_H
#define FILTERS_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

float threshold(float x, float power, float midpoint);
float transform(float x, float sea_threshold, float sea_depth, float sea_dropoff, float above_power, float below_power);
void t_terrain_fill(TTerrain *terrain, float elevation, float factor);
void t_terrain_fold(TTerrain *terrain, int margin);
void t_terrain_mosaic(TTerrain *terrain, int x_mosaicsize, int y_mosaicsize);
float t_terrain_calculate_average(TTerrain *terrain);
float t_terrain_calculate_variance(TTerrain *terrain, float *return_average);
float t_terrain_calculate_skewness(TTerrain *terrain, float *return_average, float *return_variance);
float t_terrain_calculate_dimension(TTerrain *terrain);
void t_terrain_mirror(TTerrain *terrain, int type); 
void t_terrain_connect(TTerrain *terrain, int iteration_count);
void t_terrain_radial_scale(TTerrain *terrain, float center_x, float center_y, float scale_factor, float min_dist, float max_dist, float smooth_factor, int frequency);
void t_terrain_gaussian_hill(TTerrain *terrain, float center_x, float center_y, float radius, float radius_factor, float hscale, float smooth_factor, float delta_scale);
void t_terrain_craters(TTerrain *terrain, int count, bool wrap, float height_scale, float radius_scale, float crater_coverage, int seed, float center_x, float center_y);
void t_terrain_spherical(TTerrain *terrain, float offset);
void t_terrain_fill_basins(TTerrain *terrain, int iterations, bool big_grid);
TTerrain *t_terrain_flowmap(TTerrain *terrain, bool do_sfd, bool ignore_sealevel, float max_elevation_erode);
int t_terrain_erode_flowmap(TTerrain *terrain, TTerrain *flowmap, int iterations, bool trim_local_peaks);
int t_terrain_erode (TTerrain *terrain, int iterations, int max_flow_age, int age_flow_times, float max_elevation_erode, char *filename_anim, char *filename_flow, int n_frames, bool trim_local_peaks, bool do_sfd, bool ignore_sealevel);
void t_terrain_roughen_smooth(TTerrain *terrain, bool roughen, bool big_grid, float factor);
void t_terrain_digital_filter(TTerrain *terrain, float *filterData, int filterSize, float elv_min, float elv_max);
void t_terrain_rasterize(TTerrain *terrain, int x_size, int y_size, float tightness);
void t_terrain_rotate(TTerrain *terrain, int amount);
void t_terrain_terrace(TTerrain *terrain, int level_count, float factor, bool adjust_sealevel);
void t_terrain_transform(TTerrain *terrain, float sea_threshold, float sea_depth, float sea_dropoff, float above_power, float below_power);
void t_terrain_tiler(TTerrain *terrain, float offset);
void t_terrain_tile(TTerrain *terrain, int multiply);

#endif // FILTERS_H
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/