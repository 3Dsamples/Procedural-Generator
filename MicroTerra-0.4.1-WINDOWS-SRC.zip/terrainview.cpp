/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: terrainview.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: terrainview
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <math.h>
#include <stdlib.h>
#include <qprinter.h>
#include "terrainview.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/

#ifndef G_PI
#define G_PI 3.14159265358979323846264
#endif

/** ***************************************************************************************************************** **/
/**				         MACROS				                                                                          **/
/** ***************************************************************************************************************** **/

#define SQR(x)  ((x)*(x))
#define rint(x) floor((x)+0.5)
  
/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

TerrainView::TerrainView( QWidget *parent, const char *name, int wFlags )
: QWidget( parent, name, wFlags )
{
	col = new ColorMaps();
	contour = new CContour();
	setBackgroundColor( white );
	model = T_VIEW_2D_PLANE;
	raster = NULL;
	trans = NULL;
	mouse_mode = T_MOUSE_NONE;
   
	terraOK = false;
	histOK = false;
	drawindex = 0;				// draw first thing
	maxindex  = 2;
	contour_dirty           = false;
	dirty                   = false;
	size                    = 0;
	rotate_timeout          = 0;
	terrain                 = NULL;
	colormap                = T_COLORMAP_LAND;
	angle                   = (float)0.0;
	elevation               = (float)0.25;
	auto_rotate             = false;
	do_tile                 = false;
	crosshair_x             = -1.0;
	crosshair_y             = -1.0;
	anchor_x                = 0;
	anchor_y                = 0;
    contour_lines           = NULL;
	heightfield_modified_id = 0;
	selection_modified_id   = 0;
	object_added_id         = 0;
	object_modified_id      = 0;
	object_deleted_id       = 0;
	tool_mode               = T_TOOL_NONE;
   //	compose_op              = T_COMPOSE_NONE;
	crosshair_x = (float)0.0;
	crosshair_y = (float)0.0;
	crosshair = false;
}

//
// Clean up
//
TerrainView::~TerrainView()
{
}

void TerrainView::draw_line_add_aa(int vcol, int x1, int y1, int x2, int y2)
{
  int x, y;
  int count;
  int delta_x, delta_y;
  int dir_x, dir_y;
  int gamma_curve[32];
  int i;

  for (i = 0; i < 32; i++)
    gamma_curve[i] = (int)(pow ((i + 0.5) / 32.0, 1.0 / 1.8) * 31.0 + 0.5);
 
  delta_x = x2 - x1;
  if (delta_x < 0) delta_x = -delta_x, dir_x = -1; else dir_x = 1;

  delta_y = y2 - y1;
  if (delta_y < 0) delta_y = -delta_y, dir_y = -1; else dir_y = 1;

  x = x1; 
  y = y1;
  count = 0;
  if (delta_x > delta_y)
    {
      /* Mostly horizontal */
      for (; x != x2 + dir_x; x += dir_x)
        {
          if (x >= 0 && x < terrain->width)
            {
              int   *pos;
              int    y2;
              int    alpha = 32 * count / delta_x;
              int    value;

              pos = &raster[(y * terrain->width + x) * 3];
              if (y >= 0 && y < terrain->height)
                {
                  value = gamma_curve[31 - alpha];
                  // value = 31 - alpha;

                  pos[0] = MIN (pos[0] + ((col->colmap[vcol + 0] * value) >> 5), 255);
                  pos[1] = MIN (pos[1] + ((col->colmap[vcol + 1] * value) >> 5), 255);
                  pos[2] = MIN (pos[2] + ((col->colmap[vcol + 2] * value) >> 5), 255);
                }

              y2 = y + dir_y;
              pos += dir_y * terrain->width * 3;
              if (y2 >= 0 && y2 < terrain->height)
                {
                  value = gamma_curve[alpha];
                  // value = alpha;

                  pos[0] = MIN (pos[0] + ((col->colmap[vcol + 0] * value) >> 5), 255);
                  pos[1] = MIN (pos[1] + ((col->colmap[vcol + 1] * value) >> 5), 255);
                  pos[2] = MIN (pos[2] + ((col->colmap[vcol + 2] * value) >> 5), 255);
                }
            }

          count += delta_y;
          if (count >= delta_x) count -= delta_x, y += dir_y;
        }
    }
  else if (delta_y > 0)
    {
      /* Mostly vertical */
      for (; y != y2 + dir_y; y += dir_y)
        {
          if (y >= 0 && y < terrain->height)
            {
              int   *pos;
              int    alpha = 32 * count / delta_y;
              int    value;

              pos = &raster[(y * terrain->width + x) * 3];
              if (x >= 0 && x < terrain->width)
                {
                  value = gamma_curve[31 - alpha];
                  // value = 31 - alpha;

                  pos[0] = MIN (pos[0] + ((col->colmap[vcol + 0] * value) >> 5), 255);
                  pos[1] = MIN (pos[1] + ((col->colmap[vcol + 1] * value) >> 5), 255);
                  pos[2] = MIN (pos[2] + ((col->colmap[vcol + 2] * value) >> 5), 255);
                }

              x2 = x + dir_x;
              pos += dir_x * 3;
              if (x2 >= 0 && x2 < terrain->width)
                {
                  value = gamma_curve[alpha];
                  // value = alpha;

                  pos[0] = MIN (pos[0] + ((col->colmap[vcol + 0] * value) >> 5), 255);
                  pos[1] = MIN (pos[1] + ((col->colmap[vcol + 1] * value) >> 5), 255);
                  pos[2] = MIN (pos[2] + ((col->colmap[vcol + 2] * value) >> 5), 255);
                }
            }

          count += delta_x;
          if (count >= delta_y) count -= delta_y, x += dir_x;
        }
    }
  else
    {
      /* One pel */
      if (x1 >= 0 && y1 >= 0 && x1 < terrain->width && y1 < terrain->height)
        {
          int *pos;

          pos = &raster[(y1 * terrain->width + x1) * 3];
          pos[0] = MIN (pos[0] + col->colmap[vcol + 0], 255);
          pos[1] = MIN (pos[1] + col->colmap[vcol + 1], 255);
          pos[2] = MIN (pos[2] + col->colmap[vcol + 2], 255);
        }
    }
}
 
void TerrainView::draw_crosshair(QPainter *p)
{
  if (crosshair_x >= 0.0 && crosshair_y >= 0.0)
    {
      int       x, y;

      x = crosshair_x * terrain->width + 0.5;
      y = crosshair_y * terrain->height + 0.5;

      p->setPen(Qt::black);
      /* Horizontal */
	  p->drawLine(0, y, terrain->width - 1, y);
      /* Vertical */
	  p->drawLine(x, 0, x, terrain->height - 1);
    }
}
 
void TerrainView::draw_arrow(QPainter *p, int x1, int y1, int x2, int y2)
{
  const float arrow_angle = (float)(0.25 * G_PI);
  const float arrow_length = 8.0;

  p->drawLine(x1, y1, x2, y2);
  if (x1 != x2 || y1 != y2)
    {
      int   x3, y3, x4, y4;
      float angle, dist;

      dist = sqrt(SQR (x2 - x1) + SQR (y2 - y1));
      angle = acos((y1 - y2) / dist); /* 0 -> PI */
      if (x2 - x1 < 0)
        angle = -angle;

      dist = MIN(dist, arrow_length);

      x3 = (int)(x2 + cos (angle + arrow_angle) * dist);
      x4 = (int)(x2 - cos (angle - arrow_angle) * dist);
      y3 = (int)(y2 + sin (angle + arrow_angle) * dist);
      y4 = (int)(y2 - sin (angle - arrow_angle) * dist);

      p->drawLine(x2, y2, x3, y3);
      p->drawLine(x2, y2, x4, y4);
    }
}
 
//
// This function draws a color wheel.
// The coordinate system x=(0..500), y=(0..500) spans the paint device.
//

void TerrainView::drawColorWheel( QPainter *p )
{
	QFont f( "times", 18, QFont::Bold );
	p->setFont( f );
	p->setPen( Qt::black );
	p->setWindow( 0, 0, 400, 400 );		// defines coordinate system
   
	for ( int i=0; i<36; i++ ) {		// draws 36 rotated rectangles
      
		QWMatrix matrix;
		matrix.translate( 200.0F, 200.0F );	// move to center
		matrix.shear( 0.0F, 0.3F );		// twist it
		matrix.rotate( (float)i*10 );		// rotate 0,10,20,.. degrees
		p->setWorldMatrix( matrix );		// use this world matrix
      
		QColor c;
		c.setHsv( i*10, 255, 255 );		// rainbow effect
		p->setBrush( c );			// solid fill with color c
		p->drawRect( 70, -10, 80, 10 );		// draw the rectangle
      
		QString n;
		n.sprintf( "H=%d", i*10 );
		p->drawText( 80+70+5, 0, n );		// draw the hue number
	}
}

void TerrainView::drawPlane( QPainter *p )
{
	int x, xp, y;
   
	UpdateBuf();
	for (y = 0; y < terrain->height; y++)
	{
		for (x=0, xp=0; x<terrain->width*3; x+=3, xp++)
		{
			p->setPen(QColor(raster[(y*(terrain->width*3))+x], raster[(y*(terrain->width*3))+(x+1)], raster[(y*(terrain->width*3))+(x+2)]));
			p->drawPoint(xp, y);
		}
	} 

	if (crosshair == true)
		draw_crosshair(p);
}

void TerrainView::draw_2d_contour(QPainter *p)
{
  GList *pos;
  float *points = NULL;

  int    i, x, y, x2, y2, xp;
  float  scale_x, scale_y;

  contour_lines = contour->t_terrain_contour_lines(terrain, terrain->contour_levels, 5);
  UpdateBuf();

	for (y = 0; y < terrain->height; y++)
	{
		for (x=0, xp=0; x<terrain->width*3; x+=3, xp++)
		{
			p->setPen(QColor(raster[(y*(terrain->width*3))+x], raster[(y*(terrain->width*3))+(x+1)], raster[(y*(terrain->width*3))+(x+2)]));
			p->drawPoint(xp, y);
		}
	} 

  scale_x = ((float)terrain->width) / terrain->width;
  scale_y = ((float)terrain->height) / terrain->height;

  pos = contour_lines;
  while (pos != NULL)
    {
        points = pos->ldata;

      x = points[1] * scale_x;
      y = points[2] * scale_y;
      for (i = 3; i < pos->size; i += 2)
        {
          x2 = points[i + 0] * scale_x;
          y2 = points[i + 1] * scale_y;
          p->setPen(Qt::black);
		  p->drawLine(x, y, x2, y2);
          x = x2;
          y = y2;
        }

      pos = pos->next;
    }
}

/*
 * The following implements the Cohen-Sutherland line clipping algorithm, 
 * with some custom additions. 
 * It was adapeted from the code at 
 * http://www.daimi.au.dk/~mbl/cgcourse/wiki/cohen-sutherland_line-cli.html
 */

/*
 * compute the encoding of a point relative to a rectangle
 */
clip_code TerrainView::compute_clip_code(double x, double y, rectangle r)
{
  clip_code c = 0;

  if (y > r.ymax)
    c |= TOP;
  else 
  if (y < r.ymin)
    c |= BOTTOM;

  if (x > r.xmax)
    c |= RIGHT;
  else 
  if (x < r.xmin)
    c |= LEFT;

  return c;
}

/*
 * clip line P0(x0,y0)-P1(x1,y1) against a plane/rectangle. 
 * returns TRUE if the line is to be drawn, FALSE if it can be ignored.
 */
bool TerrainView::clip_line(double *x0, double *y0, double *x1, double *y1, rectangle clip_rect)
{
  clip_code C0, C1, C;
  double x, y;

  C0 = compute_clip_code (*x0, *y0, clip_rect);
  C1 = compute_clip_code (*x1, *y1, clip_rect);

  for (;;) 
    {
      /* trivial accept: both ends in rectangle */
      if ((C0 | C1) == 0) 
        return TRUE;
		
      /* trivial reject: both ends on the external side of the rectangle */
      if ((C0 & C1) != 0)
        return FALSE;

      /* RNG: extra check which is not part of the C&S algorithm.
       * Due to the fact the we're dealing with a rotated wireframe 
       * drawing of the terrain, we can reject any line which has both 
       * ends off the screen. This has the added benefit of removing 
       * lines which would be rotated behind the camera and above the 
       * screen, which otherwise would show up as incorrect vertical 
       * lines across the screen. 
       */
      if (C0 != 0 && C1 != 0)
        return FALSE;

      /* normal case: clip end outside rectangle */
      C = C0 ? C0 : C1;
      if (C & TOP) 
        {
          x = *x0 + (*x1 - *x0) * (clip_rect.ymax - *y0) / (*y1 - *y0);
          y = clip_rect.ymax;
        } 
      else if (C & BOTTOM) 
        {
          x = *x0 + (*x1 - *x0) * (clip_rect.ymin - *y0) / (*y1 - *y0);
          y = clip_rect.ymin;
        }  
      else if (C & RIGHT) 
        {
          x = clip_rect.xmax;
          y = *y0 + (*y1 - *y0) * (clip_rect.xmax - *x0) / (*x1 - *x0);
        } 
      else 
        {
          x = clip_rect.xmin;
          y = *y0 + (*y1 - *y0) * (clip_rect.xmin - *x0) / (*x1 - *x0);
        }

       /* set new end point and iterate */
       if (C == C0) 
         {
           *x0 = x; 
           *y0 = y;
           C0 = compute_clip_code (*x0, *y0, clip_rect);
         } 
       else 
         {
           *x1 = x; 
           *y1 = y;
           C1 = compute_clip_code (*x1, *y1, clip_rect);
         }
     }

  /* Not Reached */
}

bool TerrainView::clip_line_int(int *x0, int *y0, int *x1, int *y1, rectangle clip_rect)
{
  double dx0 = *x0;
  double dy0 = *y0;
  double dx1 = *x1;
  double dy1 = *y1;

  bool rc = clip_line (&dx0, &dy0, &dx1, &dy1, clip_rect);

  *x0 = (int) dx0;
  *y0 = (int) dy0;
  *x1 = (int) dx1;
  *y1 = (int) dy1;

  return rc;
}

void TerrainView::draw_3d_wire(QPainter *p)
						
						//TTerrain *terrain, TPixbuf  *pixbuf,
                        //gfloat    angle,
                        //gfloat    elevation /* -2.0 - 2.0 */,
                        //gint      resolution,
                        //guchar   *palette, 
                        //gboolean  do_tile)
{
  int   y;
  int   division;
  int   width_offset, height_offset;
  int   lim_x, lim_y;
  float scrn_offset_x, scrn_offset_y;
  float y_scale;
  float terrain_size;
  float cos_angle, sin_angle;
  float camera_y, camera_z;
  float zoom;
  float half_width, half_height;
  rectangle screen_rect;
  int   resolution = terrain->wireframe_resolution;
	int x, xp;
   
  terrain_size = MAX (terrain->width, terrain->height);

  division = (int) ceil(((float)terrain_size) / terrain_size * resolution);
  y_scale = terrain->y_scale_factor * terrain_size;

  /* Add 0.5 to the elevation so that an elevation parameter of 0.0 centers
     the camera at the midpoint of a normalized heightfield. */
  /* camera_y = terrain_size * (elevation + 0.5); */
  camera_y = terrain_size * ((elevation + 0.5) + terrain->camera_height_factor);
  camera_z = -terrain_size * 1.5;
  zoom = terrain_size * 1.0;

  /* Use the offsets to center the plot onscreen. */
  scrn_offset_x = terrain->width * 0.5;
  scrn_offset_y = terrain->height * 0.5 + zoom * (camera_y - 0.5 * y_scale) / camera_z; 

  cos_angle = cos (angle);
  sin_angle = sin (angle);

  width_offset = (terrain->width % division) >> 1;
  height_offset = (terrain->height % division) >> 1;

  screen_rect.xmin = 0;
  screen_rect.ymin = 0;
  screen_rect.xmax = terrain->width;
  screen_rect.ymax = terrain->height;

  if (do_tile) 
    {
      half_width = terrain->width;
      half_height = terrain->height;

      lim_x = terrain->width * 2;
      lim_y = terrain->height * 2;
    }
  else
    {
      half_width = terrain->width * 0.5;
      half_height = terrain->height * 0.5;

      lim_x = terrain->width;
      lim_y = terrain->height;
    }

  for (y = height_offset; y < lim_y; y += division)
    {
      int x;

      for (x = width_offset; x < lim_x; x += division)
        {
          float   temp_x, temp_y, temp_z;
          float   coord_x, coord_y;
          int     scrn_x_1, scrn_y_1;
          int     scrn_x_2=0, scrn_y_2=0; /* silence compiler warnings */
          int     scrn_x_3, scrn_y_3;
          int     value;
          bool    right;
      
	  int pos = y%terrain->height * terrain->width + x%terrain->width;

          value = ((terrain->heightfield[pos] * 255.0) + 0.5);
          value = MAX (MIN (value, 255), 0) * 3;
 
          coord_x = x - half_width; coord_y = y - half_height;
          temp_x = cos_angle * coord_x + sin_angle * coord_y;
          temp_y = terrain->heightfield[pos];
          if (terrain->do_filled_sea && temp_y < terrain->sealevel)
            temp_y = terrain->sealevel;
          temp_y *= y_scale;
          temp_z = sin_angle * coord_x - cos_angle * coord_y;
          scrn_x_1 = rint(scrn_offset_x + zoom * temp_x / (temp_z - camera_z));
          scrn_y_1 = rint(scrn_offset_y - zoom * (temp_y - camera_y) / (temp_z - camera_z));

          //t_pixbuf_set_fore (pixbuf, palette[value], palette[value + 1], palette[value + 2]);

          right = FALSE;
          if (x + division < lim_x)
            {
              coord_x = x + division - half_width; coord_y = y - half_height;
              temp_x = cos_angle * coord_x + sin_angle * coord_y;
              temp_y = terrain->heightfield[pos + division];
              if (terrain->do_filled_sea && temp_y < terrain->sealevel)
                temp_y = terrain->sealevel;
              temp_y *= y_scale;
              temp_z = sin_angle * coord_x - cos_angle * coord_y;
              scrn_x_2 = rint(scrn_offset_x + zoom * temp_x / (temp_z - camera_z));
              scrn_y_2 = rint(scrn_offset_y - zoom * (temp_y - camera_y) / (temp_z - camera_z));

              right = TRUE;
              if (clip_line_int (&scrn_x_1, &scrn_y_1, &scrn_x_2, &scrn_y_2, screen_rect))
                draw_line_add_aa(value, scrn_x_1, scrn_y_1, scrn_x_2, scrn_y_2);
            }

          if (y + division < lim_y)
            {
              coord_x = x - half_width; coord_y = y + division - half_height;
              temp_x = cos_angle * coord_x + sin_angle * coord_y;

	      if (y%terrain->height + division < terrain->height)
                temp_y = terrain->heightfield[pos + division * terrain->width];
	      else
                {
                  int yoff = terrain->height - y % terrain->height - 1; 
                  temp_y = terrain->heightfield[pos + yoff * terrain->width];
                }

              if (terrain->do_filled_sea && temp_y < terrain->sealevel)
                temp_y = terrain->sealevel;
              temp_y *= y_scale;
              temp_z = sin_angle * coord_x - cos_angle * coord_y;
              scrn_x_3 = rint(scrn_offset_x + zoom * temp_x / (temp_z - camera_z));
              scrn_y_3 = rint(scrn_offset_y - zoom * (temp_y - camera_y) / (temp_z - camera_z));

              if (clip_line_int (&scrn_x_1, &scrn_y_1, &scrn_x_3, &scrn_y_3, screen_rect))
                draw_line_add_aa(value, scrn_x_1, scrn_y_1, scrn_x_3, scrn_y_3);

              if (right)
                if (clip_line_int (&scrn_x_2, &scrn_y_2, &scrn_x_3, &scrn_y_3, screen_rect))
                  draw_line_add_aa(value, scrn_x_2, scrn_y_2, scrn_x_3, scrn_y_3);
            }
        }
    }
	for (y = 0; y < terrain->height; y++)
	{
		for (x=0, xp=0; x<terrain->width*3; x+=3, xp++)
		{
			p->setPen(QColor(raster[(y*(terrain->width*3))+x], raster[(y*(terrain->width*3))+(x+1)], raster[(y*(terrain->width*3))+(x+2)]));
			p->drawPoint(xp, y);
		}
	} 

}

int point_comparison(const void *point_1, const void *point_2)
{
  return ((GdkPoint*) point_1)->y > ((GdkPoint*) point_2)->y;
}

void TerrainView::fill_triangle(QPainter *pixbuf, GdkPoint *points)
{
  GdkPoint pts[3];
  int      count_1, count_2;
  int      max_1, max_2;
  int      inc_1, inc_2;
  int      x_1, x_2;
  int      dir_1, dir_2;
  int      y;

  if (points[0].y == points[1].y && points[1].y == points[2].y)
    {
	  pixbuf->drawLine(MIN(points[0].x, MIN (points[1].x, points[2].x)), points[0].y, MAX(points[0].x, MAX (points[1].x, points[2].x)), points[0].y);
      return;
    }

  /* Copy and sort points by y-coordinate. */
  memcpy(pts, points, sizeof(GdkPoint) * 3);
  qsort(pts, 3, sizeof(GdkPoint), &point_comparison);

  x_1 = x_2 = pts[0].x;
  dir_1 = (pts[0].x < pts[2].x) ? 1 : -1;
  dir_2 = (pts[0].x < pts[1].x) ? 1 : -1;
  max_1 = abs (pts[0].y - pts[2].y);
  max_2 = abs (pts[0].y - pts[1].y);
  inc_1 = abs (pts[0].x - pts[2].x);
  count_1 = 0;
  inc_2 = abs (pts[0].x - pts[1].x);
  count_2 = 0;
  for (y = pts[0].y; y <= pts[2].y; y++)
    {
      if (y == pts[1].y)
        {
          x_2 = pts[1].x;
          max_2 = abs (pts[1].y - pts[2].y);
          inc_2 = abs (pts[1].x - pts[2].x);
          count_2 = 0;
          dir_2 = (pts[1].x < pts[2].x) ? 1 : -1;
        }

      pixbuf->drawLine(MIN (x_1, x_2), y, MAX (x_1, x_2), y);

      count_1 += inc_1;
      if (max_1 > 0)
        while (count_1 >= max_1)
          {
            count_1 -= max_1;
            x_1 += dir_1;
          }

      count_2 += inc_2;
      if (max_2 > 0)
        while (count_2 >= max_2)
          {
            count_2 -= max_2;
            x_2 += dir_2;
          }
    }
}
 
void TerrainView::draw_3d_light(QPainter *p)
{
  int   y, x, xp;
  int   scrn_offset_x, scrn_offset_y;
  int   lim_x, lim_y;
  float y_scale;
  float terrain_size, pixbuf_size;
  float camera_y, camera_z;
  float zoom;
  float half_width, half_height;

	for (y = 0; y < terrain->height; y++)
	{
		for (x=0, xp=0; x<terrain->width*3; x+=3, xp++)
		{
			p->setPen(Qt::black);
			p->drawPoint(xp, y);
		}
	} 
  terrain_size = MAX(terrain->width, terrain->height);
  pixbuf_size = MIN(terrain->width, terrain->height);
  y_scale = terrain->y_scale_factor * terrain_size;

  /* camera_y = terrain_size * 0.75; */
  camera_y = terrain_size * ((elevation + 0.5) + terrain->camera_height_factor);
  camera_z = -terrain_size * 1.5;

  if (do_tile) 
    {
      zoom = pixbuf_size * 0.5;

      half_width = terrain->width;
      half_height = terrain->height;

      lim_x = terrain->width * 2;
      lim_y = terrain->height * 2;
    } 
  else
    {
      zoom = pixbuf_size * 1.0;

      half_width = terrain->width * 0.5;
      half_height = terrain->height * 0.5;

      lim_x = terrain->width;
      lim_y = terrain->height;
    }

  /* Use the offsets to center the plot onscreen. */
  scrn_offset_x = terrain->width / 2;
  /* scrn_offset_y = -pixbuf->height / 8 +
   *   pixbuf->height / 2 + zoom * (camera_y - 0.5 * y_scale) / camera_z;
   */
  scrn_offset_y = terrain->height * 0.5 + zoom * (camera_y - 0.5 * y_scale) / camera_z;

  for (y=0; y+1 < lim_y; y++)
    {
      int   x;
      int   pos;
      int   temp_x_1, temp_y_1;
      int   temp_x_2, temp_y_2;
      float coord_x_1, coord_y_1, coord_z_1;
      float coord_x_2, coord_y_2, coord_z_2;

      pos = y%terrain->height * terrain->width;

      coord_x_1 = -half_width;
      coord_y_1 = terrain->heightfield[pos];
      if (terrain->do_filled_sea && coord_y_1 < terrain->sealevel)
        coord_y_1 = terrain->sealevel;
      coord_y_1 *= y_scale;
      coord_z_1 = half_height - y;
      temp_x_1 = zoom * coord_x_1 / (coord_z_1 - camera_z);
      temp_y_1 = zoom * (coord_y_1 - camera_y) / (coord_z_1 - camera_z);

      coord_x_2 = -half_width;
      /* Required to tile correctly */
      if (y % terrain->height + 1 < terrain->height)
        coord_y_2 = terrain->heightfield[pos + terrain->width];
      else 
        {
          int yoff = terrain->height - y%terrain->height - 1;
          coord_y_2 = terrain->heightfield[yoff * terrain->width];
        }
      if (terrain->do_filled_sea && coord_y_2 < terrain->sealevel)
        coord_y_2 = terrain->sealevel;
      coord_y_2 *= y_scale;
      coord_z_2 = half_height - y - 1;
      temp_x_2 = zoom * coord_x_2 / (coord_z_2 - camera_z);
      temp_y_2 = zoom * (coord_y_2 - camera_y) / (coord_z_2 - camera_z);

      for (x=0; x+1 < lim_x; x++)
        {
          int     temp_x_3, temp_y_3;
          int     temp_x_4, temp_y_4;
          float   coord_x_3, coord_y_3, coord_z_3;
          float   coord_x_4, coord_y_4, coord_z_4;
          float   vector_y_2, vector_y_3;
          float   light_x, light_y, light_z;
          float   magnitude;
          int     value;
          float   light;
          GdkPoint points[3];

	      /* Simple fix for tiling edges -> skip border pixel */
	      if (do_tile && x == terrain->width-1)
            x++;

          pos = y%terrain->height * terrain->width + x%terrain->width;

          value = ((terrain->heightfield[pos] * 255.0) + 0.5);
          value = MAX (MIN (value, 255), 0) * 3;
 
          coord_x_3 = x + 1 - half_width;
          coord_y_3 = terrain->heightfield[pos + 1];
          if (terrain->do_filled_sea && coord_y_3 < terrain->sealevel)
            coord_y_3 = terrain->sealevel;
          coord_y_3 *= y_scale;
          coord_z_3 = half_height - y;
          temp_x_3 = zoom * coord_x_3 / (coord_z_3 - camera_z);
          temp_y_3 = zoom * (coord_y_3 - camera_y) / (coord_z_3 - camera_z);

          coord_x_4 = x + 1 - half_width;
          coord_y_4 = terrain->heightfield[pos + terrain->width + 1];
          if (terrain->do_filled_sea && coord_y_4 < terrain->sealevel)
            coord_y_4 = terrain->sealevel;
          coord_y_4 *= y_scale;
          coord_z_4 = half_height - y - 1;
          temp_x_4 = zoom * coord_x_4 / (coord_z_4 - camera_z);
          temp_y_4 = zoom * (coord_y_4 - camera_y) / (coord_z_4 - camera_z);

          /* Calculate the light for the upper left triangle.  We
             also draw the lower right triangle using the same value
             and lighting to save CPU time. */
          vector_y_2 = coord_y_2 - coord_y_1;
          magnitude = sqrt (1.0 + vector_y_2 * vector_y_2);
          vector_y_2 /= magnitude;

          vector_y_3 = coord_y_3 - coord_y_1;
          magnitude = sqrt (1.0 + vector_y_3 * vector_y_3);
          vector_y_3 /= magnitude;

          /* Dot product */
          magnitude = sqrt(vector_y_2 * vector_y_2 + 1.0 + vector_y_3 * vector_y_3);
          coord_x_1 = vector_y_2 / magnitude;
          coord_y_1 = 1.0 / magnitude;
          coord_z_1 = vector_y_3 / magnitude;

          light_x = (float)0.5773;
          light_y = (float)0.5773;
          light_z = (float)0.5773;

          light = pow((coord_x_1 * light_x + coord_y_1 * light_y + coord_z_1 * light_z + 1.0) * 0.5, 2.0) * 0.5;

		  p->setPen(QColor(MIN((col->colmap[value] >> 1) + light * 255, 255), MIN((col->colmap[value + 1] >> 1) + light * 255, 255), MIN((col->colmap[value + 2] >> 1) + light * 255, 255)));

          points[0].x = scrn_offset_x + temp_x_1;
          points[0].y = scrn_offset_y - temp_y_1;
          points[1].x = scrn_offset_x + temp_x_2;
          points[1].y = scrn_offset_y - temp_y_2;
          points[2].x = scrn_offset_x + temp_x_3;
          points[2].y = scrn_offset_y - temp_y_3;
          fill_triangle(p, points);

          points[0].x = scrn_offset_x + temp_x_4;
          points[0].y = scrn_offset_y - temp_y_4;
          fill_triangle(p, points);

          temp_x_1 = temp_x_3;
          temp_y_1 = temp_y_3;
          temp_x_2 = temp_x_4;
          temp_y_2 = temp_y_4;
          coord_x_1 = coord_x_3;
          coord_y_1 = coord_y_3;
          coord_x_2 = coord_x_4;
          coord_y_2 = coord_y_4;
        }
    }
}
 
void TerrainView::draw_3d_height(QPainter *p)
{
  int   y, x, xp;
  int   scrn_offset_x, scrn_offset_y;
  int   lim_x, lim_y;
  float y_scale;
  float terrain_size, pixbuf_size;
  float camera_y, camera_z;
  float zoom;
  float half_width, half_height;

	for (y = 0; y < terrain->height; y++)
	{
		for (x=0, xp=0; x<terrain->width*3; x+=3, xp++)
		{
			p->setPen(Qt::black);
			p->drawPoint(xp, y);
		}
	} 
  terrain_size = MAX (terrain->width, terrain->height);
  pixbuf_size = MIN (terrain->width, terrain->height);
  y_scale = terrain->y_scale_factor * terrain_size;

  /* camera_y = terrain_size * 0.75; */
  camera_y = terrain_size * ((elevation + 0.5) + terrain->camera_height_factor);
  camera_z = -terrain_size * 1.5;

  if (do_tile) 
    {
      zoom = pixbuf_size * 0.5;

      half_width = terrain->width;
      half_height = terrain->height;

      lim_x = terrain->width * 2;
      lim_y = terrain->height * 2;
    }
  else
    {
      zoom = pixbuf_size * 1.0;

      half_width = terrain->width * 0.5;
      half_height = terrain->height * 0.5;

      lim_x = terrain->width;
      lim_y = terrain->height;
    }

  /* Use the offsets to center the plot onscreen. */
  scrn_offset_x = terrain->width / 2;
  /* scrn_offset_y = -pixbuf->height / 8 +
   *   pixbuf->height / 2 + zoom * (camera_y - 0.5 * y_scale) / camera_z;
   */
  scrn_offset_y =
    terrain->height * 0.5 + zoom * (camera_y - 0.5 * y_scale) / camera_z;

  for (y = 0; y + 1 < lim_y; y++)
    {
      int   x;
      int   pos;
      float coord_x_1, coord_y_1, coord_z_1, coord_y_2;
      int   temp_x_1, temp_y_1;
      int   temp_x_2, temp_y_2;

      pos = y%terrain->height * terrain->width;

      coord_x_1 = -half_width;
      coord_y_1 = terrain->heightfield[pos];
      if (terrain->do_filled_sea && coord_y_1 < terrain->sealevel)
        coord_y_1 = terrain->sealevel;
      coord_y_1 *= y_scale;
      coord_z_1 = half_height - y;
      temp_x_1 = zoom * coord_x_1 / (coord_z_1 - camera_z);
      temp_y_1 = zoom * (coord_y_1 - camera_y) / (coord_z_1 - camera_z);

      /* Required to tile correctly */
      if (y % terrain->height + 1 < terrain->height)
        coord_y_2 = terrain->heightfield[pos + terrain->width];
      else 
        {
          int yoff = terrain->height - y % terrain->height - 1;
          coord_y_2 = terrain->heightfield[yoff * terrain->width];
        }
      if (terrain->do_filled_sea && coord_y_2 < terrain->sealevel)
        coord_y_2 = terrain->sealevel;
      coord_y_2 *= y_scale;
      temp_x_2 = zoom * coord_x_1 / ((coord_z_1 - 1) - camera_z);
      temp_y_2 = zoom * (coord_y_2 - camera_y) / ((coord_z_1 - 1) - camera_z);

      for (x = 0; x + 1 < lim_x; x++)
        {
          int     temp_x_3, temp_y_3;
          int     temp_x_4, temp_y_4;
          float   coord_y_3, coord_y_4;
          int     value;
          GdkPoint pts[3];

	  /* Simple fix for tiling edges -> skip border pixel */
	  if (do_tile && x == terrain->width-1)
            x++;

          pos = y%terrain->height * terrain->width + x%terrain->width;

          coord_x_1 = x - half_width;

          coord_y_3 = terrain->heightfield[pos + 1];
          if (terrain->do_filled_sea && coord_y_3 < terrain->sealevel)
            coord_y_3 = terrain->sealevel;
          coord_y_3 *= y_scale;
          temp_x_3 = zoom * (coord_x_1 + 1) / (coord_z_1 - camera_z);
          temp_y_3 = zoom * (coord_y_3 - camera_y) / (coord_z_1 - camera_z);

          coord_y_4 = terrain->heightfield[pos + terrain->width + 1];
          if (terrain->do_filled_sea && coord_y_4 < terrain->sealevel)
            coord_y_4 = terrain->sealevel;
          coord_y_4 *= y_scale;
          temp_x_4 = zoom * (coord_x_1 + 1) / ((coord_z_1 - 1) - camera_z);
          temp_y_4 = zoom * (coord_y_4 - camera_y) / ((coord_z_1 - 1) - camera_z);

          value = ((terrain->heightfield[pos] * 255.0) + 0.5);
          value = MAX (MIN (value, 255), 0) * 3;

		  p->setPen(QColor(col->colmap[value], col->colmap[value + 1], col->colmap[value + 2]));
          //t_pixbuf_set_fore (pixbuf, palette[value], palette[value + 1], palette[value + 2]);

          pts[0].x = scrn_offset_x + temp_x_1;
          pts[0].y = scrn_offset_y - temp_y_1;
          pts[1].x = scrn_offset_x + temp_x_2;
          pts[1].y = scrn_offset_y - temp_y_2;
          pts[2].x = scrn_offset_x + temp_x_3;
          pts[2].y = scrn_offset_y - temp_y_3;

          fill_triangle(p, pts);

          pts[0].x = scrn_offset_x + temp_x_4;
          pts[0].y = scrn_offset_y - temp_y_4;

          fill_triangle(p, pts);

          temp_x_1 = temp_x_3;
          temp_y_1 = temp_y_3;
          temp_x_2 = temp_x_4;
          temp_y_2 = temp_y_4;
        }
    }
}
 
void TerrainView::drawHistogram( QPainter *p )
{
	int ix,iy,idx, x, i;
	int screenx, screeny;
	float *hf, tmp;
	float hmin,hmax,scalefac;
	long *hist;
	long hf_max;
	double sfac;

	if (histOK == false)
		return;
	histOK = false;
	p->setBackgroundColor(Qt::white);
	QFont f( "arial", 10, QFont::Bold );
	screenx = terrain->width;
	screeny = terrain->height;
	p->setFont( f );
	p->setPen( Qt::black );
	p->setWindow(0, 0, screenx, screeny);		/* defines coordinate system */

	
	hist = new long[screeny];
	for (i=0; i<screeny; i++)
		hist[i] = 0;

	hf = terrain->heightfield;

	hmin = (float)0.0;
	hmax = (float)0.0;
	for (iy = 0; iy<screeny; iy++)
	{
		for (ix = 0; ix<screenx; ix++)
		{
			tmp = (double)(hf[((iy) * screenx) + ix]);
			if (tmp > hmax) hmax = tmp;
			if (tmp < hmin) hmin = tmp;
		}
	}
	if (hmin == hmax)
	{
		return;
	}

	scalefac = 0.999999/(hmax - hmin);

	/* -------- generate histogram -------- */

	for (iy = 0; iy<screeny; iy++)
	{
		for (ix = 0; ix<screenx; ix++)
		{
			tmp = ((hf[((iy) * screenx) + ix]) - hmin)*scalefac; /* normalize 0..1 */
			if ((tmp > 1.0)||(tmp < 0))
			{
				return;
			}	
			idx = (int)(screeny*tmp);
			if (idx >= screeny)
			{
				return;
			}
			hist[idx]++;   /* increment this histogram bin */
		}
	}
	
	hf_max = 0;
	for (i=0; i<screenx; i++)
	{
		if (hist[i] > hf_max)
			hf_max = hist[i];
	}
	if (hf_max == 0)
	{
		return;
	}

	sfac = (float)screeny / (float)hf_max;

	for(x=0; x<screenx; x++)
	{
		p->drawLine (x, screeny-hist[x]*sfac, x, screeny);
	}
}

void TerrainView::drawTransform(QPainter *p)
{
	int i, x, xp, y;
	int sea_line_1, sea_line_2, sea_line_3;

	if (trans == NULL)
		return;

	for (y = 0; y < 102; y++)
	{
		for (x=0, xp=0; x<250*3; x+=3, xp++)
		{
			p->setPen(QColor(255, 255, 255));
			p->drawPoint(xp, y);
		}
	} 

	sea_line_1 = (int)rint(trans->sea_threshold * 100.0);
	sea_line_2 = (int)rint(trans->sea_depth * 100.0);
	sea_line_3 = (int)rint(trans->sea_threshold * trans->sea_dropoff * 100.0);

	p->setPen(QColor(0, 0, 255));
	p->drawLine(1, 100 - sea_line_1, 100, 100 - sea_line_1);
	p->drawLine(149, 100 - sea_line_2, 248, 100 - sea_line_2);
	draw_arrow(p, 104, 100 - sea_line_1, 145, 100 - sea_line_2);

	p->setPen(QColor(192, 192, 192));
	p->drawLine(149 + sea_line_3, 1, 149 + sea_line_3, 100);

	p->setPen(QColor(0, 0, 0));
	p->drawRect(0, 0, 101, 101);
	p->drawRect(148, 0, 249, 101);
	for (i = 0; i < 100; i++)
		p->drawPoint(i + 1, 100 - i);

	for (i = 0; i < 100; i++)
    {
		float y;

		y = transform ((i + 0.5) / 100.0, trans->sea_threshold, trans->sea_depth, trans->sea_dropoff, trans->above_power, trans->below_power) * 100.0;
		p->drawPoint(i + 150, 100 - ((int)(y + 0.5)));
    } 
}

//
// Calls the drawing function as specified by the radio buttons.
//
void TerrainView::drawIt( QPainter *p )
{
	switch (drawindex)
	{
		case 0:
			drawColorWheel(p);
			break;
		case 1:
			drawPlane(p);
			break;
		case 2:
			draw_2d_contour(p);
			break;
		case 3:
			draw_3d_wire(p);
			break;
		case 4:
			draw_3d_height(p);
			break;
		case 5:
			draw_3d_light(p);
			break;
		case 6:
			drawHistogram(p);
			break;
		case 8:
			drawTransform(p);
			break;
	}
	dirty = false;
}

//
// Called when the widget needs to be updated.
//

void TerrainView::paintEvent( QPaintEvent * )
{
	QPainter paint( this );
	if (terraOK)
	{
		t_terrain_paint();
		drawIt( &paint );
	} else {
		if (trans != NULL)
		{
			drawindex = 8;
			drawIt(&paint);
		}
		else
		{
			drawindex = 0;
			drawIt( &paint );
		}
	}
}

void TerrainView::t_terrain_paint()
{
	if (terrain == NULL || terrain->width == 0 || terrain->height == 0)
		return;
   
	switch (model)
	{
		case T_VIEW_2D_PLANE: 
			drawindex = 1;
			break;
		case T_VIEW_2D_CONTOUR: 
			drawindex = 2;
			break;
		case T_VIEW_3D_WIRE: 
			drawindex = 3;
			break;
		case T_VIEW_3D_HEIGHT: 
			drawindex = 4;
			break;
		case T_VIEW_3D_LIGHT: 
			drawindex = 5;
			break;
		case T_VIEW_HISTOGRAM: 
			drawindex = 6;
			break;
		case T_VIEW_TRANSFORM: 
			drawindex = 8;
			break;
	}
}

void TerrainView::mousePressEvent(QMouseEvent *e)
{
}

void TerrainView::mouseReleaseEvent(QMouseEvent * e)
{
	switch (mouse_mode)
	{
		case T_MOUSE_CLICK:
			emit mouseCLICKED();
			releaseMouse();
			break;
	}
}

//
// Called when the widget has been resized.
// Moves the button group to the upper right corner
// of the widget.

void TerrainView::resizeEvent( QResizeEvent * )
{
//	int t=0;

//	if ((width() != terrain->width) || (height() != terrain->height))
//	{
//		t = t + 1;
//	}
}

void TerrainView::UpdateBuf()
{
	int x, y, c;
	int c0, c1, c2;
	int count; 
	int hf_pos;
   
	for (y=0; y<terrain->height; y++)
	{
//         hf_pos = y * terrain->width / 400 * terrain->height;
		hf_pos = y * terrain->height / terrain->height * terrain->width;
		count = 0; 
		for (x=0; x<terrain->width*3; x+=3)
		{
			c = 0;
            c = terrain->heightfield[hf_pos] * 256;
            c = MAX (MIN (c, 255), 0) * 3;
            c0 = col->colmap[c];
            c1 = col->colmap[c+1];
            c2 = col->colmap[c+2];
            if (((c0 >= 256) || (c1 >= 256) || (c2 >= 256)) ||
               ((c0 < 0) || (c1 < 0) || (c2 < 0)))
            {
               c0 = 0;
               c1 = 0;
               c2 = 0;
            }
            raster[(y*(terrain->width*3))+x] = c0;
            raster[(y*(terrain->width*3))+(x+1)] = c1;
            raster[(y*(terrain->width*3))+(x+2)] = c2;
         //      count += terrain->width;
         //      while (count >= terrain->width)
         //      {
         //        count -= terrain->width;
            hf_pos++;
         //      }
		}
	}
}

void TerrainView::terrain_print()
{
    QPrinter *printer;

	printer = new QPrinter;
#ifndef QT_NO_PRINTER
    if ( printer->setup( this ) ) {
        QPainter paint;
        if ( !paint.begin( printer ) )
            return;
        drawIt( &paint );
    }
#endif
	delete printer;
}

void TerrainView::t_terrain_view_setMouseMode(TMouseMode mm)
{
	mouse_mode = mm;
}

/**************************************************************/

void TerrainView::t_terrain_view_set_terrain(TTerrain *terra)
{
	int  memcnt;

	if (terra == NULL)
		return;

	terrain = terra;
	if (raster != NULL)
	{
		delete raster;
		memcnt = ((terrain->width * terrain->height) * 3);
		raster = new int[memcnt];
	} else {
		memcnt = ((terrain->width * terrain->height) * 3);
		raster = new int[memcnt];
	}
    col->colormap_new(colormap, terrain->sealevel);
	terraOK = true;
	contour_dirty = true;
	dirty = true;

//	update();
	repaint();
}

TViewModel TerrainView::t_terrain_view_get_model()
{
	return model;
}

void TerrainView::t_terrain_view_set_model(TViewModel mdl)
{
	if (model != mdl)
    {
		model = mdl;
		dirty = true;
		contour_dirty = true;
		if ((model == T_VIEW_HISTOGRAM) || (model == T_VIEW_HISTOGRAM2))
			histOK = true;
		if (model == T_VIEW_HISTOGRAM2)
			hist2OK = true;

//      t_terrain_contour_list_free (view->contour_lines);
//      view->contour_lines = NULL;

//      if (view->model == T_VIEW_2D_PLANE)
//        for (i = 0; i < view->terrain->objects->len; i++)
//          on_object_added (GTK_OBJECT (view->terrain), i, GTK_WIDGET (view));
//      else
//        t_canvas_clear_objects (T_CANVAS (view));
	}
}

void TerrainView::t_terrain_draw_transform(float threshold, float depth, float dropoff, float above, float below)
{
	trans->sea_threshold = threshold;
	trans->sea_depth = depth;
	trans->sea_dropoff = dropoff;
	trans->above_power = above;
	trans->below_power = below;

	repaint();
}

void TerrainView::t_terrain_view_set_colormap(TColormapType  colmap)
{
  if (colormap != colmap)
    {
      colormap = colmap;
    }
}
 
void TerrainView::t_terrain_view_set_crosshair(float x, float y)
{
  if (x == crosshair_x && y == crosshair_y)
    return;

  crosshair_x = x;
  crosshair_y = y;
  crosshair = true;
}

void TerrainView::t_terrain_view_unset_crosshair()
{
  if (crosshair == false)
    return;

  crosshair = false;
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/