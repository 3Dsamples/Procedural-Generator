/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genspectraldlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genspectraldlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qcheckbox.h>

#include "genSpectralDlgImpl.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

genSpectralDlgImpl::genSpectralDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : genSpectralDlg( parent, name, modal, fl )
{
  cbtf = false;
  cbns = false;
  cb_trigofuncs->setChecked(cbtf);
  cb_newseed->setChecked(cbns);
}

/*  
 *  Destroys the object and frees any allocated resources
 */
genSpectralDlgImpl::~genSpectralDlgImpl()
{
}

void genSpectralDlgImpl::trigoClicked()
{
	cbtf = cb_trigofuncs->isChecked();
}

void genSpectralDlgImpl::seedClicked()
{
	cbns = cb_newseed->isChecked();
}
/***********************************************************************************************************************
 * Version history:
 *  * 29-12-2004
 *   - created
 *
 ***********************************************************************************************************************/