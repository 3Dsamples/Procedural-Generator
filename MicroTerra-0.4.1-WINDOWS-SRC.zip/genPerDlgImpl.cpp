/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genperdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genperdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qcheckbox.h>

#include "genPerDlgImpl.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

genPerDlgImpl::genPerDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : genPerDlg( parent, name, modal, fl )
{
}

/*  
 *  Destroys the object and frees any allocated resources
 */
genPerDlgImpl::~genPerDlgImpl()
{
}

void genPerDlgImpl::seedClicked()
{
	cbns = new_seed->isChecked();
}

void genPerDlgImpl::firstClicked()
{
	cbfi = first->isChecked();
}

void genPerDlgImpl::secondClicked()
{
	cbse = second->isChecked();
}

void genPerDlgImpl::thirdClicked()
{
	cbth = third->isChecked();
}

void genPerDlgImpl::fourthClicked()
{
	cbfo = fourth->isChecked();
}
/***********************************************************************************************************************
 * Version history:
 *  * 29-12-2002
 *   - created
 *
 ***********************************************************************************************************************/