/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gaussianhilldlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gaussianhilldlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "GaussianHillDlg.h"

#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a GaussianHillDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
GaussianHillDlg::GaussianHillDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "GaussianHillDlg" );
    resize( 495, 350 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Gaussian Hill" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 175, 305, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 285, 498, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 11, 125, 270 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 350, 270 ) ); 
    GroupBox2->setTitle( tr( "Options" ) );

    Line2 = new QFrame( GroupBox2, "Line2" );
    Line2->setGeometry( QRect( 4, 110, 341, 16 ) ); 
    Line2->setProperty( "frameShape", (int)QFrame::HLine );
    Line2->setFrameShadow( QFrame::Sunken );
    Line2->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line2->setProperty( "frameShape", (int)QFrame::HLine );

    center_x = new QSlider( GroupBox2, "center_x" );
    center_x->setGeometry( QRect( 135, 20, 150, 20 ) ); 
    center_x->setMaxValue( 100 );
    center_x->setPageStep( 0 );
    center_x->setValue( 50 );
    center_x->setOrientation( QSlider::Horizontal );
    center_x->setTickmarks( QSlider::NoMarks );

    center_y = new QSlider( GroupBox2, "center_y" );
    center_y->setGeometry( QRect( 135, 50, 150, 20 ) ); 
    center_y->setMaxValue( 100 );
    center_y->setPageStep( 0 );
    center_y->setValue( 50 );
    center_y->setOrientation( QSlider::Horizontal );
    center_y->setTickmarks( QSlider::NoMarks );

    hill_radius = new QSlider( GroupBox2, "hill_radius" );
    hill_radius->setGeometry( QRect( 135, 80, 150, 20 ) ); 
    hill_radius->setMinValue( 0 );
    hill_radius->setMaxValue( 100 );
    hill_radius->setPageStep( 0 );
    hill_radius->setValue( 50 );
    hill_radius->setOrientation( QSlider::Horizontal );
    hill_radius->setTickmarks( QSlider::NoMarks );

    hill_scale_factor = new QSlider( GroupBox2, "hill_scale_factor" );
    hill_scale_factor->setGeometry( QRect( 135, 130, 150, 20 ) ); 
    hill_scale_factor->setMaxValue( 200 );
    hill_scale_factor->setPageStep( 0 );
    hill_scale_factor->setValue( 150 );
    hill_scale_factor->setOrientation( QSlider::Horizontal );
    hill_scale_factor->setTickmarks( QSlider::NoMarks );

    hill_radius_factor = new QSlider( GroupBox2, "hill_radius_factor" );
    hill_radius_factor->setGeometry( QRect( 135, 165, 150, 20 ) ); 
    hill_radius_factor->setMinValue( 1 );
    hill_radius_factor->setMaxValue( 299 );
    hill_radius_factor->setPageStep( 0 );
    hill_radius_factor->setValue( 33 );
    hill_radius_factor->setOrientation( QSlider::Horizontal );

    hill_smoothing_factor = new QSlider( GroupBox2, "hill_smoothing_factor" );
    hill_smoothing_factor->setGeometry( QRect( 135, 201, 150, 20 ) ); 
    hill_smoothing_factor->setMinValue( 0 );
    hill_smoothing_factor->setMaxValue( 100 );
    hill_smoothing_factor->setPageStep( 0 );
    hill_smoothing_factor->setValue( 50 );
    hill_smoothing_factor->setOrientation( QSlider::Horizontal );

    hill_delta_scale_factor = new QSlider( GroupBox2, "hill_delta_scale_factor" );
    hill_delta_scale_factor->setGeometry( QRect( 135, 235, 150, 20 ) ); 
    hill_delta_scale_factor->setMinValue( 0 );
    hill_delta_scale_factor->setMaxValue( 50 );
    hill_delta_scale_factor->setPageStep( 0 );
    hill_delta_scale_factor->setValue( 10 );
    hill_delta_scale_factor->setOrientation( QSlider::Horizontal );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 295, 18, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "0.50" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    slid2 = new QLabel( GroupBox2, "slid2" );
    slid2->setGeometry( QRect( 295, 46, 35, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2_font.setBold( TRUE );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "0.50" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

    slid3 = new QLabel( GroupBox2, "slid3" );
    slid3->setGeometry( QRect( 295, 80, 35, 17 ) ); 
    QFont slid3_font(  slid3->font() );
    slid3_font.setPointSize( 10 );
    slid3_font.setBold( TRUE );
    slid3->setFont( slid3_font ); 
    slid3->setText( tr( "0.50" ) );
    slid3->setAlignment( int( QLabel::AlignCenter ) );

    slid4 = new QLabel( GroupBox2, "slid4" );
    slid4->setGeometry( QRect( 295, 129, 35, 20 ) ); 
    QFont slid4_font(  slid4->font() );
    slid4_font.setPointSize( 10 );
    slid4_font.setBold( TRUE );
    slid4->setFont( slid4_font ); 
    slid4->setText( tr( "1.50" ) );
    slid4->setAlignment( int( QLabel::AlignCenter ) );

    slid5 = new QLabel( GroupBox2, "slid5" );
    slid5->setGeometry( QRect( 295, 163, 35, 20 ) ); 
    QFont slid5_font(  slid5->font() );
    slid5_font.setPointSize( 10 );
    slid5_font.setBold( TRUE );
    slid5->setFont( slid5_font ); 
    slid5->setText( tr( "0.33" ) );
    slid5->setAlignment( int( QLabel::AlignCenter ) );

    slid6 = new QLabel( GroupBox2, "slid6" );
    slid6->setGeometry( QRect( 295, 200, 35, 20 ) ); 
    QFont slid6_font(  slid6->font() );
    slid6_font.setPointSize( 10 );
    slid6_font.setBold( TRUE );
    slid6->setFont( slid6_font ); 
    slid6->setText( tr( "0.50" ) );
    slid6->setAlignment( int( QLabel::AlignCenter ) );

    slid7 = new QLabel( GroupBox2, "slid7" );
    slid7->setGeometry( QRect( 295, 234, 35, 20 ) ); 
    QFont slid7_font(  slid7->font() );
    slid7_font.setPointSize( 10 );
    slid7_font.setBold( TRUE );
    slid7->setFont( slid7_font ); 
    slid7->setText( tr( "0.10" ) );
    slid7->setAlignment( int( QLabel::AlignCenter ) );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 21, 60, 20 ) ); 
    lbl1->setText( tr( "Center X" ) );
    lbl1->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl2 = new QLabel( GroupBox2, "lbl2" );
    lbl2->setGeometry( QRect( 10, 50, 60, 17 ) ); 
    lbl2->setText( tr( "Center Y" ) );
    lbl2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl3 = new QLabel( GroupBox2, "lbl3" );
    lbl3->setGeometry( QRect( 10, 80, 110, 20 ) ); 
    lbl3->setText( tr( "Hill radius" ) );

    lbl4 = new QLabel( GroupBox2, "lbl4" );
    lbl4->setGeometry( QRect( 10, 130, 85, 20 ) ); 
    lbl4->setText( tr( "Scale factor" ) );

    lbl5 = new QLabel( GroupBox2, "lbl5" );
    lbl5->setGeometry( QRect( 10, 165, 85, 20 ) ); 
    lbl5->setText( tr( "Radius factor" ) );

    lbl6 = new QLabel( GroupBox2, "lbl6" );
    lbl6->setGeometry( QRect( 10, 201, 90, 20 ) ); 
    lbl6->setText( tr( "Smoothing factor" ) );

    lbl7 = new QLabel( GroupBox2, "lbl7" );
    lbl7->setGeometry( QRect( 10, 235, 110, 20 ) ); 
    lbl7->setText( tr( "Delta scale factor" ) );

	terra = NULL;

    // signals and slots connections
    connect( center_x, SIGNAL(valueChanged(int)), this, SLOT(setCenterX(int)) );
    connect( center_y, SIGNAL(valueChanged(int)), this, SLOT(setCenterY(int)) );
    connect( hill_radius, SIGNAL(valueChanged(int)), this, SLOT(setRadius(int)) );
    connect( hill_scale_factor, SIGNAL(valueChanged(int)), this, SLOT(setScale(int)) );
    connect( hill_radius_factor, SIGNAL(valueChanged(int)), this, SLOT(setRadfac(int)) );
    connect( hill_smoothing_factor, SIGNAL(valueChanged(int)), this, SLOT(setSmooth(int)) );
    connect( hill_delta_scale_factor, SIGNAL(valueChanged(int)), this, SLOT(setDelta(int)) );
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
GaussianHillDlg::~GaussianHillDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool GaussianHillDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont slid1_font(  slid1->font() );
	slid1_font.setPointSize( 10 );
	slid1_font.setBold( TRUE );
	slid1->setFont( slid1_font ); 
	QFont slid2_font(  slid2->font() );
	slid2_font.setPointSize( 10 );
	slid2_font.setBold( TRUE );
	slid2->setFont( slid2_font ); 
	QFont slid3_font(  slid3->font() );
	slid3_font.setPointSize( 10 );
	slid3_font.setBold( TRUE );
	slid3->setFont( slid3_font ); 
	QFont slid4_font(  slid4->font() );
	slid4_font.setPointSize( 10 );
	slid4_font.setBold( TRUE );
	slid4->setFont( slid4_font ); 
	QFont slid5_font(  slid5->font() );
	slid5_font.setPointSize( 10 );
	slid5_font.setBold( TRUE );
	slid5->setFont( slid5_font ); 
	QFont slid6_font(  slid6->font() );
	slid6_font.setPointSize( 10 );
	slid6_font.setBold( TRUE );
	slid6->setFont( slid6_font ); 
	QFont slid7_font(  slid7->font() );
	slid7_font.setPointSize( 10 );
	slid7_font.setBold( TRUE );
	slid7->setFont( slid7_font ); 
    }
    return ret;
}

void GaussianHillDlg::setCenterX(int value)
{
}

void GaussianHillDlg::setCenterY(int value)
{
}

void GaussianHillDlg::setRadius(int value)
{
}

void GaussianHillDlg::setScale(int value)
{
}

void GaussianHillDlg::setRadfac(int value)
{
}

void GaussianHillDlg::setSmooth(int value)
{
}

void GaussianHillDlg::setDelta(int value)
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - 
 *
 ***********************************************************************************************************************/