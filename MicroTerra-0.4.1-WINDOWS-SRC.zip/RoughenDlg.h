/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: roughendlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: roughendlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef ROUGHENDLG_H
#define ROUGHENDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;

class RoughenDlg : public QDialog
{ 
    Q_OBJECT

public:
    RoughenDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~RoughenDlg();

    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QLabel* slid1;
    QSlider* roughen_factor;
    QCheckBox* roughen_big;
    QFrame* Line1;
    QPushButton* OK;
    QPushButton* CANCEL;
	TTerrain *terra;

public slots:
	virtual void setFactor(int value);
	virtual void bigClicked();

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // ROUGHENDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - created
 *
 ***********************************************************************************************************************/