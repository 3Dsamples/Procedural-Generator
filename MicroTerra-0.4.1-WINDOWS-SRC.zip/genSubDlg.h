/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gensubdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gensubdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENSUBDLG_H
#define GENSUBDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QComboBox;
class QFrame;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QSpinBox;

class genSubDlg : public QDialog
{ 
    Q_OBJECT

public:
    genSubDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~genSubDlg();

    QPushButton* pb_generate;
    QPushButton* pb_cancel;
    QGroupBox* GroupBox1;
    QLabel* seedlbl;
    QSpinBox* sb_scale;
    QLabel* tl_scalefac;
    QLineEdit* le_seed;
    QCheckBox* cb_newseed;
    QLabel* tl_submethod;
    QComboBox* ComboBox1;
    QSpinBox* sb_size;
    QLabel* tl_size;
    QFrame* Line1;

public slots:
    virtual void seedClicked();

protected:
    QHBoxLayout* Layout1;
};

#endif // GENSUBDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-01-2003
 *   - 
 *
 ***********************************************************************************************************************/