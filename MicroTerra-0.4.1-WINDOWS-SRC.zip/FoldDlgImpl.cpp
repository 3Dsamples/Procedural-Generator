/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: folddlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: folddlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "FoldDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

FoldDlgImpl::FoldDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : FoldDlg( parent, name, modal, fl )
{
	offset = (float)0.10;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
FoldDlgImpl::~FoldDlgImpl()
{
}

void FoldDlgImpl::update_preview()
{
	TTerrain *clone;
	int       margin;

	clone = t_terrain_clone(terra);
	margin = offset * MIN(clone->width, clone->height);
	t_terrain_fold(clone, margin);
	PreView->t_terrain_view_set_terrain(clone);
}

void FoldDlgImpl::setOffset(int value)
{
	char buf[15];

	offset = (float)(value/100.0);
	sprintf(buf,"%1.2f", offset);
	slid1->setText((char *)buf);
	update_preview();
}
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/