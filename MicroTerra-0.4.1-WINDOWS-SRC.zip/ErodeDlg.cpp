/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: erodedlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: erodedlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "ErodeDlg.h"

#include <qcheckbox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qradiobutton.h>
#include <qslider.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a ErodeDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
ErodeDlg::ErodeDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "ErodeDlg" );
    resize( 497, 482 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Erode" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 175, 440, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 420, 498, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 403 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    update_preview = new QPushButton(GroupBox1, "update_preview");
    update_preview->setGeometry(QRect(35, 140, 50, 20)); 
    update_preview->setText(tr("Update"));

    GroupBox3 = new QGroupBox( this, "GroupBox3" );
    GroupBox3->setGeometry( QRect( 140, 283, 350, 130 ) ); 
    GroupBox3->setTitle( tr( "Flowmap Controls" ) );

    Line6 = new QFrame( GroupBox3, "Line6" );
    Line6->setGeometry( QRect( 4, 77, 341, 16 ) ); 
    Line6->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );

    erode_sealevel = new QCheckBox( GroupBox3, "erode_sealevel" );
    erode_sealevel->setGeometry( QRect( 10, 100, 120, 20 ) ); 
    erode_sealevel->setText( tr( "Observe sealevel" ) );

    erode_multiple = new QRadioButton( GroupBox3, "erode_multiple" );
    erode_multiple->setGeometry( QRect( 10, 50, 155, 20 ) ); 
    erode_multiple->setText( tr( "Multiple flow direction" ) );

    erode_single = new QRadioButton( GroupBox3, "erode_single" );
    erode_single->setGeometry( QRect( 10, 20, 155, 20 ) ); 
    erode_single->setText( tr( "Single flow direction" ) );
    erode_single->setChecked( TRUE );

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 350, 270 ) ); 
    GroupBox2->setTitle( tr( "Erosion Parameters" ) );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 20, 125, 20 ) ); 
    lbl1->setText( tr( "Number of iterations" ) );
    lbl1->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl2 = new QLabel( GroupBox2, "lbl2" );
    lbl2->setGeometry( QRect( 10, 50, 125, 17 ) ); 
    lbl2->setText( tr( "Maximum flowmap age" ) );
    lbl2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl3 = new QLabel( GroupBox2, "lbl3" );
    lbl3->setGeometry( QRect( 10, 80, 125, 20 ) ); 
    lbl3->setText( tr( "Age flowmap N times" ) );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 305, 18, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "100" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    slid2 = new QLabel( GroupBox2, "slid2" );
    slid2->setGeometry( QRect( 305, 46, 35, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2_font.setBold( TRUE );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "10" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

    slid3 = new QLabel( GroupBox2, "slid3" );
    slid3->setGeometry( QRect( 305, 80, 35, 17 ) ); 
    QFont slid3_font(  slid3->font() );
    slid3_font.setPointSize( 10 );
    slid3_font.setBold( TRUE );
    slid3->setFont( slid3_font ); 
    slid3->setText( tr( "0" ) );
    slid3->setAlignment( int( QLabel::AlignCenter ) );

    erode_iterations = new QSlider( GroupBox2, "erode_iterations" );
    erode_iterations->setGeometry( QRect( 145, 20, 150, 20 ) ); 
    erode_iterations->setMinValue( 1 );
    erode_iterations->setMaxValue( 500 );
    erode_iterations->setValue( 100 );
    erode_iterations->setOrientation( QSlider::Horizontal );
    erode_iterations->setTickmarks( QSlider::NoMarks );

    max_flowmap_age = new QSlider( GroupBox2, "max_flowmap_age" );
    max_flowmap_age->setGeometry( QRect( 145, 50, 150, 20 ) ); 
    max_flowmap_age->setMinValue( 1 );
    max_flowmap_age->setMaxValue( 100 );
    max_flowmap_age->setValue( 10 );
    max_flowmap_age->setOrientation( QSlider::Horizontal );
    max_flowmap_age->setTickmarks( QSlider::NoMarks );

    age_flowmap_times = new QSlider( GroupBox2, "age_flowmap_times" );
    age_flowmap_times->setGeometry( QRect( 145, 80, 150, 20 ) ); 
    age_flowmap_times->setMinValue( 0 );
    age_flowmap_times->setMaxValue( 10 );
    age_flowmap_times->setValue( 0 );
    age_flowmap_times->setOrientation( QSlider::Horizontal );
    age_flowmap_times->setTickmarks( QSlider::NoMarks );

    erode_save_flowmap_name = new QLineEdit( GroupBox2, "erode_save_flowmap_name" );
    erode_save_flowmap_name->setGeometry( QRect( 130, 170, 200, 22 ) ); 
    erode_save_flowmap_name->setText( tr( "%s_flowmap_%d.tga" ) );

    lbl5 = new QLabel( GroupBox2, "lbl5" );
    lbl5->setGeometry( QRect( 10, 230, 75, 20 ) ); 
    lbl5->setText( tr( "Frame count" ) );

    erode_save_anim_name = new QLineEdit( GroupBox2, "erode_save_anim_name" );
    erode_save_anim_name->setGeometry( QRect( 130, 201, 200, 22 ) ); 
    erode_save_anim_name->setText( tr( "%s_erode_%d.tga" ) );

    erode_save_anim = new QCheckBox( GroupBox2, "erode_save_anim" );
    erode_save_anim->setGeometry( QRect( 10, 200, 110, 20 ) ); 
    erode_save_anim->setText( tr( "Save animation" ) );
    erode_save_anim->setChecked( FALSE );

    erode_save_flowmap = new QCheckBox( GroupBox2, "erode_save_flowmap" );
    erode_save_flowmap->setGeometry( QRect( 10, 170, 110, 20 ) ); 
    erode_save_flowmap->setText( tr( "Save flowmaps" ) );

    erode_trim = new QCheckBox( GroupBox2, "erode_trim" );
    erode_trim->setGeometry( QRect( 10, 140, 120, 20 ) ); 
    erode_trim->setText( tr( "Trim local peaks" ) );
    erode_trim->setChecked( TRUE );

    erode_threshold = new QSlider( GroupBox2, "erode_threshold" );
    erode_threshold->setGeometry( QRect( 145, 110, 150, 20 ) ); 
    erode_threshold->setMinValue( 10 );
    erode_threshold->setMaxValue( 100 );
    erode_threshold->setValue( 95 );
    erode_threshold->setOrientation( QSlider::Horizontal );
    erode_threshold->setTickmarks( QSlider::NoMarks );

    lbl4 = new QLabel( GroupBox2, "lbl4" );
    lbl4->setGeometry( QRect( 10, 110, 130, 20 ) ); 
    lbl4->setText( tr( "Max elevation to erode" ) );

    slid4 = new QLabel( GroupBox2, "slid4" );
    slid4->setGeometry( QRect( 305, 109, 35, 20 ) ); 
    QFont slid4_font(  slid4->font() );
    slid4_font.setPointSize( 10 );
    slid4_font.setBold( TRUE );
    slid4->setFont( slid4_font ); 
    slid4->setText( tr( "0.95" ) );
    slid4->setAlignment( int( QLabel::AlignCenter ) );

    erode_frame_count = new QSpinBox( GroupBox2, "erode_frame_count" );
    erode_frame_count->setGeometry( QRect( 90, 230, 58, 20 ) ); 
    erode_frame_count->setButtonSymbols( QSpinBox::PlusMinus );
    erode_frame_count->setMaxValue( 100 );
    erode_frame_count->setMinValue( 1 );
    erode_frame_count->setValue( 20 );

	terra = NULL;

    // signals and slots connections
    connect( update_preview, SIGNAL( clicked() ), this, SLOT( update_view() ) );
    connect( erode_iterations, SIGNAL(valueChanged(int)), this, SLOT(setIteration(int)) );
    connect( max_flowmap_age, SIGNAL(valueChanged(int)), this, SLOT(setMaxFlowmapAge(int)) );
    connect( age_flowmap_times, SIGNAL(valueChanged(int)), this, SLOT(setAgeFlowmapTimes(int)) );
    connect( erode_threshold, SIGNAL(valueChanged(int)), this, SLOT(setThreshold(int)) );
    connect( erode_trim, SIGNAL(clicked()), this, SLOT(trimClicked()));
    connect( erode_save_flowmap, SIGNAL(clicked()), this, SLOT(saveflowmapClicked()));
    connect( erode_save_anim, SIGNAL(clicked()), this, SLOT(saveanimClicked()));
    connect( erode_frame_count, SIGNAL(valueChanged(int)), this, SLOT(framecountChanged()) );
    connect( erode_single, SIGNAL( clicked() ), this, SLOT( single_Changed() ) );
    connect( erode_multiple, SIGNAL( clicked() ), this, SLOT( multiple_Changed() ) );
    connect( erode_sealevel, SIGNAL(clicked()), this, SLOT(sealevelClicked()));
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
ErodeDlg::~ErodeDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool ErodeDlg::event(QEvent* ev)
{
    bool ret = QDialog::event(ev); 
    
	if (ev->type() == QEvent::ApplicationFontChange)
	{
		QFont slid1_font(  slid1->font() );
		slid1_font.setPointSize( 10 );
		slid1_font.setBold( TRUE );
		slid1->setFont( slid1_font ); 
		QFont slid2_font(  slid2->font() );
		slid2_font.setPointSize( 10 );
		slid2_font.setBold( TRUE );
		slid2->setFont( slid2_font ); 
		QFont slid3_font(  slid3->font() );
		slid3_font.setPointSize( 10 );
		slid3_font.setBold( TRUE );
		slid3->setFont( slid3_font ); 
		QFont slid4_font(  slid4->font() );
		slid4_font.setPointSize( 10 );
		slid4_font.setBold( TRUE );
		slid4->setFont( slid4_font ); 
    }
    return ret;
}

void ErodeDlg::update_view()
{
}

void ErodeDlg::setIteration(int value)
{
}

void ErodeDlg::setMaxFlowmapAge(int value)
{
}

void ErodeDlg::setAgeFlowmapTimes(int value)
{
}

void ErodeDlg::setThreshold(int value)
{
}

void ErodeDlg::trimClicked()
{
}

void ErodeDlg::saveflowmapClicked()
{
}

void ErodeDlg::saveanimClicked()
{
}

void ErodeDlg::framecountChanged()
{
}

void ErodeDlg::single_Changed()
{
}

void ErodeDlg::multiple_Changed()
{
}

void ErodeDlg::sealevelClicked()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - 
 *
 ***********************************************************************************************************************/