/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: writer.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: writer
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <locale.h> 
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "terrainview.h"
#include "writer.h"
#include "reader.h"        /* defines BT file header */
#include "filenameops.h"
#include "filters.h"
#include "base64.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

TWriter::TWriter()
{
}

TWriter::~TWriter()
{
}

int TWriter::t_terrain_save(TTerrain *terrain, TFileType type, char *filename)
{
	if (type == FILE_AUTO)
	{
		FilenameOps *fno = new FilenameOps();
		type = fno->filename_determine_type(filename);
		delete fno;
	}

	if (type == FILE_NATIVE)
    {
		if (filename != NULL)
			terrain->t_terrain_set_filename(filename);
		return t_terrain_save_native(terrain);
    }
	else if (type == FILE_TGA)
		return t_terrain_export_tga(terrain, filename);
	else if (type == FILE_POV)
		return t_terrain_export_pov(terrain, filename);
	else if (type == FILE_BMP)
		return t_terrain_export_bmp(terrain, filename);
	else if (type == FILE_BMP_BW)
		return t_terrain_export_bmp_bw(terrain, filename);
	else if (type == FILE_PGM)
		return t_terrain_export_pgm(terrain, filename);
	else if (type == FILE_PG8)
		return t_terrain_export_pg8(terrain, filename);
	else if (type == FILE_MAT)
		return t_terrain_export_mat(terrain, filename);
	else if (type == FILE_OCT)
		return t_terrain_export_oct(terrain, filename);
	else if (type == FILE_AC)
		return t_terrain_export_ac(terrain, filename);
	else if (type == FILE_TERRAGEN)
		return t_terrain_export_terragen(terrain, filename);
	else if (type == FILE_GRD)
		return t_terrain_export_grd(terrain, filename);
	else if (type == FILE_XYZ)
		return t_terrain_export_xyz(terrain, filename);
	else if (type == FILE_DXF)
		return t_terrain_export_dxf(terrain, filename);
	else if (type == FILE_BNA)
		return t_terrain_export_bna(terrain, filename);
	else if (type == FILE_BT)
		return t_terrain_export_bt(terrain, filename);

	return -1;
}

bool TWriter::is_saving_as_native(TFileType type, char *filename)
{
	if (type == FILE_AUTO)
	{
		FilenameOps *fno = new FilenameOps();
		type = fno->filename_determine_type(filename);
		delete fno;
	}

	return type == FILE_NATIVE;
}

void TWriter::t_terrain_get_povray_size(TTerrain *terrain, float *x, float *y, float *z)
{
	float max_size;

	max_size = MAX(terrain->width, terrain->height);

	*x = terrain->render_options.render_scale_x * terrain->width / max_size;
	*y = terrain->render_options.render_scale_y;
	*z = terrain->render_options.render_scale_z * terrain->height / max_size;
}
/*
void TWriter::heightfield_save_data(FILE *fp, float *heightfield, int width, int height)
{
	char   *encoded;
	uint32 *decoded;
	int     x, y;

	xml_pack_prop_int(node, "width", width);
	xml_pack_prop_int(node, "height", height);

	decoded = g_new (uint32, width);
	encoded = g_new (uchar, base64_encoded_length(width * 4));

	for (y = 0; y < height; y++)
    {
		uint32 *data;

		data = (uint32*) &heightfield[y * width];
		for (x = 0; x < width; x++)
			decoded[x] = GUINT32_TO_LE (data[x]);

		base64_encode ((gchar*) decoded, width * 4, encoded);
		xmlNewChild (node, NULL, "row", encoded);
    }

	g_free (encoded);
	g_free (decoded);
}

void TWriter::heightfield_save(TTerrain *terrain, FILE *fp)
{
  heightfield_save_data(node, terrain->heightfield, terrain->width, terrain->height);

  terrain->t_terrain_set_modified(false);
}

void TWriter::selection_save(TTerrain *terrain, FILE *fp)
{
  heightfield_save_data (node, terrain->selection, terrain->width, terrain->height);

  terrain->t_terrain_set_modified(false);
}

void TWriter::options_save(TTerrain *terrain, FILE *fp)
{
  xml_pack_float (node, "camera_x", terrain->camera_x);
  xml_pack_float (node, "camera_y", terrain->camera_y);
  xml_pack_float (node, "camera_z", terrain->camera_z);
  xml_pack_float (node, "lookat_x", terrain->lookat_x);
  xml_pack_float (node, "lookat_y", terrain->lookat_y);
  xml_pack_float (node, "lookat_z", terrain->lookat_z);
  xml_pack_float (node, "elevation_offset", terrain->elevation_offset);
  xml_pack_boolean (node, "observe_sealevel", terrain->observe_sealevel);
  xml_pack_boolean (node, "clouds", terrain->clouds);
  xml_pack_boolean (node, "fog", terrain->fog);
  xml_pack_boolean (node, "filled_sea", terrain->filled_sea);
  xml_pack_float (node, "time_of_day", terrain->time_of_day);
  xml_pack_float (node, "north_direction", terrain->north_direction);
  xml_pack_float (node, "water_clarity", terrain->water_clarity);
  xml_pack_int (node, "render_width", terrain->render_width);
  xml_pack_float (node, "y_scale_factor", terrain->y_scale_factor);
  xml_pack_float (node, "sealevel", terrain->sealevel);
  xml_pack_int (node, "wireframe_resolution",
                terrain->wireframe_resolution);
  xml_pack_string (node, "theme_file",
                   terrain->theme_file);
  xml_pack_int (node, "lighting_level", terrain->lighting_level);
  xml_pack_int (node, "contour_levels", terrain->contour_levels);
}

void TWriter::objects_save(TTerrain *terrain, FILE *fp)
{
  GArray *array;
  gint    i;

  array = terrain->objects;
  for (i = 0; i < array->len; i++)
    {
      TTerrainObject *object;
      xmlNodePtr      xml_object;

      object = &g_array_index (array, TTerrainObject, i);
      xml_object = xmlNewChild (node, NULL, "object", NULL);

      xmlSetProp (xml_object, "name", object->name);
      xml_pack_prop_float (xml_object, "ox", object->ox);
      xml_pack_prop_float (xml_object, "oy", object->oy);
      xml_pack_prop_float (xml_object, "x", object->x);
      xml_pack_prop_float (xml_object, "y", object->y);
      xml_pack_prop_float (xml_object, "angle", object->angle);
      xml_pack_prop_float (xml_object, "scale_x", object->scale_x);
      xml_pack_prop_float (xml_object, "scale_y", object->scale_y);
      xml_pack_prop_float (xml_object, "scale_z", object->scale_z);
    }
}
*/
int TWriter::t_terrain_save_native(TTerrain *terrain)
{
/*	xmlDocPtr  doc;
	xmlNodePtr node;

	doc = xmlNewDoc ("1.0");
	doc->root = xmlNewDocNode (doc, NULL, "Terrain", NULL);
	node = xmlNewChild (doc->root, NULL, "Options", NULL);
	options_save (terrain, node);
	node = xmlNewChild (doc->root, NULL, "Heightfield", NULL);
	heightfield_save (terrain, node);
	node = xmlNewChild (doc->root, NULL, "Objects", NULL);
	objects_save (terrain, node);

	if (terrain->selection)
    {
		node = xmlNewChild (doc->root, NULL, "Selection", NULL);
		selection_save (terrain, node);
    }

	xmlSaveFile (terrain->filename, doc);
	xmlFreeDoc (doc);
*/
	return 0;
}

int TWriter::t_terrain_export_tga_field(TTerrain *terrain, char *filename, float *field)
{
  FILE  *out;
  char  buf[3];
  int   i, size;
  int   status = 0;

  out = fopen(filename, "wb");
  if (!out)
    return -1;

  fputc(0, out); /* Id Length */
  fputc(0, out); /* CoMapType (0 = no map) */
  fputc(2, out); /* Image type */
  fputc(0, out); /* Index of first color entry */
  fputc(0, out);
  fputc(0, out); /* Number of entries in colormap */
  fputc(0, out);
  fputc(0, out); /* Size of colormap entry 15/16/24/32 */
  fputc(0, out); /* X origin */
  fputc(0, out);
  fputc(0, out); /* Y origin */
  fputc(0, out);
  fputc(terrain->width, out);        /* Width */
  fputc(terrain->width >> 8, out);
  fputc(terrain->height, out);       /* Height */
  fputc(terrain->height >> 8, out);
  fputc(24, out);   /* Depth */
  fputc(0x20, out); /* Descriptor */

  size = terrain->width * terrain->height;
  buf[0] = 0; /* Blue */
  for (i = 0; i < size; i++)
    {
      int value;

      value =
        (int) MIN (MAX (MAX_16_BIT * field[i], 0.0), MAX_16_BIT);

      buf[1] = value;      /* Green */
      buf[2] = value >> 8; /* Red   */

      fwrite(buf, 3, 1, out);
    }

  status = ferror(out);
  fclose(out);

  return status;
}

int TWriter::t_terrain_export_tga(TTerrain *terrain, char *filename)
{
  return t_terrain_export_tga_field(terrain, filename, terrain->heightfield);
}

int TWriter::t_terrain_export_pov(TTerrain *terrain, char *filename)
{
  FILE   *out;
  time_t  now;
  char  *tga;
  float  size_x, size_y, size_z;
  int    status;
//  int    i;
//  GArray *array;
//  GTree  *includes;

  out = fopen (filename, "wb");
  if (!out)
    return -1;

  now = time(NULL);

  FilenameOps *fno = new FilenameOps();
  fprintf(out, "// File created by MicroTerra on %s\n", ctime (&now));
  tga = fno->filename_new_extension(filename, "tga");
  fprintf(out, "#declare TF_HEIGHT_FIELD = height_field { tga \"%s\" smooth }\n", tga);
  t_terrain_export_tga(terrain, tga);
  //fprintf (out, "#declare TF_TILE_TERRAIN = %s;\n", terrain->do_tile ? "true" : "false");
  fprintf(out, "#declare TF_TILE_TERRAIN = %s;\n", "false");
  fprintf(out, "#declare TF_WATER_LEVEL = %f;\n", terrain->sealevel);
  fprintf(out, "#declare TF_HAVE_WATER = %s;\n", terrain->do_filled_sea ? "true" : "false");
  fprintf(out, "#declare TF_HAVE_WATER = true;\n");
  fprintf(out, "#declare TF_WATER_CLARITY = %f;\n", terrain->render_options.water_clarity);
  fprintf(out, "#declare TF_TIME_OF_DAY = %f;\n", terrain->render_options.time_of_day);
  fprintf(out, "#declare TF_HAVE_CLOUDS = %s;\n", terrain->render_options.do_clouds ? "true" : "false");
  fprintf(out, "#declare TF_HAVE_FOG = %s;\n", terrain->render_options.do_fog ? "true" : "false");
  fprintf(out, "#declare TF_FOG_OFFSET = %f;\n", terrain->render_options.fog_offset);
  fprintf(out, "#declare TF_FOG_ALT = %f;\n", terrain->render_options.fog_alt);
  fprintf(out, "#declare TF_FOG_DISTANCE = %f;\n", terrain->render_options.fog_density);
  fprintf(out, "#declare TF_NORTH_DIR = %f;\n", terrain->render_options.north_direction);

  fprintf(out, "#declare TF_Y_SCALE_FACTOR = %f;\n", terrain->y_scale_factor);

//  if (terrain->lighting_level == 0)
//    fprintf(out, "#declare TF_REAL_LIGHTING = false;\n");
//  else
    fprintf(out, "#declare TF_REAL_LIGHTING = true;\n");

//  if (terrain->lighting_level > 1)
//    fprintf(out, "#declare TF_HAVE_SUNBEAMS = true;\n");
//  else
    fprintf(out, "#declare TF_HAVE_SUNBEAMS = false;\n");

//  if (terrain->lighting_level > 2)
//    fprintf(out, "#declare TF_FAST_SUNBEAMS = false;\n");
//  else
    fprintf(out, "#declare TF_FAST_SUNBEAMS = true;\n");

  /* write any objects which are to be placed to the POV file */
  fprintf(out, "\n\n");

  t_terrain_get_povray_size(terrain, &size_x, &size_y, &size_z);

  fprintf(out, "#declare TF_X_SCALE = %f;\n", size_x);
  fprintf(out, "#declare TF_Y_SCALE = %f;\n", size_y);
  fprintf(out, "#declare TF_Z_SCALE = %f;\n", size_z);

  fprintf(out, "#declare TF_CAMERA_LOCATION = <%f, %f, %f>;\n", terrain->render_options.camera_x * size_x, terrain->render_options.camera_y * size_y, terrain->render_options.camera_z * size_z);
  fprintf(out, "#declare TF_CAMERA_LOOK_AT = <%f, %f, %f>;\n", terrain->render_options.lookat_x * size_x, terrain->render_options.lookat_y * size_y, terrain->render_options.lookat_z * size_z);
  fprintf(out, "\n\n");
//  fprintf(out, "#include \"%s\"", terrain->theme_file);
  fprintf(out, "#include \"pov\\earth_green.pov\"");
  fprintf(out, "\n\n");

//  array = terrain->objects;

  /* Write out all the #includes */
//  includes = g_tree_new ((GCompareFunc) strcmp);
//  for (i = 0; i < array->len; i++)
//    {
//      TTerrainObject *object;

//      object = &g_array_index (array, TTerrainObject, i);
//      if (g_tree_lookup (includes, object->name) == NULL)
//        {
//          g_tree_insert (includes, object->name, object->name);
//          fprintf (out, "#include \"%s\"\n", object->name);
//        }
//    }
//  g_tree_destroy (includes);

//  fprintf (out, "\n");

//  for (i = 0; i < array->len; i++)
//    {
//      TTerrainObject *object;
//      gint            hf_x, hf_y;
//      gfloat          pov_x, pov_y, pov_z;
//      gchar          *filename, *name;
//      gboolean        macro;

//      object = &g_array_index (array, TTerrainObject, i);

//      hf_x = object->x * (terrain->width - 1);
//      hf_y = object->y * (terrain->height - 1);
//      pov_x = object->x * size_x;
//      pov_y = terrain->heightfield[hf_y * terrain->width + hf_x] * size_y;
//      pov_z = (1.0 - object->y) * size_z;

//      filename = filename_get_base (object->name);
//      name = filename_new_extension (filename, NULL);
//      g_free (filename);

//      macro = FALSE;
      /* Does the object name end with "_macro"? */
//      if (strlen (name) > 6 && !strcmp (&name[strlen (name) - 6], "_macro"))
//        macro = TRUE;

      /* FIXME: Handle macros */
//      fprintf_C (out, "object { %s%s() scale <%f, %f, %f> rotate y * %f translate <%f, %f, %f> }\n",
//        name, macro ? "()" : "",
//        object->scale_x, object->scale_y, object->scale_z,
//        object->angle, pov_x, pov_y, pov_z);

//      g_free (name);
//    }

  status = ferror (out);
  delete fno;
  fclose (out);

  /* restore the original locale */
//  setlocale (LC_NUMERIC, previous_locale); 

  return status;
}

int TWriter::t_terrain_export_bmp(TTerrain *terrain, char *filename)
{
  return 0;
}

int TWriter::t_terrain_export_bmp_bw(TTerrain *terrain, char *filename)
{
  return 0;
}

int TWriter::t_terrain_export_pgm(TTerrain *terrain, char *filename)
{
  return 0;
}

int TWriter::t_terrain_export_pg8(TTerrain *terrain, char *filename)
{
  return 0;
}

int TWriter::t_terrain_export_mat(TTerrain *terrain, char *filename)
{
  return 0;
}

int TWriter::t_terrain_export_oct(TTerrain *terrain, char *filename)
{
  return 0;
}

/*
 * t_terrain_export_ac:
 *   Write the Height Field to an AC file.
 *   The strategy is to create a HeightFieldModel of the field and then to 
 *   save the 3D Data to the file.... 
 *
 * Function created by Roland Reckel (reckel@stud.montefiore.ulg.ac.be)
 * Modified by David A. Bartold
 */

int TWriter::t_terrain_export_ac(TTerrain *terrain, char *filename)
{
  FILE   *out;
  int     x, y;
  int     vert_x, vert_y;
  int     res;
  int     status;

  out = fopen (filename, "wb");
  if (!out)
    return -1;

  res = terrain->wireframe_resolution;
  if (MIN (terrain->width, terrain->height) < 40)
    res = 1;

  vert_x = (terrain->width - 1) / res + 1;
  vert_y = (terrain->height - 1) / res + 1;

  fprintf (out, "AC3Db\n");
  /* TODO: set good materials */
  fprintf (out, "MATERIAL \"\" rgb 1 1 1  amb 0.2 0.2 0.2  emis 0 0 0 spec 0.5 0.5 0.5  shi 10  trans 0\n");
  fprintf (out, "OBJECT world\n");
  fprintf (out, "kids 1\n");
  fprintf (out, "OBJECT poly\n");
  fprintf (out, "name \"terrain\"\n");
  fprintf (out, "numvert %d\n", vert_x * vert_y);

  for (y = 0; y < terrain->height; y += res)
    for (x = 0; x < terrain->width; x += res)
    fprintf(out, "%f %f %f\n", x / ((float) terrain->width) - 0.5, terrain->heightfield[y * terrain->width + x] * terrain->y_scale_factor, y / ((float) terrain->height) - 0.5);

  fprintf (out, "numsurf %d\n", (vert_y - 1) * (vert_x - 1) * 2);
  for (y = 0; y < vert_y - 1; y++)
    for (x = 0; x < vert_x - 1; x++)
      {
        int t1, t2, t3;

        t1 = y * vert_x + x;
        t2 = t1 + 1;
        t3 = t1 + vert_x;

        fprintf (out, "SURF 0x20\n");
        fprintf (out, "mat 0\n");
        fprintf (out, "refs 3\n");
        fprintf (out, "%d 0 0\n", t1);
        fprintf (out, "%d 0 0\n", t2);
        fprintf (out, "%d 0 0\n", t3);

        t1 = t2;
        t2 = t3 + 1;
        fprintf (out, "SURF 0x20\n");
        fprintf (out, "mat 0\n");
        fprintf (out, "refs 3\n");
        fprintf (out, "%d 0 0\n", t1);
        fprintf (out, "%d 0 0\n", t2);
        fprintf (out, "%d 0 0\n", t3);
      }
  fprintf (out, "kids 0\n");

  status = ferror(out);
  fclose(out);

  return status;
}


/*
 * This code is derived from the information gathered from the bmp2ter 
 * utililty, * originally written by Alistair Milne. I also found a 
 * description of the file format at 
 *   http://www.planetside.co.uk/terragen/dev/tgterrain.html
 * which made it possible to implement the complete spec.
 */

	// one-byte structure alignment turned on
	#pragma pack( push, pack1, 1)
/* complete header */
typedef struct terragen_header terragen_header;
struct terragen_header
{
	char      magic[16];
	char      size_marker[4];
	uint16    size;
	uint16    pad1;
	char      xpts_marker[4];
	uint16    xpts;
	uint16    pad2;
	char      ypts_marker[4];
	uint16    ypts;
	uint16    pad3;
	char      scal_marker[4];
	float     scal[3];
	char      crad_marker[4];
	float     crad;
	char      crvm_marker[4];
	uint32    crvm;
	char      altw_marker[4];
	int16     heightscale;
	int16     baseheight;
};
	// one-byte structure alignment turned off
	#pragma pack( pop, pack1)

int TWriter::t_terrain_export_terragen(TTerrain *terrain, char *filename)
{
//  int    last;
//  float  min, max, k;
//  float *data;
//  int     size;
  int     bwritten=0;
  int     to_pad;
  int     paddata = 0;
  int     status;
//  int i
  int x, y;
  int16   value;
  FILE   *out;
  terragen_header theader;

//  data = terrain->heightfield;
//  last = terrain->width * terrain->height;
//  min = max = data[0];
//  for (i = 0; i < last; i++)
//  {
//      if (data[i] < min) min = data[i];
//      if (data[i] > max) max = data[i];
//  }
//  k = 1.0 / (max - min);
//  for (i = 0; i < last; i++)
//    data[i] = (data[i] / k) + min; //(data[i] - min) * k;

  out = fopen (filename, "wb");
  if (!out)
    return -1;

  strncpy(theader.magic, "TERRAGENTERRAIN ", 16);
  strncpy(theader.size_marker, "SIZE", 4);
  strncpy(theader.xpts_marker, "XPTS", 4);
  strncpy(theader.ypts_marker, "YPTS", 4);
  strncpy(theader.scal_marker, "SCAL", 4);
  strncpy(theader.crad_marker, "CRAD", 4);
  strncpy(theader.crvm_marker, "CRVM", 4);
  strncpy(theader.altw_marker, "ALTW", 4);
  theader.size = MIN (terrain->width, terrain->height) - 1;
  theader.pad1 = 0;
  theader.xpts = terrain->width;
  theader.pad2 = 0;
  theader.ypts = terrain->height;
  theader.pad3 = 0;
  theader.scal[0] = (float)30.0;
  theader.scal[1] = (float)30.0;
  theader.scal[2] = (float)30.0;
  theader.crad = (float)6370;
  theader.crvm = 0;
  theader.heightscale = 43; //32767;
  theader.baseheight = 1;

  fwrite (&theader, sizeof(theader), 1, out);

  /* mirror to adjust to terragen coordinate system */
  t_terrain_mirror(terrain, 1); 
/*
  size = terrain->width * terrain->height; 
  for (i=0; i<size; i++) 
  {
      value = (int16)(((terrain->heightfield[i]*2)-1) * theader.heightscale);
      fwrite (&value, sizeof(value), 1, out);
  }
*/
	for (y=0; y<terrain->height; y++)
	{
		for (x=0; x<terrain->width*3; x+=3)
		{
			int16 blue  = (int16)(vraster[(y*(terrain->width*3))+x]);
			int16 green = (int16)(vraster[(y*(terrain->width*3))+(x+1)]);
			int16 red   = (int16)(vraster[(y*(terrain->width*3))+(x+2)]);

			value = 29*blue + 150*green + 76*red - 32768;
			fwrite (&value, sizeof(value), 1, out);
			bwritten += 2; 
		}
	}

  /* padding to 4 byte boundry derived from original source */
  to_pad = bwritten % 4;
  if (to_pad != 0)
    fwrite(&paddata, sizeof(paddata), 4-to_pad, out);

  /* reconstruct original terrain */
  t_terrain_mirror(terrain, 1); 

  status = ferror(out);
  fclose(out);
  return status;
}

int TWriter::t_terrain_export_grd(TTerrain *terrain, char *filename)
{
  return 0;
}

/*
 * export to a standard XYZ file:
 * 3 columns per line (x, y, elevation)
 */
int TWriter::t_terrain_export_xyz(TTerrain *terrain, char *filename)
{
  return 0;
}

/*
 * export to a DXF 
 * adapted from the code in dem2dxf, written by Sol Katz, May 27 1998
 */
int TWriter::t_terrain_export_dxf(TTerrain *terrain, char *filename)
{
  return 0;
}

int TWriter::t_terrain_export_bna(TTerrain *terrain, char *filename)
{
  return 0;
}

/* binary terrain format as desribed @ 
 * http://vterrain.org/Implementation/BT.html
 * written by RNG
 */
int TWriter::t_terrain_export_bt(TTerrain *terrain, char *filename)
{
  return 0;
}

void TWriter::twriter_set_raster(int *raster)
{
	vraster = raster;
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/