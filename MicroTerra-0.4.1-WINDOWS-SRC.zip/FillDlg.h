/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: filldlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: filldlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef FILLDLG_H
#define FILLDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;

class FillDlg : public QDialog
{ 
    Q_OBJECT

public:
    FillDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~FillDlg();

    QFrame* Line1;
    QPushButton* OK;
    QPushButton* CANCEL;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QLabel* lbl2;
    QSlider* fill_elevation;
    QSlider* fill_tightness;
    QLabel* slid1;
    QLabel* slid2;
	TTerrain *terra;

public slots:
	virtual void setFillElev(int value);
	virtual void setFillTight(int value);

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // FILLDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/