/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: contour.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: contour
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qarray.h>
#include <qlist.h>
#include "tterrain.h"
#include "Array.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class GList
{
public:
	float *ldata;
	int    size;
	GList *next;
};

class Edgemap
{
public:
  int    width;
  int    height;
  unsigned char *data;
};

class Edge
{
public:
  int x;
  int y;
  int bit;
};

class CContour
{
public:
	CContour();
	~CContour();
	void t_terrain_contour_list_free(GList *contour);
	GList *t_terrain_contour_lines(TTerrain *terrain, int level_count, int resolution);

private:
	Edgemap *edgemap_new(int width, int height);
	void edgemap_free(Edgemap *map);
	void to_edgemap(unsigned char *bitmap, int level, Edgemap *edgemap);
	bool within_bounds(Edgemap *map, Edge *edge);
	void to_float(Edge *edge, float *out_x, float *out_y);
	bool move_ok(Edgemap *map, Edge *edge);
	int invert_color(int edge);
	int invert_side(int edge);
	int invert_side_and_color(int edge);
	int reverse_direction(int dir);
	void move(Edgemap *map, int last_dir, int cur_dir, Edge *in, Edge *out);
	GList *follow_forward(Edgemap *map, Edge *start_edge, int start_dir, bool *closed);
	GList *follow_backward(GList *list, Edgemap *map, Edge *start_edge, int start_dir);
	GList *trace_at(Edgemap *map, int x, int y, bool *closed);
	void trace_list_free(GList *list);
	float *simplify(GList *points, float level, int resolution, bool closed);
};
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/