/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: rasterizedlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: rasterizedlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "RasterizeDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

RasterizeDlgImpl::RasterizeDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : RasterizeDlg( parent, name, modal, fl )
{
	adjust = true;
	xsize = 10;
	ysize = 10;
	factor = (float)0.50;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
RasterizeDlgImpl::~RasterizeDlgImpl()
{
}

void RasterizeDlgImpl::update_preview()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	if (adjust)
	{
		int       org_x = main_terra->width;
		int       org_y = main_terra->height;
		int       new_x = clone->width;
		int       new_y = clone->height;
		float     f = sqrt((float)(new_x+new_y) / (float)(org_x+org_y));

		xsize = (int)(xsize*f);
		if (xsize == 0)
			xsize = 1;
      
		ysize = (int)(ysize*f);
		if (ysize == 0)
			ysize = 1;
	}
	t_terrain_rasterize(clone, xsize, ysize, factor); 
	PreView->t_terrain_view_set_terrain(clone);
}

void RasterizeDlgImpl::adjustClicked()
{
	adjust = rasterize_do_adjust_size->isChecked();
	update_preview();
}

void RasterizeDlgImpl::setXsize(int value)
{
	char buf[15];

	xsize = value;
	sprintf(buf,"%d", xsize);
	slid1->setText((char *)buf);
	update_preview();
}

void RasterizeDlgImpl::setYsize(int value)
{
	char buf[15];

	ysize = value;
	sprintf(buf,"%d", ysize);
	slid2->setText((char *)buf);
	update_preview();
}

void RasterizeDlgImpl::setFactor(int value)
{
	char buf[15];

	factor = (float)(value/100.0);
	sprintf(buf,"%1.2f", factor);
	slid3->setText((char *)buf);
	update_preview();
}
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   -
 *
 ***********************************************************************************************************************/