/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: mosaicdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: mosaicdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef MOSAICDLG_H
#define MOSAICDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/
#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSpinBox;

class MosaicDlg : public QDialog
{ 
    Q_OBJECT

public:
    MosaicDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~MosaicDlg();

    QFrame* Line1;
    QPushButton* OK;
    QPushButton* CANCEL;
    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QLabel* lbl2;
    QLabel* lbl3;
    QLabel* lbl4;
    QSpinBox* x_mosaicsize;
    QSpinBox* y_mosaicsize;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
	TTerrain *terra;

public slots:
	virtual void xsizeChanged();
	virtual void ysizeChanged();

protected:
    QHBoxLayout* Layout1;
};

#endif // MOSAICDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - created
 *
 ***********************************************************************************************************************/