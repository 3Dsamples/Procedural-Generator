/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: tiledlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: tiledlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef TILEDLHIMPL_H
#define TILEDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "TileDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class TileDlgImpl : public TileDlg
{ 
    Q_OBJECT

public:
    TileDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~TileDlgImpl();

	bool  teras;
	float offset;
	int   assemx;
	int   assemy;

public slots:
	void setOffset(int value);
	void terasClicked();
	void setAssemX(int value);
	void setAssemY(int value);

protected:
	void update_preview();

};

#endif // TILEDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/