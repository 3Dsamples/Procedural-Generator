#ifndef __MT_H__
#define __MT_H__

/* include varargs functions for assertment macros
 */
#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* 
 *   Provide macros to feature the function attribute.
 */ 
#define MT_PRINTF( format_idx, arg_idx )
#define MT_SCANF( format_idx, arg_idx )
#define MT_FORMAT( arg_idx )
#define MT_NORETURN
#define MT_CONST
#define	MT_UNUSED 

/* Define MT_COPY() to do the right thing for copying va_list variables.
 */
#if !defined (MT_COPY)
#  define MT_COPY(ap1, ap2)	  (*(ap1) = *(ap2))
#endif /* !MT_COPY */

/* Provide type definitions for commonly used types.
 *  These are useful because a "gint8" can be adjusted
 *  to be 1 byte (8 bits) on all platforms. Similarly and
 *  more importantly, "gint32" can be adjusted to be
 *  4 bytes (32 bits) on all platforms.
 */

typedef unsigned char	uchar;
typedef unsigned short	ushort;
typedef unsigned long	ulong;
typedef unsigned int	uint;
typedef signed short    int16;
typedef unsigned short  uint16;
typedef signed int      int32;
typedef unsigned int    uint32;

/* String utility functions that modify a string argument or
 * return a constant string that must not be freed.
 */
#define	 G_STR_DELIMITERS	"_-|> <."
char* g_strdelimit(char *string, const char *delimiters, char new_delimiter);
int g_strcasecmp(const char *s1, const char *s2);
int g_strncasecmp(const char *s1, const char *s2, uint n);
void g_strdown(char *string);
void g_strup(char *string);
void g_strreverse(char *string);

/* String utility functions that return a newly allocated string which
 * ought to be freed from the caller at some point.
 */
char* g_strdup(const char *str);
char* g_strdup_printf(const char *format, ...) MT_PRINTF (1, 2);
char* g_strdup_vprintf(const char *format, va_list args);
char* g_strndup(const char *str, uint n);
char* g_strnfill(uint length, char fill_char);
char* g_strconcat(const char *string1, ...); /* NULL terminated */
char* g_strjoin(const char  *separator, ...); /* NULL terminated */
char* g_strescape(char *string);
 
/* calculate a string size, guarranteed to fit format + args.
 */
uint g_printf_string_upper_bound(const char* format, va_list args);
 
#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __MT_H__ */
