/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: optionsdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: optionsdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "OptionsDlg.h"

#include <qcheckbox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qradiobutton.h>
#include <qslider.h>
#include <qspinbox.h>
#include <qtabwidget.h>
#include <qwidget.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a OptionsDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
OptionsDlg::OptionsDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "OptionsDlg" );
    resize( 452, 337 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Options" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 150, 290, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    NoteBook1 = new QTabWidget( this, "NoteBook1" );
    NoteBook1->setGeometry( QRect( 10, 10, 435, 270 ) ); 
    NoteBook1->setTabShape( QTabWidget::Rounded );

    page1 = new QWidget( NoteBook1, "page1" );

    Notebook2 = new QTabWidget( page1, "Notebook2" );
    Notebook2->setGeometry( QRect( 10, 10, 405, 215 ) ); 

    general_tab1 = new QWidget( Notebook2, "general_tab1" );

    GroupBox2 = new QGroupBox( general_tab1, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 125, 10, 270, 165 ) ); 
    GroupBox2->setTitle( tr( "Executable Path" ) );

    povray_browse = new QPushButton( GroupBox2, "povray_browse" );
    povray_browse->setGeometry( QRect( 225, 80, 30, 24 ) ); 
    povray_browse->setText( tr( "...." ) );

    ac3d_browse = new QPushButton( GroupBox2, "ac3d_browse" );
    ac3d_browse->setGeometry( QRect( 225, 50, 30, 24 ) ); 
    ac3d_browse->setText( tr( "...." ) );

    lightwave_browse = new QPushButton( GroupBox2, "lightwave_browse" );
    lightwave_browse->setGeometry( QRect( 225, 20, 30, 24 ) ); 
    lightwave_browse->setText( tr( "...." ) );

    exe_lightwave = new QLineEdit( GroupBox2, "exe_lightwave" );
    exe_lightwave->setGeometry( QRect( 10, 20, 200, 22 ) ); 

    exe_ac3d = new QLineEdit( GroupBox2, "exe_ac3d" );
    exe_ac3d->setGeometry( QRect( 11, 50, 200, 22 ) ); 

    exe_povray = new QLineEdit( GroupBox2, "exe_povray" );
    exe_povray->setGeometry( QRect( 11, 80, 200, 22 ) ); 

    GroupBox1 = new QGroupBox( general_tab1, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 110, 165 ) ); 
    GroupBox1->setTitle( tr( "Parameters" ) );

    progs_lightwave = new QRadioButton( GroupBox1, "progs_lightwave" );
    progs_lightwave->setGeometry( QRect( 10, 20, 90, 20 ) ); 
    QFont progs_lightwave_font(  progs_lightwave->font() );
    progs_lightwave_font.setBold( FALSE );
    progs_lightwave->setFont( progs_lightwave_font ); 
    progs_lightwave->setText( tr( "LightWave" ) );

    progs_ac3d = new QRadioButton( GroupBox1, "progs_ac3d" );
    progs_ac3d->setGeometry( QRect( 10, 50, 90, 20 ) ); 
    QFont progs_ac3d_font(  progs_ac3d->font() );
    progs_ac3d_font.setBold( FALSE );
    progs_ac3d->setFont( progs_ac3d_font ); 
    progs_ac3d->setText( tr( "AC3D" ) );

    progs_povray = new QRadioButton( GroupBox1, "progs_povray" );
    progs_povray->setGeometry( QRect( 10, 80, 90, 20 ) ); 
    QFont progs_povray_font(  progs_povray->font() );
    progs_povray_font.setBold( FALSE );
    progs_povray->setFont( progs_povray_font ); 
    progs_povray->setText( tr( "POV Ray" ) );
    Notebook2->insertTab( general_tab1, tr( "3D Programs" ) );

    general_tab2 = new QWidget( Notebook2, "general_tab2" );

    GroupBox3 = new QGroupBox( general_tab2, "GroupBox3" );
    GroupBox3->setGeometry( QRect( 10, 10, 380, 165 ) ); 
    GroupBox3->setTitle( tr( "" ) );

    lbl1 = new QLabel( GroupBox3, "lbl1" );
    lbl1->setGeometry( QRect( 10, 20, 105, 20 ) ); 
    QFont lbl1_font(  lbl1->font() );
    lbl1_font.setBold( FALSE );
    lbl1->setFont( lbl1_font ); 
    lbl1->setText( tr( "Max undo states" ) );

    lbl2 = new QLabel( GroupBox3, "lbl2" );
    lbl2->setGeometry( QRect( 74, 65, 180, 20 ) ); 
    QFont lbl2_font(  lbl2->font() );
    lbl2_font.setBold( FALSE );
    lbl2->setFont( lbl2_font ); 
    lbl2->setText( tr( "Changes to this option won't" ) );

    lbl3 = new QLabel( GroupBox3, "lbl3" );
    lbl3->setGeometry( QRect( 74, 90, 180, 20 ) ); 
    QFont lbl3_font(  lbl3->font() );
    lbl3_font.setBold( FALSE );
    lbl3->setFont( lbl3_font ); 
    lbl3->setText( tr( "affect already open windows" ) );

    max_undo = new QSpinBox( GroupBox3, "max_undo" );
    max_undo->setGeometry( QRect( 130, 20, 65, 24 ) ); 
    QFont max_undo_font(  max_undo->font() );
    max_undo_font.setPointSize( 10 );
    max_undo->setFont( max_undo_font ); 
    max_undo->setButtonSymbols( QSpinBox::PlusMinus );
    max_undo->setMaxValue( 50 );
    max_undo->setMinValue( 2 );
    max_undo->setLineStep( 1 );
    max_undo->setValue( 5 );
    Notebook2->insertTab( general_tab2, tr( "Undo" ) );

    general_tab3 = new QWidget( Notebook2, "general_tab3" );

    GroupBox4 = new QGroupBox( general_tab3, "GroupBox4" );
    GroupBox4->setGeometry( QRect( 10, 10, 380, 165 ) ); 
    GroupBox4->setTitle( tr( "" ) );

    Frame1 = new QFrame( GroupBox4, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 54 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	GammaView = new MOGammaPreview( Frame1, "GammaView" );
	GammaView->setGeometry( QRect( 2, 2, 100, 50 ) );
	GammaView->on_gamma_preview_realize();
	GammaView->show();

    gamma = new QSlider( GroupBox4, "gamma" );
    gamma->setGeometry( QRect( 130, 35, 150, 24 ) ); 
    gamma->setMinValue( 100 );
    gamma->setMaxValue( 300 );
    gamma->setLineStep( 1 );
    gamma->setValue( 150 );
    gamma->setOrientation( QSlider::Horizontal );
    gamma->setTickmarks( QSlider::NoMarks );

    lbl4 = new QLabel( GroupBox4, "lbl4" );
    lbl4->setGeometry( QRect( 112, 94, 175, 20 ) ); 
    QFont lbl4_font(  lbl4->font() );
    lbl4_font.setBold( FALSE );
    lbl4->setFont( lbl4_font ); 
    lbl4->setText( tr( "Adjust the gamma until both" ) );

    lbl5 = new QLabel( GroupBox4, "lbl5" );
    lbl5->setGeometry( QRect( 100, 115, 205, 20 ) ); 
    QFont lbl5_font(  lbl5->font() );
    lbl5_font.setBold( FALSE );
    lbl5->setFont( lbl5_font ); 
    lbl5->setText( tr( "squares are the same brightness" ) );

    slid1 = new QLabel( GroupBox4, "slid1" );
    slid1->setGeometry( QRect( 300, 35, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "1.50" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );
    Notebook2->insertTab( general_tab3, tr( "Gamma" ) );

    size = new QWidget( Notebook2, "size" );

    GroupBox5 = new QGroupBox( size, "GroupBox5" );
    GroupBox5->setGeometry( QRect( 10, 10, 380, 165 ) ); 
    GroupBox5->setTitle( tr( "" ) );

    default_size = new QSpinBox( GroupBox5, "default_size" );
    default_size->setGeometry( QRect( 150, 20, 65, 24 ) ); 
    QFont default_size_font(  default_size->font() );
    default_size_font.setPointSize( 10 );
    default_size->setFont( default_size_font ); 
    default_size->setButtonSymbols( QSpinBox::PlusMinus );
    default_size->setMaxValue( 2000 );
    default_size->setMinValue( 10 );
    default_size->setLineStep( 1 );
    default_size->setValue( 400 );

    lbl6 = new QLabel( GroupBox5, "lbl6" );
    lbl6->setGeometry( QRect( 10, 20, 130, 20 ) ); 
    QFont lbl6_font(  lbl6->font() );
    lbl6_font.setBold( FALSE );
    lbl6->setFont( lbl6_font ); 
    lbl6->setText( tr( "Default terrain size" ) );
    Notebook2->insertTab( size, tr( "Size" ) );

    generation = new QWidget( Notebook2, "generation" );

    GroupBox6 = new QGroupBox( generation, "GroupBox6" );
    GroupBox6->setGeometry( QRect( 10, 10, 380, 165 ) ); 
    GroupBox6->setTitle( tr( "" ) );

    rand_gen_faulting = new QCheckBox( GroupBox6, "rand_gen_faulting" );
    rand_gen_faulting->setGeometry( QRect( 11, 21, 150, 20 ) ); 
    QFont rand_gen_faulting_font(  rand_gen_faulting->font() );
    rand_gen_faulting_font.setBold( FALSE );
    rand_gen_faulting->setFont( rand_gen_faulting_font ); 
    rand_gen_faulting->setText( tr( "Faulting Syntheses" ) );
    rand_gen_faulting->setChecked( TRUE );

    rand_gen_perlin = new QCheckBox( GroupBox6, "rand_gen_perlin" );
    rand_gen_perlin->setGeometry( QRect( 11, 51, 150, 20 ) ); 
    QFont rand_gen_perlin_font(  rand_gen_perlin->font() );
    rand_gen_perlin_font.setBold( FALSE );
    rand_gen_perlin->setFont( rand_gen_perlin_font ); 
    rand_gen_perlin->setText( tr( "Perlin Synthesis" ) );
    rand_gen_perlin->setChecked( TRUE );

    rand_gen_spectral = new QCheckBox( GroupBox6, "rand_gen_spectral" );
    rand_gen_spectral->setGeometry( QRect( 11, 81, 150, 20 ) ); 
    QFont rand_gen_spectral_font(  rand_gen_spectral->font() );
    rand_gen_spectral_font.setBold( FALSE );
    rand_gen_spectral->setFont( rand_gen_spectral_font ); 
    rand_gen_spectral->setText( tr( "Spectral Synthesis" ) );
    rand_gen_spectral->setChecked( TRUE );

    rand_gen_subdiv = new QCheckBox( GroupBox6, "rand_gen_subdiv" );
    rand_gen_subdiv->setGeometry( QRect( 11, 111, 150, 20 ) ); 
    QFont rand_gen_subdiv_font(  rand_gen_subdiv->font() );
    rand_gen_subdiv_font.setBold( FALSE );
    rand_gen_subdiv->setFont( rand_gen_subdiv_font ); 
    rand_gen_subdiv->setText( tr( "Subdivision Synthesis" ) );
    rand_gen_subdiv->setChecked( TRUE );
    Notebook2->insertTab( generation, tr( "Generation" ) );

    dirs = new QWidget( Notebook2, "dirs" );

    GroupBox13 = new QGroupBox( dirs, "GroupBox13" );
    GroupBox13->setGeometry( QRect( 5, 10, 390, 165 ) ); 
    GroupBox13->setTitle( tr( "Directory Path" ) );

    microterra_browse = new QPushButton( GroupBox13, "microterra_browse" );
    microterra_browse->setGeometry( QRect( 340, 20, 30, 24 ) ); 
    microterra_browse->setText( tr( "...." ) );

    dir_microterra = new QLineEdit( GroupBox13, "dir_microterra" );
    dir_microterra->setGeometry( QRect( 126, 20, 200, 22 ) ); 

    lbl15 = new QLabel( GroupBox13, "lbl15" );
    lbl15->setGeometry( QRect( 10, 20, 105, 20 ) ); 
    QFont lbl15_font(  lbl15->font() );
    lbl15_font.setBold( FALSE );
    lbl15->setFont( lbl6_font ); 
    lbl15->setText( tr( "MicroTerra Home" ) );
    Notebook2->insertTab( dirs, tr( "Dirs" ) );
    NoteBook1->insertTab( page1, tr( "General" ) );

    page2 = new QWidget( NoteBook1, "page2" );

    TabWidget6 = new QTabWidget( page2, "TabWidget6" );
    TabWidget6->setGeometry( QRect( 10, 10, 410, 220 ) ); 

    tab = new QWidget( TabWidget6, "tab" );

    GroupBox7 = new QGroupBox( tab, "GroupBox7" );
    GroupBox7->setGeometry( QRect( 10, 10, 385, 85 ) ); 
    GroupBox7->setTitle( tr( "Absolute Terrain Scale" ) );
    GroupBox7->setAlignment( int( QGroupBox::AlignLeft ) );

    scale_z = new QSlider( GroupBox7, "scale_z" );
    scale_z->setGeometry( QRect( 105, 50, 150, 20 ) ); 
    scale_z->setMinValue( 500 );
    scale_z->setMaxValue( 25000 );
    scale_z->setLineStep( 100 );
    scale_z->setPageStep( 0 );
    scale_z->setValue( 1000 );
    scale_z->setOrientation( QSlider::Horizontal );

    scale_x = new QSlider( GroupBox7, "scale_x" );
    scale_x->setGeometry( QRect( 105, 20, 150, 20 ) ); 
    scale_x->setMinValue( 500 );
    scale_x->setMaxValue( 25000 );
    scale_x->setLineStep( 100 );
    scale_x->setPageStep( 0 );
    scale_x->setValue( 1000 );
    scale_x->setOrientation( QSlider::Horizontal );

    slid2 = new QLabel( GroupBox7, "slid2" );
    slid2->setGeometry( QRect( 275, 19, 55, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "1000" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

    slid3 = new QLabel( GroupBox7, "slid3" );
    slid3->setGeometry( QRect( 275, 49, 55, 20 ) ); 
    QFont slid3_font(  slid3->font() );
    slid3_font.setPointSize( 10 );
    slid3->setFont( slid3_font ); 
    slid3->setText( tr( "1000" ) );
    slid3->setAlignment( int( QLabel::AlignCenter ) );

    lbl7 = new QLabel( GroupBox7, "lbl7" );
    lbl7->setGeometry( QRect( 10, 20, 66, 20 ) ); 
    QFont lbl7_font(  lbl7->font() );
    lbl7_font.setBold( FALSE );
    lbl7->setFont( lbl7_font ); 
    lbl7->setText( tr( "Size X" ) );

    lbl8 = new QLabel( GroupBox7, "lbl8" );
    lbl8->setGeometry( QRect( 10, 50, 66, 20 ) ); 
    QFont lbl8_font(  lbl8->font() );
    lbl8_font.setBold( FALSE );
    lbl8->setFont( lbl8_font ); 
    lbl8->setText( tr( "Size Z" ) );

    GroupBox8 = new QGroupBox( tab, "GroupBox8" );
    GroupBox8->setGeometry( QRect( 10, 100, 385, 80 ) ); 
    GroupBox8->setTitle( tr( "Relative Y Scale" ) );

    y_scale_factor = new QSlider( GroupBox8, "y_scale_factor" );
    y_scale_factor->setGeometry( QRect( 105, 35, 150, 20 ) ); 
    y_scale_factor->setMinValue( 1 );
    y_scale_factor->setMaxValue( 100 );
    y_scale_factor->setPageStep( 0 );
    y_scale_factor->setValue( 33 );
    y_scale_factor->setOrientation( QSlider::Horizontal );

    slid4 = new QLabel( GroupBox8, "slid4" );
    slid4->setGeometry( QRect( 275, 34, 50, 20 ) ); 
    QFont slid4_font(  slid4->font() );
    slid4_font.setPointSize( 10 );
    slid4->setFont( slid4_font ); 
    slid4->setText( tr( "0.33" ) );
    slid4->setAlignment( int( QLabel::AlignCenter ) );

    lbl9 = new QLabel( GroupBox8, "lbl9" );
    lbl9->setGeometry( QRect( 10, 35, 66, 20 ) ); 
    QFont lbl9_font(  lbl9->font() );
    lbl9_font.setBold( FALSE );
    lbl9->setFont( lbl9_font ); 
    lbl9->setText( tr( "Size Y" ) );
    TabWidget6->insertTab( tab, tr( "Scaling" ) );

    tab_2 = new QWidget( TabWidget6, "tab_2" );

    GroupBox9 = new QGroupBox( tab_2, "GroupBox9" );
    GroupBox9->setGeometry( QRect( 10, 10, 385, 50 ) ); 
    GroupBox9->setTitle( tr( "" ) );

    filled_sea = new QCheckBox( GroupBox9, "filled_sea" );
    filled_sea->setGeometry( QRect( 10, 15, 90, 20 ) ); 
    QFont filled_sea_font(  filled_sea->font() );
    filled_sea_font.setBold( FALSE );
    filled_sea->setFont( filled_sea_font ); 
    filled_sea->setText( tr( "Filled Sea" ) );
    filled_sea->setChecked( TRUE );

    GroupBox10 = new QGroupBox( tab_2, "GroupBox10" );
    GroupBox10->setGeometry( QRect( 10, 65, 385, 115 ) ); 
    GroupBox10->setTitle( tr( "Sea Parameters" ) );

    sealevel = new QSlider( GroupBox10, "sealevel" );
    sealevel->setGeometry( QRect( 105, 30, 150, 20 ) ); 
    sealevel->setMinValue( 1 );
    sealevel->setMaxValue( 100 );
    sealevel->setPageStep( 0 );
    sealevel->setValue( 33 );
    sealevel->setOrientation( QSlider::Horizontal );

    clarity = new QSlider( GroupBox10, "clarity" );
    clarity->setGeometry( QRect( 105, 70, 150, 20 ) ); 
    clarity->setMinValue( 0 );
    clarity->setMaxValue( 100 );
    clarity->setPageStep( 0 );
    clarity->setValue( 65 );
    clarity->setOrientation( QSlider::Horizontal );

    slid5 = new QLabel( GroupBox10, "slid5" );
    slid5->setGeometry( QRect( 275, 29, 50, 20 ) ); 
    QFont slid5_font(  slid5->font() );
    slid5_font.setPointSize( 10 );
    slid5->setFont( slid5_font ); 
    slid5->setText( tr( "0.33" ) );
    slid5->setAlignment( int( QLabel::AlignCenter ) );

    slid6 = new QLabel( GroupBox10, "slid6" );
    slid6->setGeometry( QRect( 275, 69, 50, 20 ) ); 
    QFont slid6_font(  slid6->font() );
    slid6_font.setPointSize( 10 );
    slid6->setFont( slid6_font ); 
    slid6->setText( tr( "0.65" ) );
    slid6->setAlignment( int( QLabel::AlignCenter ) );

    lbl10 = new QLabel( GroupBox10, "lbl10" );
    lbl10->setGeometry( QRect( 10, 30, 66, 20 ) ); 
    QFont lbl10_font(  lbl10->font() );
    lbl10_font.setBold( FALSE );
    lbl10->setFont( lbl10_font ); 
    lbl10->setText( tr( "Sealevel" ) );

    lbl11 = new QLabel( GroupBox10, "lbl11" );
    lbl11->setGeometry( QRect( 10, 70, 85, 20 ) ); 
    QFont lbl11_font(  lbl11->font() );
    lbl11_font.setBold( FALSE );
    lbl11->setFont( lbl11_font ); 
    lbl11->setText( tr( "Water Clarity" ) );
    TabWidget6->insertTab( tab_2, tr( "Sea" ) );

    tab_3 = new QWidget( TabWidget6, "tab_3" );

    GroupBox11 = new QGroupBox( tab_3, "GroupBox11" );
    GroupBox11->setGeometry( QRect( 10, 10, 385, 90 ) ); 
    GroupBox11->setTitle( tr( "3d Views" ) );

    wireframe_resolution = new QSlider( GroupBox11, "wireframe_resolution" );
    wireframe_resolution->setGeometry( QRect( 155, 20, 150, 20 ) ); 
    wireframe_resolution->setMinValue( 1 );
    wireframe_resolution->setMaxValue( 50 );
    wireframe_resolution->setPageStep( 0 );
    wireframe_resolution->setValue( 10 );
    wireframe_resolution->setOrientation( QSlider::Horizontal );

    camera_height_factor = new QSlider( GroupBox11, "camera_height_factor" );
    camera_height_factor->setGeometry( QRect( 155, 55, 150, 20 ) ); 
    camera_height_factor->setMinValue( 0 );
    camera_height_factor->setMaxValue( 100 );
    camera_height_factor->setPageStep( 0 );
    camera_height_factor->setValue( 33 );
    camera_height_factor->setOrientation( QSlider::Horizontal );

    slid7 = new QLabel( GroupBox11, "slid7" );
    slid7->setGeometry( QRect( 320, 19, 50, 20 ) ); 
    QFont slid7_font(  slid7->font() );
    slid7_font.setPointSize( 10 );
    slid7->setFont( slid7_font ); 
    slid7->setText( tr( "10" ) );
    slid7->setAlignment( int( QLabel::AlignCenter ) );

    slid8 = new QLabel( GroupBox11, "slid8" );
    slid8->setGeometry( QRect( 320, 54, 50, 20 ) ); 
    QFont slid8_font(  slid8->font() );
    slid8_font.setPointSize( 10 );
    slid8->setFont( slid8_font ); 
    slid8->setText( tr( "0.33" ) );
    slid8->setAlignment( int( QLabel::AlignCenter ) );

    lbl12 = new QLabel( GroupBox11, "lbl12" );
    lbl12->setGeometry( QRect( 10, 20, 130, 20 ) ); 
    QFont lbl12_font(  lbl12->font() );
    lbl12_font.setBold( FALSE );
    lbl12->setFont( lbl12_font ); 
    lbl12->setText( tr( "Wireframe Resolution" ) );

    lbl13 = new QLabel( GroupBox11, "lbl13" );
    lbl13->setGeometry( QRect( 10, 55, 135, 20 ) ); 
    QFont lbl13_font(  lbl13->font() );
    lbl13_font.setBold( FALSE );
    lbl13->setFont( lbl13_font ); 
    lbl13->setText( tr( "Camera Height Factor" ) );

    GroupBox12 = new QGroupBox( tab_3, "GroupBox12" );
    GroupBox12->setGeometry( QRect( 11, 105, 385, 75 ) ); 
    GroupBox12->setTitle( tr( "Contour Line Map" ) );

    levels = new QSlider( GroupBox12, "levels" );
    levels->setGeometry( QRect( 155, 30, 150, 20 ) ); 
    levels->setMinValue( 1 );
    levels->setMaxValue( 50 );
    levels->setPageStep( 0 );
    levels->setValue( 10 );
    levels->setOrientation( QSlider::Horizontal );

    slid9 = new QLabel( GroupBox12, "slid9" );
    slid9->setGeometry( QRect( 320, 29, 50, 20 ) ); 
    QFont slid9_font(  slid9->font() );
    slid9_font.setPointSize( 10 );
    slid9->setFont( slid9_font ); 
    slid9->setText( tr( "10" ) );
    slid9->setAlignment( int( QLabel::AlignCenter ) );

    lbl14 = new QLabel( GroupBox12, "lbl14" );
    lbl14->setGeometry( QRect( 10, 30, 120, 20 ) ); 
    QFont lbl14_font(  lbl14->font() );
    lbl14_font.setBold( FALSE );
    lbl14->setFont( lbl14_font ); 
    lbl14->setText( tr( "Number of Levels" ) );
    TabWidget6->insertTab( tab_3, tr( "Views" ) );
    NoteBook1->insertTab( page2, tr( "Page 1" ) );

    // signals and slots connections
    connect( progs_lightwave, SIGNAL( stateChanged(int) ), this, SLOT( progslightwave_Changed() ) );
    connect( progs_ac3d, SIGNAL( stateChanged(int) ), this, SLOT( progsac3d_Changed() ) );
    connect( progs_povray, SIGNAL( stateChanged(int) ), this, SLOT( progspovray_Changed() ) );
    connect( lightwave_browse, SIGNAL( clicked() ), this, SLOT( lightwavebrowse() ) );
    connect( ac3d_browse, SIGNAL( clicked() ), this, SLOT( ac3dbrowse() ) );
    connect( povray_browse, SIGNAL( clicked() ), this, SLOT( povraybrowse() ) );
    connect( gamma, SIGNAL(valueChanged(int)), this, SLOT(setGamma(int)) );
    connect( default_size, SIGNAL(valueChanged(int)), this, SLOT(defaultsizeChanged()) );
    connect( rand_gen_faulting, SIGNAL(clicked()), this, SLOT(randgenfaultingClicked()));
    connect( rand_gen_perlin, SIGNAL(clicked()), this, SLOT(randgenperlinClicked()));
    connect( rand_gen_spectral, SIGNAL(clicked()), this, SLOT(randgenspectralClicked()));
    connect( rand_gen_subdiv, SIGNAL(clicked()), this, SLOT(randgensubdivClicked()));
    connect( microterra_browse, SIGNAL( clicked() ), this, SLOT( microterrabrowse() ) );
    connect( scale_x, SIGNAL(valueChanged(int)), this, SLOT(setXscale(int)) );
    connect( scale_z, SIGNAL(valueChanged(int)), this, SLOT(setZscale(int)) );
    connect( y_scale_factor, SIGNAL(valueChanged(int)), this, SLOT(setYscalefactor(int)) );
    connect( filled_sea, SIGNAL(clicked()), this, SLOT(filledseaClicked()));
    connect( sealevel, SIGNAL(valueChanged(int)), this, SLOT(setSealevel(int)) );
    connect( clarity, SIGNAL(valueChanged(int)), this, SLOT(setClarity(int)) );
    connect( wireframe_resolution, SIGNAL(valueChanged(int)), this, SLOT(setWireframeResolution(int)) );
    connect( camera_height_factor, SIGNAL(valueChanged(int)), this, SLOT(setCameraHeightFactor(int)) );
    connect( levels, SIGNAL(valueChanged(int)), this, SLOT(setLevels(int)) );
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
OptionsDlg::~OptionsDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool OptionsDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev );

    if ( ev->type() == QEvent::ApplicationFontChange )
	{
		QFont progs_lightwave_font(  progs_lightwave->font() );
		progs_lightwave_font.setBold( FALSE );
		progs_lightwave->setFont( progs_lightwave_font ); 
		QFont progs_ac3d_font(  progs_ac3d->font() );
		progs_ac3d_font.setBold( FALSE );
		progs_ac3d->setFont( progs_ac3d_font ); 
		QFont progs_povray_font(  progs_povray->font() );
		progs_povray_font.setBold( FALSE );
		progs_povray->setFont( progs_povray_font ); 
		QFont lbl1_font(  lbl1->font() );
		lbl1_font.setBold( FALSE );
		lbl1->setFont( lbl1_font ); 
		QFont lbl2_font(  lbl2->font() );
		lbl2_font.setBold( FALSE );
		lbl2->setFont( lbl2_font ); 
		QFont lbl3_font(  lbl3->font() );
		lbl3_font.setBold( FALSE );
		lbl3->setFont( lbl3_font ); 
		QFont max_undo_font(  max_undo->font() );
		max_undo_font.setPointSize( 10 );
		max_undo->setFont( max_undo_font ); 
		QFont lbl4_font(  lbl4->font() );
		lbl4_font.setBold( FALSE );
		lbl4->setFont( lbl4_font ); 
		QFont lbl5_font(  lbl5->font() );
		lbl5_font.setBold( FALSE );
		lbl5->setFont( lbl5_font ); 
		QFont slid1_font(  slid1->font() );
		slid1_font.setPointSize( 10 );
		slid1->setFont( slid1_font ); 
		QFont default_size_font(  default_size->font() );
		default_size_font.setPointSize( 10 );
		default_size->setFont( default_size_font ); 
		QFont lbl6_font(  lbl6->font() );
		lbl6_font.setBold( FALSE );
		lbl6->setFont( lbl6_font ); 
		QFont rand_gen_faulting_font(  rand_gen_faulting->font() );
		rand_gen_faulting_font.setBold( FALSE );
		rand_gen_faulting->setFont( rand_gen_faulting_font ); 
		QFont rand_gen_perlin_font(  rand_gen_perlin->font() );
		rand_gen_perlin_font.setBold( FALSE );
		rand_gen_perlin->setFont( rand_gen_perlin_font ); 
		QFont rand_gen_spectral_font(  rand_gen_spectral->font() );
		rand_gen_spectral_font.setBold( FALSE );
		rand_gen_spectral->setFont( rand_gen_spectral_font ); 
		QFont rand_gen_subdiv_font(  rand_gen_subdiv->font() );
		rand_gen_subdiv_font.setBold( FALSE );
		rand_gen_subdiv->setFont( rand_gen_subdiv_font ); 
		QFont slid2_font(  slid2->font() );
		slid2_font.setPointSize( 10 );
		slid2->setFont( slid2_font ); 
		QFont slid3_font(  slid3->font() );
		slid3_font.setPointSize( 10 );
		slid3->setFont( slid3_font ); 
		QFont lbl7_font(  lbl7->font() );
		lbl7_font.setBold( FALSE );
		lbl7->setFont( lbl7_font ); 
		QFont lbl8_font(  lbl8->font() );
		lbl8_font.setBold( FALSE );
		lbl8->setFont( lbl8_font ); 
		QFont slid4_font(  slid4->font() );
		slid4_font.setPointSize( 10 );
		slid4->setFont( slid4_font ); 
		QFont lbl9_font(  lbl9->font() );
		lbl9_font.setBold( FALSE );
		lbl9->setFont( lbl9_font ); 
		QFont filled_sea_font(  filled_sea->font() );
		filled_sea_font.setBold( FALSE );
		filled_sea->setFont( filled_sea_font ); 
		QFont slid5_font(  slid5->font() );
		slid5_font.setPointSize( 10 );
		slid5->setFont( slid5_font ); 
		QFont slid6_font(  slid6->font() );
		slid6_font.setPointSize( 10 );
		slid6->setFont( slid6_font ); 
		QFont lbl10_font(  lbl10->font() );
		lbl10_font.setBold( FALSE );
		lbl10->setFont( lbl10_font ); 
		QFont lbl11_font(  lbl11->font() );
		lbl11_font.setBold( FALSE );
		lbl11->setFont( lbl11_font ); 
		QFont slid7_font(  slid7->font() );
		slid7_font.setPointSize( 10 );
		slid7->setFont( slid7_font ); 
		QFont slid8_font(  slid8->font() );
		slid8_font.setPointSize( 10 );
		slid8->setFont( slid8_font ); 
		QFont lbl12_font(  lbl12->font() );
		lbl12_font.setBold( FALSE );
		lbl12->setFont( lbl12_font ); 
		QFont lbl13_font(  lbl13->font() );
		lbl13_font.setBold( FALSE );
		lbl13->setFont( lbl13_font ); 
		QFont slid9_font(  slid9->font() );
		slid9_font.setPointSize( 10 );
		slid9->setFont( slid9_font ); 
		QFont lbl14_font(  lbl14->font() );
		lbl14_font.setBold( FALSE );
		lbl14->setFont( lbl14_font ); 
		QFont lbl15_font(  lbl15->font() );
		lbl15_font.setBold( FALSE );
		lbl15->setFont( lbl15_font ); 
    }
    return ret;
}

void OptionsDlg::progslightwave_Changed()
{
}

void OptionsDlg::progsac3d_Changed()
{
}

void OptionsDlg::progspovray_Changed()
{
}

void OptionsDlg::lightwavebrowse()
{
}

void OptionsDlg::ac3dbrowse()
{
}

void OptionsDlg::povraybrowse()
{
}

void OptionsDlg::setGamma(int value)
{
}

void OptionsDlg::defaultsizeChanged()
{
}

void OptionsDlg::randgenfaultingClicked()
{
}

void OptionsDlg::randgenperlinClicked()
{
}

void OptionsDlg::randgenspectralClicked()
{
}

void OptionsDlg::randgensubdivClicked()
{
}

void OptionsDlg::microterrabrowse()
{
}

void OptionsDlg::setXscale(int value)
{
}

void OptionsDlg::setZscale(int value)
{
}

void OptionsDlg::setYscalefactor(int value)
{
}

void OptionsDlg::filledseaClicked()
{
}

void OptionsDlg::setSealevel(int value)
{
}

void OptionsDlg::setClarity(int value)
{
}

void OptionsDlg::setWireframeResolution(int value)
{
}

void OptionsDlg::setCameraHeightFactor(int value)
{
}

void OptionsDlg::setLevels(int value)
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 07-12-2004
 *   - created
 *
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/