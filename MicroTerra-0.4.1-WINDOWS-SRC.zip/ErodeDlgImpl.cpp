/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: erodedlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: erodedlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "stdio.h"
#include <qcheckbox.h>
#include <qradiobutton.h>
#include "ErodeDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

ErodeDlgImpl::ErodeDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : ErodeDlg( parent, name, modal, fl )
{
	iterations = 100;
	flowage = 10;
	flowmaptimes = 0;
	threshold = (float)0.95;
	trim = true;
	anim = "%s_flowmap_%d.tga";
	flow = "%s_erode_%d.tga";
	saveanim = false;
	saveflow = false;
	count = 20;
	direction = true;
	sealevel = false;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
ErodeDlgImpl::~ErodeDlgImpl()
{
}

void ErodeDlgImpl::update_view()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	t_terrain_erode(clone, iterations, flowage, flowmaptimes, threshold, NULL, NULL, count, trim, direction, !sealevel);
	PreView->t_terrain_view_set_terrain(clone);
}

void ErodeDlgImpl::setIteration(int value)
{
	char buf[15];

	iterations = value;
	sprintf(buf,"%d", iterations);
	slid1->setText((char *)buf);
}

void ErodeDlgImpl::setMaxFlowmapAge(int value)
{
	char buf[15];

	flowage = value;
	sprintf(buf,"%d", flowage);
	slid2->setText((char *)buf);
}

void ErodeDlgImpl::setAgeFlowmapTimes(int value)
{
	char buf[15];

	flowmaptimes = value;
	sprintf(buf,"%d", flowmaptimes);
	slid3->setText((char *)buf);
}

void ErodeDlgImpl::setThreshold(int value)
{
	char buf[15];

	threshold = (float)value/100;
	sprintf(buf,"%1.2f", threshold);
	slid4->setText((char *)buf);
}

void ErodeDlgImpl::trimClicked()
{
	trim = erode_trim->isChecked();
}

void ErodeDlgImpl::saveflowmapClicked()
{
	saveflow = erode_save_flowmap->isChecked();
}

void ErodeDlgImpl::saveanimClicked()
{
	saveanim = erode_save_anim->isChecked();
}

void ErodeDlgImpl::framecountChanged()
{
	count = erode_frame_count->value();
}

void ErodeDlgImpl::single_Changed()
{
	if (erode_single->isChecked())
	{
		direction = true;
	}
}

void ErodeDlgImpl::multiple_Changed()
{
	if (erode_multiple->isChecked())
	{
		direction = false;
	}
}

void ErodeDlgImpl::sealevelClicked()
{
	sealevel = erode_sealevel->isChecked();
}
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - created
 *
 ***********************************************************************************************************************/