/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: terracedlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: terracedlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef TERRACEDLG_H
#define TERRACEDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/
#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;

class TerraceDlg : public QDialog
{ 
    Q_OBJECT

public:
    TerraceDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~TerraceDlg();

    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QFrame* Line1;
    QPushButton* OK;
    QPushButton* CANCEL;
    QGroupBox* GroupBox2;
    QSlider* terrace_levels;
    QSlider* terrace_tightness;
    QLabel* lbl1;
    QLabel* lbl2;
    QLabel* slid1;
    QLabel* slid2;
    QCheckBox* terrace_adjust_waterlevel;
	TTerrain *terra;

public slots:
	virtual void setLevel(int value);
	virtual void setTight(int value);
	virtual void adjustClicked();

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // TERRACEDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/