#ifndef _KCONFIGDATA_H
#define _KCONFIGDATA_H

#include <qdict.h> // QDict
#include <qtextstream.h> // QTextStream

/**
* Entry-dictionary entry.
* @internal
*/
struct KEntryDictEntry
{
  QString aValue;
  bool    bDirty; // must the entry be written back to disk?
  bool    bGlobal; // entry should be written to the global config file
  bool    bNLS;    // entry should be written with locale tag
};

typedef QDict<KEntryDictEntry> KEntryDict;
typedef QDict<KEntryDict> KGroupDict;
typedef QDictIterator<KEntryDict> KGroupIterator;
typedef QDictIterator<KEntryDictEntry> KEntryIterator;

/**
* Configuration data manager, used internally by KConfig.
* @short Configuration data manager, used internally by KConfig.
* @version $Id: kconfigdata.h,v 1.11 1998/10/07 06:49:24 kalle Exp $
* @author Matthias Kalle Dalheimer (kalle@kde.org)
* @internal
*/
class KConfigBaseData
{
friend class KConfig;
friend class KConfigBase;
friend class KSimpleConfig;
private:
  QString aLocalAppFile;
  QString aGlobalAppFile;
  QString aGroup;
  QString aLocaleString; // locale code
  bool bDirty; // is there any entry that has to be written back to disk?
  bool bLocaleInitialized;
  bool bReadOnly; // currently only used by KSimpleConfig
	bool bExpand; // whether dollar expansion is used

  QDict<KEntryDict> aGroupDict;

#ifndef NDEBUG
  QString aFile;
#endif
  
public:
  KConfigBaseData();
  KConfigBaseData( const char* pGlobalAppFile, const char* pLocalAppFile );
  
  KGroupIterator* groupIterator( void );
};

inline KConfigBaseData::KConfigBaseData() :
    aLocalAppFile(0), aGlobalAppFile(0),
    aGroup("<default>"), aLocaleString(0), bDirty(false),
    bLocaleInitialized(false), bReadOnly(false), bExpand( true ),
	aGroupDict( 37, false )
#ifndef NDEBUG
  , aFile(0)
#endif
{
  aGroupDict.setAutoDelete( true );
}
  
inline KConfigBaseData::KConfigBaseData( const char* pGlobalAppFile,
					 const char* pLocalAppFile ) :
  aLocalAppFile(pLocalAppFile), aGlobalAppFile(pGlobalAppFile), 
  aGroup("<default>"), aLocaleString(0), bDirty(false), 
  bLocaleInitialized(false), bReadOnly(false), aGroupDict( 37, false )
#ifndef NDEBUG
  , aFile(0)
#endif
{
  aGroupDict.setAutoDelete( true );
}

inline KGroupIterator* KConfigBaseData::groupIterator(void)
{
  return new KGroupIterator(aGroupDict);
}


#endif
