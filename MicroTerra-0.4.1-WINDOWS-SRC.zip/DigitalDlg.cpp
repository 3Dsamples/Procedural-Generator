/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: digitaldlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: digitaldlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "DigitalDlg.h"

#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a DigitalDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
DigitalDlg::DigitalDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "DigitalDlg" );
    resize( 456, 325 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Digital Filter" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 150, 280, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 235 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    update_preview = new QPushButton(GroupBox1, "update_preview");
    update_preview->setGeometry(QRect(35, 140, 50, 20)); 
    update_preview->setText(tr("Update"));

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 305, 235 ) ); 
    GroupBox2->setTitle( tr( "Filter Values" ) );

    filter_val_1 = new QSpinBox( GroupBox2, "filter_val_1" );
    filter_val_1->setGeometry( QRect( 20, 20, 45, 20 ) ); 
    filter_val_1->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_1->setMaxValue( 500 );
    filter_val_1->setValue( 25 );

    filter_val_2 = new QSpinBox( GroupBox2, "filter_val_2" );
    filter_val_2->setGeometry( QRect( 75, 20, 45, 20 ) ); 
    filter_val_2->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_2->setMaxValue( 500 );
    filter_val_2->setValue( 25 );

    filter_val_6 = new QSpinBox( GroupBox2, "filter_val_6" );
    filter_val_6->setGeometry( QRect( 20, 45, 45, 20 ) ); 
    filter_val_6->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_6->setMaxValue( 500 );
    filter_val_6->setValue( 25 );

    filter_val_7 = new QSpinBox( GroupBox2, "filter_val_7" );
    filter_val_7->setGeometry( QRect( 75, 45, 45, 20 ) ); 
    filter_val_7->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_7->setMaxValue( 500 );
    filter_val_7->setValue( 100 );

    filter_val_3 = new QSpinBox( GroupBox2, "filter_val_3" );
    filter_val_3->setGeometry( QRect( 130, 20, 45, 20 ) ); 
    filter_val_3->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_3->setMaxValue( 500 );
    filter_val_3->setValue( 25 );

    filter_val_4 = new QSpinBox( GroupBox2, "filter_val_4" );
    filter_val_4->setGeometry( QRect( 185, 20, 45, 20 ) ); 
    filter_val_4->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_4->setMaxValue( 500 );
    filter_val_4->setValue( 25 );

    filter_val_5 = new QSpinBox( GroupBox2, "filter_val_5" );
    filter_val_5->setGeometry( QRect( 240, 20, 45, 20 ) ); 
    filter_val_5->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_5->setMaxValue( 500 );
    filter_val_5->setValue( 25 );

    filter_val_8 = new QSpinBox( GroupBox2, "filter_val_8" );
    filter_val_8->setGeometry( QRect( 130, 45, 45, 20 ) ); 
    filter_val_8->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_8->setMaxValue( 500 );
    filter_val_8->setValue( 200 );

    filter_val_9 = new QSpinBox( GroupBox2, "filter_val_9" );
    filter_val_9->setGeometry( QRect( 185, 45, 45, 20 ) ); 
    filter_val_9->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_9->setMaxValue( 500 );
    filter_val_9->setValue( 100 );

    filter_val_10 = new QSpinBox( GroupBox2, "filter_val_10" );
    filter_val_10->setGeometry( QRect( 240, 45, 45, 20 ) ); 
    filter_val_10->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_10->setMaxValue( 500 );
    filter_val_10->setValue( 25 );

    filter_val_11 = new QSpinBox( GroupBox2, "filter_val_11" );
    filter_val_11->setGeometry( QRect( 20, 70, 45, 20 ) ); 
    filter_val_11->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_11->setMaxValue( 500 );
    filter_val_11->setValue( 25 );

    filter_val_12 = new QSpinBox( GroupBox2, "filter_val_12" );
    filter_val_12->setGeometry( QRect( 75, 70, 45, 20 ) ); 
    filter_val_12->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_12->setMaxValue( 500 );
    filter_val_12->setValue( 200 );

    filter_val_16 = new QSpinBox( GroupBox2, "filter_val_16" );
    filter_val_16->setGeometry( QRect( 20, 95, 45, 20 ) ); 
    filter_val_16->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_16->setMaxValue( 500 );
    filter_val_16->setValue( 25 );

    filter_val_17 = new QSpinBox( GroupBox2, "filter_val_17" );
    filter_val_17->setGeometry( QRect( 75, 95, 45, 20 ) ); 
    filter_val_17->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_17->setMaxValue( 500 );
    filter_val_17->setValue( 100 );

    filter_val_21 = new QSpinBox( GroupBox2, "filter_val_21" );
    filter_val_21->setGeometry( QRect( 20, 120, 45, 20 ) ); 
    filter_val_21->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_21->setMaxValue( 500 );
    filter_val_21->setValue( 25 );

    filter_val_22 = new QSpinBox( GroupBox2, "filter_val_22" );
    filter_val_22->setGeometry( QRect( 75, 120, 45, 20 ) ); 
    filter_val_22->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_22->setMaxValue( 500 );
    filter_val_22->setValue( 25 );

    filter_val_25 = new QSpinBox( GroupBox2, "filter_val_25" );
    filter_val_25->setGeometry( QRect( 240, 120, 45, 20 ) ); 
    filter_val_25->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_25->setMaxValue( 500 );
    filter_val_25->setValue( 25 );

    filter_val_24 = new QSpinBox( GroupBox2, "filter_val_24" );
    filter_val_24->setGeometry( QRect( 185, 120, 45, 20 ) ); 
    filter_val_24->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_24->setMaxValue( 500 );
    filter_val_24->setValue( 25 );

    filter_val_23 = new QSpinBox( GroupBox2, "filter_val_23" );
    filter_val_23->setGeometry( QRect( 130, 120, 45, 20 ) ); 
    filter_val_23->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_23->setMaxValue( 500 );
    filter_val_23->setValue( 25 );

    filter_val_18 = new QSpinBox( GroupBox2, "filter_val_18" );
    filter_val_18->setGeometry( QRect( 130, 95, 45, 20 ) ); 
    filter_val_18->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_18->setMaxValue( 500 );
    filter_val_18->setValue( 200 );

    filter_val_19 = new QSpinBox( GroupBox2, "filter_val_19" );
    filter_val_19->setGeometry( QRect( 185, 95, 45, 20 ) ); 
    filter_val_19->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_19->setMaxValue( 500 );
    filter_val_19->setValue( 100 );

    filter_val_20 = new QSpinBox( GroupBox2, "filter_val_20" );
    filter_val_20->setGeometry( QRect( 240, 95, 45, 20 ) ); 
    filter_val_20->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_20->setMaxValue( 500 );
    filter_val_20->setValue( 25 );

    filter_val_15 = new QSpinBox( GroupBox2, "filter_val_15" );
    filter_val_15->setGeometry( QRect( 240, 70, 45, 20 ) ); 
    filter_val_15->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_15->setMaxValue( 500 );
    filter_val_15->setValue( 25 );

    filter_val_14 = new QSpinBox( GroupBox2, "filter_val_14" );
    filter_val_14->setGeometry( QRect( 185, 70, 45, 20 ) ); 
    filter_val_14->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_14->setMaxValue( 500 );
    filter_val_14->setValue( 200 );

    filter_val_13 = new QSpinBox( GroupBox2, "filter_val_13" );
    filter_val_13->setGeometry( QRect( 130, 70, 45, 20 ) ); 
    filter_val_13->setButtonSymbols( QSpinBox::PlusMinus );
    filter_val_13->setMaxValue( 500 );
    filter_val_13->setValue( 500 );

    Line1 = new QFrame( GroupBox2, "Line1" );
    Line1->setGeometry( QRect( 4, 150, 298, 16 ) ); 
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 9, 170, 85, 20 ) ); 
    lbl1->setText( tr( "Min Elevation" ) );

    lbl2 = new QLabel( GroupBox2, "lbl2" );
    lbl2->setGeometry( QRect( 10, 200, 85, 20 ) ); 
    lbl2->setText( tr( "Max Elevation" ) );

    min_elevation = new QSlider( GroupBox2, "min_elevation" );
    min_elevation->setGeometry( QRect( 100, 170, 150, 20 ) ); 
    min_elevation->setMaxValue( 100 );
    min_elevation->setPageStep( 0 );
    min_elevation->setValue( 33 );
    min_elevation->setOrientation( QSlider::Horizontal );

    max_elevation = new QSlider( GroupBox2, "max_elevation" );
    max_elevation->setGeometry( QRect( 100, 200, 150, 20 ) ); 
    max_elevation->setMaxValue( 100 );
    max_elevation->setPageStep( 0 );
    max_elevation->setValue( 51 );
    max_elevation->setOrientation( QSlider::Horizontal );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 260, 167, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "0.33" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    slid2 = new QLabel( GroupBox2, "slid2" );
    slid2->setGeometry( QRect( 260, 197, 35, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2_font.setBold( TRUE );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "0.51" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

    Line2 = new QFrame( this, "Line2" );
    Line2->setGeometry( QRect( 2, 256, 455, 16 ) ); 
    Line2->setProperty( "frameShape", (int)QFrame::HLine );
    Line2->setFrameShadow( QFrame::Sunken );
    Line2->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line2->setProperty( "frameShape", (int)QFrame::HLine );

	terra = NULL;

    // signals and slots connections
    connect( update_preview, SIGNAL( clicked() ), this, SLOT( update_view() ) );
    connect( filter_val_1, SIGNAL(valueChanged(int)), this, SLOT(filter1Changed()) );
    connect( filter_val_2, SIGNAL(valueChanged(int)), this, SLOT(filter2Changed()) );
    connect( filter_val_3, SIGNAL(valueChanged(int)), this, SLOT(filter3Changed()) );
    connect( filter_val_4, SIGNAL(valueChanged(int)), this, SLOT(filter4Changed()) );
    connect( filter_val_5, SIGNAL(valueChanged(int)), this, SLOT(filter5Changed()) );
    connect( filter_val_6, SIGNAL(valueChanged(int)), this, SLOT(filter6Changed()) );
    connect( filter_val_7, SIGNAL(valueChanged(int)), this, SLOT(filter7Changed()) );
    connect( filter_val_8, SIGNAL(valueChanged(int)), this, SLOT(filter8Changed()) );
    connect( filter_val_9, SIGNAL(valueChanged(int)), this, SLOT(filter9Changed()) );
    connect( filter_val_10, SIGNAL(valueChanged(int)), this, SLOT(filter10Changed()) );
    connect( filter_val_11, SIGNAL(valueChanged(int)), this, SLOT(filter11Changed()) );
    connect( filter_val_12, SIGNAL(valueChanged(int)), this, SLOT(filter12Changed()) );
    connect( filter_val_13, SIGNAL(valueChanged(int)), this, SLOT(filter13Changed()) );
    connect( filter_val_14, SIGNAL(valueChanged(int)), this, SLOT(filter14Changed()) );
    connect( filter_val_15, SIGNAL(valueChanged(int)), this, SLOT(filter15Changed()) );
    connect( filter_val_16, SIGNAL(valueChanged(int)), this, SLOT(filter16Changed()) );
    connect( filter_val_17, SIGNAL(valueChanged(int)), this, SLOT(filter17Changed()) );
    connect( filter_val_18, SIGNAL(valueChanged(int)), this, SLOT(filter18Changed()) );
    connect( filter_val_19, SIGNAL(valueChanged(int)), this, SLOT(filter19Changed()) );
    connect( filter_val_20, SIGNAL(valueChanged(int)), this, SLOT(filter20Changed()) );
    connect( filter_val_21, SIGNAL(valueChanged(int)), this, SLOT(filter21Changed()) );
    connect( filter_val_22, SIGNAL(valueChanged(int)), this, SLOT(filter22Changed()) );
    connect( filter_val_23, SIGNAL(valueChanged(int)), this, SLOT(filter23Changed()) );
    connect( filter_val_24, SIGNAL(valueChanged(int)), this, SLOT(filter24Changed()) );
    connect( filter_val_25, SIGNAL(valueChanged(int)), this, SLOT(filter25Changed()) );
    connect( min_elevation, SIGNAL(valueChanged(int)), this, SLOT(setMinElev(int)) );
    connect( max_elevation, SIGNAL(valueChanged(int)), this, SLOT(setMaxElev(int)) );
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
DigitalDlg::~DigitalDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool DigitalDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev );

    if ( ev->type() == QEvent::ApplicationFontChange )
	{
		QFont slid1_font(  slid1->font() );
		slid1_font.setPointSize( 10 );
		slid1_font.setBold( TRUE );
		slid1->setFont( slid1_font );
		QFont slid2_font(  slid2->font() );
		slid2_font.setPointSize( 10 );
		slid2_font.setBold( TRUE );
		slid2->setFont( slid2_font );
    }
    return ret;
}

void DigitalDlg::update_view()
{
}

void DigitalDlg::filter1Changed()
{
}

void DigitalDlg::filter2Changed()
{
}

void DigitalDlg::filter3Changed()
{
}

void DigitalDlg::filter4Changed()
{
}

void DigitalDlg::filter5Changed()
{
}

void DigitalDlg::filter6Changed()
{
}

void DigitalDlg::filter7Changed()
{
}

void DigitalDlg::filter8Changed()
{
}

void DigitalDlg::filter9Changed()
{
}

void DigitalDlg::filter10Changed()
{
}

void DigitalDlg::filter11Changed()
{
}

void DigitalDlg::filter12Changed()
{
}

void DigitalDlg::filter13Changed()
{
}

void DigitalDlg::filter14Changed()
{
}

void DigitalDlg::filter15Changed()
{
}

void DigitalDlg::filter16Changed()
{
}

void DigitalDlg::filter17Changed()
{
}

void DigitalDlg::filter18Changed()
{
}

void DigitalDlg::filter19Changed()
{
}

void DigitalDlg::filter20Changed()
{
}

void DigitalDlg::filter21Changed()
{
}

void DigitalDlg::filter22Changed()
{
}

void DigitalDlg::filter23Changed()
{
}

void DigitalDlg::filter24Changed()
{
}

void DigitalDlg::filter25Changed()
{
}

void DigitalDlg::setMinElev(int value)
{
}

void DigitalDlg::setMaxElev(int value)
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/