/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: reader.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: reader
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <qmessagebox.h>
#include "base64.h"
#include "reader.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

TReader::TReader()
{
}

TReader::~TReader()
{
}

TTerrain *TReader::t_terrain_load(char *filename, TFileType type)
{
	if (type == FILE_AUTO)
	{
		FilenameOps *fno = new FilenameOps();
		type = fno->filename_determine_type(filename);
		delete fno;
	}

  if (type == FILE_NATIVE)
    return t_terrain_load_native(filename);
  else if (type == FILE_BMP || type == FILE_BMP_BW)
    return t_terrain_import_bmp(filename);
  else if (type == FILE_TGA)
    return t_terrain_import_tga(filename);
  else if (type == FILE_GTOPO)
    return t_terrain_import_gtopo(filename, 10);
  else if (type == FILE_GRD)
    return t_terrain_import_grd(filename);
  else if (type == FILE_MAT)
    return t_terrain_import_mat(filename);
  else if (type == FILE_OCT)
    return t_terrain_import_oct(filename);
  else if (type == FILE_PGM || type == FILE_PG8)
    return t_terrain_import_pgm(filename);
  else if (type == FILE_GIF || type == FILE_ICO || type == FILE_JPG ||
           type == FILE_PNG || type == FILE_RAS || type == FILE_TIF ||
           type == FILE_XBM || type == FILE_XPM)
    return t_terrain_import_gdk_pixbuf(filename);
  else if (type == FILE_TERRAGEN)
    return t_terrain_import_terragen(filename);
  else if (type == FILE_XYZ)
    return t_terrain_import_xyz(filename);
  else if (type == FILE_DXF)
    return t_terrain_import_dxf(filename);
  else if (type == FILE_BNA)
    return t_terrain_import_bna(filename);
  else if (type == FILE_BT)
    return t_terrain_import_bt(filename);
  else if (type == FILE_DTED)
    return t_terrain_import_dted(filename);
  else if (type == FILE_E00)
    return t_terrain_import_e00grid(filename);

  return NULL;
}

void TReader::heightfield_load_data(float **heightfield, int width, int height, FILE *fp)
{
	int y;

	for (y = 0; y < height; y++)
    {
		uchar  *data;
		int     length;
		int     le;
		char   *content;

		if ((fread(&le, 4, 1, fp)) == 1) {}
		if ((fread(&content, le, 1, fp)) == 1) {}

		data = (uchar*) &heightfield[y * width];
		length = base64_decode((uchar *)content, data, width * 4);

//      for (x = 0; x < width; x++)
//        data[x] = GUINT32_FROM_LE (data[x]);

    }
}

TTerrain *TReader::heightfield_load(FILE *fp)
{
	TTerrain   *terrain;
	int         width, height;

	width = -1; height = -1;
	if ((fread(&width, 4, 1, fp)) == 1) {}
	if ((fread(&height, 4, 1, fp)) == 1) {}

	terrain = new TTerrain(width, height);

	heightfield_load_data(&terrain->heightfield, width, height, fp);

	return terrain;
}

void options_load (TTerrain *terrain, FILE *fp)
{
	if ((fread(&terrain->render_options.camera_x, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.camera_y, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.camera_z, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.lookat_x, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.lookat_y, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.lookat_z, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.elevation_offset, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.do_observe_sealevel, 1, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.do_clouds, 1, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.do_fog, 1, 1, fp)) == 1) {}
	if ((fread(&terrain->do_filled_sea, 1, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.time_of_day, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.north_direction, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->render_options.water_clarity, 4, 1, fp)) == 1) {}
//	if ((fread(&terrain->render_width, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->y_scale_factor, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->sealevel, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->wireframe_resolution, 4, 1, fp)) == 1) {}
//	if ((fread(&terrain->render_options.theme_file, 4, 1, fp)) == 1) {}
//	if ((fread(&terrain->render_options.lighting_level, 4, 1, fp)) == 1) {}
	if ((fread(&terrain->contour_levels, 4, 1, fp)) == 1) {}
}
 
float* selection_load(TTerrain *terrain, FILE *fp)
{
/*	int width, height;

	width = -1; height = -1;
	if ((fread(&width, 4, 1, fp)) == 1) {}
	if ((fread(&height, 4, 1, fp)) == 1) {}

	if (terrain->selection == NULL)
		terrain->selection = new float(width*height);

	heightfield_load_data(terrain->selection, width, height, fp);

	return terrain->selection;*/return NULL;
}

void objects_load(TTerrain *terrain, FILE *fp)
{
/*	int cnt;
	
	if ((fread(&cnt, 4, 1, fp)) == 1) {}
	for (int i=0; i<cnt;i++)
    {
		TTerrainObject object;

		object.name = g_strdup (xmlGetProp (child, "name"));
		xml_unpack_prop_int (child, "ox", &object.ox);
		xml_unpack_prop_int (child, "oy", &object.oy);
		xml_unpack_prop_float (child, "x", &object.x);
		xml_unpack_prop_float (child, "y", &object.y);
		xml_unpack_prop_float (child, "angle", &object.angle);
		xml_unpack_prop_float (child, "scale_x", &object.scale_x);
		xml_unpack_prop_float (child, "scale_y", &object.scale_y);
		xml_unpack_prop_float (child, "scale_z", &object.scale_z);

		terrain->t_terrain_add_object(object.ox, object.oy, object.x, object.y, object.angle, object.scale_x, object.scale_y, object.scale_z, object.name);

		delete object.name;
    }*/
}

TTerrain *TReader::t_terrain_load_native(char *filename)
{
	FILE          *fp;
	TTerrain      *terrain;
	unsigned char  ch4[4];
	unsigned char  ch7[7];

	fp = fopen(filename, "rb");
	if ((fread(&ch7, 7, 1, fp)) == 1) {}
	if (strcmp((char *)ch7, "TERRAIN") != 0)     // file corrupt
    {
		fclose(fp);
		return NULL;
    }

	if ((fread(&ch4, 4, 1, fp)) == 1) {}
	if (strcmp((char *)ch4, "HEIG") != 0)        // file corrupt
    {
		fclose(fp);
		return NULL;
    }

	terrain = NULL;
    terrain = heightfield_load(fp);

	if (terrain != NULL)
    {
		if ((fread(&ch4, 4, 1, fp)) == 1) {}
		if (strcmp((char *)ch4, "OPTS") != 0)        // file corrupt
		{
			fclose(fp);
			return NULL;
		}
		options_load(terrain, fp);
/*		if ((fread(&ch4, 4, 1, fp)) == 1) {}
		if (strcmp(ch4, "OBJS") != 0)        // file corrupt
		{
			fclose(fp);
			return NULL;
		}
		objects_load(terrain, node);
		if ((fread(&ch4, 4, 1, fp)) == 1) {}
		if (strcmp(ch4, "SELS") != 0)        // file corrupt
		{
			fclose(fp);
			return NULL;
		}
		selection_load(terrain, fp);*/

		delete (char *)terrain->filename;
		terrain->filename = strdup(filename);
    }

	return terrain;
}

/* ********************************************** */
/* **** Based on the bmp code from the GIMP  **** */
/* ********************************************** */
/* bmp.c                                          */
/* Version 0.44                                   */
/* This is a File input and output filter for     */
/* Gimp. It loads and saves images in windows(TM) */
/* bitmap format.                                 */
/* Some Parts that deal with the interaction with */
/* the Gimp are taken from the GIF plugin by      */
/* Peter Mattis & Spencer Kimball and from the    */
/* PCX plugin by Francisco Bustamante.            */
/*                                                */
/* Alexander.Schulz@stud.uni-karlsruhe.de         */

/* Changes:   28.11.1997 Noninteractive operation */
/*            16.03.1998 Endian-independent!!     */
/*            21.03.1998 Little Bug-fix           */
/*            06.04.1998 Bugfix in Padding        */
/*            11.04.1998 Arch. cleanup (-Wall)    */
/*                       Parses gtkrc             */
/*            14.04.1998 Another Bug in Padding   */
/* ********************************************** */

typedef struct BmpFileHead BmpFileHead;
struct BmpFileHead
{
  unsigned int bfSize;         /* 02 */
  unsigned int reserved;       /* 06 */
  unsigned int bfOffs;         /* 0A */
  unsigned int biSize;         /* 0E */
};

typedef struct BmpHead BmpHead;
struct BmpHead
{
  unsigned int biWidth;        /* 12 */
  unsigned int biHeight;       /* 16 */
  unsigned short biPlanes;       /* 1A */
  unsigned short biBitCnt;       /* 1C */
  unsigned int biCompr;        /* 1E */
  unsigned int biSizeIm;       /* 22 */
  unsigned int biXPels;        /* 26 */
  unsigned int biYPels;        /* 2A */
  unsigned int biClrUsed;      /* 2E */
  unsigned int biClrImp;       /* 32 */
                          /* 36 */
};

typedef struct BmpOS2Head BmpOS2Head;
struct BmpOS2Head
{
  unsigned short bcWidth;        /* 12 */
  unsigned short bcHeight;       /* 14 */
  unsigned short bcPlanes;       /* 16 */
  unsigned short bcBitCnt;       /* 18 */
};

static int bmp_read_palette(FILE *in, unsigned char buffer[256][3], int count, int size)
{
	int   i;
	unsigned char rgb[4];

	for (i = 0; i < count; i++)
    {
		if (fread (&rgb, size, 1, in) != 1)
        {
			/* Failure. */
			return -1;
        }

		/* Bitmap save the colors in another order! */
		/* But change only once! */
		if (size == 4)
        {
			buffer[i][0] = rgb[2];
			buffer[i][1] = rgb[1];
			buffer[i][2] = rgb[0];
        }
		else
        {
			/* this one is for old os2 Bitmaps, but it dosn't work well */
			buffer[i][0] = rgb[1];
			buffer[i][1] = rgb[0];
			buffer[i][2] = rgb[2];
        }
    }

	return 0;
}

static TTerrain *bmp_read_image(FILE *in, int width, int height, unsigned char palette[256][3], int color_count, int bpp, int compression, int stride)
{
	int            i, j, x, y, size;
	unsigned char *image;
	unsigned char  buf[3];
	int            shift_right, mask;
	TTerrain      *terrain;
	unsigned char *pos;

	if (bpp == 24)
    {
		image = new unsigned char[width * height * 3];

		for (y = 0; y < height; y++)
        {
			pos = &image[(height - y - 1) * width * 3];
			for (x = 0; x < width; x++)
            {
				fread (buf, 3, 1, in);
				pos[0] = buf[2];
				pos[1] = buf[1];
				pos[2] = buf[0];
				pos += 3;
            }

			for (x = 0; x < stride - width * 3; x++)
				fgetc (in);
        }
    }
	else
    {
		image = new unsigned char[width * height];
		shift_right = 8 - bpp;
		mask = (1 << bpp) - 1;

		switch (compression)
        {
        case 0: /* Uncompressed. */
			for (y = 0; y < height; y++)
            {
				pos = &image[(height - y - 1) * width];
				for (x = 0; x < width;)
                {
					unsigned int c;

					c = fgetc (in);
					for (i = 0; i < 8 / bpp && x < width; i++, x++)
                    {
						*pos = (c >> shift_right) & mask;
						pos++;
						c <<= bpp;
                    }
                }

				for (i = 0; i < (stride - width) / (8 / bpp); i++)
					fgetc (in);
            }
			break;

        default: /* Compressed. */
			for (y = 0; y < height; y++)
            {
				pos = &image[(height - y - 1) * width];
				for (x = 0; x < width;)
                {
					fread (buf, 2, 1, in);
					if (ferror (in))
                    {
						delete image;
						return NULL;
                    }

					if (buf[0] != 0) /* Count + Color record. */
                    {
						for (i = 0; i < buf[0] && x < width; i++)
                        {
							signed int c;

							c = buf[1];
							for (j = 0; j < (8 / bpp) && x < width; j++, x++)
                            {
								*pos = (c >> shift_right) & mask;
								pos++;
								c <<= bpp;
                            }
                        }
                    }
					else if (buf[1] > 2) /* Uncompressed record. */
                    {
						for (i = 0; i < buf[1] && x < width; i++)
                        {
							signed int c;

							c = fgetc (in);
							for (j = 0; j < (8 / bpp) && x < width; j++, x++)
                            {
								*pos = (c >> shift_right) & mask;
								pos++;
								c <<= bpp;
                            }
                        }

						if (((buf[1] / (8 / bpp)) & 1) != 0)
							fgetc (in);
                    }

                  /* Row end */
					if (buf[0] == 0 && buf[1] == 0)
						y++, x = 0;

                  /* Bitmap end */
					if (buf[0] == 0 && buf[1] == 1)
                    {
						y = height;
						x = width;
						break;
                    }

                  /* Delta record */
					if (buf[0] == 0 && buf[1] == 2)
                    {
						x += fgetc (in);
						y += fgetc (in);
                    }
                }
            }
        }
    }

	if (ferror (in))
    {
		delete image;

		return NULL;
    }

	terrain = new TTerrain(width, height);

	size = width * height;
	if (bpp == 24)
    {
		for (i = 0; i < size; i++)
			terrain->heightfield[i] = (image[i * 3 + 0] * 256.0 + image[i * 3 + 1]) / MAX_16_BIT;
    }
	else
    {
		for (i = 0; i < size; i++)
	        terrain->heightfield[i] = ((int) palette[image[i]][0] + palette[image[i]][1] + palette[image[i]][2]) / 3.0 / 256.0;
    }

	delete image;

	return terrain;
}

TTerrain *TReader::t_terrain_import_bmp(char *filename)
{
	FILE          *in;
	char           buf[5];
	int            palette_size, stride, maps;
	unsigned char  palette[256][3];
	BmpFileHead    bmp_file_head;
	BmpHead        bmp_head;
	BmpOS2Head     bmp_os2_head;
	TTerrain      *terrain;

	in = fopen(filename, "rb");
	if (!in)
		return NULL;

	/* Now is it a Bitmap? */
	if (fread (buf, 2, 1, in) != 1 || strncmp (buf, "BM", 2) != 0)
    {
		fclose (in);
		return NULL;
    }

	/* How long is the Header? */
	if (fread (&bmp_file_head, sizeof (bmp_file_head), 1, in) != 1)
    {
      fclose (in);
      return NULL;
    }

	/* bring them to the right byteorder. Not too nice, but it should work */
	bmp_file_head.bfSize = bmp_file_head.bfSize;
	bmp_file_head.reserved = bmp_file_head.reserved;
	bmp_file_head.bfOffs = bmp_file_head.bfOffs;
	bmp_file_head.biSize = bmp_file_head.biSize;

	/* Is it a Windows (tm) Bitmap or not */
	if (bmp_file_head.biSize != 40)
    {
		/* OS/2 not supported, but load anyway. */
		if (fread (&bmp_os2_head, sizeof (bmp_os2_head), 1, in) != 1)
        {
			fclose (in);
			return NULL;
        }

		bmp_os2_head.bcWidth = bmp_os2_head.bcWidth;
		bmp_os2_head.bcHeight = bmp_os2_head.bcHeight;
		bmp_os2_head.bcPlanes = bmp_os2_head.bcPlanes;
		bmp_os2_head.bcBitCnt = bmp_os2_head.bcBitCnt;
		bmp_file_head.bfSize = (bmp_file_head.bfSize * 4) - bmp_file_head.bfOffs * 3;

		bmp_head.biHeight = bmp_os2_head.bcHeight;
		bmp_head.biWidth = bmp_os2_head.bcWidth;
		bmp_head.biClrUsed = 0;
		bmp_head.biCompr = 0;
		maps = 3;
    }
	else
    {
		if (fread (&bmp_head, sizeof (bmp_head), 1, in) != 1)
        {
			fclose (in);
			return NULL;
        }

		bmp_head.biWidth = bmp_head.biWidth;
		bmp_head.biHeight = bmp_head.biHeight;
		bmp_head.biPlanes = bmp_head.biPlanes;
		bmp_head.biBitCnt = bmp_head.biBitCnt;
		bmp_head.biCompr = bmp_head.biCompr;
		bmp_head.biSizeIm = bmp_head.biSizeIm;
		bmp_head.biXPels = bmp_head.biXPels;
		bmp_head.biYPels = bmp_head.biYPels;
		bmp_head.biClrUsed = bmp_head.biClrUsed;
		bmp_head.biClrImp = bmp_head.biClrImp;

		maps = 4;
    }

	/* This means wrong file Format. I test this because it could crash */
	if (bmp_head.biBitCnt > 24)
    {
		fclose (in);
		return NULL;
    }

	/* There should be some colors used! */
	palette_size = (bmp_file_head.bfOffs - bmp_file_head.biSize - 14) / maps;
	if (bmp_head.biClrUsed == 0 && bmp_head.biBitCnt < 24)
		bmp_head.biClrUsed = palette_size;

	if (bmp_head.biBitCnt == 24)
		stride = (bmp_file_head.bfSize - bmp_file_head.bfOffs) / bmp_head.biHeight;
	else
		stride = (bmp_file_head.bfSize - bmp_file_head.bfOffs) / bmp_head.biHeight * (8 / bmp_head.biBitCnt);

	/* Get the Colormap */
	if (bmp_read_palette (in, palette, palette_size, maps) != 0)
    {
		fclose (in);
		return NULL;
    }

	/* Get the Image and return the terrain. */
	terrain = bmp_read_image (in, bmp_head.biWidth, bmp_head.biHeight, palette, bmp_head.biClrUsed, bmp_head.biBitCnt, bmp_head.biCompr, stride);

	fclose (in);

	return terrain;
}

TTerrain *TReader::t_terrain_import_gtopo(char *filename, int scale)
{
	return NULL;
}

TTerrain *TReader::t_terrain_import_mat(char *filename)
{
	return NULL;
}

TTerrain *TReader::t_terrain_import_oct(char *filename)
{
	return NULL;
}

/*
 * The TGA reading code has been adapted from the plug-ins/common/tga.c
 * file shipped with the GIMP (1.1.17).
 *
 * Release 1.2, 1997-09-24, Gordon Matzigkeit <gord@gnu.ai.mit.edu>:
 *   - Bug fixes and source cleanups.
 */
#define RLE_PACKETSIZE 0x80

struct tga_header
{
  unsigned char id_length;
  unsigned char color_map_type;

  /* The image type. */
#define TGA_TYPE_MAPPED      1
#define TGA_TYPE_COLOR       2
#define TGA_TYPE_GRAY        3
#define TGA_TYPE_MAPPED_RLE  9
#define TGA_TYPE_COLOR_RLE  10
#define TGA_TYPE_GRAY_RLE   11
  unsigned char   image_type;

  /*
   * Color Map Specification. We need to separately specify
   * High and Low bytes to avoid endianness and alignment problems.
   */

  unsigned char color_map_index_lo;
  unsigned char color_map_index_hi;
  unsigned char color_map_length_lo;
  unsigned char color_map_length_hi;
  unsigned char color_map_size;

  /* Image Specification. */
  unsigned char x_origin_lo;
  unsigned char x_origin_hi;
  unsigned char y_origin_lo;
  unsigned char y_origin_hi;

  unsigned char width_lo;
  unsigned char width_hi;
  unsigned char height_lo;
  unsigned char height_hi;

  unsigned char bpp;
  /* Image descriptor.
    3-0: attribute bpp
    4:   left-to-right ordering
    5:   top-to-bottom ordering
    7-6: zero
  */
#define TGA_DESC_ABITS      0x0f
#define TGA_DESC_HORIZONTAL 0x10
#define TGA_DESC_VERTICAL   0x20
  unsigned char descriptor;
};


#define TGA_SIGNATURE "TRUEVISION-XFILE"
static struct
{
  unsigned int extensionAreaOffset;
  unsigned int developerDirectoryOffset;
  char   signature[16];
  char   dot;
  char   null;
} tga_footer;


/*
 *  tga_standard_fread: read in a bufferful of file
 */

static int tga_standard_fread(unsigned char *buf, int datasize, int nelems, FILE *in)
{
  return fread (buf, datasize, nelems, in);
}


/*
 *  tga_rle_fread: decode a bufferful of file
 */
static int tga_rle_fread(unsigned char *buf, int datasize, int nelems, FILE *in)
{
  unsigned char *statebuf = NULL;
  int    statelen = 0;
  int    laststate = 0;
  int    j, k;
  int    buflen, count, bytes;
  unsigned char *p;

  /* Scale the buffer length. */
  buflen = nelems * datasize;

  j = 0;
  while (j < buflen)
    {
      if (laststate < statelen)
        {
          /* Copy bytes from our previously decoded buffer. */
          bytes = MIN (buflen - j, statelen - laststate);
          memcpy (buf + j, statebuf + laststate, bytes);
          j += bytes;
          laststate += bytes;

          /* If we used up all of our state bytes, then reset them. */
          if (laststate >= statelen)
            {
              laststate = 0;
              statelen = 0;
            }

          /* If we filled the buffer, then exit the loop. */
          if (j >= buflen)
            break;
        }

      /* Decode the next packet. */
      count = fgetc (in);
      if (count == EOF)
        return j / datasize; /* No next packet. */

      /* Scale the byte length to the size of the data. */
      bytes = ((count & ~RLE_PACKETSIZE) + 1) * datasize;

      if (j + bytes <= buflen)
        {
          /* We can copy directly into the image buffer. */
          p = buf + j;
        }
      else
        {
          /* Allocate the state buffer if we haven't already. */
          if (!statebuf)
            statebuf = (unsigned char *)new unsigned char *[RLE_PACKETSIZE * datasize];
          p = statebuf;
        }

      if (count & RLE_PACKETSIZE)
        {
          /* Fill the buffer with the next value. */
          if (fread (p, datasize, 1, in) != 1)
            return j / datasize;

          /* Optimized case for single-byte encoded data. */
          if (datasize == 1)
            memset (p + 1, *p, bytes - 1);
          else
            for (k = datasize; k < bytes; k += datasize)
              memcpy (p + k, p, datasize);
        }
      else
        {
          /* Read in the buffer. */
          if (fread (p, bytes, 1, in) != 1)
            return j / datasize;
        }

      /* We may need to copy bytes from the state buffer. */
      if (p == statebuf)
        statelen = bytes;
      else
        j += bytes;
    }

  return nelems;
}


static TTerrain *tga_read_image(FILE *in, struct tga_header *hdr)
{
  TTerrain  *terrain;
  unsigned char    *data;
  int        width, height, bpp, pbpp;
  int        i, j;
  int        pelbytes=3, tileheight, wbytes, bsize, npels, pels;
  int        rle, badread;

  int (*myfread)(unsigned char *, int, int, FILE *);

  /*
   * Find out whether the image is horizontally or vertically reversed
   * We like things left-to-right, top-to-bottom.
   */
  char horzrev = hdr->descriptor & TGA_DESC_HORIZONTAL;
  char vertrev = !(hdr->descriptor & TGA_DESC_VERTICAL);

  /* Byteswap header values. */
  width = hdr->width_lo | (hdr->width_hi << 8);
  height = hdr->height_lo | (hdr->height_hi << 8);
  bpp = hdr->bpp;

  if ((hdr->descriptor & TGA_DESC_ABITS) != 0)
    {
		QString aboutMsg = "Sorry, Terraform cannot load TGA files with alpha channels.\n";
		QMessageBox::about( NULL, "MicroTerra", aboutMsg);
		return NULL;
    }

  if (hdr->image_type == TGA_TYPE_COLOR ||
      hdr->image_type == TGA_TYPE_COLOR_RLE)
    pbpp = MIN (bpp / 3, 8) * 3;
  else
    pbpp = bpp;

  rle = 0;
  switch (hdr->image_type)
    {
    case TGA_TYPE_MAPPED_RLE:
      rle = 1;

    case TGA_TYPE_MAPPED:
      printf ("Sorry, Terraform cannot load paletted TGA images.\n");
      return NULL;
      break;

    case TGA_TYPE_GRAY_RLE:
      rle = 1;

    case TGA_TYPE_GRAY:
      break;

    case TGA_TYPE_COLOR_RLE:
      rle = 1;

    case TGA_TYPE_COLOR:
      break;

    default:
      //printf ("TGA: unrecognized image type %d\n", hdr->image_type);
      return NULL;
  }

  if (hdr->color_map_type != 0)
    {
      //printf ("TGA: non-indexed image has invalid color map type %d\n", hdr->color_map_type);
      return NULL;
    }

  /* Calculate TGA bytes per pixel. */
  bpp = (pbpp + 7) / 8;

  /* Allocate the data. */
  tileheight = height;
  data = (unsigned char *)new unsigned char *[width * tileheight * pelbytes];

  if (rle)
    myfread = tga_rle_fread;
  else
    myfread = tga_standard_fread;

  wbytes = width * pelbytes;
  badread = 0;
  for (i = 0; i < height; i += tileheight)
    {
      tileheight = MIN (tileheight, height - i);

      npels = width * tileheight;
      bsize = wbytes * tileheight;

      /* Suck in the data one tileheight at a time */
      if (badread)
        pels = 0;
      else
        pels = (*myfread) (data, bpp, npels, in);

      if (pels != npels)
        {
          if (!badread)
            {
              /* Probably premature end of file. */
              //printf ("TGA: error reading (ftell == %ld)\n", ftell (in));
              badread = 1;
            }

          /* Fill the rest of this tile with zeros. */
          memset (data + (pels * bpp), 0, ((npels - pels) * bpp));
        }

      if (pelbytes >= 3)
        {
          /* Rearrange the colors from BGR to RGB. */
          for (j = 0; j < bsize; j += pelbytes)
            {
              int tmp;

              tmp = data[j];
              data[j] = data[j + 2];
              data[j + 2] = tmp;
            }
        }
    }

  if (fgetc (in) != EOF)
  {}//printf ("TGA: too much input data, ignoring extra...\n");

  /* Allocate new HF */
  terrain = new TTerrain(width, height);

  /* Convert tga data to HF data. */
  if (bpp == 3)
    {
      int pos, size;

      pos = 0;
      size = width * height;
      for (i = 0; i < size; i++)
        {
          short red;
          short green;

          red = data[pos + 0];
          green = data[pos + 1];

          terrain->heightfield[i] = (red * 256.0 + green) / MAX_16_BIT;
          pos += 3;
        }
    }
  else if (bpp == 1)
    {
      int i, size;

      size = width * height;
      for (i = 0; i < size; i++)
        terrain->heightfield[i] = data[i] / 256.0;
    }
  else
    return NULL;

  if (vertrev && horzrev)
    t_terrain_rotate(terrain, 1);
  else if (vertrev)
    t_terrain_mirror(terrain, 1);
  else if (horzrev)
    t_terrain_mirror(terrain, 0);

  delete data;

  return terrain;
}
 
TTerrain *TReader::t_terrain_import_tga(char *filename)
{
  struct tga_header hdr;
  FILE     *in;
  TTerrain *terrain;

  in = fopen (filename, "rb");
  if (!in)
    return NULL;

  /* Check the footer */
  if (fseek (in, 0L - (sizeof (tga_footer)), SEEK_END)
      || fread (&tga_footer, sizeof (tga_footer), 1, in) != 1)
    {
      /* Couldn't read footer. */
      fclose (in);
      return NULL;
    }

  /* Load the header */
  if (fseek (in, 0, SEEK_SET) || fread (&hdr, sizeof (hdr), 1, in) != 1)
    {
      fclose (in);
      return NULL;
    }

  /* Skip the image ID field. */
  if (hdr.id_length && fseek (in, hdr.id_length, SEEK_CUR))
    {
      fclose (in);
      return NULL;
    }

  terrain = tga_read_image (in, &hdr);

  fclose (in);

  return terrain; 
}

TTerrain *TReader::t_terrain_import_pgm(char *filename)
{
	return NULL;
}

TTerrain *TReader::t_terrain_import_gdk_pixbuf(char *filename)
{
	return NULL;
}

/* 
 * This code is based on the bmp2ter utililty, originally written by 
 * Alistair Milne. I also found a description of the file format at 
 *   http://www.planetside.co.uk/terragen/dev/tgterrain.html
 * which made it possible to implement the complete spec. 
 */

/* required header fields */
typedef struct terragen_header terragen_header;
struct terragen_header
{
	char      magic[16];
	char      size_marker[4];
	uint16    size;
	uint16    pad1;
	char      xpts_marker[4];
	uint16    xpts;
	uint16    pad2;
	char      ypts_marker[4];
	uint16    ypts;
	uint16    pad3;
};

TTerrain *TReader::t_terrain_import_terragen(char *filename)
{
	TTerrain       *terrain = NULL;

	FILE           *in;
	char           ch2[2];
	int            height;
	int            width;
	int            size;
//  int16      	 word;
	int            i;

	/* data fields to read; mostly unused */
	char           marker[4];
	float          scale[3];
	float          radius;
	bool           found_data;
	int32          curvature_mode;
	int16          heightscale=-1;
	int16          baseheight=-1;
	terragen_header theader;

	in = fopen (filename, "rb");
	if (!in)
		return NULL;

	/* *** check read *** */
	if (fread(&theader, sizeof(terragen_header), 1, in) != 1)
	{
		fclose (in);
		return NULL;
	}

	width = theader.xpts;
	height = theader.ypts;
	size = theader.size;

	found_data = false;
	while (!found_data)
    {
		if (fread (marker, 4, 1, in) != 1)
		{
			fclose (in);
			return NULL;
		}

		if (!strncmp (marker, "SCAL", 4))
			fread (&scale, sizeof(float), 3, in);  /* x, y, z */
		else if (!strncmp (marker, "CRAD", 4))
			fread (&radius, sizeof(float), 1, in); 
		else if (!strncmp (marker, "CRVM", 4))
			fread (&curvature_mode, sizeof(float), 1, in); 
		else if (!strncmp (marker, "ALTW", 4))
		{
			fread (&heightscale, sizeof(int), 1, in); 
			fread (&baseheight, sizeof(int), 1, in); 
			found_data = true;
		}

    }

	/*
	printf ("height = %d\n", height);
	printf ("width = %d\n", width);
	printf ("size = %d\n", size);
	printf ("scale = %f, %f, %f\n", scale[0], scale[1], scale[2]);
	printf ("heightscale = %d\n", heightscale);
	printf ("baseheight = %d\n", baseheight);
	*/
 
	terrain = new TTerrain(width, height);

	size = height*width;
	for (i=0; i<size; i++)
	{
		if ((fread(&ch2, 2, 1, in)) == 1) {terrain->heightfield[i] = (float)(((int)ch2[1]) * 256) + ((int)ch2[0]);}
	}

	terrain->t_terrain_normalize(true);

	/* terragen has a different coordinate system. Mirroring the HF 
	 * creates a display identical to the terragen terrain window */
	t_terrain_mirror(terrain, 1);

	fclose (in);
	return terrain;
}

TTerrain *TReader::t_terrain_import_grd(char *filename)
{
	return NULL;
}

TTerrain *TReader::t_terrain_import_xyz(char *filename)
{
	return NULL;
}

TTerrain *TReader::t_terrain_import_dxf(char *filename)
{
	return NULL;
}

TTerrain *TReader::t_terrain_import_bna(char *filename)
{
	return NULL;
}

TTerrain *TReader::t_terrain_import_bt(char *filename)
{
	return NULL;
}

TTerrain *TReader::t_terrain_import_dted(char *filename)
{
	return NULL;
}

TTerrain *TReader::t_terrain_import_e00grid(char *filename)
{
	return NULL;
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/