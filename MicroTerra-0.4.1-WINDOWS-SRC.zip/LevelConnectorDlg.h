/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: levelconnectordlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: levelconnectordlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef LEVELCONNECTORDLG_H
#define LEVELCONNECTORDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/
#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSpinBox;

class LevelConnectorDlg : public QDialog
{ 
    Q_OBJECT

public:
    LevelConnectorDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~LevelConnectorDlg();

    QPushButton* OK;
    QPushButton* CANCEL;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QGroupBox* GroupBox2;
    QSpinBox* count;
    QLabel* lbl1;
    QFrame* Line1;
	TTerrain *terra;

public slots:
	virtual void iterChanged();

protected:
    QHBoxLayout* Layout1;
};

#endif // LEVELCONNECTORDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 01-12-2004
 *   - created
 *
 ***********************************************************************************************************************/