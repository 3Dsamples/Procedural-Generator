/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: tterrain.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: tterrain
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <math.h>
#include "tterrain.h"
#include "mt.h"
#include "filenameops.h"
#include "ksimpleconfig.h"

/** ***************************************************************************************************************** **/
/**				          MACROS				                                                                      **/
/** ***************************************************************************************************************** **/

#define CLIP(x,m,M) MAX(MIN(x,M),m)
#define SQR(x)      ((x)*(x))

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

TTerrain::TTerrain() : heightfield(0)
{
	t_terrain_init();
	width = 400;
	height = 400;
	render_options.render_width = width;
	heightfield = new float[(width * height)];
}

TTerrain::TTerrain(int w, int h) : heightfield(0)
{
	y_scale_factor = ((float)0.33);
	t_terrain_init();
	width = w;
	height = h;
	heightfield = new float[(width * height)];
	render_options.render_width = w;
}

TTerrain::~TTerrain()
{
}

void TTerrain::t_terrain_init()
{
	KSimpleConfig aConfig("./microterra.cfg");

	aConfig.setGroup("Options");
	camera_height_factor = (float)(aConfig.readNumEntry("camera_height_factor", 33)/100.0);
	contour_levels = (aConfig.readNumEntry("levels", 10));
	do_filled_sea = (aConfig.readBoolEntry("filled_sea", true));
	sealevel = (float)(aConfig.readNumEntry("sealevel", 33)/100.0);
	wireframe_resolution = (aConfig.readNumEntry("wireframe_resolution", 10));
	y_scale_factor = (float)(aConfig.readNumEntry("y_scale_factor", 33)/100.0);

	filename = "untitled";
	heightfield = 0;
	selection = 0;
	width = 0;
	height = 0;
	modified = false;
	autogenned = false;

	objects = new AR_Object();
	riversources = new AR_River();
	riverfield = NULL;

	render_options.do_clouds = true;
	render_options.do_fog = false;
	render_options.do_ground_fog = false;
	render_options.do_observe_sealevel = true;
	render_options.do_rainbow = false;
	render_options.camera_x = 0.500000;
	render_options.camera_y = 2.500000;
	render_options.camera_z = -1.250000;
	render_options.lookat_x = 0.500000;
	render_options.lookat_y = 0.0;
	render_options.lookat_z = 0.500000;
	render_options.elevation_offset = ((float)0.100000);
	render_options.fog_alt = 0.250000;
	render_options.fog_density = 0.250000;
	render_options.fog_offset = ((float)0.330000);
	render_options.fog_turbulence = ((float)0.330000);
	render_options.time_of_day = 12.000000;
	render_options.north_direction = 0.0;
	render_options.water_clarity = ((float)0.650000);
	render_options.render_scale_x = 1000;
	render_options.render_scale_y = 1000 * y_scale_factor;
	render_options.render_scale_z = 1000;

	render_options.atmosphere_file = "earth_fog.inc";
	render_options.cloud_file = "clouds_01.inc";
	render_options.image_size_string = "320x240";
	render_options.povray_filename = "";
	render_options.sky_file = "earth_regular_sky.inc";
	render_options.star_file = "stars_01.inc";
	render_options.texture_file = "earth_green_landscape.inc";
	render_options.water_file = "earth_water.inc";

	render_options.do_aa = false;
	render_options.do_custom_size = false;
	render_options.do_jitter = false;
	render_options.filetype = 0;          /* 0 = png */
	render_options.image_width = 320;
	render_options.image_height = 240;
	render_options.render_quality = 9;
	render_options.aa_depth = 1.000000;
	render_options.aa_threshold = ((float)0.300000);
	render_options.aa_type = 0;
	render_options.jitter_amount = 0.500000;
}

void TTerrain::t_terrain_set_filename(char *fname)
{
	if (filename != fname)
    {
//		delete filename;
		filename = strdup(fname);
//		gtk_signal_emit (GTK_OBJECT (terrain), title_modified_signal);
    }
}
 
void TTerrain::t_terrain_set_modified(bool modifi)
{
  if (modified != modifi)
    {
      modified = modifi;
//      gtk_signal_emit (GTK_OBJECT (terrain), title_modified_signal);
    }
}

void TTerrain::t_terrain_normalize(bool never_grow)
{
  int    i, last;
  float  min, max;
  float *data;

  data = heightfield;
  last = width * height;

  /*
   * When never_grow is true, normalize assumes that if the minimum
   * and maximum value range of the terrain is smaller than [0.0, 1.0],
   * the user wants it that way.
   */

  if (never_grow)
    min = 0.0, max = 1.0;
  else
    min = max = data[0];

  for (i = 0; i < last; i++)
    {
      if (data[i] < min) min = data[i];
      if (data[i] > max) max = data[i];
    }

  if (fabs (max - min) > 0.0001)
    {
      float k;

      k = 1.0 / (max - min);
      for (i = 0; i < last; i++)
        data[i] = (data[i] - min) * k;

      if (never_grow)
        sealevel = MIN (MAX ((sealevel - min) * k, 0.0), 1.0);
    }
}

void TTerrain::t_terrain_crop(int x1, int y1, int x2, int y2)
{ 
  int    from_x, from_y;
  int    to_x, to_y;
  float* hf;

  if (x1 <= 0 && y1 <= 0 && x2 > width && y2 > height)
	  return;
  if (x1 >= x2 && y1 >= y2)
	  return;

return;
  for (from_y = y1, to_y = 0; from_y <= y2; from_y++, to_y++)
    {
      int from_pos, to_pos;

      from_pos = from_y * width + x1;
      to_pos = to_y * (x2 - x1 + 1);
      for (from_x = x1, to_x = 0; from_x <= x2; from_x++, to_x++)
        {
          heightfield[to_pos] = heightfield[from_pos];

//          if (terrain->riverfield != NULL)
//            terrain->riverfield[to_pos] = terrain->riverfield[from_pos];

//          if (terrain->selection != NULL)
//            terrain->selection[to_pos] = terrain->selection[from_pos];

          from_pos++;
          to_pos++;
        }
    }

  hf = new float[(width * height)];
  hf = heightfield;
  int fhw = width;
  int fhh = height;
  width = x2 - x1 + 1;
  height = y2 - y1 + 1;
  render_options.render_width = width;
  delete heightfield;
  heightfield = 0;
  heightfield = new float[(width * height)];

  for (int hfy=0; hfy<height; hfy++)
  {
      for (int hfx=0; hfx<width; hfx++)
      {
		  heightfield[((hfy*width)+hfx)] = hf[((hfy*fhw)+hfx)];
	  }
  }
//  delete hf;
//  hf = 0;
//  if (terrain->riverfield != NULL)
//    terrain->riverfield = g_renew (gfloat, terrain->riverfield,
//                                  terrain->width * terrain->height);
//  if (terrain->selection != NULL)
//    terrain->selection = g_renew (gfloat, terrain->selection,
//                                  terrain->width * terrain->height);
}

/**
 * t_terrain_seed: seed the specified HF with the specified data. 
 * Returns a partially filled HF!
 */
int TTerrain::t_terrain_seed_data(float *data, int w, int h)
{
  int      x, y;
  float    incx, incy; 
  float    offx=0, offy=0;
  float   *hfield = heightfield;

  if ((data == NULL) || (w < 10) || (h < 10) || (width < w) || (height < h))
	  return -1;

  incx = width / w;
  incy = height / h;

  memset (hfield, 0, (width * height) * sizeof (float));

  for (y = 0; y < height; y++, offy += incy, offx = 0)
    for (x = 0, offx = 0; x < width; x++, offx += incx)
      {
        /* printf ("%f, %f\n", offx, offy);fflush (stdout); */
        hfield[(int)(((int) offy) * width + offx)] =
          data[y * width + x];
      }

  t_terrain_set_modified(true);

  return 0;
}

/**
 * t_terrain_seed: re-seed the specified terrain with it's data from 
 * the specified region. Optionally resizes the terrain to 
 * new_width * new_height
 */
int TTerrain::t_terrain_seed(int new_width, int new_height, int sel_x, int sel_y, int sel_width, int sel_height)
{
  int x, y;
  int rc;
  int sel_size = sel_width*sel_height;
  float *hfield = heightfield;
  float *data_extract = new float[sel_size]; 

  if (sel_x+sel_width > width)
    sel_width = width - sel_x;
  if (sel_y+sel_height > height)
    sel_height = height - sel_y;

  for (y=0; y<sel_height; y++)
    for (x=0; x<sel_width; x++)
      {
        int offdst = y * sel_width + x;
        int offsrc = (sel_y + y) * width + (sel_x + x);

        data_extract[offdst] = hfield[offsrc];
      }

  if (new_width != -1 && new_height != -1)
    if (new_width != width && new_height != height)
      {
	    delete heightfield;
        heightfield = 0;
        heightfield = new float[(new_width * new_height)];
        width = new_width;
        height = new_height;
		render_options.render_width = width;
      }

  rc = t_terrain_seed_data(data_extract, sel_width, sel_height);

//  if (rc == 0)
//    t_terrain_select_none(terrain);

//  delete data_extract;
//  data_extract = 0;

  return rc;
}

void TTerrain::t_terrain_set_size(int w, int h)
{
	if (width != w || height != h)
    {
		width = w;
		height = h;
		delete heightfield;
		//g_free (terrain->selection);
		heightfield = new float[width * height];
		//terrain->selection = NULL;
    }
}
 
TTerrain *TTerrain::t_terrain_tile_new(int num_x, int num_y)
{
  TTerrain  *tnew;
  int       lim_x = width * num_x;
  int       lim_y = height * num_y;
  int       x;
  int       y;
  //char      *ext;
  //char      *base;
  //char      buf[256];

  tnew = new TTerrain(lim_x, lim_y);

//  if (terrain->selection != NULL)
//    tnew->selection = g_new (gfloat, lim_x * lim_y);

  for (y=0; y<lim_y; y++)
    {
      int yofforg = y % height;

      for (x=0; x<lim_x; x++)
        {
          int pnew = y * lim_x + x;
          int porg = yofforg*width + x % width;

          tnew->heightfield[pnew] = heightfield[porg];

          //if (terrain->selection != NULL)
            //tnew->selection[pnew] = terrain->selection[porg];
        }
    }

  //base = filename_get_base_without_extension(filename);
  //ext = filename_get_extension(filename);
  //sprintf(buf, "%s_tiled_%dx%d.%s", base, num_x, num_y, ext);
  //tnew->filename = strdup(buf);

  return tnew;
} 

TTerrain *t_terrain_clone_resize(TTerrain *ter, int width, int height, bool terrain_only)
{
  TTerrain *out;
  float     fx = width/ter->width;
  float     fz = height/ter->height;
  float     fy = (fx+fz)/2;
  int       y;
  int       pos;

  out = new TTerrain(width, height);

  out->filename = strdup(ter->filename);

  //g_free (out->theme_file);
  //out->theme_file = g_strdup (terrain->theme_file);

  if (ter->selection != NULL)
    out->selection = new float[out->width * out->height];

  pos = 0;
  for (y = 0; y < out->height; y++)
  {
      int x;
      int count;
      int prev_pos;

      prev_pos = y * ter->height / out->height * ter->width;
      count = 0;
      for (x = 0; x < out->width; x++)
      {
          out->heightfield[pos] = ter->heightfield[prev_pos];
          if (out->selection != NULL)
            out->selection[pos] = ter->selection[prev_pos];

          pos++;
          count += ter->width;
          while (count >= out->width)
            {
              count -= out->width;
              prev_pos++;
            }
        }
    }

  /* clone_resize doesn't always need objects (when it's used for preview) */
/*  if (!terrain_only)
    for (y=0; y<terrain->objects->len; y++)
      {
      TTerrainObject  *obj;

      obj = &g_array_index (terrain->objects, TTerrainObject, y);
      obj->x *= fx;
      obj->y *= fz;
      obj->scale_x *= fx;
      obj->scale_z *= fz;
      obj->scale_y *= fy;

      g_array_append_val (out->objects, obj);
      }*/

  return out;
}
 
TTerrain *t_terrain_clone(TTerrain *terrain)
{
  TTerrain  *out;
//  int       i;
  int       memsize;

  memsize = terrain->width * terrain->height * sizeof(float);
  out = new TTerrain(terrain->width, terrain->height);
  out->filename = strdup(terrain->filename);

//  out->theme_file = g_strdup(terrain->theme_file);

  memcpy(out->heightfield, terrain->heightfield, memsize);
/*
  if (terrain->selection != NULL)
    out->selection = g_memdup (terrain->selection, sizeof(gfloat)*terrain->width*terrain->height);

  if (terrain->objects != NULL)
    for (i=0; i<terrain->objects->len; i++)
      g_array_append_val (out->objects, g_array_index (terrain->objects, TTerrainObject, i));
*/
  return out;
}
 
TTerrain *t_terrain_clone_preview(TTerrain *terrain)
{
  int       maximum;
  TTerrain *clone;

  maximum = MAX (terrain->width, terrain->height);

  clone = t_terrain_clone_resize(terrain, 100, 100, true);
  clone->wireframe_resolution = 5;

  return clone;
}

void t_terrain_copy_heightfield(TTerrain *from, TTerrain *to)
{
	int memsize;

	if (from->width != to->width && from->height != to->height)
		return;

	memsize = from->width*from->height*sizeof(float);

	memcpy(to->heightfield, from->heightfield, memsize);
	to->sealevel = from->sealevel;
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/