/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genfaultdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genfaultdlgimpl
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENFAULTDLHIMPL_H
#define GENFAULTDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "genFaultDlg.h"
#include <qlineedit.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qlabel.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/
class genFaultDlgImpl : public genFaultDlg
{ 
    Q_OBJECT

public:
    genFaultDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~genFaultDlgImpl();

    int getMethod() { return fault_method->currentItem(); };
    void setMethod(int index) { fault_method->setCurrentItem(index); };
    int getSize() { return fault_size->value(); };
    void setSize(int size) { fault_size->setValue(size); };
    int getIter() { return fault_iterations->value(); };
    void setIter(int i1) { fault_iterations->setValue(i1); };
    int getScale() { return fault_scale_factor->value(); };
    void setScale(int a1) { fault_scale_factor->setValue(a1); };
    int getCycle() { return fault_cycles->value(); };
    void setCycle(int a1) { fault_cycles->setValue(a1); };

    bool getCSize() { return cbcs; };
    void setCSize(bool cs) { cbcs = cs; };
    bool getNewSeed() { return cbns; };
    void setNewSeed(bool ns) { cbns = ns; };
    QString getSeed() { return seed->text(); };
    void setSeed(QString s) { seed->setText(s); };

public slots:
	void csizeClicked();
	void seedClicked();

//private:
public:
	bool cbns;
	bool cbcs;
};

#endif // GENFAULTDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/