/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: rasterizedlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: rasterizedlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef RASTERIZEDLHIMPL_H
#define RASTERIZEDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "RasterizeDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qslider.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class RasterizeDlgImpl : public RasterizeDlg
{ 
    Q_OBJECT

public:
    RasterizeDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~RasterizeDlgImpl();

	bool  adjust;
	int   xsize;
	int   ysize;
	float factor;

public slots:
	void adjustClicked();
	void setXsize(int value);
	void setYsize(int value);
	void setFactor(int value);

protected:
	void update_preview();

};

#endif // RASTERIZEDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   -
 *
 ***********************************************************************************************************************/