/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: terracedlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: terracedlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef TERRACEDLHIMPL_H
#define TERRACEDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "TerraceDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class TerraceDlgImpl : public TerraceDlg
{ 
    Q_OBJECT

public:
    TerraceDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~TerraceDlgImpl();

	int level;
	float tight;
	bool adjust;

public slots:
	void setLevel(int value);
	void setTight(int value);
	void adjustClicked();

protected:
	void update_preview();

};

#endif // TERRACEDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/