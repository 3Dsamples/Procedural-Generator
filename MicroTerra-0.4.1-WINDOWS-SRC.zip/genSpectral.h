#ifndef GENSPECTRAL_H
#define GENSPECTRAL_H

#include "tterrain.h"
#include "trandom.h"

class genSpec
{
public:
	genSpec( TTerrain* terra);
	~genSpec();
	void t_terrain_generate_spectral(int n, float h, int seed, bool invert);

private:
	TTerrain* terrain;
	TRandom*  gauss;
};

#endif // GENSPECTRAL_H
