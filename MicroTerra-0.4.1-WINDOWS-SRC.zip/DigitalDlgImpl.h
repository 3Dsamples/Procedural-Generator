/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: digitaldlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: digitaldlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef DIGITALDLHIMPL_H
#define DIGITALDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "DigitalDlg.h"
#include "tterrain.h"
#include <qspinbox.h>
#include <qlabel.h>

/** ***************************************************************************************************************** **/
/** 				      CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/

#define FLEN  5
#define FSIZE FLEN*FLEN

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class DigitalDlgImpl : public DigitalDlg
{ 
    Q_OBJECT

public:
    DigitalDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~DigitalDlgImpl();

	float      filter[FSIZE]; 
	float      elv_min;
	float      elv_max;

public slots:
	void filter1Changed();
	void filter2Changed();
	void filter3Changed();
	void filter4Changed();
	void filter5Changed();
	void filter6Changed();
	void filter7Changed();
	void filter8Changed();
	void filter9Changed();
	void filter10Changed();
	void filter11Changed();
	void filter12Changed();
	void filter13Changed();
	void filter14Changed();
	void filter15Changed();
	void filter16Changed();
	void filter17Changed();
	void filter18Changed();
	void filter19Changed();
	void filter20Changed();
	void filter21Changed();
	void filter22Changed();
	void filter23Changed();
	void filter24Changed();
	void filter25Changed();
	void setMinElev(int value);
	void setMaxElev(int value);

protected:
	void update_view();
};

#endif // DIGITALDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/