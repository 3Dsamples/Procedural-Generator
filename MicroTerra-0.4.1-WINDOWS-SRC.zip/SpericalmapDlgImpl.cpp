/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: sphericalmapdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: sphericalmapdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "SpericalmapDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

SpericalmapDlgImpl::SpericalmapDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : SpericalmapDlg( parent, name, modal, fl )
{
	offs = (float)0.10;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
SpericalmapDlgImpl::~SpericalmapDlgImpl()
{
}

void SpericalmapDlgImpl::update_preview()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	t_terrain_spherical(clone, offs);
	PreView->t_terrain_view_set_terrain(clone);
}

void SpericalmapDlgImpl::setOffset(int value)
{
	char buf[15];

	offs = (float)(value/100.0);
	sprintf(buf,"%1.2f", offs);
	slid1->setText((char *)buf);
	update_preview();
}
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/