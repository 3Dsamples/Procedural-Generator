/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: array.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: array
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef ARRAY_H
#define ARRAY_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <assert.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/
/**
 *  A resizable array of objects.
 *
 *  NOTES:
 *  The array's location in memory may change.
 *  Uses either T(const T &) or operator=(const T &) to copy elements.
 *  Makes sure constructors and destructors are called properly for
 *  all elements in the array.
 */

template <class T>

class Array 
{
public:
  Array(int size=0);
  Array(const Array &init);
  ~Array();

  void add(const T *items, int num);
  void add(const T item) { add(&item, 1); }

  T &operator [](int i) const {
    assert(i >= 0 && i < size_);
    return data_[i];
  }

  Array &operator =(const Array &init);

  int size() const { return size_; }
  void resize(int size);

private:
  T   *data_;
  int  size_;

};

#endif  /* ARRAY_H */
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/