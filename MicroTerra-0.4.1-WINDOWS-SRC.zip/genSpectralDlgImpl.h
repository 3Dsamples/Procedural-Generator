/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genspectraldlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genspectraldlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENSPECTRALDLHIMPL_H
#define GENSPECTRALDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "genSpectralDlg.h"
#include <qlineedit.h>
#include <qspinbox.h>
#include <qlabel.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class genSpectralDlgImpl : public genSpectralDlg
{ 
    Q_OBJECT

public:
    genSpectralDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~genSpectralDlgImpl();

    int getSize() { return sb_size->value(); };
    void setSize(int size) { sb_size->setValue(size); };

    int getFracDim() { return sb_fracdim->value(); };
    void setFracDim(int fd) { sb_fracdim->setValue(fd); };

    bool getTrigoFuncs() { return cbtf; };
    void setTrigoFuncs(bool tf) { cbtf = tf; };
    bool getNewSeed() { return cbns; };
    void setNewSeed(bool ns) { cbns = ns; };
    QString getSeed() { return le_seed->text(); };
    void setSeed(QString s) { le_seed->setText(s); };

public slots:
	void trigoClicked();
	void seedClicked();

//private:
public:
	bool cbtf;
	bool cbns;
};

#endif // GENSPECTRALDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 29-12-2004
 *   - created
 *
 ***********************************************************************************************************************/