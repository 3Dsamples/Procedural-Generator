/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: radialscaledlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: radialscaledlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef RADIALSCALEDLG_H
#define RADIALSCALEDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;

class RadialScaleDlg : public QDialog
{ 
    Q_OBJECT

public:
    RadialScaleDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~RadialScaleDlg();

    QPushButton* OK;
    QPushButton* CANCEL;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QGroupBox* GroupBox2;
    QSlider* center_y;
    QSlider* center_x;
    QLabel* lbl1;
    QLabel* lbl2;
    QLabel* slid1;
    QLabel* slid2;
    QFrame* Line2;
    QLabel* lbl4;
    QLabel* lbl3;
    QLabel* lbl5;
    QLabel* lbl6;
    QSlider* scale_start_distance;
    QSlider* scale_end_distance;
    QSlider* frequency;
    QSlider* scale_factor;
    QSlider* smoothing_factor;
    QLabel* slid3;
    QLabel* slid4;
    QLabel* slid5;
    QLabel* slid6;
    QLabel* slid7;
    QCheckBox* invert;
    QLabel* lbl7;
    QFrame* Line1;
	TTerrain *terra;

public slots:
	virtual void setCenterX(int value);
	virtual void setCenterY(int value);
	virtual void setStart(int value);
	virtual void setEnd(int value);
	virtual void setFreq(int value);
	virtual void setScale(int value);
	virtual void setSmooth(int value);
	virtual void invertClicked();

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // RADIALSCALEDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - created
 *
 ***********************************************************************************************************************/