/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: optionsdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: optionsdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef OPTIONSDLG_H
#define OPTIONSDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/
#include <qvariant.h>
#include <qdialog.h>
#include "gammapreview.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QRadioButton;
class QSlider;
class QSpinBox;
class QTabWidget;
class QWidget;

class OptionsDlg : public QDialog
{ 
    Q_OBJECT

public:
    OptionsDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~OptionsDlg();

    QPushButton* OK;
    QPushButton* CANCEL;
    QTabWidget* NoteBook1;
    QWidget* page1;
    QTabWidget* Notebook2;
    QWidget* general_tab1;
    QGroupBox* GroupBox2;
    QPushButton* povray_browse;
    QPushButton* ac3d_browse;
    QPushButton* lightwave_browse;
    QLineEdit* exe_lightwave;
    QLineEdit* exe_ac3d;
    QLineEdit* exe_povray;
    QGroupBox* GroupBox1;
    QRadioButton* progs_lightwave;
    QRadioButton* progs_ac3d;
    QRadioButton* progs_povray;
    QWidget* general_tab2;
    QGroupBox* GroupBox3;
    QLabel* lbl1;
    QLabel* lbl2;
    QLabel* lbl3;
    QSpinBox* max_undo;
    QWidget* general_tab3;
    QGroupBox* GroupBox4;
    QFrame* Frame1;
	MOGammaPreview* GammaView;
    QSlider* gamma;
    QLabel* lbl4;
    QLabel* lbl5;
    QLabel* slid1;
    QWidget* size;
    QGroupBox* GroupBox5;
    QSpinBox* default_size;
    QLabel* lbl6;
    QWidget* generation;
    QGroupBox* GroupBox6;
    QCheckBox* rand_gen_faulting;
    QCheckBox* rand_gen_perlin;
    QCheckBox* rand_gen_spectral;
    QCheckBox* rand_gen_subdiv;
    QWidget* dirs;
    QGroupBox* GroupBox13;
    QPushButton* microterra_browse;
    QLineEdit* dir_microterra;
    QLabel* lbl15;
    QWidget* page2;
    QTabWidget* TabWidget6;
    QWidget* tab;
    QGroupBox* GroupBox7;
    QSlider* scale_z;
    QSlider* scale_x;
    QLabel* slid2;
    QLabel* slid3;
    QLabel* lbl7;
    QLabel* lbl8;
    QGroupBox* GroupBox8;
    QSlider* y_scale_factor;
    QLabel* slid4;
    QLabel* lbl9;
    QWidget* tab_2;
    QGroupBox* GroupBox9;
    QCheckBox* filled_sea;
    QGroupBox* GroupBox10;
    QSlider* sealevel;
    QSlider* clarity;
    QLabel* slid5;
    QLabel* slid6;
    QLabel* lbl10;
    QLabel* lbl11;
    QWidget* tab_3;
    QGroupBox* GroupBox11;
    QSlider* wireframe_resolution;
    QSlider* camera_height_factor;
    QLabel* slid7;
    QLabel* slid8;
    QLabel* lbl12;
    QLabel* lbl13;
    QGroupBox* GroupBox12;
    QSlider* levels;
    QLabel* slid9;
    QLabel* lbl14;

public slots:
	virtual void progslightwave_Changed();
	virtual void progsac3d_Changed();
	virtual void progspovray_Changed();
	virtual void lightwavebrowse();
	virtual void ac3dbrowse();
	virtual void povraybrowse();
	virtual void setGamma(int value);
	virtual void defaultsizeChanged();
	virtual void randgenfaultingClicked();
	virtual void randgenperlinClicked();
	virtual void randgenspectralClicked();
	virtual void randgensubdivClicked();
	virtual void microterrabrowse();
	virtual void setXscale(int value);
	virtual void setZscale(int value);
	virtual void setYscalefactor(int value);
	virtual void filledseaClicked();
	virtual void setSealevel(int value);
	virtual void setClarity(int value);
	virtual void setWireframeResolution(int value);
	virtual void setCameraHeightFactor(int value);
	virtual void setLevels(int value);

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // OPTIONSDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 07-12-2004
 *   - created
 *
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/