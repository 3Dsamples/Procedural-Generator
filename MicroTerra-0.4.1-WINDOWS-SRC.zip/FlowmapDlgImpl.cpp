/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: flowmapdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: flowmapdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "stdio.h"
#include <qcheckbox.h>
#include <qradiobutton.h>
#include "FlowmapDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

FlowmapDlgImpl::FlowmapDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : FlowmapDlg( parent, name, modal, fl )
{
	direction = true;
	sealevel = false;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
FlowmapDlgImpl::~FlowmapDlgImpl()
{
}

void FlowmapDlgImpl::update_view()
{
	TTerrain *clone;
	TTerrain *flowmap;

	clone = t_terrain_clone(terra);
	flowmap = t_terrain_flowmap(clone, direction, !sealevel, (float)1.0);
	t_terrain_copy_heightfield(flowmap, clone); 
	PreView->t_terrain_view_set_terrain(clone);
}

void FlowmapDlgImpl::single_Changed()
{
	if (flowmap_single->isChecked())
	{
		flowmap_multiple->setChecked(false);
		direction = true;
	}
}

void FlowmapDlgImpl::multiple_Changed()
{
	if (flowmap_multiple->isChecked())
	{
		flowmap_single->setChecked(false);
		direction = false;
	}
}

void FlowmapDlgImpl::sealevelClicked()
{
	sealevel = flowmap_sealevel->isChecked();
}
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/