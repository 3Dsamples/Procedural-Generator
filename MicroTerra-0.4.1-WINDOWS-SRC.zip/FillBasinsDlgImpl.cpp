/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: fillbasinsdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: fillbasinsdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "FillBasinsDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

FillBasinsDlgImpl::FillBasinsDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : FillBasinsDlg( parent, name, modal, fl )
{
	iters = 10;
	bigG = false;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
FillBasinsDlgImpl::~FillBasinsDlgImpl()
{
}

void FillBasinsDlgImpl::update_preview()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	t_terrain_fill_basins(clone, iters, bigG);
	clone->t_terrain_normalize(true);
	PreView->t_terrain_view_set_terrain(clone);
}

void FillBasinsDlgImpl::setIter(int value)
{
	char buf[15];

	iters = value;
	sprintf(buf,"%d", iters);
	slid1->setText((char *)buf);
	update_preview();
}

void FillBasinsDlgImpl::biggridClicked()
{
	bigG = big_grid->isChecked();
	update_preview();
}
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - created
 *
 ***********************************************************************************************************************/