/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: aboutdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: aboutdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "AboutDlg.h"

#include <stdio.h>
#include <qdatetime.h>
#include <qframe.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qstring.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "aboutview.h"
#include "AutoBuild.h"
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a AboutDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
AboutDlg::AboutDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
	char buf[256]="";

    if ( !name )
		setName( "AboutDlg" );
    resize( 345, 370 ); 
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 345, 370 ) );
    setMaximumSize( QSize( 340, 370 ) );
    setBaseSize( QSize( 340, 370 ) );
    setCaption( tr( "About Window" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    Frame = new QFrame( this, "Frame" );
    Frame->setGeometry( QRect( 9, 10, 324, 244 ) ); 
    Frame->setFrameShape( QFrame::WinPanel );
    Frame->setFrameShadow( QFrame::Sunken );

	View = new AboutView(Frame, "View");
	View->setGeometry( QRect( 2, 2, 320, 240 ) );
	View->about_dlg_load_logo();
	View->show();

    TextLabel1 = new QLabel( this, "TextLabel1" );
    TextLabel1->setGeometry( QRect( 82, 261, 164, 29 ) ); 
    QFont TextLabel1_font(  TextLabel1->font() );
    TextLabel1_font.setFamily( "Arial" );
    TextLabel1_font.setPointSize( 14 );
    TextLabel1_font.setBold( TRUE );
    TextLabel1->setFont( TextLabel1_font ); 
    TextLabel1->setFrameShape( QLabel::WinPanel );
    TextLabel1->setFrameShadow( QLabel::Raised );
    TextLabel1->setText( tr( "MicroTerra 0.4.1" ) );
    TextLabel1->setAlignment( int( QLabel::AlignCenter ) );

    TextLabel2 = new QLabel( this, "TextLabel2" );
    TextLabel2->setGeometry( QRect( 23, 291, 294, 25 ) ); 
    QFont TextLabel2_font(  TextLabel2->font() );
    TextLabel2_font.setFamily( "Arial" );
    TextLabel2_font.setPointSize( 10 );
    TextLabel2_font.setBold( TRUE );
    TextLabel2->setFont( TextLabel2_font ); 
    TextLabel2->setFrameShape( QLabel::MShape );
    TextLabel2->setFrameShadow( QLabel::MShadow );
    TextLabel2->setText( tr( "a Virtual landscape engine for MS-Windows " ) );
    TextLabel2->setAlignment( int( QLabel::AlignCenter ) );

    TextLabel4 = new QLabel( this, "TextLabel4" );
    TextLabel4->setGeometry( QRect( 65, 315, 213, 22 ) ); 
    QFont TextLabel4_font(  TextLabel4->font() );
    TextLabel4_font.setFamily( "Arial" );
    TextLabel4_font.setBold( TRUE );
    TextLabel4->setFont( TextLabel4_font ); 
    TextLabel4->setFrameShape( QLabel::WinPanel );
    TextLabel4->setFrameShadow( QLabel::Plain );
    QDateTime dt = QDateTime::currentDateTime();
	QString s = dt.toString();
	sprintf(buf, "build [%d][%s]", BUILD_NUM, (char *)s.latin1()); 
    TextLabel4->setText(buf);
    TextLabel4->setAlignment( int( QLabel::AlignCenter ) );

    TextLabel3 = new QLabel( this, "TextLabel3" );
    TextLabel3->setGeometry( QRect( 5, 338, 333, 26 ) ); 
    QFont TextLabel3_font(  TextLabel3->font() );
    TextLabel3_font.setFamily( "Comic Sans MS" );
    TextLabel3_font.setPointSize( 9 );
    TextLabel3->setFont( TextLabel3_font ); 
    TextLabel3->setText( tr( "MicroTerra is created by Peter J. vd Sluis    (1998-2004)" ) );
    TextLabel3->setAlignment( int( QLabel::AlignCenter ) );

}

/*  
 *  Destroys the object and frees any allocated resources
 */
AboutDlg::~AboutDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool AboutDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 

    if ( ev->type() == QEvent::ApplicationFontChange )
	{
		QFont TextLabel2_font(  TextLabel2->font() );
		TextLabel2_font.setFamily( "Arial" );
		TextLabel2_font.setPointSize( 10 );
		TextLabel2_font.setBold( TRUE );
		TextLabel2->setFont( TextLabel2_font ); 
		QFont TextLabel1_font(  TextLabel1->font() );
		TextLabel1_font.setFamily( "Arial" );
		TextLabel1_font.setPointSize( 14 );
		TextLabel1_font.setBold( TRUE );
		TextLabel1->setFont( TextLabel1_font ); 
		QFont TextLabel3_font(  TextLabel3->font() );
		TextLabel3_font.setFamily( "Comic Sans MS" );
		TextLabel3_font.setPointSize( 9 );
		TextLabel3->setFont( TextLabel3_font ); 
    }
    return ret;
}
/***********************************************************************************************************************
 * Version history:
 *  * 14-09-2004
 *   - created
 *
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/