#ifndef __AUTOBUILD_H__
#define __AUTOBUILD_H__
//change the FALSE to TRUE for autoincrement of build number
#define INCREMENT_BUILD_NUM FALSE
#define BUILD_NUM 945
#endif //__AUTOBUILD_H__
