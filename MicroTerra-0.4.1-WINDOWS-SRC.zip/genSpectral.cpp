/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genspectral.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genspectral
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <math.h>
#include "genSpectral.h"
#include "fftn.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

genSpec::genSpec( TTerrain* terra )
{
	terrain = terra;
}

genSpec::~genSpec()
{
}

/**
 *  spectralSynthesisFM2D 
 *  generate: spectralSynthesisFM2D create a landscape through fractal motion 
 *  in 2 dimensions. Taken from 'The Science of Fractal Images' by Peitgen & 
 *  Saupe, 1988 (page 108)
 */
void genSpec::t_terrain_generate_spectral(int size, float h, int seed, bool invert)
{
  int       x, y, x0, y0;
  int       dim[2], lim;
  int       memcnt;
  float    *ar;
  float    *ai;
  TRandom  *gauss;

//  g_return_val_if_fail (size != 0, NULL);
  if (size == 0) return;
//  g_return_val_if_fail (h > 0.0, NULL);
  if (h < 0) return;
//  g_return_val_if_fail (h < 3.0, NULL);
  if (h > 3.0) return;

  gauss = new TRandom(seed);

  /* Real array */
  ar = terrain->heightfield;

  /* Imaginary array */
  memcnt = (size * size);
  ai = new float[memcnt];

  lim = size / 2;
  for (x = 0; x < lim; x++)
    for (y = 0; y < lim; y++)
      {
        double phase, rad; 

        phase = 2.0 * M_PI * gauss->t_random_rnd(0.0, 1.0);

        if (x != 0 || y != 0)
          rad = pow (x * x + y * y, -(h + 1.0) / 2.0) * gauss->t_random_gauss();
        else
          rad = 0.0;

        if (invert)
          {
            ar[(y * size) + x] = (float)(-rad * cos(phase));
            ai[(y * size) + x] = (float)(-rad * sin(phase));
          }
        else
          {
            ar[(y * size) + x] = (float)(rad * cos(phase));
            ai[(y * size) + x] = (float)(rad * sin(phase));
          }

        x0 = (x == 0) ? 0 : size - x;
        y0 = (y == 0) ? 0 : size - y;

        if (invert)
          {
            ar[(y0 * size) + x0] = (float)(-rad * cos(phase));
            ai[(y0 * size) + x0] = (float)(rad * sin(phase));
          }
        else
          {
            ar[(y0 * size) + x0] = (float)(rad * cos(phase));
            ai[(y0 * size) + x0] = (float)(-rad * sin(phase));
          }
      }

  ai[size / 2] = 0;
  ai[(size / 2) * size] = 0;
  ai[(size / 2) * size + (size / 2)] = 0;

  lim = size - lim - 1;
  for (x = 1; x < lim; x++)
    for (y = 1; y < lim; y++)
      {
        double phase, rad; 

        phase = 2.0 * M_PI + gauss->t_random_rnd(0.0, 1.0);
        rad = pow (x * x + y * y, -(h + 1.0) / 2.0) * gauss->t_random_gauss();

        if (invert)
          {
            ar[(size - y) * size + x] = (float)(rad * cos(phase));
            ai[(size - y) * size + x] = (float)(rad * sin(phase));
            ar[y * size + size - x] = (float)(rad * cos(phase));
            ai[y * size + size - x] = (float)(-rad * sin(phase));
          }
        else
          {
            ar[(size - y) * size + x] = (float)(-rad * cos(phase));
            ai[(size - y) * size + x] = (float)(-rad * sin(phase));
            ar[y * size + size - x] = (float)(-rad * cos(phase));
            ai[y * size + size - x] = (float)(rad * sin(phase));
          }
      }

  dim[0] = size;
  dim[1] = size;

  fftnf (2, dim, ar, ai, -1, 1.0);

//  delete gauss;
//  delete ai;

  terrain->t_terrain_normalize(false);
  terrain->t_terrain_set_modified(true);
}
/***********************************************************************************************************************
 * Version history:
 *  * 29-12-2002
 *   - created
 *
 ***********************************************************************************************************************/