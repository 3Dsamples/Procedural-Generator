/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: filters.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: filters
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "filters.h"
#include "trandom.h"
#include "fftn.h"
#include "filenameops.h"

/** ***************************************************************************************************************** **/
/**				      MACROS				                                                                          **/
/** ***************************************************************************************************************** **/
/*
 * This macro updates the terrain taking into account the
 * selection.
 */
#define APPLY(terrain,pos,value)                                    \
if (terrain->selection == NULL)                                     \
    terrain->heightfield[pos] = value;                              \
  else                                                              \
    terrain->heightfield[pos] =                                     \
      terrain->heightfield[pos] * (1.0 - terrain->selection[pos]) + \
      value * terrain->selection[pos];

/*
 * Other utility macros
 */
#define INTERPOLATE(x,y,frac)  (1-(frac))*(x) + (frac)*(y)

#define X_WRAP(x)  x = ((x + terrain->width) % terrain->width)
#define Y_WRAP(y)  y = ((y + terrain->height) % terrain->height)

#define X_CLIP(x)  x = (x<0 ? 0 : ((x>=terrain->width)?(terrain->width-1):x))
#define Y_CLIP(y)  y = (y<0 ? 0 : ((y>=terrain->height)?(terrain->height-1):y))

#define ATAN2(y,x) ((x==0 && y==0)?0:atan2(y,x))

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

float threshold(float x, float power, float midpoint)
{
	if (x < midpoint)
		return pow(x * (1.0 / midpoint), power) * 0.5;

	return 1.0 - pow((1.0 - x) * (1.0 / (1.0 - midpoint)), power) * 0.5;
}
 
float transform(float x, float sea_threshold, float sea_depth, float sea_dropoff, float above_power, float below_power)
{
	if (x <= sea_threshold)
    {
		/* Apply a threshold function to terrain underwater. */

		return threshold(x / sea_threshold, below_power, sea_dropoff) * sea_depth;
    }

	/* Above the sea threshold */
	return pow((x - sea_threshold) / (1.0 - sea_threshold), above_power) * (1.0 - sea_depth) + sea_depth;
}
 
void t_terrain_fill(TTerrain *terrain, float elevation, float factor)
{
	int    i, size;

	size = terrain->width * terrain->height;

	for (i = 0; i < size; i++)
		if (terrain->heightfield[i] < elevation)
		{
			float value;

			value = elevation - (elevation - terrain->heightfield[i]) * (1.0 - factor);

			APPLY (terrain, i, value);
		}
}
 
static int fold_sort(const void *_a, const void *_b)
{
	const float *a = (float *)_a;
	const float *b = (float *)_b;

	if (*a < *b)
		return -1;
	else if (*a > *b)
		return 1;
	return 0;
}

/**
 *  fold: fold height field edges under sealevel.
 *  How: Take a slice 'margin' long, fill it with the ABS 
 *  difference between it's height and the sealevel, sort it and 
 *  then subtract it from the HF elevation at that point 
 *  (starting with the largest values on the HF outside), 
 *  scaling the value subtracted in a linear fashion (0..1).
 */
void t_terrain_fold(TTerrain *terrain, int margin)
{
	int    x, y, width, height;
	float *data;
	int    pos;
	float  pstep;
	float *slice; 

	if (margin == 0)
		return;

	slice = new float[margin];
	width = terrain->width;
	height = terrain->height;
	data = terrain->heightfield;

	pstep = 1.0 / margin;

	/* Top and bottom. */
	for (x = 0; x < width; x++)
    {
		/* Top. */
		pos = x;
		for (y = 0; y < margin; y++)
        {
			slice[y] = data[pos] - terrain->sealevel;

			if (slice[y] < 0.0)
				slice[y] = 0.0;

			pos += width;
        }

		qsort ((void *)slice, (size_t)margin, (size_t)sizeof(float), fold_sort);

		pos = x;
		for (y = 0; y < margin; y++)
        {
			float v = data[pos] - slice[margin - 1 - y] * pstep * (margin - y);

			APPLY (terrain, pos, v);
			if (data[pos] < 0.0)
				data[pos] = 0.0;

			pos += width;
        }

		/* Bottom. */
		pos = (height - 1) * width + x;
		for (y = 0; y < margin; y++)
        {
			slice[y] = data[pos] - terrain->sealevel;
			if (slice[y] < 0.0)
				slice[y] = 0.0;

			pos -= width;
        }
		qsort ((void *)slice, (size_t)margin, (size_t)sizeof(float), fold_sort);

		pos = (height - 1) * width + x;
		for (y = 0; y < margin; y++)
        {
			float v = data[pos] - slice[margin - 1 - y] * pstep * (margin - y);

			APPLY (terrain, pos, v);
			if (data[pos] < 0.0)
				data[pos] = 0.0;

			pos -= width;
        }
    }

	/* Left and right sides. */
	for (y = 0; y < height; y++)
    {
		/* Left side. */
		pos = y * width;
		for (x = 0; x < margin; x++)
        {
			slice[x] = data[pos] - terrain->sealevel;
			if (slice[x] < 0.0)
				slice[x] = 0.0;

			pos++;
        }
		qsort ((void *)slice, (size_t)margin, (size_t)sizeof(float), fold_sort);

		pos = y * width;
		for (x = 0; x < margin; x++)
        {
			float v = data[pos] - slice[margin - 1 - x] * pstep * (margin - x);

			APPLY (terrain, pos, v);
			if (data[pos] < 0.0)
				data[pos] = 0.0;

			pos++;
        }

		/* Right. */
		pos = y * width + (width - 1);
		for (x = 0; x < margin; x++)
        {
			slice[x] = data[pos] - terrain->sealevel;
			if (slice[x] < 0.0)
				slice[x] = 0;

			pos--;
        }

		qsort ((void *)slice, (size_t)margin, (size_t)sizeof(float), fold_sort);

		pos = y * width + (width - 1);
		for (x = 0; x < margin; x++)
        {
			float v = data[pos] - slice[margin - 1 - x] * pstep * (margin - x);

			APPLY (terrain, pos, v);
			if (data[pos] < 0.0)
				data[pos] = 0.0;

			pos--;
        }
    }
	delete slice;
}
 
void t_terrain_mosaic(TTerrain *terrain, int x_mosaicsize, int y_mosaicsize)
{
	/* This filter has been inspired by a filter from the windows 
	 *  program leveller, 
	 *  http://www.daylongraphics.com/products/leveller/index.htm
	 *  
	 *  this code has been contributed by Koos Jan Niesink
	 * 
	 *  This filter equalizes the elevations in the heightfield in small 
	 *  rectangular section. The result is a blocky heigtfield.
	 */
	
	int height, width;
	int ycells_left, xcells_left, mosaic_size;
	int i, j, x, y;
	int x_smallest, y_smallest;
	float *data, mosaic_value, data_total;
	
	height = terrain->height;
	width = terrain->width;
	data = terrain->heightfield;

	if (x_mosaicsize<0 && x_mosaicsize>=width && y_mosaicsize<0 && y_mosaicsize>=height)
		return;
	
	ycells_left = height;
	x_smallest = 0;
	y_smallest = 0;	
	
	for(y = 0; y < height; y+=y_mosaicsize)
	{
		xcells_left = width;
		for(x = 0; x < width; x+=x_mosaicsize)
		{
			data_total = 0;
			mosaic_size = y_mosaicsize * x_mosaicsize;
			
			if (x_mosaicsize <= xcells_left && y_mosaicsize <= ycells_left)
			{
				for(i = 0; i < y_mosaicsize; i++)
					for(j = 0; j < x_mosaicsize; j++)
						data_total += data[(y + i)* height + (x + j)];
						
				mosaic_value = data_total / mosaic_size;
				for(i = 0; i < y_mosaicsize; i++)
					for(j = 0; j < x_mosaicsize; j++)
						data[(y+i) * height + (x+j)] = mosaic_value;			
			}
			else
			{			
				if (x_mosaicsize < xcells_left)
					x_smallest = x_mosaicsize;
				else
					x_smallest = xcells_left;
					
				if (y_mosaicsize < ycells_left)
					y_smallest = y_mosaicsize;
				else
					y_smallest = ycells_left;
				for(i = 0; i < y_smallest; i++)
					for(j = 0; j < x_smallest; j++)
						data_total += data[(y + i)*height + (x + j)];
						
				mosaic_value = data_total / (y_smallest * x_smallest);
				
				for(i = 0; i < y_smallest; i++)
					for(j = 0; j < x_smallest; j++)
						data[(y+i) * height + (x+j)] = mosaic_value;
			}
			xcells_left -= x_mosaicsize;
		}
		ycells_left -= y_mosaicsize;
	}
}
 
/* ******************************** */
/* statistical routines ollow go here */
/* ******************************** */

/* use the box-counting method to determine the 
 * terrain's fractal dimension where fractal 
 * dimension is defined as 
 *   log(N)/log(r)
 * where 
 *   N = number of box points in the set
 *   r = scale factor (avg side length);
 *
 * The implementation is generally correct, although 
 * the code suffers from the fact that terraform 
 * always scales the terrain between 0 .. 1 so that 
 * the computed fractal dimension will almost be 
 * somewhere between 2.25 and 2.75.
 * I need to come up with some bright idea here on 
 * how to deal with this!!
 */
float t_terrain_calculate_dimension(TTerrain *terrain)
{
  int width = terrain->width;
  int height = terrain->height;
  int cnt_x = 1;
  int cnt_y = 1;
  int cnt_z = 1;
  float inc_x;
  float inc_y;
  float inc_z;
  float off_x ;
  float off_y ;
  float off_z;
  int x, y, z;
  int i, j;
  int count;
  double dim;

  /* determine x box size */
  do 
    {
    cnt_x = cnt_x*2;
    inc_x = width/cnt_x;
    }
  while (inc_x>=4);

  /* determine z box size */
  do 
    {
    cnt_z = cnt_z*2;
    inc_z = height/cnt_z;
    }
  while (inc_z>=4);

  /* determine y box size */
  cnt_y = (cnt_x + cnt_z)/2;
  inc_y = 1.0/cnt_y;

  /* iterate through the boxes */
  count = 0;
  off_z = 0;
  for (z=0; z<cnt_z; z++)
    {
    off_x = 0;

    for (x=0; x<cnt_x; x++)
      {
      off_y = 0;

      for (y=0; y<cnt_y; y++)
        {
	/* iterate through the points in each box and 
	 * see if it contains part of the terrain 
	 */
        bool found = FALSE;
	int     lim_z = (int)(off_z+inc_z); 

	off_y += inc_y;
	for (j=(int)off_z; j<lim_z && !found; j++)
          {
	  int lim_x = (int)(off_x+inc_x); 
	  for (i=(int)off_x; i<lim_x && !found; i++)
            {
            if (terrain->heightfield[j*width+i] >= off_y)
              found = TRUE;
            }
	  }

	if (found)
          count++;
	else
          y = cnt_y; /* exit upwards search, boxes above this one are empty */
	    
        off_y += inc_y;
        }
      off_x += inc_x;
      }
    off_z += inc_z;
    }

  dim = log10 (count) / log10 ((cnt_z+cnt_x)/2);
  return dim;
}

float t_terrain_calculate_average(TTerrain *terrain)
{
  float *data = terrain->heightfield;
  float  sum = 0; 
  int    size = terrain->width*terrain->height;
  int    i; 

  for (i=0; i<size; i++)
   sum += data[i];

  return sum/(float)size;
}

float t_terrain_calculate_variance(TTerrain *terrain, float *return_average)
{
  int    size = terrain->width*terrain->height;
  float *data = terrain->heightfield;
  float  sum = 0.0; 
  float  ss  = 0.0; 
  float  var = 0.0; 
  float  avg;
  int    i; 

  /* return average to avoid 'wasting' the average calculations*/
  avg = t_terrain_calculate_average(terrain);
  if (return_average != NULL)
    *return_average = avg;

  var = 0.0;
  ss = 0.0;
  for (i=0; i<size; i++)
    {
    sum = data[i] - avg;
    var += sum*sum;
    ss += sum;
    }

  var = (var - ss * ss / size) / (size -  1);
  return var;
}

float t_terrain_calculate_skewness (TTerrain *terrain, float *return_average, float *return_variance)
{
  int    size = terrain->width*terrain->height;
  float *data = terrain->heightfield;
  float  skew = 0.0; 
  float  var;
  float  avg;
  float  s;
  double sqrtvar;
  int    i; 

  var = t_terrain_calculate_variance(terrain, &avg);
  sqrtvar = sqrt(var);

  if (return_average != NULL)
    *return_average = avg;

  if (return_variance != NULL)
    *return_variance = var;

  for (i=0; i<size; i++)
    {
    s = (data[i] - avg) / sqrtvar;
    skew += s * s * s;
    }

 return skew/(float)size;
}

#define NO_FLOW         -987654321  /* marker for 'undefined' */

/* find greatest common denominaor */
static int greatest_common_denominator(int a, int b) 
{
  if (a % b == 0) 
    return b; 
  else 
    return greatest_common_denominator(b, a%b);
}
 
/**
 *  mirror: mirror the height field on one of it's axis.
 *  Type can be 1, 2, 3, 4 for x-axis, y-axis, top (left
 *  to bottom right) or bottom (left to top right)
 */
void t_terrain_mirror(TTerrain *terrain, int type)
{
  int    pos1, pos2;
  int    middle, x, y, width, height;
  float *data;
//  float *selection;
  float  temp;

  width = terrain->width;
  height = terrain->height;
  data = terrain->heightfield;
//  selection = terrain->selection;

  if (type == 0) /* Mirror over the Y Axis */
    {
      middle = width >> 1;
      for (y = 0; y < height; y++)
        {
          pos1 = y * width;
          pos2 = pos1 + width - 1;
          for (x = 0; x < middle; x++)
            {
              temp = data[pos1];
              data[pos1] = data[pos2];
              data[pos2] = temp;

//              if (selection != NULL)
//                {
//                  temp = selection[pos1];
//                  selection[pos1] = selection[pos2];
//                  selection[pos2] = temp;
//                }

              pos1++;
              pos2--;
            }
        }
    }
  else if (type == 1) /* Mirror across the X Axis */
    {
      middle = height >> 1;
      for (y = 0; y < middle; y++)
        {
          pos1 = y * width;
          pos2 = (height - y - 1) * width;
          for (x = 0; x < width; x++)
            {
              temp = (float)data[pos1];
              data[pos1] = data[pos2];
              data[pos2] = temp;

//              if (selection != NULL)
//                {
//                  temp = selection[pos1];
//                  selection[pos1] = selection[pos2];
//                  selection[pos2] = temp;
//                }

              pos1++;
              pos2++;
            }
        }
    }
  else if (type == 2 || type == 3)
    {
      if (type == 2) /* Top left to bottom right */
        {
          for (y = 0; y < height; y++)
            for (x = y; x < width; x++)
              {
                pos1 = y * width + x;
                pos2 = x * width + y;

                temp = data[pos1];
                data[pos1] = data[pos2];
                data[pos2] = temp;

//                if (selection != NULL)
//                  {
//                    temp = selection[pos1];
//                    selection[pos1] = selection[pos2];
//                    selection[pos2] = temp;
//                  }
              }
        }
      else /* Bottom left to top right */
        {
          for (y = 0; y < height; y++)
            for (x = 0; x < width - y; x++)
              {
                pos1 = y * width + x;
                pos2 = (width - x - 1) * width + (height - y - 1);

                temp = data[pos1];
                data[pos1] = data[pos2];
                data[pos2] = temp;

//                if (selection != NULL)
//                  {
//                    temp = selection[pos1];
//                    selection[pos1] = selection[pos2];
//                    selection[pos2] = temp;
//                  }
              }
        }
    }

  terrain->t_terrain_set_modified(true);
}

/* 
Here is the code. Just two functions, LevelConnector and SolveEquations.
There only one parameter (int maxiter) for this filter. One iteration
round increases the affected area 1-2 pixels in all directions from 
selection boundary.

Test images are in the win32 zip on the levcon page. I cleaned the
Leveller plug-in code for this so there may some errors.

BTW, I do have Linux boxes here at the office but not any decent X
server for a PC. Every other GUI explodes with with this MIX server. If
you can't get the code to work then point me to a decent X server and
I'll help out.

LevelConnector uses these pseudo functions to communicate with the
rest of the app.

SetHeight(x, y, hv);      
hv=GetHeight(x, y);
Sel=GetSelValue(x, y); // is pixel selected
PixV=HVToFloat(hv);    // convert from internal type to float
hv=FloatToHV(PixV);    // convert to internal type
*/

/* compare func used by bsearch */
typedef int (*compare_func)(const void*, const void*);

static int level_compare(const int *a, const int *b)
{
  return *a - *b;
}

/**
 * The main calculations. Processes data in u[].
 * Solves this Laplace's 2nd order differential
 * equation using Gauss-Seidel iteration.
 *
 *    d2u   d2u
 *    --- + --- = 0 + (force, not used)
 *    dx2   dy2
 *
 * Can be solved by FFT also but this iterative method lets user control
 * the accuracy of the solution. If all pixels are selected then this works
 * like smooth with variable radius. Basically it just averages 4 adjacent
 * pixels into the middle pixel :) Note however that one iteration pass uses
 * uses 2 values per pixel already computed in that pass so it's a kind of
 * cumulative smooth.
 */
static void level_solve_equations (int **s, float *h, float *u, int node_count, int iteration_count)
{
  int     i, c, dir, node;
  float   sum;

  dir = 1;
  for (i = 0; i < iteration_count; i++)
    {
      for (node = (node_count - 1) * (1 - dir) / 2;
           dir * node <= (node_count - 1) * (1 + dir) / 2;
           node += dir)
        {
          sum = h[node];
          for (c = 1; c <= s[node][0]; c++)
            sum = sum + u[s[node][c]];
          u[node] = 0.25 * sum;
        }

      dir = -dir;  /* toggle direction */
    }
}

/**
 * t_terrain_connect: preapares data for LvLSolveEquations.  At this point
 * not selection-sensitive.
 */
void t_terrain_connect(TTerrain *terrain, int iteration_count)
{
  int     width, height;
  int     xo[4] = {1, -1, 0,  0};
  int     yo[4] = {0,  0, 1, -1};
  int     c, node_count, *node_ptr, node, pos;
  int     x, y, xt, yt, i, j, *position, **s;
  float   *h, *u, value, k;

  width = terrain->width;
  height = terrain->height;

  node_count = width * height;

  u = new float[node_count];        /* This is the actual height data  */
  h = new float[node_count];        /* aux data for equations          */
  position = new int[node_count];   /* Stores pixel positions of nodes */
  s = new int*[node_count];         /* aux data for equations          */

  /* clear arrays */
  for (node = 0; node < node_count; node++)
    {
      s[node] = new int[5];

      for (j = 0; j < 5; j++)
        s[node][j] = 0;

      u[node] = 0;
      h[node] = 0;
      position[node] = 0;
    }

  /* Fill position table */
  pos = 0;
  for (y = 0; y < height; y++)
    {
      for (x = 0; x < width; x++)
        {
          position[pos] = pos;
          pos++;
        }
    }


  /* Make equations */
  node = 0;
  pos = 0;
  for (y = 0; y < height; y++)
    {
      for (x = 0; x < width; x++)
        {
          if (true)
            {
              k = 0;
              c = 0;
              for (i = 0; i < 4; i++)
                {
                  yt = y + yo[i];
                  xt = x + xo[i];
                  if (yt == -1)
                    yt = height - 1;
                  if (yt == height)
                    yt = 0;
                  if (xt == -1)
                    xt = width - 1;
                  if (xt == width)
                    xt = 0;

                  value = terrain->heightfield[yt * width + xt];

                  if (terrain->selection != NULL && terrain->selection[yt * width + xt] <= 0.5)
                    k = k + value;
                  else
                    {
                      c++;

                      /* find node number of adjacent pixel */
                      pos = yt * width + xt;
                      node_ptr = (int*)bsearch (&pos, position, node_count, sizeof(int), (compare_func)level_compare);
                      if (node_ptr == NULL)
                        {
                          perror("error in bserch");
                          exit(1);
                        }

                      s[node][c] = node_ptr - position;
                    }
                }

              u[node] = terrain->heightfield[y * width + x];
              h[node] = k;
              s[node][0] = c;
              node++;
            }
        }
    }

  level_solve_equations(s, h, u, node_count, iteration_count);
  delete h;

  /* Write data in u[] back to hf */
  for (node = 0; node < node_count; node++)
    {
      delete (s[node]);

      APPLY(terrain, position[node], u[node]);
    }

  delete s;
  delete position;
  delete u;
}

/**
 *  radial_scale: pick a point (centerx, centery) and scale the points 
 *      where distance is mindist<=distance<=maxdist linarly.  The formula
 *      we'll use for a nice sloping smoothing factor is (-cos(x*3)/2)+0.5.
 */
void t_terrain_radial_scale(TTerrain *terrain, float center_x, float center_y, float scale_factor, float min_dist, float max_dist, float smooth_factor, int frequency)
{
	int    pos, x, y, i;
	float  max_size;
	float  band_width;
	float *data;

	if (center_x <= 0.0)
		return;
	if (center_y <= 0.0)
		return;
	if (center_x >= 1.0)
		return;
	if (center_y >= 1.0)
		return;
	if (scale_factor < 0.0)
		return;
	if (min_dist <= 0.0)
		return;
	if (max_dist <= 0.0)
		return;
	if (min_dist >= 1.0)
		return;
	if (max_dist >= 1.0)
		return;
	if (smooth_factor <= 0.005)
		return;
	if (smooth_factor >= 1.0)
		return;

	if (fabs (min_dist - max_dist) < 0.01)
		return;

	max_size = MAX (terrain->width, terrain->height);

	data = terrain->heightfield;

	center_x *= terrain->width;
	center_y *= terrain->height;
	min_dist *= max_size;
	max_dist *= max_size;
	band_width = (max_dist-min_dist)/frequency;

	for (i=0; i<frequency; i++)
    {
		float min_d = min_dist + band_width * i;
		float max_d = min_dist + band_width * (i+1);
		float s_low = min_d + (max_d - min_d) * 0.5 * smooth_factor;
		float s_high = max_d - (max_d - min_d) * 0.5 * smooth_factor;
		float cd = min_d + band_width/2;

		pos = 0;
		for (y = 0; y < terrain->height; y++)
			for (x = 0; x < terrain->width; x++)
			{
				float point_old, point;
				float distance;

				distance = sqrt ((x - center_x) * (x - center_x) + (y - center_y) * (y - center_y));

				point_old = data[pos];

				/* Lower half of scaling area. */
				if (distance >= min_d && distance <= cd)
				{
					point = (distance - min_d) / (cd - min_d);

					point = point_old * point * scale_factor + point_old * (1 - point);

					if (distance <= s_low)
					{
						float temp;

						temp = point;
						point = (distance - min_d) / (s_low - min_d);
						point = -(cos (point * 3.0) * 0.5) + 0.5;
						point = point_old * (1.0 - point) + temp * point;
					}

					APPLY (terrain, pos, point);
				}
				else if (distance <= max_d && distance >= cd)
				{
					/* Upper half of scaling area. */
					point = (max_d - distance) / (max_d - cd);

					/* Increase linearly from higher end to middle. */
					point = point_old * point * scale_factor + point_old * (1 - point);

					if (distance > s_high)
					{
						float temp;

						temp = point;
						point = (max_d - distance) / (max_d - s_high);
						point = -(cos (point * 3.0) * 0.5) + 0.5;
						point = point_old * (1.0 - point) + temp * point;
					}

					APPLY (terrain, pos, point);
				}

				pos++;
			}
	}
}
 
/*
 *  gaussian_hill: create a gaussian hill according to paramters 
 */
void t_terrain_gaussian_hill(TTerrain *terrain, float center_x, float center_y, float radius, float radius_factor, float hscale, float smooth_factor, float delta_scale)
{
	int    x, y;
	int    pos;
	int    width, height;
	float *data;
	float  fxmin, fxmax, fymin, fymax;
	float  sdist, sdistr;
	int    xmin, xmax, ymin, ymax;
	int    xcent, ycent;

	if (center_y <= 0.0)
		return;
	if (center_x >= 1.0)
		return;
	if (center_y >= 1.0)
		return;
	if (smooth_factor <= 0.0)
		return;
	if (smooth_factor >= 1.0)
		return;
	if (delta_scale <= 0.0)
		return;
	if (delta_scale >= 1.0)
		return;

	data = terrain->heightfield;
	width = terrain->width;
	height = terrain->height;

	/* calculate max and min coordinates on 0 .. 1 scale */
	fxmin = center_x - radius;
	fxmax = center_x + radius;
	fymin = center_y - radius;
	fymax = center_y + radius;
	if (fxmin < 0.0) fxmin = 0.0;
	if (fxmax > 1.0) fxmax = 1.0;
	if (fymin < 0.0) fymin = 0.0;
	if (fymax > 1.0) fymax = 1.0;

	/* translate everything to subscript scale (0 .. n) */
	xmin = (int) (fxmin * width);
	xmax = (int) (fxmax * width);
	ymin = (int) (fymin * height);
	ymax = (int) (fymax * height);
	xcent = (int) (center_x * width);
	ycent = (int) (center_y * width);
	radius *= ((width + height) * 0.5);
	sdist = radius * smooth_factor;
	sdistr = radius - sdist;

	radius_factor = radius_factor * radius_factor;
	for (y = ymin; y < ymax; y++) 
    {
		float ya;

		ya = (((float) y + 0.5) / height) - center_y;
		ya = ya * ya;

		pos = y * terrain->width + xmin;
		for (x = xmin; x < xmax; x++) 
        {
			float xa, distance, temp;

			distance = sqrt ((xcent - x) * (xcent - x) + (ycent - y) * (ycent - y));
			if (distance <= radius)
            {
				float radius;

				temp = data[pos];
				xa = (((float) x + 0.5) / width) - center_x;
				xa = xa * xa;
				radius = xa + ya;

				/* see if we should be smoothing */
				if (distance > sdistr)
                {
					float sf;

					distance -= sdistr;
					sf = 1.0 - distance / sdist;
					temp += delta_scale * sf * hscale * exp (-radius / radius_factor);
                }
				else
					temp += delta_scale * hscale * exp (-radius / radius_factor);

				APPLY (terrain, pos, temp);
            }

			pos++;
        } 
    } 
}
 
/*
 * Add craters to a heightfield array 
 * Copyright (C) 1995 by Heiko Eissfeldt
 * heiko@colossus.escape.de
 * modified JAN 1996 John Beale for use with HF-Lab  
 * modified JUN 1999 Robert Gasch for use with Terraform
 * modified DEC 2000 David A. Bartold for use with Terraform 0.8.x+
 */


#define alpha        (35.25 / 180.0 * M_PI) /* sphere segment cutoff angle */
#define crater_depth 0.85                   /* 0.9 */

static double a1 = crater_depth, b, d;

/*
 * crater_profile: method to determine the z-elevation dependent on normalized
 *      squared radial coordinate 
 */

static double crater_profile(double nsq_rad)
{
  static double thickness;
  double        radial_coord;

  thickness = 50.0; /* controls the wall thickeness */
  radial_coord = sqrt (fabs (nsq_rad));

  if (radial_coord > b)
    /* outer region gauss distribution */
    return d * exp (-thickness * (radial_coord - b) * (radial_coord - b));
  else 
    /* inner region sphere segment */
    return a1 - sqrt (1.0 - nsq_rad);
}

#define pow4(x)     ((x) * (x) * (x) * (x))
#define inner_scale 1.0
#define outer_scale (1.0 - inner_scale * pow4 (border)) / pow4 (1.0 - border)

/* 
 * crater_dissolve: function to control the weight of the crater profile as
 * opposed to the underlying terrain elevation 
 */
static double crater_dissolve(double nsq_rad)
{
  if (nsq_rad > 0.6 * 0.6)
    return 1.0 - 0.9 * exp (-30.0 * (sqrt (nsq_rad) - 0.6) * (sqrt (nsq_rad) - 0.6));
  else 
    return 0.1 * exp (-25.0 * (sqrt (nsq_rad) - 0.6) * (sqrt (nsq_rad) - 0.6));
}

void t_terrain_craters(TTerrain *terrain, int count, bool wrap, float height_scale, float radius_scale, float crater_coverage, int seed, float center_x, float center_y)
{
  int        i, j, k, xloc, yloc, crater_size;
  int        sq_radius;
  double     nsq_rad, weight;
  int        lev_samples, samples;
  double     level_with, level_pure;
  double     crater_scale;           /* vertical crater scaling factor */
  double     c, d2, shift;
  double     b1, b2, b3;             /* radius scaling params  */
  int        mesh_size;              /* geometric mean of width and height */
  int        data_size;
  float     *data_orig;
  TRandom   *rnd, *rnd_seed;

//  g_return_if_fail (count != 1 || (center_x >= 0.0 && center_y >= 0.0));
//  g_return_if_fail (count != 1 || (center_x <= 1.0 && center_y <= 1.0));

  data_size = terrain->width * terrain->height;
  data_orig = new float[data_size];

  rnd = new TRandom(seed);
  rnd_seed = new TRandom(rnd->t_random_rnd(0.0, 1.0));
  b1 = 10.0;
  b2 = 1.0 / (b1 * b1 * b1 * b1);
  b3 = 1.0 / b1;
  mesh_size = (int)sqrt(terrain->width * terrain->height);
  b = sin (alpha);
  d = a1 - cos (alpha);

  /* copy the terrain */
  memcpy(data_orig, terrain->heightfield, data_size * sizeof(float)); 

  for (k = 0; k < count; k++)
    {
      int     ii, jj;
      TRandom *rnd_loop;

      /*
       * allocating a new random number thread for every crater means
       * that we also keep the same sequence of random numbers when
       * changing the number of craters. We scale the random number 
       * seed from 0 to MAXINT (32 bits).
       */

	  rnd_loop = new TRandom(rnd_seed->t_random_rnd(0, 2147483647));

      /* pick a cratersize according to a power law distribution */
      /* greatest first. So great craters never eliminate small ones */
      /* c = (double)(count - k + 1) / count + b3; */
      /* craters appear in random order */

      c = rnd_loop->t_random_rnd1() + b3;   /* c is in the range b3 ... b3+1 */
      d2 = b2 / (c * c * c * c);      /* d2 is in the range 0 ... 1 */

      //if (count == 1) d2 = 1.0;   /* single craters set to max. size */

      if (count == 1)
        {
          xloc = (int)(center_x * terrain->width);
          yloc = (int)(center_y * terrain->height);
          crater_size = (int)(radius_scale * (terrain->width + terrain->height) * 0.5);
        }
      else
        {
          /* pick a random location for the crater */
          xloc = (int)(rnd_loop->t_random_rnd1() * (terrain->width - 1));
          yloc = (int)(rnd_loop->t_random_rnd1() * (terrain->height - 1));

          crater_size = 3.0 + (int)(d2 * crater_coverage * mesh_size * radius_scale);

          /* Is crater outside of selection?  If so, don't create it. */
          if (terrain->selection != NULL && terrain->selection[yloc * terrain->width + xloc] < 0.5)
            continue;
        }

/* macro to determine the height dependent on crater size */
#define CRATER_SCALE ((height_scale * \
        pow ((crater_size / (3.0 + crater_coverage * mesh_size)), 0.9)) \
        / 256.0 * pow (mesh_size / 256.0, 0.1) / crater_coverage * 80.0)

      crater_scale = CRATER_SCALE;     /* vertical crater scaling factor */

      /* what is the mean height of this plot */
      samples = lev_samples = MAX ((crater_size * crater_size) / 5.0, 1.0);
      level_with = level_pure = 0.0;
      while (samples) 
        {
          i = (int) (rnd_loop->t_random_rnd1() * 2.0 * crater_size - crater_size);
          j = (int) (rnd_loop->t_random_rnd1() * (2.0 * crater_size) - crater_size);

          if (i * i + j * j > crater_size * crater_size)
            continue;
          ii = xloc + i;
          jj = yloc + j;

          /* handle wrapping details... */
          if (wrap || (ii >= 0 && ii < terrain->width && jj >= 0 && jj < terrain->height)) 
            {
              X_WRAP (ii);
              Y_WRAP (jj);
              level_with += terrain->heightfield[jj * terrain->width + ii];
              level_pure += data_orig[jj * terrain->width + ii];

              samples--;
            }
        }
      level_with /= lev_samples;
      level_pure /= lev_samples;

      /* Now lets create the crater. */

      /* In order to do it efficiently, we calculate for one octant
       * only and use eightfold symmetry, if possible.
       * Main diagonals and axes have a four fold symmetry only.
       * The center point has to be treated single.
       */

#define SQUEEZE 1.3

/* this macro calculates the coordinates, does clipping and modifies
 * the elevation at this spot due to shift and weight.
 * hfOrig() contains the crater-free underground. p_HF() contains the result.
 * level_with: average altitude of cratered surface in region
 * level_pure: average altitude of uncratered surface
 */

#define SHIFT(x,y) \
  { \
    ii = xloc + (x); jj = yloc + (y); \
    if (wrap || ((ii >= 0) && (ii < terrain->width) && \
                  (jj >= 0) && (jj < terrain->height))) \
    {\
      X_WRAP (ii);  Y_WRAP (jj); \
      terrain->heightfield[jj * terrain->width + ii] = \
      (shift + terrain->heightfield[jj * terrain->width + ii] * weight + \
      (level_with + (data_orig[jj * terrain->width + ii] - level_pure) / \
      SQUEEZE) * (1.0 - weight)); \
    } \
  }

/* macro to do four points at once. Points are rotated by 90 degrees. */
#define FOURFOLD(i,j)   { SHIFT (i,j) SHIFT (-j,i) SHIFT (-i,-j) SHIFT (j,-i) }

/* get eightfold symmetry by mirroring fourfold symmetry along the x==y axe */
#define EIGHTFOLD       { FOURFOLD (i,j) FOURFOLD (j,i) }


      /* The loop covers a triangle (except the center point)
       * Eg crater_size is 3, coordinates are shown as i, j
       *
       *              3,3 j
       *         2,2  3,2 |
       *    1,1  2,1  3,1 v
       * x  1,0  2,0  3,0
       * ^          <-i
       * |
       * center point
       *
       * 2,1 , 3,2 and 3,1 have eightfold symmetry.
       * 1,0 , 2,0 , 3,0 , 1,1 , 2,2 and 3,3 have fourfold symmetry.
       */

      for (i = crater_size; i > 0; i--)
        {
          for (j = i; j >= 0; j--)
            {
              /* check if outside */
              sq_radius = i * i + j * j;
              nsq_rad = (double) sq_radius / crater_size / crater_size;
              if (nsq_rad > 1.0) continue;

              /* inside the crater area */
              shift = crater_scale * crater_profile (nsq_rad);
              weight = crater_dissolve(nsq_rad);

              if (i == j || j == 0)
                FOURFOLD (i, j)
              else
                EIGHTFOLD
            }
        }
      /* the center point */
      shift = crater_scale * crater_profile (0.0);
      weight = crater_dissolve (0.0);
      SHIFT (0,0)

      delete rnd_loop;
    }

  delete data_orig;
  delete rnd_seed;
  delete rnd;
}
 
/* t_terrain_spherical: Convert the terrain into a form useable as
 * a POV-Ray spherical_map.
 */
void t_terrain_spherical(TTerrain *terrain, float offset)
{
	int    x, y;
	int    width;
	int    height;
	float *raster;

	if (offset <= 0.0)
		return;
	if (offset >= 1.0)
		return;

	width = terrain->width;
	height = terrain->height;
	raster = new float[width];

	for (y = 0; y < height; y++)
    {
		float  *data;
		double  scale;
		double  from_x;
		double  fract_x;
		int      int_x;

		scale = ((y * 2.0) / (height - 1)) - 1.0;
		scale = sqrt(1.0 - scale * scale);

		data = &terrain->heightfield[y * width];
		memcpy(raster, data, width * sizeof(float));

		/* Stretch a row of the terrain outwards */
		for (x = 0; x < width; x++)
        {
			double a, b;
			double height;

			from_x = (x - width / 2.0) * scale + width / 2.0;
			int_x = (int)from_x;
			fract_x = from_x - int_x;

			if (int_x < 0)
				a = 0.0;
			else
				a = raster[int_x];

			if (int_x + 1 >= width)
				b = 0.0;
			else
				b = raster[int_x + 1];

			height = a * (1.0 - fract_x) + b * fract_x;
			data[x] = height;
        }

		from_x = (width * offset * 0.5 - width / 2.0) * scale + width / 2.0;
		int_x = (int)from_x;

		/* Make the terrain tilable in the X direction */
		for (x = 0; x < int_x; x++)
        {
			double k;

			k = ((double)x) / int_x;
			data[width - x - 1] = data[width - x - 1] * k + data[x] * (1.0 - k);
        }
    }
//	delete raster;
}
 
/* 
 * return the sum of the neightbouring cells in a square size with 
 * sides 1+(size*2) long
 */
static float grid_neighbour_sum_size(TTerrain *terrain, int x, int y, int size)
{
	int   xx;
	int   yy;
	int   xoff = MAX(x-size, 0);
	int   yoff = MAX(y-size, 0);
	int   xlim = MIN(x+size, terrain->width-1);
	int   ylim = MIN(y+size, terrain->height-1);
	float sum = 0;

	if (x <= 0)
		return -1;
	if (y <= 0)
		return -1;
	if (size < 0)
		return -1;

	for (xx=xoff; xx<=xlim; xx++)
		for (yy=yoff; yy<=ylim; yy++)
			if (xx!=x || yy!=y)
				sum += terrain->heightfield[yy*terrain->width+xx];

	return sum;
} 

static float grid_neighbour_average_size(TTerrain *terrain, int x, int y, int size)
{
	int   xoff = MAX (x-size, 0);
	int   yoff = MAX (y-size, 0);
	int   xlim = MIN (x+size, terrain->width-1);
	int   ylim = MIN (y+size, terrain->height-1);

	float num = (((xlim-xoff)+1) * ((ylim-yoff)+1)) - 1;
	float sum;

	if (num <0)
		return -1;
	sum = grid_neighbour_sum_size (terrain, x, y, size);

	return sum/num;
}

static float grid_neighbour_average(TTerrain *terrain, int x, int y)
{
  return grid_neighbour_average_size(terrain, x, y, 1);
}
 
static bool is_lowest_point_size(TTerrain *terrain, int x, int y, int size)
{
	int   xx;
	int   yy;
	int   xoff;
	int   yoff;
	int   xlim;
	int   ylim;
	float elv;
	float diff;

	if (x <= 0)
		return false;
	if (y <= 0)
		return false;
	if (size < 0)
		return false;

	xoff = MAX (x-size, 0);
	yoff = MAX (y-size, 0);
	xlim = MIN (x+size, terrain->width-1);
	ylim = MIN (y+size, terrain->height-1);

	elv  = terrain->heightfield[y*terrain->width+x]; 

	for (xx=xoff; xx<=xlim; xx++)
		for (yy=yoff; yy<=ylim; yy++)
		{
			diff = terrain->heightfield[yy*terrain->width+xx] - elv;
			if (diff < 0)
				return false;
		}

	return true;
} 

static bool is_lowest_point(TTerrain *terrain, int x, int y)
{
  return is_lowest_point_size(terrain, x, y, 1);
}
 
/*
 * t_terrain_fill_basins: fill the terrains' basins. 
 */
void t_terrain_fill_basins(TTerrain *terrain, int iterations, bool big_grid)
{
	int xsize, ysize;
	int gsize = 1;
	int x, y, i;
	float *tmpdata;

	xsize = terrain->width;
	ysize = terrain->height;
	tmpdata = new float[xsize*ysize];
	memcpy(tmpdata, terrain->heightfield, sizeof(float)*xsize*ysize);
	if (big_grid) 
		gsize = 2;

	for(i=0; i<iterations; i++)
    {
		int count = 0;

		memcpy (tmpdata, terrain->heightfield, sizeof(float)*xsize*ysize);

		for(y=0; y<ysize; y++)
			for (x=0; x<xsize; x++)
			{
				int   off = y*xsize+x;
				float sel;

				if (terrain->selection == NULL)
					sel = 1.0;
				else
					sel = terrain->selection[off];

				if (sel>0.0 && is_lowest_point(terrain, x, y))  
				{
					tmpdata[off] = (sel*grid_neighbour_average_size(terrain,x,y,gsize) + (1.0-sel) * terrain->heightfield[off]);
					count++;
				}
				else 
					tmpdata[off] = terrain->heightfield[off];
			}

		if (count == 0)
			i = iterations;

		memcpy(terrain->heightfield, tmpdata, sizeof(float)*xsize*ysize);
    }

	delete tmpdata;
} 
 
static void t_terrain_iterate_flowmap(TTerrain *tflowmap)
{
	int    i;
	int    size; 
	float *data = tflowmap->heightfield;

	size = tflowmap->width * tflowmap->height;
	for (i=0; i<size; i++)
		data[i] = pow (data[i], 1.15);

	tflowmap->t_terrain_normalize(false);
}
 
/**
 *  upslope_sfd: find the number of single-flow-direction
 *      upslope cells for a given cell. Cache is used to
 *      to store computed SFD values.
 */
static int t_terrain_upslope_sfd(TTerrain *terrain, int given_x, int given_y, float *cache)
{
  if (cache[given_y * terrain->width + given_x] == NO_FLOW)
    {
      bool found;
      int  count;
      int  upflow_x, upflow_y;
      int  x_low, x_high;
      int  y_low, y_high;
      int  x, y;

      upflow_x = given_x;
      upflow_y = given_y;

      found = FALSE;
      x_low = MAX (upflow_x - 1, 0);
      x_high = MIN (upflow_x + 1, terrain->width - 1);
      y_low = MAX (upflow_y - 1, 0);
      y_high = MIN (upflow_y + 1, terrain->height - 1);

      /* find the highest downflow neighbour */
      for (x = x_low; x <= x_high; x++)
        for (y = y_low; y <= y_high; y++)
          {
            if (terrain->heightfield[y * terrain->width + x] >
                terrain->heightfield[upflow_y * terrain->width + upflow_x])
              {
                found = TRUE;
                upflow_x = x;
                upflow_y = y;
              }
          }

      /* downflow */
      if (found)
        count = t_terrain_upslope_sfd (terrain, upflow_x, upflow_y, cache) + 1;
      else
        count = 0;

      cache[given_y * terrain->width + given_x] = count;

      return count;
    }

  return cache[given_y * terrain->width + given_x];
}


/**
 *  upslope_mfd: find the number of multiple-flow-direction
 *      upslope cells for a given cell. hitcache should be
 *      re-initialized every time flowmap() calls this
 *      function since it's being used as an indicator
 *      that a cell has been counted in the current MFD
 *      pass.
 */
static float t_terrain_upslope_mfd(TTerrain *terrain, int given_x, int given_y, float *cache, bool *hitcache)
{
  int   x, y;
  int   x_low, x_high;
  int   y_low, y_high;
  float count;

  count = 0.0;

  x_low = MAX (given_x - 1, 0);
  x_high = MIN (given_x + 1, terrain->width - 1);
  y_low = MAX (given_y - 1, 0);
  y_high = MAX (given_y + 1, terrain->height - 1);

  for (x = x_low; x <= x_high; x++)
    for (y = y_low; y <= y_high; y++)
      {
	int yoff            = y * terrain->width;
	int pos             = yoff + x;
	int gpos            = given_y * terrain->width + given_x;

        if (terrain->heightfield[pos] > terrain->heightfield[gpos] &&
	    hitcache[pos] == FALSE)
	    {
	    if (cache[pos] == NO_FLOW)
	      {
	      hitcache[pos] = TRUE;
              count += t_terrain_upslope_mfd (terrain, x, y, cache, hitcache) +
                                   ((x == given_x || y == given_y) ? 0.6 : 0.4);
              cache[pos] = count;
	      }
	    else
	      {
              count += cache[pos];
	      }
	    }
      }

  return count;
}

/**
 *  flowmap: calculate the flowmap for the height field as detailed in
 *    "Comparison of single and mulitple flow direction algorithms for
 *    computing topographic parameters in TOPMODEL", Wolock & McCabe Jr.,
 *    Water Resources Research, Vol. 31, No. 5, Pages 1315-1324, May 1995
 *
 * /verbatim
 *  The flowmap is essentially   ln(a/tan(b))   where
 *      a = A/C
 *      C = contour length
 *      A = (number of upslope cells + 1) * (grid cell area)
 *      tan(b) = ( change in elevation with neighboring cell /
 *                              cell center distance )
 *      ln = Napierian Log =
 *                                 log (n/10^7)
 *              ln (n) =     -  -------------------
 *                              log (10^7/(10^7-1))
 * /endverbatim
 *
 *  Interestingly enough, the paper uses the Napierian Log, which
 *  in my case gives huge numbers at the top of the scale and zero
 *  at the bottom. I find that using the natural log I get a
 *  range which closely resembles the ones shown in the paper.
 *  Does anybody out there (who has found this) know more about this?
 *  I've probably goofed up somewhere but don't know where.
 */
TTerrain *t_terrain_flowmap(TTerrain *terrain, bool do_sfd, bool ignore_sealevel, float max_elevation_erode)
{
  float     elevation_rt = (float)0.33;
  int       i, x, y, xx, yy;
  int       offxy;
  int       dfx, dfy;                       /* upflow x & y coordinates */
  bool      found;
  int       x_low, x_high;
  int       y_low, y_high;
  int       size;
  double    C = 10.0;                       /* contour length XXXXXXX */
  double    gca = C * C;                    /* Grid Cell Area */
  double    a, A;
  float     fmin;                    /* -NO_FLOW is positive */
  float    *cache;                   /* SFD/MFD cache */
  float    *flowmap;                 /* flowmap */
  bool     *hitcache;                   /* MFD cache */
  TTerrain  *terrain_out;

  fmin = (float)-NO_FLOW;
  terrain_out = new TTerrain(terrain->width, terrain->height);

  flowmap = terrain_out->heightfield;
  size = terrain->width * terrain->height;

  cache = new float[size];
  for (i = 0; i < size; i++)
    cache[i] = fmin;

  if (do_sfd)
    hitcache = NULL;
  else
    hitcache = new bool[size];

  for (y = 0; y < terrain->height; y++)
    for (x = 0; x < terrain->width; x++)
      if (ignore_sealevel ||
          (terrain->heightfield[y * terrain->width + x] > terrain->sealevel &&
           terrain->heightfield[y * terrain->width + x] < max_elevation_erode))
        {
          if (do_sfd)
            A = t_terrain_upslope_sfd(terrain, x, y, cache) * gca;
          else
            {
              for (i = 0; i < size; i++)
                hitcache[i] = FALSE;

              A = t_terrain_upslope_mfd(terrain, x, y, cache, hitcache) * gca;
            }
          a = A / C;

          /* find lowest downslope square */
          found = FALSE;
          dfx = x;
          dfy = y;
          x_low = MAX (dfx - 1, 0);
          x_high = MIN (dfx + 1, terrain->width - 1);
          y_low = MAX (dfy - 1, 0);
          y_high = MIN (dfy + 1, terrain->height - 1);

          for (xx = x_low; xx <= x_high; xx++)
            for (yy = y_low; yy <= y_high; yy++)
              {
                if (terrain->heightfield[yy * terrain->width + xx] <
                    terrain->heightfield[dfy * terrain->width + dfx])
                  {
                    found = TRUE;
                    dfx = xx;
                    dfy = yy;
                  }
              }

          /* there is a downflow */
          offxy = y * terrain->width + x;
          if (found && a != 0.0)
            {
              double tanb;

              tanb = (terrain->heightfield[offxy] -
                      terrain->heightfield[dfy * terrain->width + dfx]) *
                      terrain->width * elevation_rt / C;

              if (fabs (tanb) >= 0.00001)
                {
                  flowmap[offxy] = log (a / tanb);

                  if (flowmap[offxy] < fmin)
                    fmin = flowmap[offxy];
                }
              else
               flowmap[offxy] = (float)NO_FLOW;
            }
          /* no downflow */
          else
            flowmap[offxy] = (float)NO_FLOW;
        }
      else
        flowmap[y * terrain->width + x] = (float)NO_FLOW;

  /* make 0.0 lowest value so that NO_FLOW can equal 0.0 */
  for (i = 0; i < size; i++)
    if (flowmap[i] == (float)NO_FLOW)
      flowmap[i] = 0.0;
    else
      flowmap[i] -= fmin;

  terrain_out->sealevel = (float)0.0;
  terrain_out->t_terrain_normalize(false);

  delete cache;
  delete hitcache;

  return terrain_out;
}

/**
 * erode: erode the HF using the flowmap to determine the terrain delta
 */
int t_terrain_erode_flowmap(TTerrain *terrain, TTerrain *flowmap, int iterations, bool trim_local_peaks)
{
  int      i, x, y;
  double   erosion_rate = 0.01;

  for (i=0; i<iterations; i++)
    {
    int pos = 0;

    t_terrain_fill_basins(terrain, 1, false);

    for (y=0; y<terrain->height; y++)
      for (x=0; x<terrain->width; x++, pos++)
        {
        if (flowmap->heightfield[pos] > 0.0)
          {
          APPLY (terrain, pos, 
                   (terrain->heightfield[pos]-
                     (erosion_rate*flowmap->heightfield[pos])));
	  }
        else
          {
            /* average flowmap value with neighbors */
            if (trim_local_peaks)
              {
                int   count;
                float sum;

                count = 0;
                sum = 0;

                if (x > 0)
                  count++, sum += flowmap->heightfield[pos - 1];

                if (x < terrain->width - 1)
                  count++, sum += flowmap->heightfield[pos + 1];

                if (y > 0)
                  count++, sum +=
                    flowmap->heightfield[pos - terrain->width];

                if (y < terrain->height - 1)
                  count++, sum +=
                    flowmap->heightfield[pos + terrain->width];

                APPLY (terrain, pos, 
                       terrain->heightfield[pos]-(erosion_rate*sum/count));
              }
            else
              {
                APPLY (terrain, pos, 
                         (terrain->heightfield[pos]-
		           (erosion_rate*flowmap->heightfield[pos])));
              }
          }

        if (terrain->heightfield[pos] < 0.0)
          terrain->heightfield[pos] = 0.0;
        }

    t_terrain_roughen_smooth(terrain, false, false, (float)0.05);
    }

  return 0;
}

static int validate_erode_filenames(char **filenames)
{
  int      i;

  /* filenames should be a sprintf format string and contain %s and %d */
  for (i=0; filenames[i]!=NULL; i++)
    {
    char *filename = filenames[i];

    if (filename != NULL)
      {
      /* Should only be more than 1 '%' sign in the filename */
      if (strchr (filename, '%') == strrchr (filename, '%'))
        return -1;

      /* Should have a '%s' in the filename */
      if (strstr (filename, "%s") == NULL)
        return -1;

      /* Should have a '%d' in the filename */
      if (strstr (filename, "%d") == NULL)
        return -1;
      }
    }

  return 0;
}

/**
 * erode: erode the HF using the flowmap to determine the terrain delta
 */
int t_terrain_erode (TTerrain *terrain,
                 int      iterations,          // # of erosion iterations
                 int      max_flow_age,        // new flowmap every n iters
                 int      age_flow_times,      // how many times to age flowmap
                 float    max_elevation_erode, // above this no erosion
                 char    *filename_anim,       // if != NULL save animation
                 char    *filename_flow,       // if != NULL save flowmap
                 int      n_frames,            // # of frames in animation
                 bool     trim_local_peaks,    // trim if (flowmap==0)
                 bool     do_sfd,              // flowmap param
                 bool     ignore_sealevel)     // flowmap param
{
	int       i;
	int       frame_lim = 0;
	int       gcd; 
	char     *filename_array[] = { filename_anim, filename_flow, NULL };
	TTerrain *flowmap_terrain = NULL;

	/* sanity check */
	if (validate_erode_filenames(filename_array))
		return -1;

	/* force parameters to be sensical */
	if (max_flow_age > iterations)
		max_flow_age = iterations;

	frame_lim = iterations/n_frames;

	/* greatest common denominator */
	gcd = greatest_common_denominator(max_flow_age, frame_lim);

	for (i=0; i<iterations; i+=gcd)
    {
		int  fmap_count = i/max_flow_age;
		bool do_new_flowmap = !(i%max_flow_age);
		bool do_age_flowmap = (age_flow_times<=0 ? FALSE : !(fmap_count%(age_flow_times+1)));

		if (do_new_flowmap)
        {
			/* create a new flowmap or iterate/age it */
			if (!do_age_flowmap)
			{
				if (flowmap_terrain) 
					delete flowmap_terrain;

				flowmap_terrain = t_terrain_flowmap(terrain, do_sfd, ignore_sealevel, max_elevation_erode);
			}
			else
				t_terrain_iterate_flowmap(flowmap_terrain);

			/* do we have a filename to save the flowmap with? */
			if (filename_flow != NULL)
			{
				//char *fnt;
				//char *filename_current;

				//FilenameOps *fno = new FilenameOps();
				//fnt = fno->filename_get_base_without_extension(terrain->filename);
				//filename_current = g_strdup_printf (filename_flow,fnt,fmap_count);
				//flowmap_terrain->t_terrain_normalize(false);
				//t_terrain_save (flowmap_terrain, FILE_AUTO, filename_current);

				//g_free (filename_current);
				//g_free (fnt);
			}
		}

		/* erode for max_flow_age teerains */
		t_terrain_erode_flowmap(terrain, flowmap_terrain, gcd, trim_local_peaks);

		/* save eroded terrain */
		if (filename_anim)
        {
			if (!(i%frame_lim))
			{
				//char *fnt;
				//char *filename_current;
				//int   frame_count = i/frame_lim;

				//fnt = filename_get_base_without_extension (terrain->filename);
				//filename_current = g_strdup_printf (filename_anim, fnt, frame_count);
				//t_terrain_normalize (terrain, FALSE);
				//t_terrain_save (terrain, FILE_AUTO, filename_current);

				//g_free (filename_current);
				//g_free (fnt);
			}
        }

		terrain->t_terrain_normalize(false);
    }

	return 0;
}

void t_terrain_roughen_smooth(TTerrain *terrain, bool roughen, bool big_grid, float factor)
{
	float *data;
	int    width, height;
	int    x, y;

	if (factor <= 0.0)
		return;
	if (factor >= 1.0)
		return;

	data = terrain->heightfield;
	width = terrain->width;
	height = terrain->height;

	for (y = 1; y < height - 1; y++)
		for (x = 1; x < width - 1; x++)
		{
			int    pos = y * width + x;
			int    size = (big_grid ? 2 : 1);
			float  value, original, average;

			original = data[pos];
			average = grid_neighbour_average_size (terrain, x, y, size);

			if (roughen)
				value = original - factor * (average - original);
			else
				value = original + factor * (average - original);

			APPLY (terrain, pos, value);
		}
}

/* Digital Filter
 * Given the filter, the terrain and the elevation range, we 
 * calculate the sum of values (multiplied by the filter
 * scaler) for the particular tile being considered.
 * The sum is then divided by the number of tiles in the
 * passed filter.
 * see: http://www.cosc.brocku.ca/Project/info/moss/system/system32.html
 */
void t_terrain_digital_filter(TTerrain *terrain, float *filterData, int filterSize, float elv_min, float elv_max)
{
	int       x, y;
	int       i, j;
	int       width = terrain->width;
	int       height = terrain->height;
	float    *tmpdata;

	if (filterSize < 0)
		return;

	/* create a reference copy of HF data */
	tmpdata = new float[width*height]; 
	memcpy(tmpdata, terrain->heightfield, sizeof(float)*width*height);

	for(y=0; y<height; y++)
    {
		for(x=0; x<width; x++)
		{
			int   off = y*width+x;
			float elv = tmpdata[off];

			if (elv >= elv_min && elv <= elv_max)
			{
				float count = 0;
				float total = 0;
      
				for (j=0; j<filterSize; j++ ) 
					for (i=0; i<filterSize; i++ )
						if (x + (i-(filterSize/2)) < width && x + (i-(filterSize/2)) >= 0 && y + (j-(filterSize/2)) < height && y + (j-(filterSize/2)) >= 0)
						{
							int pos = (y+(j-(filterSize/2)))*width + (x+(i-(filterSize/2)));

							total += terrain->heightfield[pos] * filterData[j*filterSize+i]; 
							count++;
						}

				APPLY (terrain, off, total/count);
			}
		}
    }

	delete tmpdata;
}
 
void t_terrain_rasterize(TTerrain *terrain, int x_size, int y_size, float tightness)
{
	int width = terrain->width;
	int height = terrain->height;

	int x, y;

	if (x_size<0)
		return;
	if (y_size<0)
		return;
	if (tightness <=0 && tightness>=1)
		return;

	for (x=0; x<width; x+=x_size)
		for (y=0; y<height; y+=y_size)
		{
			float avg, sum=0;
			int xx=0, yy =0;
			int xlim = x+x_size;
			int ylim = y+y_size;

			for (xx=x; xx<xlim && xx<width; xx++)
				for (yy=y; yy<ylim && yy<height; yy++)
					sum += terrain->heightfield[yy*width+xx];
			avg = sum/((xx-x)*(yy-y));

			for (yy=y; yy<ylim && yy<height; yy++)
				for (xx=x; xx<xlim && xx<width; xx++)
				{
					int pos = yy*width+xx;
					float elv = terrain->heightfield[pos];
					float diff = (elv - avg)*(1-tightness);
					float newval = avg+diff;

					APPLY (terrain, pos, newval);
				}
		}
}
 
void t_terrain_rotate(TTerrain *terrain, int amount)
{
  if (amount == 0) /* 90 degrees clockwise */
    {
      int    x, y;
      int    width, height;
      float *data, *data2;

      data = terrain->heightfield;
      width = terrain->width;
      height = terrain->height;

      data2 = new float[terrain->width * terrain->height];
      for (x = 0; x < width; x++)
        for (y = 0; y < height; y++)
          data2[x * height + y] = data[(height - y - 1) * width + x];

      terrain->heightfield = data2;
      delete data;

//      if (terrain->selection != NULL)
//        {
//          data = terrain->selection;
//          data2 = g_new (gfloat, terrain->width * terrain->height);
//          for (x = 0; x < width; x++)
//            for (y = 0; y < height; y++)
//              data2[x * height + y] = data[(height - y - 1) * width + x];

//          terrain->selection = data2;
//          g_free (data);
//        }

      terrain->width = height;
      terrain->height = width;
    }
  else if (amount == 1) /* 180 degrees */
    {
      int    pos1, pos2, size;
      float *data;

      pos2 = terrain->width * terrain->height;
      size = pos2 >> 1;
      data = terrain->heightfield;

      for (pos1 = 0; pos1 < size; pos1++)
        {
          float temp;

          pos2--;

          temp = data[pos2];
          data[pos2] = data[pos1];
          data[pos1] = temp;
        }

      if (terrain->selection != NULL)
        {
          pos2 = terrain->width * terrain->height;
          data = terrain->selection;
          for (pos1 = 0; pos1 < size; pos1++)
            {
              float temp;

              pos2--;

              temp = data[pos2];
              data[pos2] = data[pos1];
              data[pos1] = temp;
            }
        }
    }
  else if (amount == 2) /* 270 degrees clockwise */
    {
      int    x, y;
      int    width, height;
      float *data, *data2;

      data = terrain->heightfield;
      width = terrain->width;
      height = terrain->height;

      data2 = new float[terrain->width * terrain->height];
      for (x = 0; x < width; x++)
        for (y = 0; y < height; y++)
          data2[x * height + y] = data[y * width + (width - x - 1)];

      terrain->heightfield = data2;
      delete data;

//      if (terrain->selection != NULL)
//        {
//          data = terrain->selection;
//          data2 = g_new (gfloat, terrain->width * terrain->height);
//          for (x = 0; x < width; x++)
//            for (y = 0; y < height; y++)
//             data2[x * height + y] = data[y * width + (width - x - 1)];

//          terrain->selection = data2;
//          g_free (data);
//        }

      terrain->width = height;
      terrain->height = width;
    }
}
 
void t_terrain_terrace(TTerrain *terrain, int level_count, float factor, bool adjust_sealevel)
{
	int   i, size;
	int   level;
	float range = 1.0, level_range, base, diff;

	/* increase level count by one so that the highest elevation (1.0) gets 
	   the last level (which is 1 point high). */

	level_count++;
	factor = 1 - factor; /* convert tightness scale */

	level_range = range / level_count;

	size = terrain->width * terrain->height;
	for (i = 0; i < size; i++)
    {
		float value;

		level = (int)(terrain->heightfield[i] / level_range);
		base = level * level_range;
		diff = terrain->heightfield[i] - base;

		value = base + diff * factor;

		APPLY(terrain, i, value);
    }
}

void t_terrain_transform(TTerrain *terrain, float sea_threshold, float sea_depth, float sea_dropoff, float above_power, float below_power)
{
	int i, size;

	size = terrain->width * terrain->height;
	for (i = 0; i < size; i++)
    {
		float value;

		value = transform(terrain->heightfield[i], sea_threshold, sea_depth, sea_dropoff, above_power, below_power);

		APPLY(terrain, i, value);
    }
}
 
void t_terrain_tiler(TTerrain *terrain, float offset)
{
	int    x, y;
	int    width, height;
	int    margin;
	float  coeff, step;
	float *data;

	width = terrain->width;
	height = terrain->height;
	data = terrain->heightfield;

	margin = (int)(MIN(width, height) * offset);
	step = 1.0 / margin;

	for (x = 0; x < width; x++)
		for (y = 0, coeff = 0.0; y < margin; y++, coeff += step)
		{
			float v = data[y * width + x] * (1.0 - coeff) + data[(height - y - 1) * width + x] * coeff;
			APPLY(terrain, (height-y-1)*width+x, v);
		}

	for (y = 0; y < height; y++)
		for (x = 0, coeff = 0.0; x < margin; x++, coeff += step)
		{
			float v = data[y * width + x] * (1.0 - coeff) + data[y*width+(width-x-1)] * coeff;
			APPLY(terrain, y*width+(width-x-1), v);
		}
}

void t_terrain_tile(TTerrain *terrain, int multiply)
{
	TTerrain *terrain_clone;
	int      i, j, y, x, pos1, pos2;

	terrain_clone = t_terrain_clone(terrain);
	terrain->t_terrain_set_size(terrain->width * multiply, terrain->height * multiply);
	pos1 = 0;
	for (i = 0; i < multiply; i++)
		for (y = 0; y < terrain_clone->height; y++)
			for (j = 0; j < multiply; j++)
			{
				pos2 = y * terrain_clone->width;

				for (x = 0; x < terrain_clone->width; x++)
					terrain->heightfield[pos1++] = terrain_clone->heightfield[pos2++];
			}
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/