/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: contour.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: contour
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <math.h>
#include <stdlib.h>
#include "filters.h"
#include "trandom.h"
#include "contour.h"

/** ***************************************************************************************************************** **/
/** 				    LOCAL DATA				                                                                      **/
/** ***************************************************************************************************************** **/

GList *first_list;
int    simp_count;

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

CContour::CContour()
{
}

CContour::~CContour()
{
}

Edgemap *CContour::edgemap_new(int width, int height)
{
  Edgemap *map;

  map = new Edgemap();
  map->width = width;
  map->height = height;
  map->data = new unsigned char[width * height];

  return map;
}

void CContour::edgemap_free(Edgemap *map)
{
  delete map->data;
  delete map;
}

/*
 * Edge map: Each element of the edgemap corresponds to exactly one pel in the
 * bitmap.  The bit(s) set provide information about the edges for each pixel.
 * An element can have one of seven values:
 *   * 0     (no edge above or to the left of a pixel)
 *   * EDGE1 (a black pixel has a white one above it)
 *   * EDGE2 (a black pixel has a white one to the left of it)
 *   * EDGE1 | EDGE2 (both conditions for EDGE1 and EDGE2 exist)
 *   * or, subsititute EDGE3 for EDGE1 and EDGE4 for EDGE2 for a white pixel
 *
 * A typical edgemap submatrix:
 *  _______ _______ _____
 * |       |       |    /             ####
 * |       | | ### | |  |             ####  Black Pixel
 * |       | | ### | |  \             ####
 * |_______|_______|____/
 * |  ____ |       |    \                |
 * |  #### |  #### | |   |    ----  and  |  Edges
 * |  #### |  #### | |  /                |
 * |_______|_______|___|
 * |       |       |  .'
 * `--~~--~ ~-___-~~-~
 *
 *  Edge 1    Edge 2    Edge 3    Edge 4
 *   ___        .        ___        ,
 *  |   |     __|__     |###|     __|__
 *__|___|__  |  |oo|  __|###|__  |##|::|
 *  |ooo|    |__|oo|    |:::|    |##|::|
 *  |ooo|       |       |:::|       |
 *              '                   '
 * ':' = White heightfield pel
 * ' ' = White pel on the other side
 * 'o' = Black heightfield pel
 * '#' = Black pel on the other side
 */

#define EDGE1 1
#define EDGE2 2
#define EDGE3 4
#define EDGE4 8

#define UP    0
#define RIGHT 1
#define DOWN  2
#define LEFT  3

/* Turn a bitmap into an edgemap */
void CContour::to_edgemap(unsigned char *bitmap, int level, Edgemap *edgemap)
{
  int i, x, y;

  i = 0;
  for (y = 0; y < edgemap->height; y++)
    for (x = 0; x < edgemap->width; x++)
      {
        if (bitmap[i] > level) /* White */
          {
            if (y > 0 && bitmap[i - edgemap->width] <= level)
              edgemap->data[i] |= EDGE3;
            if (x > 0 && bitmap[i - 1] <= level)
              edgemap->data[i] |= EDGE4;
          }
        else /* Black */
          {
            if (y > 0 && bitmap[i - edgemap->width] > level)
              edgemap->data[i] |= EDGE1;
            if (x > 0 && bitmap[i - 1] > level)
              edgemap->data[i] |= EDGE2;
          }

        i++;
      }
}

/* Is an edge within the bounds of an edgemap? */
bool CContour::within_bounds(Edgemap *map, Edge *edge)
{
  if (edge->x < 0 || edge->y < 0 ||
      edge->x >= map->width || edge->y >= map->height)
    return false;

  if (edge->x == 0 && (edge->bit == EDGE2 || edge->bit == EDGE4))
    return false;

  if (edge->y == 0 && (edge->bit == EDGE1 || edge->bit == EDGE3))
    return false;

  return true;
}

/* Convert an edge to the nearest floating point x y coordinates */
void CContour::to_float(Edge *edge, float *out_x, float *out_y)
{
  if (edge->bit == EDGE2 || edge->bit == EDGE4)
    {
      *out_x = edge->x;
      *out_y = edge->y + 0.5;
      return;
    }

  *out_x = edge->x + 0.5;
  *out_y = edge->y;
}

/* Is the edge within bounds and is it recorded in the edgemap? */
bool CContour::move_ok(Edgemap *map, Edge *edge)
{
  if (within_bounds(map, edge))
    return (map->data[edge->y * map->width + edge->x] & edge->bit) ? 1 : 0;

  return false;
}

/* Convert a white pixel edge to a black pixel edge and vice versa */
int CContour::invert_color(int edge)
{
  if (edge == EDGE1)
    return EDGE3;
  else if (edge == EDGE2)
    return EDGE4;
  else if (edge == EDGE3)
    return EDGE1;
  else if (edge == EDGE4)
    return EDGE2;

  return -1;
}

/* Convert a top border to a side border and vice versa */
int CContour::invert_side(int edge)
{
  if (edge == EDGE1)
    return EDGE2;
  else if (edge == EDGE2)
    return EDGE1;
  else if (edge == EDGE3)
    return EDGE4;
  else if (edge == EDGE4)
    return EDGE3;

  return -1;
}

/* Perform invert_side (invert_color (edge)) */
int CContour::invert_side_and_color(int edge)
{
  if (edge == EDGE1)
    return EDGE4;
  else if (edge == EDGE2)
    return EDGE3;
  else if (edge == EDGE3)
    return EDGE2;
  else if (edge == EDGE4)
    return EDGE1;

  return -1;
}

/* Reverse a cardinal direction UP <-> DOWN, LEFT <-> RIGHT */
int CContour::reverse_direction(int dir)
{
  return (dir + 2) & 3;
}

/*
 * Move in the specified direction starting with the given edge and
 * the last direction
 */

void CContour::move(Edgemap *map, int last_dir, int cur_dir, Edge *in, Edge *out)
{
  *out = *in;

  if (last_dir == UP)
    {
      if (cur_dir == RIGHT)
        {
          out->bit = invert_side(in->bit);
        }
      else if (cur_dir == LEFT)
        {
          out->bit = invert_side_and_color(in->bit);
          out->x--;
        }
      else if (cur_dir == UP)
        {
          out->y--;
        }
    }
  else if (last_dir == DOWN)
    {
      if (cur_dir == RIGHT)
        {
          out->bit = invert_side_and_color(in->bit);
          out->y++;
        }
      else if (cur_dir == LEFT)
        {
          out->bit = invert_side(in->bit);
          out->x--;
          out->y++;
        }
      else if (cur_dir == DOWN)
        {
          out->y++;
        }
    }
  else if (last_dir == LEFT)
    {
      if (cur_dir == UP)
        {
          out->bit = invert_side_and_color(in->bit);
          out->y--;
        }
      else if (cur_dir == DOWN)
        {
          out->bit = invert_side(in->bit);
        }
      else if (cur_dir == LEFT)
        {
          out->x--;
        }
    }
  else if (last_dir == RIGHT)
    {
      if (cur_dir == UP)
        {
          out->bit = invert_side(in->bit);
          out->y--;
          out->x++;
        }
      else if (cur_dir == DOWN)
        {
          out->bit = invert_side(invert_color(in->bit));
          out->x++;
        }
      else if (cur_dir == RIGHT)
        {
          out->x++;
        }
    }
}

/* Follow an edge forward (i.e. clockwise) */
GList *CContour::follow_forward(Edgemap *map, Edge *start_edge, int start_dir, bool *closed)
{
  Edge edge, temp;
  int dir;
  GList *list = NULL;

  first_list = NULL;
  edge = *start_edge;
  dir = start_dir;
  while (1)
    {
      GList *new_list;
      int   i;
      int   last_dir;
      float *position;

      last_dir = dir;
      for (i=1; i<=4; i++)
        {
          dir = (dir + 1) & 3;

          if (i != 2)
            {
              move(map, last_dir, dir, &edge, &temp);
              if (move_ok(map, &temp))
                {
                  edge = temp;

                  break;
                }
            }
        }

      if (i == 5)
        {
          *closed = false;
          return first_list;
        }

      /* Erase edge and add it to the list */
      map->data[edge.y * map->width + edge.x] &= ~edge.bit;
      position = new float[2];
      to_float(&edge, &position[0], &position[1]);
	  new_list = new GList();
	  new_list->next = NULL;
	  new_list->ldata = position;
      if (list)
	  {
        list->next = new_list;
        list = new_list;
	  }
      else
	  {
		first_list = new_list;
        list = new_list;
	  }

      if (edge.x == start_edge->x && edge.y == start_edge->y &&
          edge.bit == start_edge->bit)
        {
          *closed = true;
          return first_list;
        }
    }
}

/* Follow an edge backwards (i.e. counter-clockwise) */
GList *CContour::follow_backward(GList *list, Edgemap *map, Edge *start_edge, int start_dir)
{
  Edge edge, temp;
  int dir;

  edge = *start_edge;
  dir = reverse_direction(start_dir);
  while (1)
    {
      GList *new_list;
      int    i;
      int    last_dir;
      float *position;

      /* Erase edge and add it to the list */
      map->data[edge.y * map->width + edge.x] &= ~edge.bit;
      position = new float[2];
      to_float (&edge, &position[0], &position[1]);
	  new_list = new GList();
	  new_list->next = NULL;
	  new_list->ldata = position;
      if (list)
	  {
        new_list->next = list;
        list = new_list;
	  }
      else
	  {
		//first_list = new_list;
        list = new_list;
	  }

      last_dir = dir;
      for (i = 1; i <= 4; i++)
        {
          dir = (dir + 3) & 3;

          if (i != 2)
            {
              move(map, last_dir, dir, &edge, &temp);
              if (move_ok(map, &temp))
                {
                  edge = temp;

                  break;
                }
            }
        }

      if (i == 5)
        {
          return list;
        }

      if (edge.x == start_edge->x && edge.y == start_edge->y &&
          edge.bit == start_edge->bit)
        {
          return list;
        }
    }
}

/* Trace a line starting with the edge(s) at (x, y) */
GList *CContour::trace_at(Edgemap *map, int x, int y, bool *closed)
{
  GList *list;
  Edge   start_edge;
  int   start_dir;
  int   bit;

  first_list = NULL;
  start_edge.x = x;
  start_edge.y = y;
  bit = map->data[y * map->width + x];

  /* Pick one edge, preferring the top edge (if more than one) */
  if (bit & EDGE1)
    {
      start_edge.bit = EDGE1;
      start_dir = RIGHT;
    }
  else if (bit & EDGE3)
    {
      start_edge.bit = EDGE3;
      start_dir = RIGHT;
    }
  else if (bit & EDGE2)
    {
      start_edge.bit = EDGE2;
      start_dir = DOWN;
    }
  else if (bit & EDGE4)
    {
      start_edge.bit = EDGE4;
      start_dir = DOWN;
    }
  else
    {
      start_edge.bit = -1;
      start_dir = -1;
    }

  list = follow_forward(map, &start_edge, start_dir, closed);
  if (!*closed)
    first_list = follow_backward(list, map, &start_edge, start_dir);

  return first_list;
}

/* Delete the unsimplified trace GList */
void CContour::trace_list_free(GList *list)
{
  GList *pos;
  GList *ghost;

  pos = list;
  while (pos != NULL)
    {
      delete pos->ldata;
	  ghost = pos->next;
	  delete pos;
      pos = ghost;
    }
}

/*
 * Simplify a contour edge list by averaging edge positions.
 * Use the resolution to determine how many to average at one time.
 */

float *CContour::simplify(GList *points, float level, int resolution, bool closed)
{
  float  average_x, average_y;
  int    count;
  int apos;
  int dpos;
  float *pos;
  float *data;
  Array<float> array = NULL;

  array.add(level);

  average_x = average_y = (float)0.0;
  count = 0;
//  points = points->first();
//  for ( pos=(float *)points->first(); pos != 0; pos=(float *)points->next() )
  while (points != NULL)
    {
	  //float *pos;

	  pos = points->ldata;

      average_x += pos[0];
      average_y += pos[1];
      count++;

      if (count == resolution || points == 0)
        {
          average_x /= count;
          average_y /= count;

          array.add(average_x);
          array.add(average_y);

          average_x = 0.0;
          average_y = 0.0;
          count = 0;
        }
	  points = points->next;
    }

  if (closed && array.size() > 5)
    {
      float x, y;

      x = array[1];
      y = array[2];

      array.add(x);
      array.add(y);
    }

  if (array.size() < 9)
    {
      return NULL;
    }

  data = new float[array.size()];
  simp_count = array.size();
  for (apos=0, dpos=0; apos<(array.size()); apos++,dpos++) {
	  data[dpos] = array[apos];
  }
  return data;
}

/* Free a contour list */
void CContour::t_terrain_contour_list_free(GList *contour)
{
  GList *pos;
  GList *ghost;

  pos = contour;
  while (pos != NULL)
    {
      delete pos->ldata;
	  ghost = pos->next;
	  delete pos;
      pos = ghost;
    }
}

/* Generate/update the contour lines for a terrain */
GList *CContour::t_terrain_contour_lines(TTerrain *terrain, int level_count, int resolution)
{
  int     i, x, y, pos, size;
  float   level;
  unsigned char  *bitmap;
  Edgemap *edgemap;
  GList *contour_list = NULL;
  GList *top_list = NULL;

  if (level_count < 0)
	  return NULL;

  bitmap = new unsigned char[terrain->width * terrain->height];
  edgemap = edgemap_new(terrain->width, terrain->height);

  /* Create a bitmap using level as the threshold */
  level = 1.0 / level_count;
  size = terrain->width * terrain->height;
  for (pos=0; pos<size; pos++)
    bitmap[pos] = terrain->heightfield[pos] / level + 0.5;

  for (i = 0; i < level_count; i++)
    {
      /* Convert to an edgemap */
      to_edgemap(bitmap, i, edgemap);

      pos = 0;
      for (y = 0; y < terrain->height; y++)
        {
          for (x = 0; x < terrain->width; x++)
            {
              GList *new_list;

              /* Is there an edge at the given pixel location? */
              if (edgemap->data[pos] != 0)
                {
                  bool      closed;
                  GList  *list;
                  float *simple_array;

                  /* Trace, simplify, and append the isogram */
				  closed = false;
                  list = trace_at(edgemap, x, y, &closed);
                  simple_array = simplify(list, level, resolution, closed);
                  trace_list_free(first_list);
                  if (simple_array != NULL)
				  {
	                new_list = new GList();
	                new_list->next = NULL;
	                new_list->ldata = simple_array;
					new_list->size = simp_count;
                    if (contour_list)
					{
                      contour_list->next = new_list;
                      contour_list = new_list;
					}
                    else
					{
		              top_list = new_list;
                      contour_list = new_list;
					}
				  }
                }

              pos++;
            }
        }
    }

  delete bitmap;
  edgemap_free(edgemap);

  return top_list;
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/