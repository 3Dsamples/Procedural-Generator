/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: filldlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: filldlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef FILLDLHIMPL_H
#define FILLDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "FillDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/
class FillDlgImpl : public FillDlg
{ 
    Q_OBJECT

public:
    FillDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~FillDlgImpl();

	float fill_elev;
	float fill_tight;

public slots:
	void setFillElev(int value);
	void setFillTight(int value);

protected:
	void update_preview();

};

#endif // CRATERSDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/