/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: rasterize.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: rasterize
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef RASTERIZEDLG_H
#define RASTERIZEDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;

class RasterizeDlg : public QDialog
{ 
    Q_OBJECT

public:
    RasterizeDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~RasterizeDlg();

    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QPushButton* OK;
    QPushButton* CANCEL;
    QFrame* Line1;
    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QSlider* rasterize_xsize;
    QSlider* rasterize_ysize;
    QLabel* slid1;
    QLabel* slid2;
    QSlider* rasterize_factor;
    QLabel* slid3;
    QLabel* lbl2;
    QLabel* lbl3;
    QLabel* lbl4;
    QCheckBox* rasterize_do_adjust_size;
	TTerrain *terra;
	TTerrain *main_terra;

public slots:
	virtual void adjustClicked();
	virtual void setXsize(int value);
	virtual void setYsize(int value);
	virtual void setFactor(int value);

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // RASTERIZEDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - 
 *
 ***********************************************************************************************************************/