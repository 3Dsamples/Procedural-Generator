/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: levelconnectordlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: levelconnectordlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef LEVELCONNECTORDLHIMPL_H
#define LEVELCONNECTORDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "LevelConnectorDlg.h"
#include "tterrain.h"
#include <qspinbox.h>
#include <qlabel.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class LevelConnectorDlgImpl : public LevelConnectorDlg
{ 
    Q_OBJECT

public:
    LevelConnectorDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~LevelConnectorDlgImpl();

	int iterations;

public slots:
	void iterChanged();

};

#endif // LEVELCONNECTORDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 01-12-2004
 *   - created
 *
 ***********************************************************************************************************************/