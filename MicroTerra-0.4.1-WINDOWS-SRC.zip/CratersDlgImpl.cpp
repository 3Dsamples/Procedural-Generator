/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: cratersdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: cratersdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "CratersDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

CratersDlgImpl::CratersDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : CratersDlg( parent, name, modal, fl )
{
	centerX = (float)0.50;
	centerY = (float)0.50;
	Count = 100;
	Radius = (float)2.0;
	Height = (float)1.0;
	Cover = (float)0.15;
	newseed = true;
	Seed = 0;
	Wrap = false;
	seed->setText("0");
}

/*  
 *  Destroys the object and frees any allocated resources
 */
CratersDlgImpl::~CratersDlgImpl()
{
}

void CratersDlgImpl::update_preview(bool cxy)
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	t_terrain_craters(clone, Count, Wrap, Height, Radius, Cover, Seed, centerX, centerY);
	clone->t_terrain_normalize(true);
	if (cxy == true)
		PreView->t_terrain_view_set_crosshair(centerX, centerY);
	PreView->t_terrain_view_set_terrain(clone);
}

void CratersDlgImpl::setCenterX(int value)
{
	char buf[15];

	centerX = (float)(value/100.0);
	sprintf(buf,"%1.2f", centerX);
	slid1->setText((char *)buf);
	update_preview(true);
}

void CratersDlgImpl::setCenterY(int value)
{
	char buf[15];

	centerY = (float)(value/100.0);
	sprintf(buf,"%1.2f", centerY);
	slid2->setText((char *)buf);
	update_preview(true);
}

void CratersDlgImpl::setCount(int value)
{
	char buf[15];

	Count = value;
	sprintf(buf,"%d", value);
	slid3->setText((char *)buf);
	update_preview(false);
}

void CratersDlgImpl::setRadius(int value)
{
	char buf[15];

	Radius = (float)(value/100.0);
	sprintf(buf,"%1.2f", Radius);
	slid4->setText((char *)buf);
	update_preview(false);
}

void CratersDlgImpl::setHeight(int value)
{
	char buf[15];

	Height = (float)(value/100.0);
	sprintf(buf,"%1.2f", Height);
	slid5->setText((char *)buf);
	update_preview(false);
}

void CratersDlgImpl::setCoverage(int value)
{
	char buf[15];

	Cover = (float)(value/100.0);
	sprintf(buf,"%1.2f", Cover);
	slid6->setText((char *)buf);
	update_preview(false);
}

void CratersDlgImpl::newseedClicked()
{
	newseed = new_seed->isChecked();
	update_preview(false);
}

void CratersDlgImpl::wrapClicked()
{
	Wrap = wrap->isChecked();
	update_preview(false);
}
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - created
 *
 ***********************************************************************************************************************/