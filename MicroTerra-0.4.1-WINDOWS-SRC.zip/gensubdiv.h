/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gensubdiv.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gensubdiv
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENSUBDIV_H
#define GENSUBDIV_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "tterrain.h"
#include "trandom.h"

/** ***************************************************************************************************************** **/
/** 				      CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/

#define NUM_METHODS_SUBDIV 6

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class genSub
{
public:
	genSub( TTerrain* terra);
	~genSub();
	void t_terrain_generate_subdiv(int method, int size, float scale_factor, int seed);
    void t_terrain_generate_subdiv_seed(int method, int size, float scale_factor, int seed, int sel_x1, int sel_y1, int sel_w, int sel_h);
    void t_terrain_generate_subdiv_seed_ns(int method, int size_x, int size_y, float scale_factor, int seed, int sel_x1, int sel_y1, int sel_w, int sel_h);
	void t_terrain_generate_recursive_square(int size, float scale_factor, bool doinit);
	void t_terrain_generate_recursive_diamond(int size, float scale_factor, bool doinit);
	void t_terrain_generate_offset(int size, float scale_factor);
	void t_terrain_generate_midpoint(int size, float scale_factor);
	void t_terrain_generate_recursive_plasma(int size, float scale_factor, bool doinit);
	void t_terrain_generate_diamond_square(int size, float scale_factor);

private:
	TTerrain* terrain;
	TRandom*  gauss;

	int preferred_size(int n);
	void process_recursive_square(int x1, int y1, int x2, int y2, float max_delta, float scale_factor);
	void random_dot_recursive_diamond(int x1, int y1, int x2, int y2, float max_delta);
	void process_recursive_diamond(int x1, int y1, int x2, int y2, float max_delta, float scale_factor);
	void process_recursive_plasma(int x1, int y1, int x2, int y2, float max_delta, float scale_factor, int type);
	float avg(int x, int y, int strut);
	float avg2(int i, int j, int strut);
};

#endif // GENSUBDIV_H
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/