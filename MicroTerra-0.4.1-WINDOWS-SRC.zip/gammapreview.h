/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gammapreview.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gammapreview
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GAMMAPREVIEW_H
#define GAMMAPREVIEW_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qwidget.h>
#include <qpainter.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class MOGammaPreview : public QWidget
{
    Q_OBJECT

public:
    MOGammaPreview( QWidget *parent=0, const char *name=0, int wFlags=0 );
    ~MOGammaPreview();
	void on_gamma_preview_realize();

	unsigned char *pixbuf;

public slots:
	void gamma_preview_update(int val);

protected:
	void drawPlane(QPainter *);
    void paintEvent( QPaintEvent * );
};

#endif // GAMMAPREVIEW_H
/***********************************************************************************************************************
 * Version history:
 *  * 02-09-2004
 *   - created
 *
 ***********************************************************************************************************************/