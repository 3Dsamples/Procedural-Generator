/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: trandom.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: trandom
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef __T_RANDOM_H__
#define __T_RANDOM_H__

/*
C This random number generator originally appeared in "Toward a Universal 
C Random Number Generator" by George Marsaglia and Arif Zaman. 
C Florida State University Report: FSU-SCRI-87-50 (1987)
C 
C It was later modified by F. James and published in "A Review of Pseudo-
C random Number Generators" 
C 
C THIS IS THE BEST KNOWN RANDOM NUMBER GENERATOR AVAILABLE.
C       (However, a newly discovered technique can yield 
C         a period of 10^600. But that is still in the development stage.)
C
C It passes ALL of the tests for random number generators and has a period 
C   of 2^144, is completely portable (gives bit identical results on all 
C   machines with at least 24-bit mantissas in the floating point 
C   representation). 
C 
C The algorithm is a combination of a Fibonacci sequence (with lags of 97
C   and 33, and operation "subtraction plus one, modulo one") and an 
C   "arithmetic sequence" (using subtraction).
C======================================================================== 
This C language version was written by Jim Butler, and was based on a
FORTRAN program posted by David LaSalle of Florida State University.
seed_ran1() and ran1() added by John Beale 7/23/95
*/

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class TRandom
{
public:
	TRandom(int);
	~TRandom();
	double t_random_rnd(double floor, double ceil);
	void t_random_init(int seed);
	void t_random_init_sequence(int ij, int kl);
	float t_random_rnd1();
	double t_random_gauss();
	int new_seed();

	float u[98];
	float c;
	float cd;
	float cm;
	int   i97;
	int   j97;
};

#endif /* __T_RANDOM_H__ */
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/