/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: tiledlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: tiledlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef TILEDLG_H
#define TILEDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/
#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;

class TileDlg : public QDialog
{ 
    Q_OBJECT

public:
    TileDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~TileDlg();

    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QSlider* tile_offset;
    QLabel* slid1;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QPushButton* OK;
    QPushButton* CANCEL;
    QFrame* Line1;
    QGroupBox* GroupBox3;
    QLabel* lbl2;
    QLabel* lbl3;
    QCheckBox* assemble_terrains;
    QSlider* assemble_terrains_x;
    QSlider* assemble_terrains_y;
    QLabel* slid3;
    QLabel* slid2;
	TTerrain *terra;

public slots:
	virtual void setOffset(int value);
	virtual void terasClicked();
	virtual void setAssemX(int value);
	virtual void setAssemY(int value);

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // TILEDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/