/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: aboutdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: aboutdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef ABOUTDLG_H
#define ABOUTDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QFrame;
class QLabel;
class AboutView;

class AboutDlg : public QDialog
{ 
    Q_OBJECT

public:
    AboutDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~AboutDlg();

    QFrame*    Frame;
	AboutView* View;
    QLabel*    TextLabel2;
    QLabel*    TextLabel1;
    QLabel*    TextLabel3;
    QLabel*    TextLabel4;

protected:
    bool event(QEvent* );
};

#endif // ABOUTDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 14-09-2004
 *   - created
 *
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/