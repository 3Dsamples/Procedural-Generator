/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gensubdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gensubdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "genSubDlg.h"

#include <qcheckbox.h>
#include <qcombobox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a genSubDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
genSubDlg::genSubDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	  setName( "genSubDlg" );
    resize( 353, 251 ); 
    setCaption( "Subdivision Window" );
    setSizeGripEnabled( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 71, 207, 210, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    pb_generate = new QPushButton( privateLayoutWidget, "pb_generate" );
    pb_generate->setText( "&Generate" );
    pb_generate->setAutoDefault( TRUE );
    pb_generate->setDefault( TRUE );
    Layout1->addWidget( pb_generate );

    pb_cancel = new QPushButton( privateLayoutWidget, "pb_cancel" );
    pb_cancel->setText( "&Cancel" );
    pb_cancel->setAutoDefault( TRUE );
    Layout1->addWidget( pb_cancel );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 333, 185 ) ); 
    GroupBox1->setTitle( "Parameters" );

    seedlbl = new QLabel( GroupBox1, "seedlbl" );
    seedlbl->setGeometry( QRect( 10, 150, 43, 20 ) ); 
    seedlbl->setFrameShape( QLabel::Box );
    seedlbl->setFrameShadow( QLabel::Raised );
    seedlbl->setText( "Seed" );

    sb_scale = new QSpinBox( GroupBox1, "sb_scale" );
    sb_scale->setGeometry( QRect( 143, 77, 90, 24 ) ); 
    sb_scale->setMaxValue( 10 );
    sb_scale->setMinValue( 0 );
    sb_scale->setLineStep( 1 );
    sb_scale->setValue( 5 );

    tl_scalefac = new QLabel( GroupBox1, "tl_scalefac" );
    tl_scalefac->setGeometry( QRect( 50, 79, 89, 21 ) ); 
    tl_scalefac->setFrameShape( QLabel::Box );
    tl_scalefac->setFrameShadow( QLabel::Raised );
    tl_scalefac->setText( "Scale Factor" );

    le_seed = new QLineEdit( GroupBox1, "le_seed" );
    le_seed->setGeometry( QRect( 57, 149, 110, 22 ) ); 

    cb_newseed = new QCheckBox( GroupBox1, "cb_newseed" );
    cb_newseed->setGeometry( QRect( 10, 120, 140, 20 ) ); 
    cb_newseed->setText( "Generate new seed" );

    tl_submethod = new QLabel( GroupBox1, "tl_submethod" );
    tl_submethod->setGeometry( QRect( 11, 18, 129, 21 ) ); 
    tl_submethod->setFrameShape( QLabel::Box );
    tl_submethod->setFrameShadow( QLabel::Raised );
    tl_submethod->setText( "Subdivision Method" );

    ComboBox1 = new QComboBox( FALSE, GroupBox1, "ComboBox1" );
    ComboBox1->setGeometry( QRect( 143, 17, 180, 22 ) ); 
    ComboBox1->insertItem( "Recursive Square" );
    ComboBox1->insertItem( "Recursive Diamond" );
    ComboBox1->insertItem( "Recursive Plasma" );
    ComboBox1->insertItem( "Offset Square" );
    ComboBox1->insertItem( "Midpoint" );
    ComboBox1->insertItem( "Diamond Square" );

    sb_size = new QSpinBox( GroupBox1, "sb_size" );
    sb_size->setGeometry( QRect( 143, 46, 90, 24 ) ); 
    sb_size->setButtonSymbols( QSpinBox::UpDownArrows );
    sb_size->setMaxValue( 1024 );
    sb_size->setMinValue( 0 );
    sb_size->setLineStep( 1 );
	sb_size->setValue( 400 );

    tl_size = new QLabel( GroupBox1, "tl_size" );
    tl_size->setGeometry( QRect( 102, 48, 38, 21 ) ); 
    tl_size->setFrameShape( QLabel::Box );
    tl_size->setFrameShadow( QLabel::Raised );
    tl_size->setText( "Size" );

    Line1 = new QFrame( GroupBox1, "Line1" );
    Line1->setGeometry( QRect( 1, 100, 330, 20 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    // signals and slots connections
    connect( pb_generate, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( pb_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( cb_newseed, SIGNAL( clicked() ), this, SLOT( seedClicked() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
genSubDlg::~genSubDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

void genSubDlg::seedClicked()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 03-01-2003
 *   - 
 *
 ***********************************************************************************************************************/