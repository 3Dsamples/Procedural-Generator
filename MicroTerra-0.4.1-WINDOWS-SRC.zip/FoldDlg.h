/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: folddlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: folddlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef FOLDDLG_H
#define FOLDDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;

class FoldDlg : public QDialog
{ 
    Q_OBJECT

public:
    FoldDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~FoldDlg();

    QPushButton* OK;
    QPushButton* CANCEL;
    QFrame* Line1;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QSlider* fold_offset;
    QLabel* slid1;
	TTerrain *terra;

public slots:
	virtual void setOffset(int value);

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // FOLDDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/