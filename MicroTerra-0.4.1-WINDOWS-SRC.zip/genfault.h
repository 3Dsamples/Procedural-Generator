/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genfault.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genfault
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        : This code is based on the Faulting algorithm descriptions given at 
 *						  http://www.lighthouse3d.com/opengl/terrain/index.php3?fault
 *                        by Ant�nio Ramires Fernandes
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENFAULT_H
#define GENFAULT_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "tterrain.h"
#include "trandom.h"

/** ***************************************************************************************************************** **/
/** 				      CONSTANTS				                                                                      **/
/** ***************************************************************************************************************** **/

#define NUM_METHODS_FAULTING 5

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class genFault
{
public:
	genFault(TTerrain* terra);
	~genFault();
	void t_terrain_generate_fault(int method, int size, int nIterations, int seed, float factor, int cycles, int useConstantSize);

private:
	TTerrain *terrain;

	void t_terrain_iterate_line(TTerrain *terrain, TRandom *gauss, int method, int nIterations, float factor);
	void t_terrain_iterate_circles(TTerrain *terrain, TRandom *gauss, int nIterations, float factor); 
	void t_terrain_iterate_squares(TTerrain *terrain, TRandom *gauss, int nIterations, float factor, int useConstantSize); 
	void t_terrain_iterate_particle_deposition(TTerrain *terrain, TRandom *gauss, int nCycles, int nIterations, float factor);
};

#endif // GENFAULT_H
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/