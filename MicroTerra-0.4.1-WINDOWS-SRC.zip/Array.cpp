/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: array.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: array
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <new.h>
#include <stdlib.h>

#include "Array.H"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

template <class T>
Array<T>::Array(int size) : data_(0), size_(0) {
  assert(size >= 0);

  resize(size);
}

template <class T>
Array<T>::Array(const Array &init) : data_(0), size_(0) {
  add(init.data_, init.size_);
}


template <class T>
Array<T>::~Array() {
  resize(0);
}


template <class T>
void
Array<T>::add(const T *items, int num) {
  assert(num >= 0);
  assert(items != 0);

  if (num <= 0) return;

  data_ = (T *) realloc(data_, (size_+num) * sizeof (T));
  if (data_ == 0) abort();

  for (int i=0; i<num; i++) {
    new (data_ + size_ + i) T(items[i]);
  }

  size_ += num;
}


template <class T>
void
Array<T>::resize(int size) {
  assert(size >= 0);

  for (int i=size; i<size_; i++) {
    data_[i].~T();
  }

  if (size == 0) {
    free(data_);
    data_ = 0;
    size_ = 0;
  } else {
    data_ = (T *) realloc(data_, size * sizeof (T));
    if (data_ == 0) abort();

    if (size > size_) {
      for (int i=size_; i<size; i++) {
	new (data_ + i) T;
      }
    }
  }

  size_ = size;
}

template <class T>
Array<T> &
Array<T>::operator =(const Array &init) {
  if (&init != this) {
    resize(init.size_);

    for (int i=0; i<size_; i++) {
      data_[i] = init.data_[i];
    }
  }

  return *this;
}


template Array<float>;
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/