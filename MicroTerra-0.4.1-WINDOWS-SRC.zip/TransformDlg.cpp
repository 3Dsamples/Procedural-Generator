/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: transformdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: transformdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "TransformDlg.h"

#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a TransformDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
TransformDlg::TransformDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "TransformDlg" );
    resize( 779, 251 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Transform" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 175 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 190, 777, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 300, 210, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 350, 175 ) ); 
    GroupBox2->setTitle( tr( "Parameters" ) );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 21, 80, 20 ) ); 
    lbl1->setText( tr( "Sea threshold" ) );
    lbl1->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl2 = new QLabel( GroupBox2, "lbl2" );
    lbl2->setGeometry( QRect( 10, 50, 60, 17 ) ); 
    lbl2->setText( tr( "Sea depth" ) );
    lbl2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    lbl3 = new QLabel( GroupBox2, "lbl3" );
    lbl3->setGeometry( QRect( 10, 80, 80, 20 ) ); 
    lbl3->setText( tr( "Sea drop-off" ) );

    lbl4 = new QLabel( GroupBox2, "lbl4" );
    lbl4->setGeometry( QRect( 10, 105, 80, 15 ) ); 
    lbl4->setLineWidth( 2 );
    lbl4->setText( tr( "Power factor" ) );

    lbl4_4 = new QLabel( GroupBox2, "lbl4_4" );
    lbl4_4->setGeometry( QRect( 10, 117, 90, 16 ) ); 
    lbl4_4->setText( tr( "(above sealevel)" ) );

    lbl5 = new QLabel( GroupBox2, "lbl5" );
    lbl5->setGeometry( QRect( 11, 135, 80, 15 ) ); 
    lbl5->setLineWidth( 2 );
    lbl5->setText( tr( "Power factor" ) );

    lbl5_5 = new QLabel( GroupBox2, "lbl5_5" );
    lbl5_5->setGeometry( QRect( 11, 147, 90, 16 ) ); 
    lbl5_5->setText( tr( "(below sealevel)" ) );

    sea_threshold = new QSlider( GroupBox2, "sea_threshold" );
    sea_threshold->setGeometry( QRect( 135, 20, 150, 20 ) ); 
    sea_threshold->setMaxValue( 100 );
    sea_threshold->setPageStep( 0 );
    sea_threshold->setValue( 33 );
    sea_threshold->setOrientation( QSlider::Horizontal );
    sea_threshold->setTickmarks( QSlider::NoMarks );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 295, 18, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "0.33" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    sea_depth = new QSlider( GroupBox2, "sea_depth" );
    sea_depth->setGeometry( QRect( 135, 50, 150, 20 ) ); 
    sea_depth->setMaxValue( 100 );
    sea_depth->setPageStep( 0 );
    sea_depth->setValue( 33 );
    sea_depth->setOrientation( QSlider::Horizontal );
    sea_depth->setTickmarks( QSlider::NoMarks );

    slid2 = new QLabel( GroupBox2, "slid2" );
    slid2->setGeometry( QRect( 295, 46, 35, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2_font.setBold( TRUE );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "0.33" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

    sea_dropoff = new QSlider( GroupBox2, "sea_dropoff" );
    sea_dropoff->setGeometry( QRect( 135, 80, 150, 20 ) ); 
    sea_dropoff->setMinValue( 1 );
    sea_dropoff->setMaxValue( 100 );
    sea_dropoff->setPageStep( 0 );
    sea_dropoff->setValue( 75 );
    sea_dropoff->setOrientation( QSlider::Horizontal );
    sea_dropoff->setTickmarks( QSlider::NoMarks );

    slid3 = new QLabel( GroupBox2, "slid3" );
    slid3->setGeometry( QRect( 295, 80, 35, 17 ) ); 
    QFont slid3_font(  slid3->font() );
    slid3_font.setPointSize( 10 );
    slid3_font.setBold( TRUE );
    slid3->setFont( slid3_font ); 
    slid3->setText( tr( "0.75" ) );
    slid3->setAlignment( int( QLabel::AlignCenter ) );

    above_power = new QSlider( GroupBox2, "above_power" );
    above_power->setGeometry( QRect( 135, 110, 150, 20 ) ); 
    above_power->setMinValue( 5 );
    above_power->setMaxValue( 500 );
    above_power->setValue( 150 );
    above_power->setOrientation( QSlider::Horizontal );
    above_power->setTickmarks( QSlider::NoMarks );

    slid4 = new QLabel( GroupBox2, "slid4" );
    slid4->setGeometry( QRect( 295, 109, 35, 20 ) ); 
    QFont slid4_font(  slid4->font() );
    slid4_font.setPointSize( 10 );
    slid4_font.setBold( TRUE );
    slid4->setFont( slid4_font ); 
    slid4->setText( tr( "1.50" ) );
    slid4->setAlignment( int( QLabel::AlignCenter ) );

    below_power = new QSlider( GroupBox2, "below_power" );
    below_power->setGeometry( QRect( 135, 140, 150, 20 ) ); 
    below_power->setMinValue( 5 );
    below_power->setMaxValue( 500 );
    below_power->setValue( 400 );
    below_power->setOrientation( QSlider::Horizontal );

    slid5 = new QLabel( GroupBox2, "slid5" );
    slid5->setGeometry( QRect( 295, 138, 35, 20 ) ); 
    QFont slid5_font(  slid5->font() );
    slid5_font.setPointSize( 10 );
    slid5_font.setBold( TRUE );
    slid5->setFont( slid5_font ); 
    slid5->setText( tr( "4.00" ) );
    slid5->setAlignment( int( QLabel::AlignCenter ) );

    GroupBox3 = new QGroupBox( this, "GroupBox3" );
    GroupBox3->setGeometry( QRect( 495, 10, 275, 175 ) ); 
    GroupBox3->setTitle( tr( "Transfer Function" ) );

    Frame2 = new QFrame( GroupBox3, "Frame2" );
    Frame2->setGeometry( QRect( 10, 35, 254, 106 ) ); 
    Frame2->setFrameShape( QFrame::WinPanel );
    Frame2->setFrameShadow( QFrame::Sunken );

	Transfer = new TerrainView( Frame2, "Transfer" );
	Transfer->setGeometry( QRect( 2, 2, 250, 102 ) );
	Transfer->show();

	terra = NULL;

    // signals and slots connections
    connect( sea_threshold, SIGNAL(valueChanged(int)), this, SLOT(setThreshold(int)) );
    connect( sea_depth, SIGNAL(valueChanged(int)), this, SLOT(setDepth(int)) );
    connect( sea_dropoff, SIGNAL(valueChanged(int)), this, SLOT(setDropoff(int)) );
    connect( above_power, SIGNAL(valueChanged(int)), this, SLOT(setAbove(int)) );
    connect( below_power, SIGNAL(valueChanged(int)), this, SLOT(setBelow(int)) );
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
TransformDlg::~TransformDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool TransformDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev );
	
    if ( ev->type() == QEvent::ApplicationFontChange )
	{
		QFont slid1_font(  slid1->font() );
		slid1_font.setPointSize( 10 );
		slid1_font.setBold( TRUE );
		slid1->setFont( slid1_font ); 
		QFont slid2_font(  slid2->font() );
		slid2_font.setPointSize( 10 );
		slid2_font.setBold( TRUE );
		slid2->setFont( slid2_font ); 
		QFont slid3_font(  slid3->font() );
		slid3_font.setPointSize( 10 );
		slid3_font.setBold( TRUE );
		slid3->setFont( slid3_font ); 
		QFont slid4_font(  slid4->font() );
		slid4_font.setPointSize( 10 );
		slid4_font.setBold( TRUE );
		slid4->setFont( slid4_font ); 
		QFont slid5_font(  slid5->font() );
		slid5_font.setPointSize( 10 );
		slid5_font.setBold( TRUE );
		slid5->setFont( slid5_font ); 
    }
    return ret;
}

void TransformDlg::setThreshold(int value)
{
}

void TransformDlg::setDepth(int value)
{
}

void TransformDlg::setDropoff(int value)
{
}

void TransformDlg::setAbove(int value)
{
}

void TransformDlg::setBelow(int value)
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/