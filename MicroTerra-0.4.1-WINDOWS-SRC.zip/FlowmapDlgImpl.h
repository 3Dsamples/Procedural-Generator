/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: flowmapdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: flowmapdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef FLOWMAPDLHIMPL_H
#define FLOWMAPDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "FlowmapDlg.h"
#include "tterrain.h"
#include <qspinbox.h>
#include <qlabel.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class FlowmapDlgImpl : public FlowmapDlg
{ 
    Q_OBJECT

public:
    FlowmapDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~FlowmapDlgImpl();

	bool   direction;
	bool   sealevel;
 
public slots:
	void single_Changed();
	void multiple_Changed();
	void sealevelClicked();

protected:
	void update_view();
};

#endif // FLOWMAPDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/