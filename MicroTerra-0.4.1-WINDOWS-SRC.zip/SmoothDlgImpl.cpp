/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: smoothdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: smoothdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "SmoothDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

SmoothDlgImpl::SmoothDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : SmoothDlg( parent, name, modal, fl )
{
	factor = (float)0.50;
	big = false;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
SmoothDlgImpl::~SmoothDlgImpl()
{
}

void SmoothDlgImpl::update_preview()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	t_terrain_roughen_smooth(clone, false, big, factor);
	PreView->t_terrain_view_set_terrain(clone);
}

void SmoothDlgImpl::setFactor(int value)
{
	char buf[15];

	factor = (float)(value/100.0);
	sprintf(buf,"%1.2f", factor);
	slid1->setText((char *)buf);
	update_preview();
}

void SmoothDlgImpl::bigClicked()
{
	big = smooth_big->isChecked();
	update_preview();
}
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/