/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: sphericalmapdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: sphericalmapdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef SPERICALMAPDLHIMPL_H
#define SPERICALMAPDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "SpericalmapDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qslider.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class SpericalmapDlgImpl : public SpericalmapDlg
{ 
    Q_OBJECT

public:
    SpericalmapDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~SpericalmapDlgImpl();

	float offs;

public slots:
	void setOffset(int value);

protected:
	void update_preview();

};

#endif // SPERICALMAPDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/