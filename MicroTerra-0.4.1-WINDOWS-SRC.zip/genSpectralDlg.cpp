/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genspectraldlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genspectraldlg
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "genSpectralDlg.h"

#include <qcheckbox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a genSpectralDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
genSpectralDlg::genSpectralDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "genSpectralDlg" );
    resize( 227, 251 ); 
    setCaption( "Spectral Window" );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 10, 210, 210, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    pb_generate = new QPushButton( privateLayoutWidget, "pb_generate" );
    pb_generate->setText( "&Generate" );
    pb_generate->setAutoDefault( TRUE );
    pb_generate->setDefault( TRUE );
    Layout1->addWidget( pb_generate );

    pb_cancel = new QPushButton( privateLayoutWidget, "pb_cancel" );
    pb_cancel->setText( "&Cancel" );
    pb_cancel->setAutoDefault( TRUE );
    Layout1->addWidget( pb_cancel );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 210, 190 ) ); 
    GroupBox1->setTitle( "Parameters" );

    Line1 = new QFrame( GroupBox1, "Line1" );
    Line1->setGeometry( QRect( 2, 100, 204, 20 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    sizelbl = new QLabel( GroupBox1, "sizelbl" );
    sizelbl->setGeometry( QRect( 10, 20, 67, 20 ) ); 
    sizelbl->setText( "Size" );

    fracdimlbl = new QLabel( GroupBox1, "fracdimlbl" );
    fracdimlbl->setGeometry( QRect( 10, 50, 120, 20 ) ); 
    fracdimlbl->setText( "Fractal Dimensions" );

    seedlbl = new QLabel( GroupBox1, "seedlbl" );
    seedlbl->setGeometry( QRect( 10, 150, 67, 20 ) ); 
    seedlbl->setText( "Seed" );

    sb_size = new QSpinBox( GroupBox1, "sb_size" );
    sb_size->setGeometry( QRect( 130, 20, 70, 24 ) ); 
    sb_size->setButtonSymbols( QSpinBox::UpDownArrows );
    sb_size->setMaxValue( 1024 );
    sb_size->setMinValue( 0 );
    sb_size->setValue( 400 );

    sb_fracdim = new QSpinBox( GroupBox1, "sb_fracdim" );
    sb_fracdim->setGeometry( QRect( 130, 50, 70, 24 ) ); 
    sb_fracdim->setButtonSymbols( QSpinBox::UpDownArrows );
    sb_fracdim->setMaxValue( 299 );
    sb_fracdim->setMinValue( 200 );
    sb_fracdim->setValue( 200 );

    cb_trigofuncs = new QCheckBox( GroupBox1, "cb_trigofuncs" );
    cb_trigofuncs->setGeometry( QRect( 10, 80, 180, 20 ) ); 
    cb_trigofuncs->setText( "Invert trignametric functions" );

    cb_newseed = new QCheckBox( GroupBox1, "cb_newseed" );
    cb_newseed->setGeometry( QRect( 10, 120, 140, 20 ) ); 
    cb_newseed->setText( "Generate new seed" );

    le_seed = new QLineEdit( GroupBox1, "le_seed" );
    le_seed->setGeometry( QRect( 90, 150, 110, 22 ) ); 

    // signals and slots connections
    connect( pb_generate, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( pb_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( cb_newseed, SIGNAL( clicked() ), this, SLOT( seedClicked() ) );
    connect( cb_trigofuncs, SIGNAL( clicked() ), this, SLOT( trigoClicked() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
genSpectralDlg::~genSpectralDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

void genSpectralDlg::trigoClicked()
{
}

void genSpectralDlg::seedClicked()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/