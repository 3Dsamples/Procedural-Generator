/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: kconfigbase.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: kconfigbase
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#include "kconfigbase.h"

// Unix includes
#include <stdlib.h>
#include <ctype.h>

// Qt includes
#include <qfile.h>

// KDE includes
#include "kdebug.h"
#include "qapp.h"
//#include "qcharsets.h"

static QString printableToString(const QString& s){
  if (!s.contains('\\'))
    return s;
  QString result="";
  unsigned int i = 0;
  if (s.length()>1){ // remember: s.length() is unsigned....
    for (i=0;i<s.length()-1;i++){
      if (s[(int)i] == '\\'){
	i++;
	if (s[(int)i] == '\\')
	  result.insert(result.length(), s[(int)i]);
	else if (s[(int)i] == 'n')
	  result.append("\n");
	else if (s[(int)i] == 't')
	  result.append("\t");
	else if (s[(int)i] == 'r')
	  result.append("\r");
	else {
	  result.append("\\");
	  result.insert(result.length(), s[(int)i]);
	}
      }
      else
	result.insert(result.length(), s[(int)i]);
    }
  }
  if (i<s.length())
    result.insert(result.length(), s[(int)i]);
  return result;
}

KConfigBase::KConfigBase()
{
  pData = new KConfigBaseData();

  // setup a group entry for the default group
  KEntryDict* pDefGroup = new KEntryDict( 37, false );
  pDefGroup->setAutoDelete( true );
  data()->aGroupDict.insert( "<default>", pDefGroup );
}


KConfigBase::~KConfigBase()
{
  delete pData;
}


void KConfigBase::setLocale()
{
  data()->bLocaleInitialized = true;
/*
  QApplication *app = QApplication::getQApplication();
  
  if (app)
    pData->aLocaleString = app->getLocale()->language();
  else*/
    pData->aLocaleString = "C";
}

void KConfigBase::parseOneConfigFile( QFile& rFile, 
				      KGroupDict* pWriteBackDict,
				      bool bGlobal )
{
    if (!rFile.isOpen()) // come back, if you have real work for us ;->
      return;

  QString aCurrentLine;
  QString aCurrentGroup = "";

  QDict<KEntryDict> *pDict;
  if( pWriteBackDict )
	// write back mode - don't mess up the normal dictionary
	pDict = pWriteBackDict;
  else
	// normal mode - use the normal dictionary
	pDict = &(data()->aGroupDict);

  KEntryDict* pCurrentGroupDict = (*pDict)[ "<default>" ];
  
  // reset the stream's device
  rFile.at(0);
  QTextStream aStream( &rFile );
  while( !aStream.eof() )
    {
      aCurrentLine = aStream.readLine();

      // check for a group
      int nLeftBracket = aCurrentLine.find( '[' );
      int nRightBracket = aCurrentLine.find( ']', 1 );
      if( nLeftBracket == 0 && nRightBracket != -1 )
	{
	  // group found; get the group name by taking everything in  
	  // between the brackets  
	  aCurrentGroup = 
	    aCurrentLine.mid( 1, nRightBracket-1 );

	  // check if there already is such a group in the group
	  // dictionary
	  pCurrentGroupDict = (*pDict)[ aCurrentGroup ];
	  if( !pCurrentGroupDict )
	    {
	      // no such group -> create a new entry dictionary
	      KEntryDict* pNewDict = new KEntryDict( 37, false );
	      pNewDict->setAutoDelete( true );
	      (*pDict).insert( aCurrentGroup, pNewDict );

	      // this is now the current group
	      pCurrentGroupDict = pNewDict;
	    }
	  continue;
	};

      if( aCurrentLine[0] == '#' )
	// comment character in the first column, skip the line
	continue;
      
      int nEqualsPos = aCurrentLine.find( '=' );
      if( nEqualsPos == -1 )
		// no equals sign: incorrect or empty line, skip it
		continue;
      
      // insert the key/value line into the current dictionary
	  KEntryDictEntry* pEntry = new KEntryDictEntry;
	  pEntry->aValue = 
	    printableToString(aCurrentLine.right( aCurrentLine.length()-nEqualsPos-1 )
			      ).stripWhiteSpace(); 
	  pEntry->bDirty = false;
	  pEntry->bGlobal = bGlobal;
	  pEntry->bNLS = false;

      pCurrentGroupDict->insert( aCurrentLine.left( nEqualsPos ).stripWhiteSpace(),
								 pEntry );
    }
}


void KConfigBase::setGroup( const char* pGroup )
{
  if( !pGroup )
    data()->aGroup = "<default>";
  else
    data()->aGroup = pGroup;
}


const char* KConfigBase::group() const
{
  static QString aEmptyStr = "";
  if( data()->aGroup == "<default>" )
    return aEmptyStr;
  else
    return data()->aGroup;
}


const QString KConfigBase::readEntry( const char* pKey, 
				      const char* pDefault ) const
{
//  if( !data()->bLocaleInitialized && kapp && kapp->localeConstructed() ) 
//      {
	  KConfigBase *that = const_cast<KConfigBase*>(this);
	  that->setLocale();
//      }
  // const_cast<KConfigBase*>(this)->setLocale();

  QString aValue;
  // retrieve the current group dictionary
  KEntryDict* pCurrentGroupDict = data()->aGroupDict[ data()->aGroup.data() ];
  
  if( pCurrentGroupDict )
    {
      // try the localized key first
      QString aLocalizedKey = QString( pKey );
	  aLocalizedKey += "[";
	  aLocalizedKey += data()->aLocaleString;
	  aLocalizedKey += "]";
      // find the value for the key in the current group

      KEntryDictEntry* pEntryData = (*pCurrentGroupDict)[ aLocalizedKey.data() ];

      if( !pEntryData )
		// next try with the non-localized one
		pEntryData = (*pCurrentGroupDict)[ pKey ];
	  
      if( pEntryData )
		aValue = pEntryData->aValue;
      else if( pDefault )
		{
		  aValue = pDefault;
		}
    }
  else if( pDefault )
	aValue = pDefault;


  // only do dollar expansion if so desired
  if( data()->bExpand ) {
	  // check for environment variables and make necessary translations
	  int nDollarPos = aValue.find( '$' );
	  
	  // detach the QString if you are doing modifications!
	  if (nDollarPos != -1)
		  aValue = "";
	  
	  while( nDollarPos != -1 && nDollarPos+1 < static_cast<int>(aValue.length()))
		  {
			  // there is at least one $
			  if( (aValue)[nDollarPos+1] != '$' )
				  {
					  uint nEndPos = nDollarPos;
					  // the next character is no $
					  do
						  {
							  nEndPos++;
						  } while ( //isalnum( (aValue)[(int)nEndPos] ) || 
									nEndPos > aValue.length() );
					  QString aVarName = aValue.mid( nDollarPos+1, 
													 nEndPos-nDollarPos-1 );
					  char* pEnv = getenv( aVarName );
					  if( pEnv )
						  aValue.replace( nDollarPos, nEndPos-nDollarPos, pEnv );
					  else
						  aValue.remove( nDollarPos, nEndPos-nDollarPos );
				  }
			  else {
				  // remove one of the dollar signs
				  aValue.remove( nDollarPos, 1 );
				  nDollarPos++;
			  }
			  nDollarPos = aValue.find( '$', nDollarPos );
		  };
  }
  return aValue;
}

int KConfigBase::readListEntry( const char* pKey, QStrList &list,  
								char sep  ) const
{
  if( !hasKey( pKey ) )
    return 0;
  QString str_list, value;
  str_list = readEntry( pKey );
  if( str_list.isEmpty() )
    return 0; 
  list.clear();
  int i;
  value = "";
  int len = str_list.length();
  for( i = 0; i < len; i++ )
    {
      if( str_list[i] != sep && str_list[i] != '\\' )
	{
	  value += str_list[i];
	  continue;
	}
      if( str_list[i] == '\\' )
	{
	  i++;
	  value += str_list[i];
	  continue;
	}
      list.append( value );
      value.truncate(0);
    }
  if ( str_list[len-1] != sep )
    list.append( value );
  return list.count();
}


int KConfigBase::readNumEntry( const char* pKey, int nDefault) const
{
  bool ok;
  int rc;

  QString aValue = readEntry( pKey );
  if( aValue.isNull() )
	return nDefault;
  else if( aValue == "true" )
	return 1;
  else if( aValue == "on" )
	return 1;
  else
	{
	  rc = aValue.toInt( &ok );
	  return( ok ? rc : 0 );
	}
}


unsigned int KConfigBase::readUnsignedNumEntry( const char* pKey, 
												unsigned int nDefault) const
{
  bool ok;
  unsigned int rc;

  QString aValue = readEntry( pKey );
  if( aValue.isNull() )
	return nDefault;
  else
	{
	  rc = aValue.toUInt( &ok );
	  return( ok ? rc : 0 );
	}
}


long KConfigBase::readLongNumEntry( const char* pKey, long nDefault) const
{
  bool ok;
  long rc;

  QString aValue = readEntry( pKey );
  if( aValue.isNull() )
	return nDefault;
  else
	{
	  rc = aValue.toLong( &ok );
	  return( ok ? rc : 0 );
	}
}


unsigned long KConfigBase::readUnsignedLongNumEntry( const char* pKey, 
													 unsigned long nDefault) const
{
  bool ok;
  unsigned long rc;

  QString aValue = readEntry( pKey );
  if( aValue.isNull() )
	return nDefault;
  else
	{
	  rc = aValue.toULong( &ok );
	  return( ok ? rc : 0 );
	}
}


double KConfigBase::readDoubleNumEntry( const char* pKey, 
										double nDefault) const
{
  bool ok;
  double rc;

  QString aValue = readEntry( pKey );
  if( aValue.isNull() )
	return nDefault;
  else
	{
	  rc = aValue.toDouble( &ok );
	  return( ok ? rc : 0 );
	}
}

float KConfigBase::readDoubleNumEntry( const char* pKey, 
										float nDefault) const
{
  bool ok;
  double rc;

  QString aValue = readEntry( pKey );
  if( aValue.isNull() )
	return nDefault;
  else
	{
	  rc = aValue.toFloat( &ok );
	  return( ok ? rc : 0 );
	}
}


bool KConfigBase::readBoolEntry( const char* pKey, const bool bDefault ) const
{
  QString aValue = readEntry( pKey );
  if( aValue.isNull() )
	return bDefault;
  else
	{
	  if( aValue == "true" || aValue == "on" )
		return true;
	  else
		{
		  bool bOK;
		  int val = aValue.toInt( &bOK );
		  if( bOK && val != 0 )
			return true;
		  else
			return false;
		}
	}
}

  


QFont KConfigBase::readFontEntry( const char* pKey,
				  const QFont* pDefault ) const
{
  QFont aRetFont;

  QString aValue = readEntry( pKey );
  if( !aValue.isNull() )
	{
	  // find first part (font family)
	  int nIndex = aValue.find( ',' );
	  if( nIndex == -1 ){
	    if( pDefault )
	      aRetFont = *pDefault;
	    return aRetFont;
	  }
	  aRetFont.setFamily( aValue.left( nIndex ) );
	  
	  // find second part (point size)
	  int nOldIndex = nIndex;
	  nIndex = aValue.find( ',', nOldIndex+1 );
	  if( nIndex == -1 ){
	    if( pDefault )
	      aRetFont = *pDefault;
	    return aRetFont;
	  }

	  aRetFont.setPointSize( aValue.mid( nOldIndex+1, 
			       	 nIndex-nOldIndex-1 ).toInt() );

	  // find third part (style hint)
	  nOldIndex = nIndex;
	  nIndex = aValue.find( ',', nOldIndex+1 );

	  if( nIndex == -1 ){
	    if( pDefault )
	      aRetFont = *pDefault;
	    return aRetFont;
	  }

	  aRetFont.setStyleHint( (QFont::StyleHint)aValue.mid( nOldIndex+1, 
													nIndex-nOldIndex-1 ).toUInt() );

	  // find fourth part (char set)
	  nOldIndex = nIndex;
	  nIndex = aValue.find( ',', nOldIndex+1 );

	  if( nIndex == -1 ){
	    if( pDefault )
	      aRetFont = *pDefault;
	    return aRetFont;
	  }
         
	 QString chStr=aValue.mid( nOldIndex+1, 
				   nIndex-nOldIndex-1 );
	 bool chOldEntry;			 
	 QFont::CharSet chId=(QFont::CharSet)aValue.mid( nOldIndex+1, 
				   nIndex-nOldIndex-1 ).toUInt(&chOldEntry);			   
         if (chOldEntry)  
	   aRetFont.setCharSet( chId );
//	 else if (qapp){
           //if (chStr=="default")
           //   if( kapp->localeConstructed() ) 
	       //   chStr=klocale->charset();
//	      chStr="iso-8859-1"; 
//	   qapp->getCharsets()->setQFont(aRetFont,chStr);   
//	 }

	  // find fifth part (weight)
	  nOldIndex = nIndex;
	  nIndex = aValue.find( ',', nOldIndex+1 );

	  if( nIndex == -1 ){
	    if( pDefault )
	      aRetFont = *pDefault;
	    return aRetFont;
	  }

	  aRetFont.setWeight( aValue.mid( nOldIndex+1,
    		       		  nIndex-nOldIndex-1 ).toUInt() );

	  // find sixth part (font bits)
	  uint nFontBits = aValue.right( aValue.length()-nIndex-1 ).toUInt();
	  if( nFontBits & 0x01 )
		aRetFont.setItalic( true );
      else
	    aRetFont.setItalic( false );
		
	  if( nFontBits & 0x02 )
		aRetFont.setUnderline( true );
      else
		aRetFont.setUnderline( false );
		
	  if( nFontBits & 0x04 )
		aRetFont.setStrikeOut( true );
      else
		aRetFont.setStrikeOut( false );
		
	  if( nFontBits & 0x08 )
		aRetFont.setFixedPitch( true );
      else
		aRetFont.setFixedPitch( false );
		
	  if( nFontBits & 0x20 )
		aRetFont.setRawMode( true );
      else
		aRetFont.setRawMode( false );
	}
  else {
    if( pDefault )
	aRetFont = *pDefault;
  }

  return aRetFont;
}


QRect KConfigBase::readRectEntry( const char* pKey,
								  const QRect* pDefault ) const
{
  QStrList list;
  
  if( !hasKey( pKey ) )
	{
	  if( pDefault )
		return *pDefault;
	  else
		return QRect();
	}

  int count = readListEntry( pKey, list, ',' );
  if( count != 4 )
	return QRect();
  else
	return QRect( QString( list.at( 0 ) ).toInt(), 
				  QString( list.at( 1 ) ).toInt(), 
				  QString( list.at( 2 ) ).toInt(), 
				  QString( list.at( 3 ) ).toInt() );
}


QPoint KConfigBase::readPointEntry( const char* pKey,
									const QPoint* pDefault ) const
{
  QStrList list;
  
  if( !hasKey( pKey ) )
	{
	  if( pDefault )
		return *pDefault;
	  else
		return QPoint();
	}

  int count = readListEntry( pKey, list, ',' );
  if( count != 2 )
	return QPoint();
  else
	return QPoint( QString( list.at( 0 ) ).toInt(), 
				   QString( list.at( 1 ) ).toInt() );
}


QSize KConfigBase::readSizeEntry( const char* pKey,
								  const QSize* pDefault ) const
{
  QStrList list;
  
  if( !hasKey( pKey ) )
	{
	  if( pDefault )
		return *pDefault;
	  else
		return QSize();
	}

  int count = readListEntry( pKey, list, ',' );
  if( count != 2 )
	return QSize();
  else
	return QSize( QString( list.at( 0 ) ).toInt(), 
				  QString( list.at( 1 ) ).toInt() );
}


QColor KConfigBase::readColorEntry( const char* pKey, 
				    const QColor* pDefault ) const
{
  QColor aRetColor;
  int nRed = 0, nGreen = 0, nBlue = 0;

  QString aValue = readEntry( pKey );
  if( !aValue.isEmpty() )
    {
      if ( aValue.left(1) == "#" ) 
        {
	  aRetColor.setNamedColor(aValue);
	} 
      else
	{

	  bool bOK;
      
	  // find first part (red)
	  int nIndex = aValue.find( ',' );
	  
	  if( nIndex == -1 ){
	    // return a sensible default -- Bernd
	    if( pDefault )
	      aRetColor = *pDefault;
	    return aRetColor;
	  }
	  
	  nRed = aValue.left( nIndex ).toInt( &bOK );
	  
	  // find second part (green)
	  int nOldIndex = nIndex;
	  nIndex = aValue.find( ',', nOldIndex+1 );
	  
	  if( nIndex == -1 ){
	    // return a sensible default -- Bernd
	    if( pDefault )
	      aRetColor = *pDefault;
	    return aRetColor;
	  }
	  nGreen = aValue.mid( nOldIndex+1,
			       nIndex-nOldIndex-1 ).toInt( &bOK );
	  
	  // find third part (blue)
	  nBlue = aValue.right( aValue.length()-nIndex-1 ).toInt( &bOK );
	  
	  aRetColor.setRgb( nRed, nGreen, nBlue );
	}
    }
  else {
    
    if( pDefault )
      aRetColor = *pDefault;
  }

  return aRetColor;
}


const char* KConfigBase::writeEntry( const char* pKey, const char* pValue,
									 bool bPersistent, 
									 bool bGlobal,
									 bool bNLS )
{
//  if( !data()->bLocaleInitialized && kapp && kapp->localeConstructed() )
//      {
	  KConfigBase *that = (KConfigBase*)this;
	  that->setLocale();
//      }
  // const_cast<KConfigBase*>(this)->setLocale();

  QString aValue;

  // retrieve the current group dictionary
  KEntryDict* pCurrentGroupDict = data()->aGroupDict[ data()->aGroup.data() ];

  if( !pCurrentGroupDict )
	{
	  // no such group -> create a new entry dictionary
	  KEntryDict* pNewDict = new KEntryDict( 37, false );
	  pNewDict->setAutoDelete( true );
	  data()->aGroupDict.insert( data()->aGroup.data(), pNewDict );
	  
	  // this is now the current group
	  pCurrentGroupDict = pNewDict;
	}

  // if this is localized entry, add the locale
  QString aLocalizedKey = pKey;
  if( bNLS )
	aLocalizedKey = aLocalizedKey + '[' + data()->aLocaleString + ']';

  // try to retrieve the current entry for this key
  KEntryDictEntry* pEntryData = (*pCurrentGroupDict)[ aLocalizedKey.data() ];
  if( pEntryData )
	{
	  // there already is such a key
	  aValue = pEntryData->aValue; // save old key as return value
	  pEntryData->aValue = pValue; // set new value
	  pEntryData->bGlobal = bGlobal;
	  pEntryData->bNLS = bNLS;
	  if( bPersistent )
		pEntryData->bDirty = TRUE;
	}
  else
	{
	  // the key currently does not exist
	  KEntryDictEntry* pEntry = new KEntryDictEntry;
	  pEntry->bGlobal = bGlobal;
	  pEntry->bNLS = bNLS;
	  pEntry->aValue = pValue;
	  if( bPersistent )
		pEntry->bDirty = TRUE;

	  // insert the new entry into group dictionary
	  pCurrentGroupDict->insert( aLocalizedKey, pEntry );
	}


  // the KConfig object is dirty now
  if( bPersistent )
	data()->bDirty = true;
  return aValue;
}


void KConfigBase::writeEntry ( const char* pKey, QStrList &list, 
							   char sep , bool bPersistent, 
							   bool bGlobal, bool bNLS )
{
  if( list.isEmpty() )
    {
      writeEntry( pKey, "", bPersistent );      
      return;
    }
  QString str_list, value;
  int i;
  for( value = list.first(); !value.isNull() ; value = list.next() )
    {
      for( i = 0; i < (int) value.length(); i++ )
	{
	  if( value[i] == sep || value[i] == '\\' )
	    str_list += '\\';
	  str_list += value[i];
	}
      str_list += sep;
    }
  if( str_list.right(1) == sep )
    str_list.truncate( str_list.length() -1 );
  writeEntry( pKey, (const char *)str_list, bPersistent, bGlobal, bNLS );
}


const char* KConfigBase::writeEntry( const char* pKey, int nValue,
									 bool bPersistent, bool bGlobal,
									 bool bNLS )
{
  QString aValue;

  aValue.setNum( nValue );

  return writeEntry( pKey, (const char *)aValue, bPersistent, bGlobal, bNLS );
}


const char* KConfigBase::writeEntry( const char* pKey, unsigned int nValue,
									 bool bPersistent, bool bGlobal,
									 bool bNLS )
{
  QString aValue;

  aValue.setNum( nValue );

  return writeEntry( pKey, (const char *)aValue, bPersistent, bGlobal, bNLS );
}


const char* KConfigBase::writeEntry( const char* pKey, long nValue,
									 bool bPersistent, bool bGlobal,
									 bool bNLS )
{
  QString aValue;

  aValue.setNum( nValue );

  return writeEntry( pKey, (const char *)aValue, bPersistent, bGlobal, bNLS );
}


const char* KConfigBase::writeEntry( const char* pKey, unsigned long nValue,
									 bool bPersistent, bool bGlobal,
									 bool bNLS )
{
  QString aValue;

  aValue.setNum( nValue );

  return writeEntry( pKey, (const char *)aValue, bPersistent, bGlobal, bNLS );
}


const char* KConfigBase::writeEntry( const char* pKey, double nValue,
									 bool bPersistent, bool bGlobal,
									 bool bNLS )
{
  QString aValue;

  aValue.setNum( nValue, 'g', 15 );

  return writeEntry( pKey, (const char *)aValue, bPersistent, bGlobal, bNLS );
}

const char* KConfigBase::writeEntry( const char* pKey, float nValue,
									 bool bPersistent, bool bGlobal,
									 bool bNLS )
{
  QString aValue;

  aValue.setNum( nValue, 'f', 9 );

  return writeEntry( pKey, (const char *)aValue, bPersistent, bGlobal, bNLS );
}


const char* KConfigBase::writeEntry( const char* pKey, bool bValue,
									 bool bPersistent, 
									 bool bGlobal,
									 bool bNLS )
{
  QString aValue;

  if( bValue )
	aValue = "true";
  else 
	aValue = "false";

  return writeEntry( pKey, (const char *)aValue, bPersistent, bGlobal, bNLS );
}


const char* KConfigBase::writeEntry( const char* pKey, const QFont& rFont, 
									 bool bPersistent, bool bGlobal,
									 bool bNLS )
{
  QString aValue;
  QString aCharset;
  UINT8 nFontBits = 0;
  // this mimics get_font_bits() from qfont.cpp
  if( rFont.italic() )
	nFontBits = nFontBits | 0x01;
  if( rFont.underline() )
	nFontBits = nFontBits | 0x02;
  if( rFont.strikeOut() )
	nFontBits = nFontBits | 0x04;
  if( rFont.fixedPitch() )
	nFontBits = nFontBits | 0x08;
  if( rFont.rawMode() )
	nFontBits = nFontBits | 0x20;

//  if (kapp){
//    aCharset=kapp->getCharsets()->name(rFont);
//  }
  aCharset="default";
  aValue.sprintf( "%s,%d,%d,%s,%d,%d", rFont.family(), rFont.pointSize(),
				  rFont.styleHint(), (const char *)aCharset,
				  rFont.weight(), nFontBits );

  return writeEntry( pKey, (const char *)aValue, bPersistent, bGlobal, bNLS );
}


void KConfigBase::writeEntry( const char* pKey, const QRect& rRect, 
							  bool bPersistent, bool bGlobal,
							  bool bNLS )
{
  QStrList list;
  QString tempstr;
  list.insert( 0, tempstr.setNum( rRect.left() ) );
  list.insert( 1, tempstr.setNum( rRect.top() ) );
  list.insert( 2, tempstr.setNum( rRect.width() ) );
  list.insert( 3, tempstr.setNum( rRect.height() ) );

  writeEntry( pKey, list, ',', bPersistent, bGlobal, bNLS );
}


void KConfigBase::writeEntry( const char* pKey, const QPoint& rPoint, 
							  bool bPersistent, bool bGlobal,
							  bool bNLS )
{
  QStrList list;
  QString tempstr;
  list.insert( 0, tempstr.setNum( rPoint.x() ) );
  list.insert( 1, tempstr.setNum( rPoint.y() ) );

  writeEntry( pKey, list, ',', bPersistent, bGlobal, bNLS );
}


void KConfigBase::writeEntry( const char* pKey, const QSize& rSize, 
							  bool bPersistent, bool bGlobal,
							  bool bNLS )
{
  QStrList list;
  QString tempstr;
  list.insert( 0, tempstr.setNum( rSize.width() ) );
  list.insert( 1, tempstr.setNum( rSize.height() ) );

  writeEntry( pKey, list, ',', bPersistent, bGlobal, bNLS );
}


void KConfigBase::writeEntry( const char* pKey, const QColor& rColor, 
							  bool bPersistent, 
							  bool bGlobal,
							  bool bNLS  )
{
  QString aValue;
  aValue.sprintf( "%d,%d,%d", rColor.red(), rColor.green(), rColor.blue() );

  writeEntry( pKey, (const char *)aValue, bPersistent, bGlobal, bNLS );
}


void KConfigBase::rollback( bool bDeep )
{
  // clear the global bDirty flag in all cases
  data()->bDirty = false;

  // if bDeep is true, clear the bDirty flags of all the entries
  if( !bDeep )
	return;
  QDictIterator<KEntryDict> aIt( data()->aGroupDict );
  // loop over all the groups
  const char* pCurrentGroup;
  while( (pCurrentGroup = aIt.currentKey()) )
	{
	  QDictIterator<KEntryDictEntry> aInnerIt( *aIt.current() );
	  // loop over all the entries
	  KEntryDictEntry* pCurrentEntry;
	  while( (pCurrentEntry = aInnerIt.current()) )
		{
		  pCurrentEntry->bDirty = false;
		  ++aInnerIt;
		}
	  ++aIt;
	}
}


bool KConfigBase::hasKey( const char* pKey ) const
{
  QString aValue = readEntry( pKey );
  return !aValue.isNull();
}


KEntryIterator* KConfigBase::entryIterator( const char* pGroup )
{
  // find the group
  KEntryDict* pCurrentGroupDict = data()->aGroupDict[ pGroup ];

  if( !pCurrentGroupDict )
	return 0L; // that group does not exist

  return new KEntryIterator( *pCurrentGroupDict );
}


void KConfigBase::reparseConfiguration()
{
  data()->aGroupDict.clear();

  // setup a group entry for the default group
  KEntryDict* pDefGroup = new KEntryDict( 37, false );
  pDefGroup->setAutoDelete( true );
  data()->aGroupDict.insert( "<default>", pDefGroup );

  // the next three lines are indeed important.
  // no longer (Kalle, 04/10/97)
  //  data()->pAppStream->device()->close();
  //  if (!data()->pAppStream->device()->open( IO_ReadWrite ))
  //    data()->pAppStream->device()->open( IO_ReadOnly );

  parseConfigFiles();
}


void KConfigBase::setDollarExpansion( bool bExpand )
{
	data()->bExpand = bExpand;
}


bool KConfigBase::isDollarExpansion() const
{
	return data()->bExpand;
}

//#include "kconfigbase.moc"

