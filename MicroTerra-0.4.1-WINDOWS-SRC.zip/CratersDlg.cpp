/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: cratersdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: cratersdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "CratersDlg.h"

#include <qcheckbox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a CraterDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
CratersDlg::CratersDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
		setName( "CraterDlg" );
    resize( 499, 439 ); 
    QFont f( font() );
    f.setFamily( "Comic Sans MS" );
    f.setPointSize( 9 );
    setFont( f ); 
    setCaption( tr( "Craters" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    GroupBox2 = new QGroupBox( this, "GroupBox2" );
    GroupBox2->setGeometry( QRect( 140, 10, 350, 360 ) ); 
    GroupBox2->setTitle( tr( "Options" ) );

    lbl1 = new QLabel( GroupBox2, "lbl1" );
    lbl1->setGeometry( QRect( 10, 21, 60, 20 ) ); 
    lbl1->setText( tr( "Center X" ) );
    lbl1->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    center_y = new QSlider( GroupBox2, "center_y" );
    center_y->setGeometry( QRect( 135, 50, 150, 20 ) ); 
    center_y->setMaxValue( 100 );
    center_y->setValue( 50 );
    center_y->setOrientation( QSlider::Horizontal );
    center_y->setTickmarks( QSlider::NoMarks );

    center_x = new QSlider( GroupBox2, "center_x" );
    center_x->setGeometry( QRect( 135, 20, 150, 20 ) ); 
    center_x->setMaxValue( 100 );
    center_x->setValue( 50 );
    center_x->setOrientation( QSlider::Horizontal );
    center_x->setTickmarks( QSlider::NoMarks );

    Line2 = new QFrame( GroupBox2, "Line2" );
    Line2->setGeometry( QRect( 4, 73, 341, 16 ) ); 
    Line2->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );

    lbl2 = new QLabel( GroupBox2, "lbl2" );
    lbl2->setGeometry( QRect( 10, 50, 60, 17 ) ); 
    lbl2->setText( tr( "Center Y" ) );
    lbl2->setAlignment( int( QLabel::AlignVCenter | QLabel::AlignLeft ) );

    Line3 = new QFrame( GroupBox2, "Line3" );
    Line3->setGeometry( QRect( 4, 257, 342, 16 ) ); 
    Line3->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );

    count = new QSlider( GroupBox2, "count" );
    count->setGeometry( QRect( 135, 96, 150, 20 ) ); 
    count->setMinValue( 1 );
    count->setMaxValue( 1000 );
    count->setValue( 100 );
    count->setOrientation( QSlider::Horizontal );
    count->setTickmarks( QSlider::NoMarks );

    radius = new QSlider( GroupBox2, "radius" );
    radius->setGeometry( QRect( 135, 130, 150, 20 ) ); 
    radius->setMaxValue( 500 );
    radius->setValue( 200 );
    radius->setOrientation( QSlider::Horizontal );
    radius->setTickmarks( QSlider::NoMarks );

    height = new QSlider( GroupBox2, "height" );
    height->setGeometry( QRect( 135, 165, 150, 20 ) ); 
    height->setMaxValue( 200 );
    height->setValue( 100 );
    height->setOrientation( QSlider::Horizontal );

    coverage = new QSlider( GroupBox2, "coverage" );
    coverage->setGeometry( QRect( 135, 201, 150, 20 ) ); 
    coverage->setMinValue( 1 );
    coverage->setMaxValue( 50 );
    coverage->setValue( 15 );
    coverage->setOrientation( QSlider::Horizontal );

    wrap = new QCheckBox( GroupBox2, "wrap" );
    wrap->setGeometry( QRect( 10, 230, 60, 21 ) ); 
    wrap->setText( tr( "Wrap" ) );

    new_seed = new QCheckBox( GroupBox2, "new_seed" );
    new_seed->setGeometry( QRect( 10, 280, 135, 21 ) ); 
    new_seed->setText( tr( "Generate New Seed" ) );
    new_seed->setChecked( TRUE );

    seed = new QLineEdit( GroupBox2, "seed" );
    seed->setGeometry( QRect( 50, 320, 110, 22 ) ); 

    lbl3 = new QLabel( GroupBox2, "lbl3" );
    lbl3->setGeometry( QRect( 10, 96, 110, 20 ) ); 
    lbl3->setText( tr( "Number of craters" ) );

    lbl4 = new QLabel( GroupBox2, "lbl4" );
    lbl4->setGeometry( QRect( 10, 130, 85, 20 ) ); 
    lbl4->setText( tr( "Crater radius" ) );

    lbl5 = new QLabel( GroupBox2, "lbl5" );
    lbl5->setGeometry( QRect( 10, 165, 85, 20 ) ); 
    lbl5->setText( tr( "Crater height" ) );

    lbl6 = new QLabel( GroupBox2, "lbl6" );
    lbl6->setGeometry( QRect( 10, 201, 90, 20 ) ); 
    lbl6->setText( tr( "Crater coverage" ) );

    lbl7 = new QLabel( GroupBox2, "lbl7" );
    lbl7->setGeometry( QRect( 10, 320, 30, 20 ) ); 
    lbl7->setText( tr( "Seed" ) );

    slid1 = new QLabel( GroupBox2, "slid1" );
    slid1->setGeometry( QRect( 295, 18, 35, 20 ) ); 
    QFont slid1_font(  slid1->font() );
    slid1_font.setPointSize( 10 );
    slid1_font.setBold( TRUE );
    slid1->setFont( slid1_font ); 
    slid1->setText( tr( "0.50" ) );
    slid1->setAlignment( int( QLabel::AlignCenter ) );

    slid2 = new QLabel( GroupBox2, "slid2" );
    slid2->setGeometry( QRect( 295, 46, 35, 20 ) ); 
    QFont slid2_font(  slid2->font() );
    slid2_font.setPointSize( 10 );
    slid2_font.setBold( TRUE );
    slid2->setFont( slid2_font ); 
    slid2->setText( tr( "0.50" ) );
    slid2->setAlignment( int( QLabel::AlignCenter ) );

    slid4 = new QLabel( GroupBox2, "slid4" );
    slid4->setGeometry( QRect( 295, 129, 35, 20 ) ); 
    QFont slid4_font(  slid4->font() );
    slid4_font.setPointSize( 10 );
    slid4_font.setBold( TRUE );
    slid4->setFont( slid4_font ); 
    slid4->setText( tr( "2.00" ) );
    slid4->setAlignment( int( QLabel::AlignCenter ) );

    slid3 = new QLabel( GroupBox2, "slid3" );
    slid3->setGeometry( QRect( 295, 96, 35, 17 ) ); 
    QFont slid3_font(  slid3->font() );
    slid3_font.setPointSize( 10 );
    slid3_font.setBold( TRUE );
    slid3->setFont( slid3_font ); 
    slid3->setText( tr( "100" ) );
    slid3->setAlignment( int( QLabel::AlignCenter ) );

    slid5 = new QLabel( GroupBox2, "slid5" );
    slid5->setGeometry( QRect( 295, 163, 35, 20 ) ); 
    QFont slid5_font(  slid5->font() );
    slid5_font.setPointSize( 10 );
    slid5_font.setBold( TRUE );
    slid5->setFont( slid5_font ); 
    slid5->setText( tr( "1.00" ) );
    slid5->setAlignment( int( QLabel::AlignCenter ) );

    slid6 = new QLabel( GroupBox2, "slid6" );
    slid6->setGeometry( QRect( 295, 200, 35, 20 ) ); 
    QFont slid6_font(  slid6->font() );
    slid6_font.setPointSize( 10 );
    slid6_font.setBold( TRUE );
    slid6->setFont( slid6_font ); 
    slid6->setText( tr( "0.15" ) );
    slid6->setAlignment( int( QLabel::AlignCenter ) );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 175, 395, 168, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    OK = new QPushButton( privateLayoutWidget, "OK" );
    OK->setText( tr( "&OK" ) );
    OK->setAutoDefault( TRUE );
    OK->setDefault( TRUE );
    Layout1->addWidget( OK );

    CANCEL = new QPushButton( privateLayoutWidget, "CANCEL" );
    CANCEL->setText( tr( "&Cancel" ) );
    CANCEL->setAutoDefault( TRUE );
    Layout1->addWidget( CANCEL );

    Line1 = new QFrame( this, "Line1" );
    Line1->setGeometry( QRect( 1, 375, 498, 16 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 125, 360 ) ); 
    GroupBox1->setTitle( tr( "Preview" ) );

    Frame1 = new QFrame( GroupBox1, "Frame1" );
    Frame1->setGeometry( QRect( 10, 20, 104, 104 ) ); 
    Frame1->setFrameShape( QFrame::WinPanel );
    Frame1->setFrameShadow( QFrame::Sunken );

	PreView = new TerrainView( Frame1, "PreView" );
	PreView->setGeometry( QRect( 2, 2, 100, 100 ) );
	PreView->show();

	terra = NULL;

    // signals and slots connections
    connect( center_x, SIGNAL(valueChanged(int)), this, SLOT(setCenterX(int)) );
    connect( center_y, SIGNAL(valueChanged(int)), this, SLOT(setCenterY(int)) );
    connect( count, SIGNAL(valueChanged(int)), this, SLOT(setCount(int)) );
    connect( radius, SIGNAL(valueChanged(int)), this, SLOT(setRadius(int)) );
    connect( height, SIGNAL(valueChanged(int)), this, SLOT(setHeight(int)) );
    connect( coverage, SIGNAL(valueChanged(int)), this, SLOT(setCoverage(int)) );
    connect( new_seed, SIGNAL(clicked()), this, SLOT(newseedClicked()));
    connect( wrap, SIGNAL(clicked()), this, SLOT(wrapClicked()));
    connect( OK, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CANCEL, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
CratersDlg::~CratersDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*  
 *  Main event handler. Reimplemented to handle application
 *  font changes
 */
bool CratersDlg::event( QEvent* ev )
{
    bool ret = QDialog::event( ev ); 
    if ( ev->type() == QEvent::ApplicationFontChange ) {
	QFont slid1_font(  slid1->font() );
	slid1_font.setPointSize( 10 );
	slid1_font.setBold( TRUE );
	slid1->setFont( slid1_font ); 
	QFont slid2_font(  slid2->font() );
	slid2_font.setPointSize( 10 );
	slid2_font.setBold( TRUE );
	slid2->setFont( slid2_font ); 
	QFont slid4_font(  slid4->font() );
	slid4_font.setPointSize( 10 );
	slid4_font.setBold( TRUE );
	slid4->setFont( slid4_font ); 
	QFont slid3_font(  slid3->font() );
	slid3_font.setPointSize( 10 );
	slid3_font.setBold( TRUE );
	slid3->setFont( slid3_font ); 
	QFont slid5_font(  slid5->font() );
	slid5_font.setPointSize( 10 );
	slid5_font.setBold( TRUE );
	slid5->setFont( slid5_font ); 
	QFont slid6_font(  slid6->font() );
	slid6_font.setPointSize( 10 );
	slid6_font.setBold( TRUE );
	slid6->setFont( slid6_font ); 
    }
    return ret;
}

void CratersDlg::setCenterX(int value)
{
}

void CratersDlg::setCenterY(int value)
{
}

void CratersDlg::setCount(int value)
{
}

void CratersDlg::setRadius(int value)
{
}

void CratersDlg::setHeight(int value)
{
}

void CratersDlg::setCoverage(int value)
{
}

void CratersDlg::newseedClicked()
{
}

void CratersDlg::wrapClicked()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - craeted
 *
 ***********************************************************************************************************************/