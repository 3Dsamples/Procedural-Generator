/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: aboutview.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: aboutview
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef ABOUTVIEW_H
#define ABOUTVIEW_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qwidget.h>
#include <qpainter.h>
#include <qimage.h>
#include <qtimer.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QPixmap;

class AboutView : public QWidget
{
    Q_OBJECT

public:
    AboutView( QWidget *parent=0, const char *name=0, int wFlags=0 );
    ~AboutView();
	bool about_dlg_load_logo();

	QPixmap  about_pix;
	QPixmap  apix;
	QImage   about_img;
	QImage   aimg;
	int     *dissolve_map;
	int      dissolve_width;
	int      dissolve_height;
	int      logo_width;
	int      logo_height; 

public slots:
	void about_dlg_timer();

private:
	bool           active;
	bool           do_animation;
	int            frame;
	int            offset;
	QTimer        *timer;

protected:
	void drawPlane(QPainter *);
    void paintEvent( QPaintEvent * );
};

#endif // ABOUTVIEW_H
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/