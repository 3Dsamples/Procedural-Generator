/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: fillbasinsdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: fillbasinsdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef FILLBASINSDLHIMPL_H
#define FILLBASINSDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "FillBasinsDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/
class FillBasinsDlgImpl : public FillBasinsDlg
{ 
    Q_OBJECT

public:
    FillBasinsDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~FillBasinsDlgImpl();

	int  iters;
	bool bigG;

public slots:
	void setIter(int value);
	void biggridClicked();

protected:
	void update_preview();

};

#endif // FILLBASINSDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - created
 *
 ***********************************************************************************************************************/