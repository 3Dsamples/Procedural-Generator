/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: erodedlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: erodedlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef ERODEDLG_H
#define ERODEDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QRadioButton;
class QSlider;
class QSpinBox;

class ErodeDlg : public QDialog
{ 
    Q_OBJECT

public:
    ErodeDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~ErodeDlg();

    QPushButton* OK;
    QPushButton* CANCEL;
    QPushButton* update_preview;
    QFrame* Line1;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
    QGroupBox* GroupBox3;
    QFrame* Line6;
    QCheckBox* erode_sealevel;
    QRadioButton* erode_multiple;
    QRadioButton* erode_single;
    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QLabel* lbl2;
    QLabel* lbl3;
    QLabel* slid1;
    QLabel* slid2;
    QLabel* slid3;
    QSlider* erode_iterations;
    QSlider* max_flowmap_age;
    QSlider* age_flowmap_times;
    QLineEdit* erode_save_flowmap_name;
    QLabel* lbl5;
    QLineEdit* erode_save_anim_name;
    QCheckBox* erode_save_anim;
    QCheckBox* erode_save_flowmap;
    QCheckBox* erode_trim;
    QSlider* erode_threshold;
    QLabel* lbl4;
    QLabel* slid4;
    QSpinBox* erode_frame_count;
	TerrainView* PreView;
	TTerrain *terra;

public slots:
	virtual void update_view();
	virtual void setIteration(int value);
	virtual void setMaxFlowmapAge(int value);
	virtual void setAgeFlowmapTimes(int value);
	virtual void setThreshold(int value);
	virtual void trimClicked();
	virtual void saveflowmapClicked();
	virtual void saveanimClicked();
	virtual void framecountChanged();
	virtual void single_Changed();
	virtual void multiple_Changed();
	virtual void sealevelClicked();

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // ERODEDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - 
 *
 ***********************************************************************************************************************/