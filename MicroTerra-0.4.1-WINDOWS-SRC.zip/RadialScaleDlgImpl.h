/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: radialscaledlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: radialscaledlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef RADIALSCALEDLHIMPL_H
#define RADIALSCALEDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "RadialScaleDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class RadialScaleDlgImpl : public RadialScaleDlg
{ 
    Q_OBJECT

public:
    RadialScaleDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~RadialScaleDlgImpl();

	float centerX;
	float centerY;
	float start;
	float end;
	int freq;
	float scale;
	float smooth;
	bool  b_invert;

public slots:
	void setCenterX(int value);
	void setCenterY(int value);
	void setStart(int value);
	void setEnd(int value);
	void setFreq(int value);
	void setScale(int value);
	void setSmooth(int value);
	void invertClicked();

protected:
	void update_preview(bool cxy);

};

#endif // RADIALSCALEDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   -
 *
 ***********************************************************************************************************************/