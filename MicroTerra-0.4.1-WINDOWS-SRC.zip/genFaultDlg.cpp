/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genfaultdlg.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genfaultdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "genFaultDlg.h"

#include <qcheckbox.h>
#include <qcombobox.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qpixmap.h>
#include "pixmaps/microterra_logo.xpm"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/
/* 
 *  Constructs a genFaultingDlg which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
genFaultDlg::genFaultDlg( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "genFaultingDlg" );
    resize( 229, 331 ); 
    setCaption( tr( "Faulting Window" ) );
    QPixmap paicon((const char**)microterra_logo_xpm);
    setIcon(paicon);
    setSizeGripEnabled( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 10, 290, 210, 33 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    generate = new QPushButton( privateLayoutWidget, "generate" );
    generate->setText( tr( "&Generate" ) );
    generate->setAutoDefault( TRUE );
    generate->setDefault( TRUE );
    Layout1->addWidget( generate );

    cancel = new QPushButton( privateLayoutWidget, "cancel" );
    cancel->setText( tr( "&Cancel" ) );
    cancel->setAutoDefault( TRUE );
    Layout1->addWidget( cancel );

    GroupBox1 = new QGroupBox( this, "GroupBox1" );
    GroupBox1->setGeometry( QRect( 10, 10, 210, 270 ) ); 
    GroupBox1->setTitle( tr( "Parameters" ) );

    Line1 = new QFrame( GroupBox1, "Line1" );
    Line1->setGeometry( QRect( 2, 190, 204, 20 ) ); 
    Line1->setProperty( "frameShape", (int)QFrame::HLine );
    Line1->setFrameShadow( QFrame::Sunken );
    Line1->setProperty( "frameStyle", QFrame::HLine | QFrame::Sunken );
    Line1->setProperty( "frameShape", (int)QFrame::HLine );

    fault_method = new QComboBox( FALSE, GroupBox1, "fault_method" );
    fault_method->insertItem( tr( "Line" ) );
    fault_method->insertItem( tr( "sin Line" ) );
    fault_method->insertItem( tr( "cos Line" ) );
    fault_method->insertItem( tr( "Circles" ) );
    fault_method->insertItem( tr( "Squares" ) );
    fault_method->insertItem( tr( "Particles" ) );
    fault_method->setGeometry( QRect( 100, 20, 101, 21 ) ); 

    lbl2 = new QLabel( GroupBox1, "lbl2" );
    lbl2->setGeometry( QRect( 10, 50, 60, 20 ) ); 
    lbl2->setText( tr( "Size" ) );

    lbl3 = new QLabel( GroupBox1, "lbl3" );
    lbl3->setGeometry( QRect( 10, 80, 110, 20 ) ); 
    lbl3->setText( tr( "Iterations" ) );

    lbl4 = new QLabel( GroupBox1, "lbl4" );
    lbl4->setGeometry( QRect( 10, 110, 110, 20 ) ); 
    lbl4->setText( tr( "Scale Factor" ) );

    lbl5 = new QLabel( GroupBox1, "lbl5" );
    lbl5->setGeometry( QRect( 10, 140, 110, 20 ) ); 
    lbl5->setText( tr( "Cycles" ) );

    fault_size = new QSpinBox( GroupBox1, "fault_size" );
    fault_size->setGeometry( QRect( 130, 50, 70, 24 ) ); 
    fault_size->setButtonSymbols( QSpinBox::PlusMinus );
    fault_size->setMaxValue( 2000 );
    fault_size->setMinValue( 10 );
    fault_size->setLineStep( 1 );
    fault_size->setValue( 400 );

    fault_iterations = new QSpinBox( GroupBox1, "fault_iterations" );
    fault_iterations->setGeometry( QRect( 130, 80, 70, 24 ) ); 
    fault_iterations->setButtonSymbols( QSpinBox::PlusMinus );
    fault_iterations->setMaxValue( 5000 );
    fault_iterations->setMinValue( 10 );
    fault_iterations->setLineStep( 1 );
    fault_iterations->setValue( 1000 );

    fault_scale_factor = new QSpinBox( GroupBox1, "fault_scale_factor" );
    fault_scale_factor->setGeometry( QRect( 130, 110, 70, 24 ) ); 
    fault_scale_factor->setMaxValue( 100 );
    fault_scale_factor->setMinValue( 1 );
    fault_scale_factor->setLineStep( 1 );
    fault_scale_factor->setValue( 5 );

    fault_cycles = new QSpinBox( GroupBox1, "fault_cycles" );
    fault_cycles->setGeometry( QRect( 130, 140, 70, 24 ) ); 
    fault_cycles->setButtonSymbols( QSpinBox::PlusMinus );
    fault_cycles->setMaxValue( 100 );
    fault_cycles->setMinValue( 1 );
    fault_cycles->setLineStep( 1 );
    fault_cycles->setValue( 5 );

    seed = new QLineEdit( GroupBox1, "seed" );
    seed->setGeometry( QRect( 90, 240, 110, 22 ) ); 
    seed->setText( tr( "0" ) );

    lbl1 = new QLabel( GroupBox1, "lbl1" );
    lbl1->setGeometry( QRect( 10, 20, 80, 21 ) ); 
    lbl1->setText( tr( "Fractal Method" ) );

    constant_size = new QCheckBox( GroupBox1, "constant_size" );
    constant_size->setGeometry( QRect( 10, 170, 180, 20 ) ); 
    constant_size->setText( tr( "Use Constant Size" ) );
    constant_size->setChecked( FALSE );

    new_seed = new QCheckBox( GroupBox1, "new_seed" );
    new_seed->setGeometry( QRect( 10, 210, 140, 20 ) ); 
    new_seed->setText( tr( "Generate new seed" ) );
    new_seed->setChecked( FALSE );

    lbl6 = new QLabel( GroupBox1, "lbl6" );
    lbl6->setGeometry( QRect( 10, 240, 60, 20 ) ); 
    lbl6->setText( tr( "Seed" ) );

    // signals and slots connections
    connect( generate, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( new_seed, SIGNAL( clicked() ), this, SLOT( seedClicked() ) );
    connect( constant_size, SIGNAL( clicked() ), this, SLOT( csizeClicked() ) );

    // tab order
    setTabOrder( fault_method, fault_size );
    setTabOrder( fault_size, fault_iterations );
    setTabOrder( fault_iterations, fault_scale_factor );
    setTabOrder( fault_scale_factor, fault_cycles );
    setTabOrder( fault_cycles, constant_size );
    setTabOrder( constant_size, new_seed );
    setTabOrder( new_seed, seed );
    setTabOrder( seed, generate );
    setTabOrder( generate, cancel );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
genFaultDlg::~genFaultDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

void genFaultDlg::seedClicked()
{
}

void genFaultDlg::csizeClicked()
{
}
/***********************************************************************************************************************
 * Version history:
 *  * 25-08-2004
 *   - created
 *
 ***********************************************************************************************************************/