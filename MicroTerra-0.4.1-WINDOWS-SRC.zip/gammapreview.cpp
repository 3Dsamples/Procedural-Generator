/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: gammapreview.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: gammapreview
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "gammapreview.h"
#include "OptionsDlgImpl.h"

/** ***************************************************************************************************************** **/
/**				          MACROS			                                                                          **/
/** ***************************************************************************************************************** **/

#define MIN(x,y)     (((x) < (y)) ? (x) : (y))
#define rint(x)      floor((x)+0.5)

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

MOGammaPreview::MOGammaPreview( QWidget *parent, const char *name, int wFlags )
	: QWidget( parent, name, wFlags )
{
	int pbuf_size;

	setBackgroundColor(black);
	pbuf_size = ((100*50)*3);
	pixbuf = new unsigned char[pbuf_size];
}

MOGammaPreview::~MOGammaPreview()
{
}

void MOGammaPreview::drawPlane(QPainter *p)
{
	int x, xp, y;
   
	for (y = 0; y < 50; y++)
	{
		for (x=0, xp=0; x<100*3; x+=3, xp++)
		{
			p->setPen(QColor(pixbuf[(y*(100*3))+x], pixbuf[(y*(100*3))+(x+1)], pixbuf[(y*(100*3))+(x+2)]));
			p->drawPoint(xp, y);
		}
	} 
}

void MOGammaPreview::paintEvent( QPaintEvent * )
{
	QPainter paint( this );

	drawPlane(&paint);
}

void MOGammaPreview::gamma_preview_update(int val)
{
	float gamma;
	int   value;
	int   x, y;

	gamma = (float)(val / 100.0);

	value = rint (pow (0.5, 1.0 / gamma) * 255.0);
	for (y = 0; y < 50; y++)
		for (x = 0; x < 50; x++)
//			if (((x >> 1) + (y >> 1)) & 1)
			{
				pixbuf[((y * 100) + x) * 3] = (unsigned char)value;
				pixbuf[((y * 100) + x+1) * 3] = (unsigned char)value;
				pixbuf[((y * 100) + x+2) * 3] = (unsigned char)value;
			}
	repaint();
}


void MOGammaPreview::on_gamma_preview_realize()
{
	int x, y;
	int i, size;
	static unsigned short lfsr;

	if (lfsr == 0)
		lfsr = time (NULL);

	srand (lfsr);
	lfsr = rand ();
	if (lfsr == 0) lfsr++;

	size = ((100 * 50) * 3);
	for (i = 0; i < size; i++)
	{
		unsigned char c;
		lfsr = ((lfsr >> 1) | (lfsr << 15)) ^ (lfsr & 0x7f);

		c = (lfsr >> 16) & 0xff;
		pixbuf[i] = (unsigned char)MIN((int)c, 255);
		i++;
		c = (lfsr >> 8) & 0xff;
		pixbuf[i] = (unsigned char)MIN((int)c, 255);
		c = lfsr & 0xff;
		i++;
		pixbuf[i] = (unsigned char)MIN((int)c, 255);
	}  

	for (y = 0; y < 50; y++)
		for (x = 50; x < 100; x++)
			//if (((x >> 1) + (y >> 1)) & 1)
			{
				pixbuf[((y * 100) + x) * 3] = 0;
				pixbuf[((y * 100) + x+1) * 3] = 0;
				pixbuf[((y * 100) + x+2) * 3] = 0;
			}

	gamma_preview_update(150);
}
/***********************************************************************************************************************
 * Version history:
 *  * 02-09-2004
 *   - created
 *
 ***********************************************************************************************************************/