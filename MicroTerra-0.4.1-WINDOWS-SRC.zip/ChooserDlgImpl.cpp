/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: chooserdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: chooserdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qcheckbox.h>

#include "ChooserDlgImpl.h"
#include "genrandom.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

ChooserDlgImpl::ChooserDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : ChooserDlg( parent, name, modal, fl )
{
	bter1 = NULL;
	bter2 = NULL;
	bter3 = NULL;
	bter4 = NULL;
	bter5 = NULL;
	bter6 = NULL;
	bter7 = NULL;
	bter8 = NULL;
	bter9 = NULL;
	ter1 = NULL;
	ter2 = NULL;
	ter3 = NULL;
	ter4 = NULL;
	ter5 = NULL;
	ter6 = NULL;
	ter7 = NULL;
	ter8 = NULL;
	ter9 = NULL;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
ChooserDlgImpl::~ChooserDlgImpl()
{
}

TTerrain *ChooserDlgImpl::getButtonChoice()
{
	int choice;

	if (mm1 == 1)
		choice = 1;
	else if (mm2 == 1)
		choice = 2;
	else if (mm3 == 1)
		choice = 3;
	else if (mm4 == 1)
		choice = 4;
	else if (mm5 == 1)
		choice = 5;
	else if (mm6 == 1)
		choice = 6;
	else if (mm7 == 1)
		choice = 7;
	else if (mm8 == 1)
		choice = 8;
	else if (mm8 == 1)
		choice = 8;

	switch (choice)
	{
		case 1:
			return bter1;
			break;
		case 2:
			return bter2;
			break;
		case 3:
			return bter3;
			break;
		case 4:
			return bter4;
			break;
		case 5:
			return bter5;
			break;
		case 6:
			return bter6;
			break;
		case 7:
			return bter7;
			break;
		case 8:
			return bter8;
			break;
		case 9:
			return bter9;
			break;
	}

	return NULL;
}

TTerrain *ChooserDlgImpl::fixterrain(TTerrain *fter)
{
	TTerrain   *out;
	int         y;
	int         pos;

	out = new TTerrain(100, 100);
	pos = 0;
	for (y = 0; y < out->height; y++)
	{
		int x;
		int count;
		int prev_pos;

		prev_pos = y * fter->height / out->height * fter->width;
		count = 0;
		for (x = 0; x < out->width; x++)
		{
			out->heightfield[pos] = fter->heightfield[prev_pos];
			//if (out->selection != NULL)
			//	out->selection[pos] = terrain->selection[prev_pos];

			pos++;
			count += fter->width;
			while (count >= out->width)
			{
				count -= out->width;
				prev_pos++;
			}
		}
	}
	return out;
}

void ChooserDlgImpl::randClicked()
{
	if (bter1 != NULL)
	{
		delete bter1;
		delete ter1;
		bter1 = new TTerrain(400, 400);
	} else {
		bter1 = new TTerrain(400, 400);
	}
 	genRan* genrandom = new genRan( bter1 );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	ter1 = fixterrain(bter1);
	View1->t_terrain_view_set_terrain(ter1);
	if (bter2 != NULL)
	{
		delete bter2;
		delete ter2;
		bter2 = new TTerrain(400, 400);
	} else {
		bter2 = new TTerrain(400, 400);
	}
 	genrandom = new genRan( bter2 );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	ter2 = fixterrain(bter2);
	View2->t_terrain_view_set_terrain(ter2);
	if (bter3 != NULL)
	{
		delete bter3;
		delete ter3;
		bter3 = new TTerrain(400, 400);
	} else {
		bter3 = new TTerrain(400, 400);
	}
 	genrandom = new genRan( bter3 );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	ter3 = fixterrain(bter3);
	View3->t_terrain_view_set_terrain(ter3);
	if (bter4 != NULL)
	{
		delete bter4;
		delete ter4;
		bter4 = new TTerrain(400, 400);
	} else {
		bter4 = new TTerrain(400, 400);
	}
 	genrandom = new genRan( bter4 );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	ter4 = fixterrain(bter4);
	View4->t_terrain_view_set_terrain(ter4);
	if (bter5 != NULL)
	{
		delete bter5;
		delete ter5;
		bter5 = new TTerrain(400, 400);
	} else {
		bter5 = new TTerrain(400, 400);
	}
 	genrandom = new genRan( bter5 );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	ter5 = fixterrain(bter5);
	View5->t_terrain_view_set_terrain(ter5);
	if (bter6 != NULL)
	{
		delete bter6;
		delete ter6;
		bter6 = new TTerrain(400, 400);
	} else {
		bter6 = new TTerrain(400, 400);
	}
 	genrandom = new genRan( bter6 );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	ter6 = fixterrain(bter6);
	View6->t_terrain_view_set_terrain(ter6);
	if (bter7 != NULL)
	{
		delete bter7;
		delete ter7;
		bter7 = new TTerrain(400, 400);
	} else {
		bter7 = new TTerrain(400, 400);
	}
 	genrandom = new genRan( bter7 );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	ter7 = fixterrain(bter7);
	View7->t_terrain_view_set_terrain(ter7);
	if (bter8 != NULL)
	{
		delete bter8;
		delete ter8;
		bter8 = new TTerrain(400, 400);
	} else {
		bter8 = new TTerrain(400, 400);
	}
 	genrandom = new genRan( bter8 );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	ter8 = fixterrain(bter8);
	View8->t_terrain_view_set_terrain(ter8);
	if (bter9 != NULL)
	{
		delete bter9;
		delete ter9;
		bter9 = new TTerrain(400, 400);
	} else {
		bter9 = new TTerrain(400, 400);
	}
 	genrandom = new genRan( bter9 );
	genrandom->t_terrain_generate_random(400, (float)0.5, GEN_TYPE_2 | GEN_TYPE_3 | GEN_TYPE_4);
	delete genrandom;
	genrandom = 0;
	ter9 = fixterrain(bter9);
	View9->t_terrain_view_set_terrain(ter9);
}
/*
void ChooserDlgImpl::vt1Clicked()
{
}

void ChooserDlgImpl::vt2Clicked()
{
}

void ChooserDlgImpl::vt3Clicked()
{
}

void ChooserDlgImpl::vt4Clicked()
{
}

void ChooserDlgImpl::vt5Clicked()
{
}

void ChooserDlgImpl::vt6Clicked()
{
}

void ChooserDlgImpl::vt7Clicked()
{
}

void ChooserDlgImpl::vt8Clicked()
{
}

void ChooserDlgImpl::vt9Clicked()
{
}*/
/***********************************************************************************************************************
 * Version history:
 *  * 26-08-2004
 *   - created
 *
 ***********************************************************************************************************************/