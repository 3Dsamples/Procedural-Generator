/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: cratersdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: cratersdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef CRATERSDLHIMPL_H
#define CRATERSDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "CratersDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class CratersDlgImpl : public CratersDlg
{ 
    Q_OBJECT

public:
    CratersDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~CratersDlgImpl();

	bool  newseed;
	bool  Wrap;
	float centerX;
	float centerY;
	float Radius;
	float Height;
	float Cover;
	int   Count;
	int   Seed;

public slots:
	void setCenterX(int value);
	void setCenterY(int value);
	void setCount(int value);
	void setRadius(int value);
	void setHeight(int value);
	void setCoverage(int value);
	void newseedClicked();
	void wrapClicked();

protected:
	void update_preview(bool cxy);

};

#endif // CRATERSDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 02-12-2004
 *   - created
 *
 ***********************************************************************************************************************/