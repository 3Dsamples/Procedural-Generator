/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: smoothdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: smoothdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef SMOOTHDLHIMPL_H
#define SMOOTHDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "SmoothDlg.h"
#include "tterrain.h"
#include <qlabel.h>
#include <qlineedit.h>
#include <qcheckbox.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class SmoothDlgImpl : public SmoothDlg
{ 
    Q_OBJECT

public:
    SmoothDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~SmoothDlgImpl();

	float factor;
	bool  big;

public slots:
	void setFactor(int value);
	void bigClicked();

protected:
	void update_preview();

};

#endif // SMOOTHDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/