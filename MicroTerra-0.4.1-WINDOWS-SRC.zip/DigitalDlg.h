/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: digitaldlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: digitaldlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef DIGITALDLG_H
#define DIGITALDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;
class QSpinBox;

class DigitalDlg : public QDialog
{ 
    Q_OBJECT

public:
    DigitalDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~DigitalDlg();

    QPushButton* OK;
    QPushButton* CANCEL;
    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QPushButton* update_preview;
    QGroupBox* GroupBox2;
    QSpinBox* filter_val_1;
    QSpinBox* filter_val_2;
    QSpinBox* filter_val_6;
    QSpinBox* filter_val_7;
    QSpinBox* filter_val_3;
    QSpinBox* filter_val_4;
    QSpinBox* filter_val_5;
    QSpinBox* filter_val_8;
    QSpinBox* filter_val_9;
    QSpinBox* filter_val_10;
    QSpinBox* filter_val_11;
    QSpinBox* filter_val_12;
    QSpinBox* filter_val_16;
    QSpinBox* filter_val_17;
    QSpinBox* filter_val_21;
    QSpinBox* filter_val_22;
    QSpinBox* filter_val_25;
    QSpinBox* filter_val_24;
    QSpinBox* filter_val_23;
    QSpinBox* filter_val_18;
    QSpinBox* filter_val_19;
    QSpinBox* filter_val_20;
    QSpinBox* filter_val_15;
    QSpinBox* filter_val_14;
    QSpinBox* filter_val_13;
    QFrame* Line1;
    QLabel* lbl1;
    QLabel* lbl2;
    QSlider* min_elevation;
    QSlider* max_elevation;
    QLabel* slid1;
    QLabel* slid2;
    QFrame* Line2;
	TTerrain *terra;

public slots:
	virtual void update_view();
	virtual void filter1Changed();
	virtual void filter2Changed();
	virtual void filter3Changed();
	virtual void filter4Changed();
	virtual void filter5Changed();
	virtual void filter6Changed();
	virtual void filter7Changed();
	virtual void filter8Changed();
	virtual void filter9Changed();
	virtual void filter10Changed();
	virtual void filter11Changed();
	virtual void filter12Changed();
	virtual void filter13Changed();
	virtual void filter14Changed();
	virtual void filter15Changed();
	virtual void filter16Changed();
	virtual void filter17Changed();
	virtual void filter18Changed();
	virtual void filter19Changed();
	virtual void filter20Changed();
	virtual void filter21Changed();
	virtual void filter22Changed();
	virtual void filter23Changed();
	virtual void filter24Changed();
	virtual void filter25Changed();
	virtual void setMinElev(int value);
	virtual void setMaxElev(int value);

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // DIGITALDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/