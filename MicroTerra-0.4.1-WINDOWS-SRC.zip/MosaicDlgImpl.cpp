/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: mosaicdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: mosaicdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "MosaicDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

MosaicDlgImpl::MosaicDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : MosaicDlg( parent, name, modal, fl )
{
	X_size = 10;
	Y_size = 10;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
MosaicDlgImpl::~MosaicDlgImpl()
{
}

void MosaicDlgImpl::update_preview()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	t_terrain_mosaic(clone, X_size, Y_size); 
	PreView->t_terrain_view_set_terrain(clone);
}

void MosaicDlgImpl::xsizeChanged()
{
	X_size = x_mosaicsize->value();
	update_preview();
}

void MosaicDlgImpl::ysizeChanged()
{
	Y_size = y_mosaicsize->value();
	update_preview();
}
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - created
 *
 ***********************************************************************************************************************/