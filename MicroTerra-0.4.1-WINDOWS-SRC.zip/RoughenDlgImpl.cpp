/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: roughendlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: roughendlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "RoughenDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

RoughenDlgImpl::RoughenDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : RoughenDlg( parent, name, modal, fl )
{
	factor = (float)0.50;
	big = false;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
RoughenDlgImpl::~RoughenDlgImpl()
{
}

void RoughenDlgImpl::update_preview()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	t_terrain_roughen_smooth(clone, TRUE, big, factor);
	PreView->t_terrain_view_set_terrain(clone);
}

void RoughenDlgImpl::setFactor(int value)
{
	char buf[15];

	factor = (float)(value/100.0);
	sprintf(buf,"%1.2f", factor);
	slid1->setText((char *)buf);
	update_preview();
}

void RoughenDlgImpl::bigClicked()
{
	big = roughen_big->isChecked();
	update_preview();
}
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - created
 *
 ***********************************************************************************************************************/