/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: writer.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: writer
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef __WRITER_H__
#define __WRITER_H__

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "tterrain.h"
#include "filenameops.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class TWriter
{
public:
	TWriter();
	~TWriter();
	int t_terrain_save(TTerrain  *terrain, TFileType type, char *filename);
	bool is_saving_as_native(TFileType  type, char *filename);
	void t_terrain_get_povray_size(TTerrain *terrain, float *x, float *y, float *z);
	void twriter_set_raster(int *raster);

	int *vraster;

private:
	int t_terrain_save_native(TTerrain *terrain);
	int t_terrain_export_tga_field(TTerrain *terrain, char *filename, float *field);
	int t_terrain_export_tga(TTerrain *terrain, char *filename);
	int t_terrain_export_pov(TTerrain *terrain, char *filename);
	int t_terrain_export_bmp(TTerrain *terrain, char *filename);
	int t_terrain_export_bmp_bw(TTerrain *terrain, char *filename);
	int t_terrain_export_pgm(TTerrain *terrain, char *filename);
	int t_terrain_export_pg8(TTerrain *terrain, char *filename);
	int t_terrain_export_mat(TTerrain *terrain, char *filename);
	int t_terrain_export_oct(TTerrain *terrain, char *filename);
	int t_terrain_export_ac(TTerrain *terrain, char *filename);
	int t_terrain_export_terragen(TTerrain *terrain, char *filename);
	int t_terrain_export_grd(TTerrain *terrain, char *filename);
	int t_terrain_export_xyz(TTerrain *terrain, char *filename);
	int t_terrain_export_dxf(TTerrain *terrain, char *filename);
	int t_terrain_export_bna(TTerrain *terrain, char *filename);
	int t_terrain_export_bt(TTerrain *terrain, char *filename);
};

#endif //__WRITER_H__
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   - 
 *
 ***********************************************************************************************************************/