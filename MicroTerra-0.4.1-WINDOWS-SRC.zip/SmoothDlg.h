/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: smoothdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: smoothdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef SMOOTHDLG_H
#define SMOOTHDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>
#include "terrainview.h"
#include "tterrain.h"

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QFrame;
class QGroupBox;
class QLabel;
class QPushButton;
class QSlider;

class SmoothDlg : public QDialog
{ 
    Q_OBJECT

public:
    SmoothDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~SmoothDlg();

    QGroupBox* GroupBox1;
    QFrame* Frame1;
	TerrainView* PreView;
    QGroupBox* GroupBox2;
    QLabel* lbl1;
    QLabel* slid1;
    QSlider* smooth_factor;
    QCheckBox* smooth_big;
    QFrame* Line1;
    QPushButton* OK;
    QPushButton* CANCEL;
	TTerrain *terra;

public slots:
	virtual void setFactor(int value);
	virtual void bigClicked();

protected:
    QHBoxLayout* Layout1;
    bool event( QEvent* );
};

#endif // SMOOTHDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - 
 *
 ***********************************************************************************************************************/