/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: colormaps.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: colormaps
 *  last changed		: 27-12-2002
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef __COLORMAPS_H__
#define __COLORMAPS_H__

/** ***************************************************************************************************************** **/
/** 				      GLOBAL DATATYPES			                                                                  **/
/** ***************************************************************************************************************** **/

typedef enum TColormapType
{
  T_COLORMAP_LAND,
  T_COLORMAP_DESERT,
  T_COLORMAP_GRAYSCALE,
  T_COLORMAP_HEAT,
  T_COLORMAP_WASTELAND
};

/** ***************************************************************************************************************** **/
/**				          MACROS				                                                                      **/
/** ***************************************************************************************************************** **/

#define MIN(x,y)     (((x) < (y)) ? (x) : (y))
#define MAX(x,y)     (((x) > (y)) ? (x) : (y))

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class ColorMaps
{
public:
	ColorMaps();
	~ColorMaps();
	void colormap_new (TColormapType which_colormap, float water_level);

	int* colmap;

private:
	void colormap_gradient (int start, int stop, int r1, int g1, int b1, int r2, int g2, int b2);
	void colormap_gradient_bands (int index_start, int index_stop, int num_points, int offset);
	void colormap_land_bands (int num_bands, float water_level, int land_level);

	const int* colors;
	bool cmore;
};

#endif /* __COLORMAPS_H__ */  
/***********************************************************************************************************************
 * Version history:
 *  * 00-00-2004
 *   -
 *
 ***********************************************************************************************************************/