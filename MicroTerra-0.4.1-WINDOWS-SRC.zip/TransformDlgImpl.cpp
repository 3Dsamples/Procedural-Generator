/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: transformdlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: transformdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <stdio.h>
#include "TransformDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

TransformDlgImpl::TransformDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : TransformDlg( parent, name, modal, fl )
{
	threshold = (float)0.33;
	depth = (float)0.33;
	dropoff = (float)0.75;
	above = (float)1.50;
	below = (float)4.00;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
TransformDlgImpl::~TransformDlgImpl()
{
}

void TransformDlgImpl::update_preview()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	Transfer->t_terrain_draw_transform(threshold, depth, dropoff, above, below);
	clone->sealevel = threshold;
	t_terrain_transform(clone, threshold, depth, dropoff, above, below);
	clone->sealevel = depth; 
	PreView->t_terrain_view_set_terrain(clone);
}

void TransformDlgImpl::setThreshold(int value)
{
	char buf[15];

	threshold = (float)(value/100.0);
	sprintf(buf,"%1.2f", threshold);
	slid1->setText((char *)buf);
	update_preview();
}

void TransformDlgImpl::setDepth(int value)
{
	char buf[15];

	depth = (float)(value/100.0);
	sprintf(buf,"%1.2f", depth);
	slid2->setText((char *)buf);
	update_preview();
}

void TransformDlgImpl::setDropoff(int value)
{
	char buf[15];

	dropoff = (float)(value/100.0);
	sprintf(buf,"%1.2f", dropoff);
	slid3->setText((char *)buf);
	update_preview();
}

void TransformDlgImpl::setAbove(int value)
{
	char buf[15];

	above = (float)(value/100.0);
	sprintf(buf,"%1.2f", above);
	slid4->setText((char *)buf);
	update_preview();
}

void TransformDlgImpl::setBelow(int value)
{
	char buf[15];

	below = (float)(value/100.0);
	sprintf(buf,"%1.2f", below);
	slid5->setText((char *)buf);
	update_preview();
}
/***********************************************************************************************************************
 * Version history:
 *  * 05-12-2004
 *   - created
 *
 ***********************************************************************************************************************/