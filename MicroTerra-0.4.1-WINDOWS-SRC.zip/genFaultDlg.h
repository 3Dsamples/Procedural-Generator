/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: genfaultdlg.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: genfaultdlg
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef GENFAULTDLG_H
#define GENFAULTDLG_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include <qvariant.h>
#include <qdialog.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QCheckBox;
class QComboBox;
class QFrame;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QSpinBox;

class genFaultDlg : public QDialog
{ 
    Q_OBJECT

public:
    genFaultDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~genFaultDlg();

    QPushButton* generate;
    QPushButton* cancel;
    QGroupBox* GroupBox1;
    QFrame* Line1;
    QComboBox* fault_method;
    QLabel* lbl2;
    QLabel* lbl3;
    QLabel* lbl4;
    QLabel* lbl5;
    QSpinBox* fault_size;
    QSpinBox* fault_iterations;
    QSpinBox* fault_scale_factor;
    QSpinBox* fault_cycles;
    QLineEdit* seed;
    QLabel* lbl1;
    QCheckBox* constant_size;
    QCheckBox* new_seed;
    QLabel* lbl6;

public slots:
	virtual void csizeClicked();
	virtual void seedClicked();

protected:
    QHBoxLayout* Layout1;
};

#endif // GENFAULTDLG_H
/***********************************************************************************************************************
 * Version history:
 *  * 25-08-2004
 *   - created
 *
 ***********************************************************************************************************************/