/****************************************************************************
** Form interface generated from reading ui file '.\AboutDialog.ui'
**
** Created: Sat Oct 16 16:36:06 2004
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef ABOUTDLG_H
#define ABOUTDLG_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QFrame;
class QLabel;

class AboutDlg : public QDialog
{ 
    Q_OBJECT

public:
    AboutDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~AboutDlg();

    QFrame* Frame;
    QLabel* TextLabel2;
    QLabel* TextLabel1_2;
    QLabel* TextLabel3;
    QLabel* TextLabel1;

protected:
    bool event( QEvent* );
};

#endif // ABOUTDLG_H
