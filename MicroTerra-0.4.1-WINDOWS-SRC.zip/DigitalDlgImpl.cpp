/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: digitaldlgimpl.cpp
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: digitaldlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "stdio.h"
#include "DigitalDlgImpl.h"
#include "filters.h"

/** ***************************************************************************************************************** **/
/** 				     FUNCTIONS				                                                                      **/
/** ***************************************************************************************************************** **/

DigitalDlgImpl::DigitalDlgImpl( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : DigitalDlg( parent, name, modal, fl )
{
	filter[0] = (float)0.25;
	filter[1] = (float)0.25;
	filter[2] = (float)0.25;
	filter[3] = (float)0.25;
	filter[4] = (float)0.25;
	filter[5] = (float)0.25;
	filter[6] = (float)1.0;
	filter[7] = (float)2.0;
	filter[8] = (float)1.0;
	filter[9] = (float)0.25;
	filter[10] = (float)0.25;
	filter[11] = (float)2.0;
	filter[12] = (float)5.0;
	filter[13] = (float)2.0;
	filter[14] = (float)0.25;
	filter[15] = (float)0.25;
	filter[16] = (float)1.0;
	filter[17] = (float)2.0;
	filter[18] = (float)1.0;
	filter[19] = (float)0.25;
	filter[20] = (float)0.25;
	filter[21] = (float)0.25;
	filter[22] = (float)0.25;
	filter[23] = (float)0.25;
	filter[24] = (float)0.25;
	elv_min = (float)0.33;
	elv_max = (float)0.51;
}

/*  
 *  Destroys the object and frees any allocated resources
 */
DigitalDlgImpl::~DigitalDlgImpl()
{
}

void DigitalDlgImpl::update_view()
{
	TTerrain *clone;

	clone = t_terrain_clone(terra);
	t_terrain_digital_filter(clone, filter, FLEN, elv_min, elv_max); 
	PreView->t_terrain_view_set_terrain(clone);
}

void DigitalDlgImpl::filter1Changed()
{
	filter[0] = filter_val_1->value();
}

void DigitalDlgImpl::filter2Changed()
{
	filter[1] = filter_val_2->value();
}

void DigitalDlgImpl::filter3Changed()
{
	filter[2] = filter_val_3->value();
}

void DigitalDlgImpl::filter4Changed()
{
	filter[3] = filter_val_4->value();
}

void DigitalDlgImpl::filter5Changed()
{
	filter[4] = filter_val_5->value();
}

void DigitalDlgImpl::filter6Changed()
{
	filter[5] = filter_val_6->value();
}

void DigitalDlgImpl::filter7Changed()
{
	filter[6] = filter_val_7->value();
}

void DigitalDlgImpl::filter8Changed()
{
	filter[7] = filter_val_8->value();
}

void DigitalDlgImpl::filter9Changed()
{
	filter[8] = filter_val_9->value();
}

void DigitalDlgImpl::filter10Changed()
{
	filter[9] = filter_val_10->value();
}

void DigitalDlgImpl::filter11Changed()
{
	filter[10] = filter_val_11->value();
}

void DigitalDlgImpl::filter12Changed()
{
	filter[11] = filter_val_12->value();
}

void DigitalDlgImpl::filter13Changed()
{
	filter[12] = filter_val_13->value();
}

void DigitalDlgImpl::filter14Changed()
{
	filter[13] = filter_val_14->value();
}

void DigitalDlgImpl::filter15Changed()
{
	filter[14] = filter_val_15->value();
}

void DigitalDlgImpl::filter16Changed()
{
	filter[15] = filter_val_16->value();
}

void DigitalDlgImpl::filter17Changed()
{
	filter[16] = filter_val_17->value();
}

void DigitalDlgImpl::filter18Changed()
{
	filter[17] = filter_val_18->value();
}

void DigitalDlgImpl::filter19Changed()
{
	filter[18] = filter_val_19->value();
}

void DigitalDlgImpl::filter20Changed()
{
	filter[19] = filter_val_20->value();
}

void DigitalDlgImpl::filter21Changed()
{
	filter[20] = filter_val_21->value();
}

void DigitalDlgImpl::filter22Changed()
{
	filter[21] = filter_val_22->value();
}

void DigitalDlgImpl::filter23Changed()
{
	filter[22] = filter_val_23->value();
}

void DigitalDlgImpl::filter24Changed()
{
	filter[23] = filter_val_24->value();
}

void DigitalDlgImpl::filter25Changed()
{
	filter[24] = filter_val_25->value();
}

void DigitalDlgImpl::setMinElev(int value)
{
	char buf[15];

	elv_min = (float)(value/100.0);
	sprintf(buf,"%1.2f", elv_min);
	slid1->setText((char *)buf);
}

void DigitalDlgImpl::setMaxElev(int value)
{
	char buf[15];

	elv_max = (float)(value/100.0);
	sprintf(buf,"%1.2f", elv_max);
	slid2->setText((char *)buf);
}
/***********************************************************************************************************************
 * Version history:
 *  * 03-12-2004
 *   - created
 *
 ***********************************************************************************************************************/