/***********************************************************************************************************************
 *  Projektname			: MicroTerra
 *  Filename			: mosaicdlgimpl.h
 *  Filetype			: C++-Source
 ***********************************************************************************************************************
 *  Modulename			: mosaicdlgimpl
 *  last changed		: 
 *  Author              : Peter J. vd Sluis
 *  Status:				: build
 *  
 *  Beschrijving        :
 *
 *  Export Funktions    :
 *
 *  ToDo                :
 *
 ***********************************************************************************************************************/
#ifndef MOSAICDLHIMPL_H
#define MOSAICDLHIMPL_H

/** ***************************************************************************************************************** **/
/** 				      HEADERS				                                                                      **/
/** ***************************************************************************************************************** **/

#include "MosaicDlg.h"
#include "tterrain.h"
#include <qspinbox.h>
#include <qlabel.h>

/** ***************************************************************************************************************** **/
/**				          PROTOTYPES				                                                                  **/
/** ***************************************************************************************************************** **/

class MosaicDlgImpl : public MosaicDlg
{ 
    Q_OBJECT

public:
    MosaicDlgImpl( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~MosaicDlgImpl();

	int X_size;
	int Y_size;

public slots:
	void xsizeChanged();
	void ysizeChanged();

protected:
	void update_preview();
};

#endif // MOSAICDLHIMPL_H
/***********************************************************************************************************************
 * Version history:
 *  * 04-12-2004
 *   - created
 *
 ***********************************************************************************************************************/