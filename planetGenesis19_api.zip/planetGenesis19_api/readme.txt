planetGenesis 1.9

New planetGenesis 1.9 features...

GUI changes

Reworked the drawing so that selected components are raised, and shadowed. Made the rest of the drawing consistent with the new positions.
The 3D preview was been reworked, and has a higher resolution mode and new keyboard controls. (Thanks to Sid D) 

New Noises.

ModifiedMultifractal - more Perlin variants that can create some very nice noise patterns. (Thanks to Colin Paddock)
All the Perlin noise engines, now have extra algorithms to play with Ridged, Billowy, Simplex, Ridged Simplex and Billowy Simplex.


New Functions - (Thanks to Colin Paddock)

Adjustments
Reciprocal
Complement
Logarithm
MultiFractalize
Musgrave MultiFractalize
Musgrave HetroFractalize
Musgrave HybridFractalize
Musgrave Ridged Fractalize
Noise Resize
Offset Scale
f(x) - curve based function

New PostProcess

Precipation


Here's the help stuff.

More detailed instructions can be found at...
http://planetgenesis.sourceforge.net/gui.html


Using planetGenesis is very simple. Most OS's will
now run Java software by double clicking on the 
java program. To run the program from the command line
cd to the directory with the jar file and type

java -jar planetGenesis.jar


Nearly forgot...on Win2000 there's a bug in Direct Draw with some graphic drivers.
If you get regular blue screens or reboots when trying pG...
a) swear at Microsoft for putting graphics stuff in the kernal
b) use the command line and try

java -Dsun.java2d.noddraw=true -jar planetGenesis.jar

a) will get you no where but is good for your karma.
b) should solve the problem.


Now for the Program instructions.
planetGenesis has a simple GUI that looks like a flow chart.

You can move each icon around by click and dragging it.
To join icons together you use shift click and drag.
To add, delete and change icons use the context menu which is 
right click or cmd-click or press and keep down a mouse button 
depending which OS you are using.

To choose what the program outputs, where it saves it
and to actually start the process use the context menu
on the terrain icon, which is the big empty circle
that you start off with.

The preview option requires Java3D to be installed.

Mac OSX
http://www.apple.com/downloads/macosx/apple/java3dandjavaadvancedimagingupdate.html

Linux
http://www.blackdown.org/java-linux/java2-status/java-3d-status.html

Windows and SPARC Solaris
http://java.sun.com/products/java-media/3D/download.html

For more other OS's try.
http://www.j3d.org/download.html


Dave 

